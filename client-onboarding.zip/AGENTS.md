# Onboard.ai Knowledge Base & System Guidance

This document captures the core architectural patterns, layout preferences, and workflow rules for the **Onboard.ai Institutional KYC & Client Onboarding Platform**.

---

## 1. Customer Portal & UI Layout Standards
- **Full-Width Portal Canvas**: The Customer Self-Service Portal (`CustomerDashboard.tsx`) is designed as a streamlined, full-width workspace (`max-w-7xl mx-auto`).
- **No Unsolicited Copilot Sidebars**: Do not embed persistent right-hand AI Copilot sidebars or guidance panels in the customer portal view unless explicitly requested. Keep the layout focused on onboarding progress, verification cards, and document management.

---

## 2. Interactive Document Verification & OCR Scanning
- **Key-Value Pair Extraction**: When a customer uploads or scans documents (e.g., Certificate of Incorporation, Board Resolution, Shareholder Register), present an interactive **On-Screen OCR Key-Value Verification Panel**.
- **Customer Editing**: Allow users to inspect, modify, add, or delete key-value pairs prior to submitting.
- **RM Notification Dispatch**: Submitting verified OCR document attributes must automatically trigger a system notification to the Relationship Manager (`SystemNotification`) with `actionRequired: true` and the embedded document details/OCR attributes.

---

## 3. RM Action Center & Autonomous Workflow Progression
- **Centralized Action Center**: The Notifications View serves as an actionable dashboard for Relationship Managers to review customer submissions, compliance flags, and OCR document key-value pairs.
- **Actionable Approvals**:
  - Approving an RM notification updates the notification state (`actioned: true`).
  - Automatically transitions the target client's node status (e.g., `doc_verification`) to `completed`.
  - Dynamically triggers autonomous workflow progression to subsequent steps in the onboarding lifecycle.
  - Generates transparent log entries documenting RM intervention and system node status updates.

---

## 4. Multi-Persona & State Persistence
- **Personas**:
  1. **Platform Admin**: System health, global agent topology, and telemetry.
  2. **Relationship Manager (RM)**: Client portfolio, Journey Workspace, Customer 360, and Notifications Action Center.
  3. **Compliance Specialist**: AML/PEP screening, adverse news audit, risk matrix.
  4. **Customer Portal**: Self-service onboarding, Singpass MyInfo sync, document vault, biometrics.
- **State Synchronization**: All client updates, notifications, and document verifications persist to `localStorage` (`onboarding_clients_v2`, `onboarding_system_notifications`) and sync reactively across all persona views.
