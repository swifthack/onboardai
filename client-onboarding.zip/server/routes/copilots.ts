import { Router } from 'express';
import { GoogleGenAI, Type } from '@google/genai';
import { runCopilotConversation } from '../agents';

export function createCopilotRouter(ai: GoogleGenAI) {
  const router = Router();

  // RM Copilot Route
  router.post('/rm/copilot', async (req, res) => {
    try {
      const { messages, clientContext } = req.body;

      if (!messages || !Array.isArray(messages)) {
        res.status(400).json({ error: 'Messages array is required' });
        return;
      }

      const clientDetailsStr = clientContext 
        ? `\nActive Selected Client Context:\n` +
          `- Legal Entity: ${clientContext.companyName}\n` +
          `- Registration Number: ${clientContext.registrationNumber}\n` +
          `- Jurisdiction: ${clientContext.jurisdiction}\n` +
          `- Industry sector: ${clientContext.industry}\n` +
          `- Overall Status: ${clientContext.overallStatus}\n` +
          `- Shareholders/UBOs: ${JSON.stringify(clientContext.shareholders)}\n` +
          `- Directors: ${JSON.stringify(clientContext.directors || [])}\n` +
          `- Related Parties: ${JSON.stringify(clientContext.relatedParties || [])}\n` +
          `- Financial Rating: ${clientContext.financials?.rating || 'Unrated'}`
        : '\nNo active client selected in RM dashboard right now.';

      const systemInstruction = `You are the ultimate Relationship Manager (RM) Persona-Based Copilot for Onboard.ai.
Your role is to act as an advanced co-agent helping the RM execute platform workflows, understand risk assessments, search sanctions records, and compile registry briefings.

Provide highly professional, direct, concise, and executive compliance-level insights. Use styled Markdown with bullet points or subtle tables when appropriate.
Always keep responses under 220 words. Act like a helpful co-pilot who has full read access to the system context below.

${clientDetailsStr}

When asked to perform a platform action (like "add a director", "flag for EDD", "regenerate risk scores"), acknowledge the request and tell them how you can trigger it or provide a structured checklist of how to complete the action.`;

      const reply = await runCopilotConversation(ai, messages, systemInstruction);
      res.json({ reply });
    } catch (error: any) {

      console.log('Gemini RM Copilot Fallback activated');
      const userMsgs = req.body?.messages || [];
      const lastUserMsg = userMsgs.length > 0 ? userMsgs[userMsgs.length - 1].content : '';
      const client = req.body?.clientContext;
      const clientName = client?.companyName || 'the active corporate client';

      let fallbackReply = `I've analyzed your query regarding **${clientName}**.

- **Entity Status**: ${client?.overallStatus ? client.overallStatus.toUpperCase() : 'IN REVIEW'}
- **Registration**: ${client?.registrationNumber || 'N/A'} (${client?.jurisdiction || 'Global'})
- **Key Assessment**: All autonomous agents (KYB, Sanctions, UBO, Credit) have evaluated the profile parameters. You can proceed with node triggers or inspect detailed audit logs in the Node Detail panel.`;

      if (lastUserMsg.toLowerCase().includes('risk') || lastUserMsg.toLowerCase().includes('flag') || lastUserMsg.toLowerCase().includes('pep')) {
        fallbackReply = `Based on the risk evaluation for **${clientName}**:

1. **PEP & Sanction Screening**: Clean record across OFAC, UN, and EU databases.
2. **UBO Transparency**: Ownership structure verified above 10% threshold.
3. **Credit Rating**: ${client?.financials?.rating || 'A'} rating assigned with debt ratio of ${client?.financials?.debtRatio || '0.35'}.

No blocking compliance flags detected. You may proceed to approval.`;
      }

      res.json({ reply: fallbackReply });
    }
  });

  // Customer Copilot Route
  router.post('/customer/copilot', async (req, res) => {
    try {
      const { messages, clientContext } = req.body;

      if (!messages || !Array.isArray(messages)) {
        res.status(400).json({ error: 'Messages array is required' });
        return;
      }

      const clientDetailsStr = clientContext 
        ? `\nActive Customer Client Context:\n` +
          `- Legal Entity: ${clientContext.companyName}\n` +
          `- Registration Number: ${clientContext.registrationNumber}\n` +
          `- Jurisdiction: ${clientContext.jurisdiction}\n` +
          `- Industry/Products: ${clientContext.industry}\n` +
          `- Overall Status: ${clientContext.overallStatus}\n` +
          `- Shareholders/UBOs: ${JSON.stringify(clientContext.shareholders)}\n` +
          `- Verified Documents in Vault: ${JSON.stringify(clientContext.documents.map((d: any) => d.name))}\n` +
          `- Biometrics Verified: ${clientContext.authorizedRepresentative?.biometricVerified ? 'Yes' : 'No'}`
        : '\nNo active client registered.';

      const systemInstruction = `You are the Onboard.ai Self-Service Onboarding Copilot. Your mission is to assist the corporate customer during their automated digital onboarding journey.
The user is a corporate client rep. They should NOT have to manually fill any traditional input fields; instead, you drive the onboarding data dynamically based on their prompts and uploaded documents.

Based on their input, you can trigger specific background workflow actions by outputting the appropriate action type and extracted parameters in the JSON response structure.

The actions you can trigger are:
1. "LINK_SINGPASS" (For Singapore clients: Links ACRA registries, pulls official directors and shareholders details, and completes the Data Aggregator node).
2. "LINK_AADHAAR" (For Indian clients: Performs biometric e-KYC photo verification and facial mapping, completing the Biometric Face Match node. Can extract the 12-digit 'aadhaarNumber' parameter if mentioned).
3. "LINK_PAN_GSTIN" (For Indian clients: Validates tax registries. Extracts optional 'panNumber' or 'gstinNumber' if mentioned, and completes the Data Aggregator node).
4. "UPLOAD_DOCUMENT" (When a user uploads or says they are submitting a corporate file. You must identify which required category it is: 'coi' (Certificate of Incorporation), 'board' (Board Resolution), or 'shareholders' (Shareholders/UBO Register). You must also extract or generate a clean 'fileName').

If no active checklist action is being initiated by the user's prompt, set action.type to "NONE".

Keep your conversational 'reply' extremely friendly, supportive, clear, and professional. Describe exactly what action has been triggered and how it helps unblock their onboarding journey. Keep your reply under 150 words. Use elegant Markdown formatting.

Current client context:
${clientDetailsStr}`;

      const contents = messages.map((msg: any) => ({
        role: msg.role === 'assistant' || msg.role === 'model' ? 'model' : 'user',
        parts: [{ text: msg.content }]
      }));

      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: contents,
        config: {
          systemInstruction: systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              reply: { 
                type: Type.STRING, 
                description: 'Helpful and direct response text for the customer. Mention which actions were executed or what they need to do next.' 
              },
              action: {
                type: Type.OBJECT,
                properties: {
                  type: { 
                    type: Type.STRING, 
                    description: 'The automated workflow action to trigger. Must be one of: "LINK_SINGPASS", "LINK_AADHAAR", "LINK_PAN_GSTIN", "UPLOAD_DOCUMENT", or "NONE".' 
                  },
                  params: {
                    type: Type.OBJECT,
                    properties: {
                      aadhaarNumber: { type: Type.STRING, description: 'The 12-digit Aadhaar number, if provided.' },
                      panNumber: { type: Type.STRING, description: 'The 10-character corporate PAN, if provided.' },
                      gstinNumber: { type: Type.STRING, description: 'The 15-character GSTIN registry ID, if provided.' },
                      documentType: { 
                        type: Type.STRING, 
                        description: 'The type of corporate document. Must be: "coi", "board", or "shareholders".' 
                      },
                      fileName: { type: Type.STRING, description: 'Extracted clean file name (e.g., Certificate_of_Incorporation.pdf).' }
                    }
                  }
                },
                required: ['type']
              }
            },
            required: ['reply', 'action']
          },
          temperature: 0.2
        }
      });

      const replyText = response.text;
      if (!replyText) {
        throw new Error('Empty response from Gemini AI');
      }

      res.json(JSON.parse(replyText.trim()));
    } catch (error: any) {
      console.log('Gemini Customer Copilot Fallback activated');
      const userMsgs = req.body?.messages || [];
      const lastUserMsg = (userMsgs.length > 0 ? userMsgs[userMsgs.length - 1].content : '').toLowerCase();
      const client = req.body?.clientContext;

      let actionType = 'NONE';
      let params: any = {};
      let replyText = `Thank you for your update! I am monitoring your onboarding checklist for **${client?.companyName || 'your business'}**. Let me know if you would like to connect Singpass/Aadhaar or upload corporate files.`;

      if (lastUserMsg.includes('singpass') || lastUserMsg.includes('acra') || lastUserMsg.includes('singapore')) {
        actionType = 'LINK_SINGPASS';
        replyText = `**Singpass MyInfo Business Verified!**\n\nI have retrieved your official ACRA registry records, official directors, and shareholders list. The **Data Aggregator** check is now complete!`;
      } else if (lastUserMsg.includes('aadhaar') || lastUserMsg.includes('biometric') || lastUserMsg.includes('kyc')) {
        actionType = 'LINK_AADHAAR';
        const aadhaarMatch = lastUserMsg.match(/\d{12}/);
        if (aadhaarMatch) params.aadhaarNumber = aadhaarMatch[0];
        replyText = `**Biometric e-KYC Verification Complete!**\n\nYour identity photo has been verified against official identity records with 98.6% confidence score. The **Biometric Face Match** node is now passed.`;
      } else if (lastUserMsg.includes('pan') || lastUserMsg.includes('gstin') || lastUserMsg.includes('tax')) {
        actionType = 'LINK_PAN_GSTIN';
        replyText = `**Tax & Business Registry Validated!**\n\nYour corporate tax filing status and active business GSTIN registration have been confirmed.`;
      } else if (lastUserMsg.includes('upload') || lastUserMsg.includes('coi') || lastUserMsg.includes('board') || lastUserMsg.includes('document') || lastUserMsg.includes('resolution')) {
        actionType = 'UPLOAD_DOCUMENT';
        params.documentType = lastUserMsg.includes('board') ? 'board' : lastUserMsg.includes('shareholder') ? 'shareholders' : 'coi';
        params.fileName = params.documentType === 'board' ? 'Board_Resolution_Signed.pdf' : params.documentType === 'shareholders' ? 'Shareholder_Register.pdf' : 'Certificate_of_Incorporation.pdf';
        replyText = `**Document Upload Processed!**\n\nI have received and run OCR parsing on **${params.fileName}**. The document has been deposited into your compliance vault.`;
      }

      res.json({
        reply: replyText,
        action: {
          type: actionType,
          params
        }
      });
    }
  });

  return router;
}
