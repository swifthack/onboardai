import { GoogleGenAI } from '@google/genai';
import { NODE_ANALYSIS_RESPONSE_SCHEMA, CopilotMessage } from '../schemas';

export async function analyzeOnboardingNode(
  ai: GoogleGenAI,
  client: Record<string, any>,
  nodeId: string,
  userPrompt?: string
) {
  const prompt = `
You are an expert autonomous compliance banking agent. Analyze the onboarding client's corporate profile specifically for the workflow node: "${nodeId}".

Client Corporate Profile:
- Company Name: ${client.companyName}
- Registration Number: ${client.registrationNumber}
- Jurisdiction: ${client.jurisdiction}
- Industry: ${client.industry}
- Authorized Representative: ${client.authorizedRepresentative?.name || 'N/A'} (${client.authorizedRepresentative?.role || 'N/A'})
- Shareholders: ${JSON.stringify(client.shareholders)}
- Financials: ${JSON.stringify(client.financials)}
- Uploaded Documents: ${JSON.stringify(client.documents?.map((d: any) => ({ name: d.name, type: d.type })) || [])}

Specific Node to Analyze: "${nodeId}"
User-Provided Overrides/Instructions: ${userPrompt || 'None'}

Please perform a rigorous review. Determine if there are high compliance flags or if it can be approved.
For metrics, provide 3 key KPIs or scores matching this node's scope as key-value pairs (e.g., 'Risk Level': 'LOW', 'UBO Confidence': '98%').
For logs, provide 3-4 realistic audit-trail actions that your autonomous team executed during the review.
`;

  const response = await ai.models.generateContent({
    model: 'gemini-3.6-flash',
    contents: prompt,
    config: {
      responseMimeType: 'application/json',
      responseSchema: NODE_ANALYSIS_RESPONSE_SCHEMA,
      temperature: 0.2
    }
  });

  const text = response.text;
  if (!text) {
    throw new Error('Empty response from Gemini AI model');
  }

  return JSON.parse(text.trim());
}

export async function runCopilotConversation(
  ai: GoogleGenAI,
  messages: CopilotMessage[],
  systemInstruction: string
) {
  const contents = messages.map((msg) => ({
    role: msg.role === 'assistant' || msg.role === 'model' ? 'model' : 'user',
    parts: [{ text: msg.content }]
  }));

  const response = await ai.models.generateContent({
    model: 'gemini-3.6-flash',
    contents: contents,
    config: {
      systemInstruction: systemInstruction,
      temperature: 0.7
    }
  });

  return response.text || "I apologize, but I couldn't generate a response.";
}
