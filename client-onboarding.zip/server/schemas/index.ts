import { Type } from '@google/genai';

export const NODE_ANALYSIS_RESPONSE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    status: {
      type: Type.STRING,
      description: 'Whether the node is approved and completed, or has high compliance flags and is flagged.'
    },
    summary: {
      type: Type.STRING,
      description: 'Professional summary of findings.'
    },
    metrics: {
      type: Type.OBJECT,
      description: '3 key performance metrics or indicators for this assessment.'
    },
    findings: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: 'Specific points of analysis or risks identified.'
    },
    logs: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: 'System actions taken by this agent team during processing.'
    }
  },
  required: ['status', 'summary', 'metrics', 'findings', 'logs']
};

export interface CopilotMessage {
  role: 'user' | 'assistant' | 'model' | 'system';
  content: string;
}

export interface CopilotRequestBody {
  messages: CopilotMessage[];
  clientContext?: Record<string, any>;
}
