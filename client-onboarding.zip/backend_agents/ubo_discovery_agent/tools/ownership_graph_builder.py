from typing import Dict, Any, List

def build_ownership_tree(entity_name: str) -> Dict[str, Any]:
    """Constructs ownership tree across holding companies and offshore trusts."""
    return {
        "entity": entity_name,
        "direct_shareholders": [
            {"name": "ACME HOLDINGS LIMITED (BVI)", "share": 60.0, "jurisdiction": "BVI"},
            {"name": "TAN WEI MING", "share": 40.0, "jurisdiction": "SG"}
        ],
        "ultimate_beneficial_owners": [
            {"name": "JOHNATHAN DOE", "effective_share": 36.0, "nationality": "US", "is_ubo": True},
            {"name": "TAN WEI MING", "effective_share": 40.0, "nationality": "SG", "is_ubo": True}
        ]
    }
