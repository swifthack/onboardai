import json
from agent.orchestrator import UBODiscoveryOrchestrator

def main():
    orchestrator = UBODiscoveryOrchestrator()
    result = orchestrator.discover_ubos("ACME GLOBAL PTE LTD")
    print("=== UBO DISCOVERY AGENT RESULT ===")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
