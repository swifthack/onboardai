from typing import Dict, Any
from ..tools.ownership_graph_builder import build_ownership_tree
from ..config.thresholds import UBO_THRESHOLD_PERCENTAGE

class UBODiscoveryOrchestrator:
    def discover_ubos(self, entity_name: str) -> Dict[str, Any]:
        tree = build_ownership_tree(entity_name)
        ubos = [u for u in tree["ultimate_beneficial_owners"] if u["effective_share"] >= UBO_THRESHOLD_PERCENTAGE]

        return {
            "entity": entity_name,
            "threshold_applied": f"{UBO_THRESHOLD_PERCENTAGE}%",
            "identified_ubos": ubos,
            "ownership_tree": tree
        }
