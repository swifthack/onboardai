from typing import Dict, Any
from ..tools.multi_source_connector import aggregate_data_feeds

class DataAggregationOrchestrator:
    def collect_external_intelligence(self, company_id: str) -> Dict[str, Any]:
        feeds = aggregate_data_feeds(company_id)
        return {
            "company_id": company_id,
            "aggregated_intelligence": feeds
        }
