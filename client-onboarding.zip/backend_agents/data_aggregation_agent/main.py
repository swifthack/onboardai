import json
from agent.orchestrator import DataAggregationOrchestrator

def main():
    orchestrator = DataAggregationOrchestrator()
    result = orchestrator.collect_external_intelligence("COMP-99120")
    print("=== DATA AGGREGATION AGENT RESULT ===")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
