from enum import Enum

class MatchLevel(str, Enum):
    CLEAR = "CLEAR"
    POTENTIAL_MATCH = "POTENTIAL_MATCH"
    EXACT_MATCH = "EXACT_MATCH"

class DispositionStatus(str, Enum):
    AUTO_CLEARED = "AUTO_CLEARED"
    ESCALATED_TO_OFFICER = "ESCALATED_TO_OFFICER"
    CONFIRMED_HIT = "CONFIRMED_HIT"
    FALSE_POSITIVE = "FALSE_POSITIVE"

class RiskLevel(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"
