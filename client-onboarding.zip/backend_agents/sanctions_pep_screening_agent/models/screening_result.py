from dataclasses import dataclass
from typing import List, Dict, Any
from .enums import MatchLevel, DispositionStatus, RiskLevel

@dataclass
class ScreeningResult:
    case_id: str
    overall_risk: RiskLevel
    disposition: DispositionStatus
    match_score: float
    sanctions_hits: List[Dict[str, Any]]
    pep_hits: List[Dict[str, Any]]
    adverse_media_hits: List[Dict[str, Any]]
    audit_rationale: str
