from dataclasses import dataclass, field
from typing import List, Optional

@dataclass
class ScreeningCase:
    case_id: str
    entity_name: str
    jurisdiction: str
    registration_number: Optional[str] = None
    directors: List[str] = field(default_factory=list)
    ubos: List[str] = field(default_factory=list)
