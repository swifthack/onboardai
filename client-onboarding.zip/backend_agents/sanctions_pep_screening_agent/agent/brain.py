from typing import Dict, Any, List
from .prompt import SYSTEM_PROMPT

class Brain:
    """LLM interface wrapper for Sanctions Reasoning."""
    
    def synthesize_screening_rationale(
        self, 
        entity_name: str, 
        sanctions_hits: List[Dict[str, Any]], 
        pep_hits: List[Dict[str, Any]], 
        media_hits: List[Dict[str, Any]]
    ) -> str:
        # In production this calls Gemini model API
        if sanctions_hits:
            top_hit = sanctions_hits[0]
            return f"Entity '{entity_name}' triggered potential sanctions match with {top_hit['list']} (Match score: {top_hit['match_score']}%). Manual compliance officer sign-off required."
        elif pep_hits:
            return f"Entity '{entity_name}' matched PEP records for role '{pep_hits[0]['role']}'. Enhanced Due Diligence (EDD) triggered."
        else:
            return f"Entity '{entity_name}' cleared sanctions, PEP, and adverse media databases with zero high-confidence hits."
