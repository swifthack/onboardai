from typing import Dict, Any

def validate_input(case_data: Dict[str, Any]) -> bool:
    if not case_data.get("entity_name"):
        raise ValueError("Guardrail Error: entity_name is required for screening.")
    return True

def validate_output(result: Dict[str, Any]) -> bool:
    required_keys = ["overall_risk", "disposition", "match_score", "audit_rationale"]
    for key in required_keys:
        if key not in result:
            raise ValueError(f"Guardrail Error: Missing required output key '{key}'")
    return True
