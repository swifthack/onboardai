from typing import Dict, Any
from ..tools.sanctions_search import search_sanctions
from ..tools.pep_lookup import search_pep
from ..tools.adverse_media_crawler import crawl_adverse_media
from .brain import Brain
from .guardrails import validate_input, validate_output
from ..config.thresholds import FUZZY_NAME_MATCH_THRESHOLD, ESCALATION_MATCH_THRESHOLD
from ..models.enums import RiskLevel, DispositionStatus

class SanctionsOrchestrator:
    def __init__(self):
        self.brain = Brain()

    def run_screening(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        validate_input(payload)
        entity_name = payload["entity_name"]

        sanctions_hits = search_sanctions(entity_name)
        pep_hits = search_pep(entity_name)
        media_hits = crawl_adverse_media(entity_name)

        max_score = max([h["match_score"] for h in sanctions_hits] + [0.0])

        if max_score >= FUZZY_NAME_MATCH_THRESHOLD:
            disposition = DispositionStatus.CONFIRMED_HIT
            risk = RiskLevel.CRITICAL
        elif max_score >= ESCALATION_MATCH_THRESHOLD:
            disposition = DispositionStatus.ESCALATED_TO_OFFICER
            risk = RiskLevel.HIGH
        else:
            disposition = DispositionStatus.AUTO_CLEARED
            risk = RiskLevel.LOW

        rationale = self.brain.synthesize_screening_rationale(entity_name, sanctions_hits, pep_hits, media_hits)

        output = {
            "overall_risk": risk.value,
            "disposition": disposition.value,
            "match_score": max_score,
            "sanctions_hits": sanctions_hits,
            "pep_hits": pep_hits,
            "adverse_media_hits": media_hits,
            "audit_rationale": rationale
        }
        validate_output(output)
        return output
