import logging
import json
from datetime import datetime

class SanctionsAuditLogger:
    def __init__(self):
        self.logger = logging.getLogger("SanctionsAudit")

    def log(self, event_type: str, data: dict):
        entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "event": event_type,
            "data": data
        }
        print(f"[AUDIT LOG] {json.dumps(entry)}")
