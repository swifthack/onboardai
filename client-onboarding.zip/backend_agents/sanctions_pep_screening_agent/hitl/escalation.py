from typing import Dict, Any

def trigger_officer_escalation(case_id: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    """Human-In-The-Loop escalation hook for ambiguous screening matches (75%-85%)."""
    return {
        "status": "PENDING_OFFICER_REVIEW",
        "case_id": case_id,
        "assigned_queue": "Compliance_L2_Review",
        "reason": f"Fuzzy match score of {payload.get('match_score')}% requires human disposition.",
        "payload": payload
    }
