import json
from agent.orchestrator import SanctionsOrchestrator
from audit.logger import SanctionsAuditLogger

def main():
    logger = SanctionsAuditLogger()
    orchestrator = SanctionsOrchestrator()

    sample_case = {
        "entity_name": "ACME INTERNATIONAL HOLDINGS",
        "jurisdiction": "SG"
    }

    logger.log("START_SCREENING", sample_case)
    result = orchestrator.run_screening(sample_case)
    logger.log("END_SCREENING", result)

    print("\n=== SCREENING AGENT RESULT ===")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
