from typing import List, Dict, Any

class VectorStore:
    """Mock Vector Database storing past compliance screening rationales for semantic similarity lookups."""
    def __init__(self):
        self.store = []

    def store_rationale(self, case_id: str, text: str, embedding: List[float] = None):
        self.store.append({"case_id": case_id, "text": text})

    def search_similar_rationales(self, query: str, top_k: int = 3) -> List[Dict[str, Any]]:
        return self.store[:top_k]
