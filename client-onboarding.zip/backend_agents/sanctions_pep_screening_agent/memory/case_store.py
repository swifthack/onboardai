from typing import Dict, Any, Optional

class CaseStore:
    """Structured Case Database repository."""
    def __init__(self):
        self._cases: Dict[str, Dict[str, Any]] = {}

    def save_case(self, case_id: str, case_data: Dict[str, Any]):
        self._cases[case_id] = case_data

    def get_case(self, case_id: str) -> Optional[Dict[str, Any]]:
        return self._cases.get(case_id)
