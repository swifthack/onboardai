import difflib
from typing import List, Dict, Any

MOCK_SANCTIONS_LIST = [
    {"name": "NORTH KOREA WEAPONS TRADING CORP", "list": "OFAC SDN", "country": "KP", "id": "SDN-1092"},
    {"name": "SYRIAN ENERGY HOLDINGS", "list": "EU SANCTIONS", "country": "SY", "id": "EU-4021"},
    {"name": "VALERY PETROV", "list": "UK SANCTIONS", "country": "RU", "id": "UK-8821"},
]

def search_sanctions(name: str) -> List[Dict[str, Any]]:
    results = []
    for item in MOCK_SANCTIONS_LIST:
        ratio = difflib.SequenceMatcher(None, name.upper(), item["name"]).ratio() * 100
        if ratio >= 60.0:
            results.append({**item, "match_score": round(ratio, 2)})
    return results
