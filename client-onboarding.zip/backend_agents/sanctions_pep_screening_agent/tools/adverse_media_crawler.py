from typing import List, Dict, Any

def crawl_adverse_media(entity_name: str) -> List[Dict[str, Any]]:
    # Simulated search for bribery, fraud, tax evasion
    return [
        {
            "headline": f"Investigation into regulatory compliance at {entity_name}",
            "snippet": f"Authorities review past financial records of {entity_name} regarding trade reporting.",
            "sentiment_score": -0.45,
            "source": "Global Financial News"
        }
    ]
