import difflib
from typing import List, Dict, Any

MOCK_PEP_DATABASE = [
    {"name": "ALEXANDER ORLOV", "role": "Deputy Minister of Energy", "country": "RU", "tier": 1},
    {"name": "TAN WEI MING", "role": "Member of Parliament", "country": "SG", "tier": 2},
]

def search_pep(name: str) -> List[Dict[str, Any]]:
    hits = []
    for pep in MOCK_PEP_DATABASE:
        ratio = difflib.SequenceMatcher(None, name.upper(), pep["name"]).ratio() * 100
        if ratio >= 65.0:
            hits.append({**pep, "match_score": round(ratio, 2)})
    return hits
