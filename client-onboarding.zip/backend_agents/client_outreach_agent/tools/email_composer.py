from typing import Dict, Any

def compose_onboarding_email(company_name: str, recipient_name: str, missing_docs: list) -> Dict[str, str]:
    docs_str = ", ".join(missing_docs) if missing_docs else "Corporate Certificate & Identity Verifications"
    return {
        "subject": f"Action Required: Complete Secure Corporate Onboarding for {company_name}",
        "body": f"Hello {recipient_name},\n\nOur Relationship Management team at Onboard.ai Bank has initiated your digital onboarding journey for '{company_name}'.\n\nPlease submit the required onboarding items ({docs_str}) via our secure portal.\n\nBest regards,\nOnboard.ai Client Outreach Team"
    }
