import json
from agent.orchestrator import ClientOutreachOrchestrator

def main():
    orchestrator = ClientOutreachOrchestrator()
    result = orchestrator.draft_and_dispatch_outreach("ACME GLOBAL PTE LTD", "Johnathan Doe", "j.doe@acmeglobal.com")
    print("=== CLIENT OUTREACH AGENT RESULT ===")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
