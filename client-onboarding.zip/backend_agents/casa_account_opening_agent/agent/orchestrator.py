from typing import Dict, Any
from ..tools.core_banking_provisioner import provision_flexcube_account

class CasaAccountOpeningOrchestrator:
    def open_accounts(self, company_name: str, currencies: list) -> Dict[str, Any]:
        result = provision_flexcube_account(company_name, currencies)
        return {
            "entity": company_name,
            "onboarding_account_package": result
        }
