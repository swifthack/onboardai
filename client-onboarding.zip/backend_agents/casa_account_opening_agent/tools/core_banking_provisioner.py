from typing import Dict, Any, List

def provision_flexcube_account(company_name: str, currencies: List[str]) -> Dict[str, Any]:
    """Interfaces with Oracle FLEXCUBE / Core Ledger to provision accounts & IBANs."""
    accounts = {}
    for idx, curr in enumerate(currencies):
        accounts[curr] = f"8810-9012-{idx+1001}-{curr}"
    return {
        "status": "PROVISIONED",
        "primary_account_no": accounts.get("USD", "8810-9012-1001-USD"),
        "sub_accounts": accounts,
        "swift_bic": "ONBDSSGSXXX"
    }
