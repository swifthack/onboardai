import json
from agent.orchestrator import CasaAccountOpeningOrchestrator

def main():
    orchestrator = CasaAccountOpeningOrchestrator()
    result = orchestrator.open_accounts("ACME GLOBAL PTE LTD", ["USD", "SGD", "EUR", "GBP"])
    print("=== CASA ACCOUNT OPENING AGENT RESULT ===")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
