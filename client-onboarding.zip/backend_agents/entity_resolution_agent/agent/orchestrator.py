from typing import Dict, Any
from ..tools.record_deduplicator import standardize_address, find_duplicate_profiles

class EntityResolutionOrchestrator:
    def resolve_entity(self, company_name: str, address: str, tax_id: str) -> Dict[str, Any]:
        clean_addr = standardize_address(address)
        dups = find_duplicate_profiles(company_name, tax_id)

        return {
            "entity_name": company_name,
            "standardized_address": clean_addr,
            "is_duplicate_profile": dups["existing_cif_found"],
            "action": "CREATE_NEW_CIF" if not dups["existing_cif_found"] else "LINK_EXISTING_CIF"
        }
