import json
from agent.orchestrator import EntityResolutionOrchestrator

def main():
    orchestrator = EntityResolutionOrchestrator()
    result = orchestrator.resolve_entity("ACME GLOBAL PTE LTD", "8 Marina Blvd, Singapore", "202012345K")
    print("=== ENTITY RESOLUTION AGENT RESULT ===")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
