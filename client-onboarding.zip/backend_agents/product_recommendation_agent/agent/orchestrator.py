from typing import Dict, Any
from ..tools.product_catalog_matcher import match_banking_products

class ProductRecommendationOrchestrator:
    def generate_recommendations(self, client_profile: Dict[str, Any]) -> Dict[str, Any]:
        matched = match_banking_products(
            turnover_usd=client_profile.get("annual_turnover_usd", 10000000.0),
            risk_tier=client_profile.get("risk_tier", "LOW"),
            primary_currencies=client_profile.get("currencies", ["USD", "SGD", "EUR"])
        )
        return {
            "client_name": client_profile.get("company_name", "ACME GLOBAL PTE LTD"),
            "recommended_package": "Enterprise Treasury Tier 1",
            "eligible_products": matched
        }
