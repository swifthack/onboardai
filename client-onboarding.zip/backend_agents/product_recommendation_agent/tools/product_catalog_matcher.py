from typing import Dict, Any, List

def match_banking_products(turnover_usd: float, risk_tier: str, primary_currencies: List[str]) -> List[Dict[str, Any]]:
    products = [
        {"product_id": "CASA-MULTI-CURR", "name": "Global Treasury Multi-Currency Operating Account", "currencies": primary_currencies},
        {"product_id": "FX-AUTO-SWEEP", "name": "Automated Yield Sweep & FX Hedging Facility", "min_turnover": 1000000}
    ]
    if turnover_usd >= 5000000 and risk_tier == "LOW":
        products.append({"product_id": "CREDIT-LINE-WORKING-CAP", "name": "Unsecured Corporate Working Capital Line", "limit_usd": 1500000})
    return products
