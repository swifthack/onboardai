import json
from agent.orchestrator import ProductRecommendationOrchestrator

def main():
    orchestrator = ProductRecommendationOrchestrator()
    profile = {"company_name": "ACME GLOBAL PTE LTD", "annual_turnover_usd": 12000000.0, "risk_tier": "LOW", "currencies": ["USD", "SGD", "EUR"]}
    result = orchestrator.generate_recommendations(profile)
    print("=== PRODUCT RECOMMENDATION AGENT RESULT ===")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
