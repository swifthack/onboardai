from typing import Dict, Any

def extract_key_fields(raw_ocr_text: str) -> Dict[str, Any]:
    """Parses raw text to extract key corporate entity fields."""
    return {
        "company_name": "ACME GLOBAL PTE LTD",
        "registration_number": "202012345K",
        "incorporation_date": "2020-01-15",
        "registered_address": "8 Marina Boulevard, #28-01, Singapore 018981"
    }
