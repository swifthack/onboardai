from typing import Dict, Any, List

def cross_verify_documents(extracted_fields: Dict[str, Any], registry_fields: Dict[str, Any]) -> List[str]:
    discrepancies = []
    if extracted_fields.get("registration_number") != registry_fields.get("registration_number"):
        discrepancies.append(f"Registration number mismatch: Doc ({extracted_fields.get('registration_number')}) vs Registry ({registry_fields.get('registration_number')})")
    return discrepancies
