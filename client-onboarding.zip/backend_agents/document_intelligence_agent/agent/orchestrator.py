from typing import Dict, Any
from ..tools.ocr_engine import process_image_ocr
from ..tools.extractor import extract_key_fields
from ..tools.cross_verifier import cross_verify_documents

class DocumentOrchestrator:
    def process_document(self, file_path: str, expected_registry: Dict[str, Any]) -> Dict[str, Any]:
        ocr = process_image_ocr(file_path)
        extracted = extract_key_fields(ocr["text_raw"])
        discrepancies = cross_verify_documents(extracted, expected_registry)

        return {
            "doc_id": "DOC-9921",
            "ocr_confidence": ocr["mean_confidence"],
            "extracted_fields": extracted,
            "discrepancies": discrepancies,
            "passed": len(discrepancies) == 0
        }
