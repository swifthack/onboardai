from dataclasses import dataclass
from typing import Dict, Any, List

@dataclass
class DocumentVerificationResult:
    doc_id: str
    doc_type: str
    confidence_score: float
    extracted_fields: Dict[str, Any]
    cross_validation_passed: bool
    discrepancies: List[str]
    audit_summary: str
