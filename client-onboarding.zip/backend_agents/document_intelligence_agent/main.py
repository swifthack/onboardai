import json
from agent.orchestrator import DocumentOrchestrator

def main():
    orchestrator = DocumentOrchestrator()
    sample_registry = {"registration_number": "202012345K", "company_name": "ACME GLOBAL PTE LTD"}
    result = orchestrator.process_document("sample_certificate.pdf", sample_registry)
    print("=== DOCUMENT INTELLIGENCE AGENT RESULT ===")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
