import json
from agent.orchestrator import RiskScoringOrchestrator

def main():
    orchestrator = RiskScoringOrchestrator()
    sample = {"case_id": "CASE-8802", "jurisdiction_risk": "LOW", "industry_risk": "MEDIUM", "pep_presence": False}
    result = orchestrator.evaluate_case_risk(sample)
    print("=== RISK SCORING AGENT RESULT ===")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
