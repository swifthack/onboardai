from typing import Dict, Any

def compute_composite_risk_score(
    sanctions_risk: str,
    jurisdiction_risk: str,
    industry_risk: str,
    pep_presence: bool
) -> Dict[str, Any]:
    """Calculates weighted risk score based on Basel AML & Wolfsberg Group framework."""
    base = 15.0
    if jurisdiction_risk == "HIGH": base += 35.0
    if industry_risk == "HIGH": base += 20.0
    if pep_presence: base += 25.0

    tier = "LOW" if base < 30 else ("MEDIUM" if base < 60 else "HIGH")
    return {
        "composite_score": min(base, 100.0),
        "risk_tier": tier,
        "edd_required": tier == "HIGH"
    }
