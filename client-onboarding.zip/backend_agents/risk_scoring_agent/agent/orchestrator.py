from typing import Dict, Any
from ..tools.risk_matrix_calculator import compute_composite_risk_score

class RiskScoringOrchestrator:
    def evaluate_case_risk(self, case_payload: Dict[str, Any]) -> Dict[str, Any]:
        result = compute_composite_risk_score(
            sanctions_risk=case_payload.get("sanctions_risk", "CLEAR"),
            jurisdiction_risk=case_payload.get("jurisdiction_risk", "LOW"),
            industry_risk=case_payload.get("industry_risk", "MEDIUM"),
            pep_presence=case_payload.get("pep_presence", False)
        )
        return {
            "case_id": case_payload.get("case_id", "CASE-1001"),
            "risk_scorecard": result
        }
