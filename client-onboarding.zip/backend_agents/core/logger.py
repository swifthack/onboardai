import logging
import json
from datetime import datetime
from typing import Any, Dict

class AuditLogger:
    """Centralized Audit Logger for all compliance agents."""
    
    def __init__(self, agent_name: str):
        self.agent_name = agent_name
        self.logger = logging.getLogger(agent_name)
        logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")

    def log_step(self, step_name: str, payload: Dict[str, Any], status: str = "SUCCESS"):
        record = {
            "timestamp": datetime.utcnow().isoformat(),
            "agent": self.agent_name,
            "step": step_name,
            "status": status,
            "payload": payload
        }
        self.logger.info(json.dumps(record))
        return record
