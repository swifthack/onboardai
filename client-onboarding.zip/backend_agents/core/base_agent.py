from abc import ABC, abstractmethod
from typing import Any, Dict

class BaseAgent(ABC):
    """Abstract Base Class for all Autonomous Compliance Agents."""
    
    def __init__(self, name: str, version: str = "1.0.0"):
        self.name = name
        self.version = version

    @abstractmethod
    def run(self, case_id: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Execute agent workflow on a given onboarding case."""
        pass
