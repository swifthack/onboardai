from enum import Enum

class KycStatus(str, Enum):
    APPROVED = "APPROVED"
    REFER_TO_OFFICER = "REFER_TO_OFFICER"
    REJECTED = "REJECTED"

class LivenessResult(str, Enum):
    PASSED = "PASSED"
    FAILED = "FAILED"
    SUSPECTED_SPOOF = "SUSPECTED_SPOOF"
