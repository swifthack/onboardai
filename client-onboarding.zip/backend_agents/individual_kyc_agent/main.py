import json
from agent.orchestrator import IndividualKycOrchestrator

def main():
    orchestrator = IndividualKycOrchestrator()
    result = orchestrator.verify_individual("selfie.jpg", "passport.jpg")
    print("=== INDIVIDUAL KYC AGENT RESULT ===")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
