from typing import Dict, Any
from ..tools.facial_matcher import verify_liveness_video, match_facial_coordinates
from ..models.enums import KycStatus

class IndividualKycOrchestrator:
    def verify_individual(self, selfie_url: str, passport_photo_url: str) -> Dict[str, Any]:
        liveness = verify_liveness_video("s3://bucket/selfie.mp4")
        match_score = match_facial_coordinates(selfie_url, passport_photo_url)

        status = KycStatus.APPROVED if (liveness["liveness_passed"] and match_score >= 90.0) else KycStatus.REFER_TO_OFFICER

        return {
            "kyc_status": status.value,
            "biometric_match_score": match_score,
            "liveness_details": liveness,
            "recommendation": "AUTO_APPROVE" if status == KycStatus.APPROVED else "MANUAL_REVIEW"
        }
