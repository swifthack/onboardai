import json
from agent.orchestrator import FraudAMLOrchestrator

def main():
    orchestrator = FraudAMLOrchestrator()
    result = orchestrator.monitor_aml_risk("ACME GLOBAL PTE LTD")
    print("=== FRAUD & AML AGENT RESULT ===")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
