from typing import Dict, Any
from ..tools.acra_api import lookup_acra_singapore
from ..tools.companies_house_api import lookup_companies_house_uk

class CorporateRegistryOrchestrator:
    def verify_entity(self, registration_no: str, jurisdiction: str) -> Dict[str, Any]:
        if jurisdiction.upper() in ["SG", "SINGAPORE"]:
            data = lookup_acra_singapore(registration_no)
        else:
            data = lookup_companies_house_uk(registration_no)

        is_active = "LIVE" in data.get("status", "").upper() or "ACTIVE" in data.get("company_status", "").upper()
        return {
            "entity_verified": True,
            "is_active_operating": is_active,
            "registry_data": data
        }
