from typing import Dict, Any

def lookup_acra_singapore(registration_no: str) -> Dict[str, Any]:
    """Connects to ACRA API gateway (Bizfile)."""
    return {
        "registry": "ACRA Singapore",
        "company_name": "ACME GLOBAL PTE LTD",
        "status": "LIVE / LIVE COMPANY",
        "incorporation_date": "2020-01-15",
        "paid_up_capital": "1,000,000 SGD",
        "registered_address": "8 Marina Boulevard, #28-01, Singapore 018981",
        "officers": [
            {"name": "Johnathan Doe", "role": "Director"},
            {"name": "Sarah Chen", "role": "Secretary"}
        ]
    }
