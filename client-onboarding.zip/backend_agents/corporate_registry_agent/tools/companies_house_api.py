from typing import Dict, Any

def lookup_companies_house_uk(company_number: str) -> Dict[str, Any]:
    """Connects to UK Companies House API."""
    return {
        "registry": "Companies House UK",
        "company_number": company_number,
        "company_status": "active",
        "jurisdiction": "england_wales"
    }
