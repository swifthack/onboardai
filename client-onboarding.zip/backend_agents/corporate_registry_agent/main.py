import json
from agent.orchestrator import CorporateRegistryOrchestrator

def main():
    orchestrator = CorporateRegistryOrchestrator()
    result = orchestrator.verify_entity("202012345K", "SG")
    print("=== CORPORATE REGISTRY AGENT RESULT ===")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
