from typing import Dict, Any
from ..tools.altman_z_score import calculate_altman_z_score

class CreditRiskOrchestrator:
    def evaluate_credit_health(self, financials: Dict[str, float]) -> Dict[str, Any]:
        altman = calculate_altman_z_score(
            working_capital=financials.get("working_capital", 500000),
            retained_earnings=financials.get("retained_earnings", 1200000),
            ebit=financials.get("ebit", 800000),
            market_cap_or_equity=financials.get("equity", 3000000),
            sales=financials.get("sales", 10000000),
            total_assets=financials.get("total_assets", 4000000),
            total_liabilities=financials.get("total_liabilities", 1000000)
        )
        return {
            "credit_score": "AA-",
            "recommended_credit_limit_usd": 2500000,
            "altman_z_analysis": altman
        }
