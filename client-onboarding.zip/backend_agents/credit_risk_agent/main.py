import json
from agent.orchestrator import CreditRiskOrchestrator

def main():
    orchestrator = CreditRiskOrchestrator()
    sample_financials = {
        "working_capital": 600000,
        "retained_earnings": 1500000,
        "ebit": 900000,
        "equity": 3500000,
        "sales": 12000000,
        "total_assets": 5000000,
        "total_liabilities": 1500000
    }
    result = orchestrator.evaluate_credit_health(sample_financials)
    print("=== CREDIT RISK AGENT RESULT ===")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
