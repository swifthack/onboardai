from typing import Dict, Any

def calculate_altman_z_score(
    working_capital: float,
    retained_earnings: float,
    ebit: float,
    market_cap_or_equity: float,
    sales: float,
    total_assets: float,
    total_liabilities: float
) -> Dict[str, Any]:
    """Calculates Altman Z-Score for non-manufacturing corporate bankruptcy prediction."""
    if total_assets == 0 or total_liabilities == 0:
        return {"z_score": 0.0, "zone": "DISTRESS"}

    X1 = working_capital / total_assets
    X2 = retained_earnings / total_assets
    X3 = ebit / total_assets
    X4 = market_cap_or_equity / total_liabilities
    X5 = sales / total_assets

    z = 1.2 * X1 + 1.4 * X2 + 3.3 * X3 + 0.6 * X4 + 0.999 * X5

    if z > 2.99:
        zone = "SAFE_ZONE"
    elif z >= 1.81:
        zone = "GREY_ZONE"
    else:
        zone = "DISTRESS_ZONE"

    return {"z_score": round(z, 2), "zone": zone}
