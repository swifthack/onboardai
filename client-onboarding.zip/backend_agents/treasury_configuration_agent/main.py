import json
from agent.orchestrator import TreasuryConfigurationOrchestrator

def main():
    orchestrator = TreasuryConfigurationOrchestrator()
    result = orchestrator.configure_treasury("8810-9012-1001-USD", 5000000.0)
    print("=== TREASURY CONFIGURATION AGENT RESULT ===")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
