from typing import Dict, Any

def configure_fx_limits(account_id: str, daily_fx_cap_usd: float) -> Dict[str, Any]:
    """Configures real-time FX trading limits & automated sweep triggers on Calypso Engine."""
    return {
        "calypso_desk_id": f"DESK-{account_id[-4:]}",
        "fx_daily_limit_approved": daily_fx_cap_usd,
        "auto_sweep_margin_pct": 0.25,
        "status": "DESK_ACTIVE"
    }
