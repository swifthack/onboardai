from typing import Dict, Any
from ..tools.fx_hedging_desk import configure_fx_limits

class TreasuryConfigurationOrchestrator:
    def configure_treasury(self, account_id: str, cap_usd: float) -> Dict[str, Any]:
        desk_config = configure_fx_limits(account_id, cap_usd)
        return {
            "account_id": account_id,
            "treasury_setup": desk_config
        }
