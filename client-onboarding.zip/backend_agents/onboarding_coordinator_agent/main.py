import json
from agent.orchestrator import OnboardingCoordinatorOrchestrator

def main():
    orchestrator = OnboardingCoordinatorOrchestrator()
    result = orchestrator.coordinate_case("CASE-2026-901", "INTAKE")
    print("=== ONBOARDING COORDINATOR AGENT RESULT ===")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
