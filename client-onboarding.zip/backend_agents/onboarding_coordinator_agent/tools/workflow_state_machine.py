from typing import Dict, Any, List

def advance_onboarding_stage(case_id: str, completed_stage: str) -> Dict[str, Any]:
    stages = ["INTAKE", "PARALLEL_REGISTRY_PARSING", "RISK_UNDERWRITING", "PRODUCT_PROVISIONING", "COMPLETED"]
    curr_idx = stages.index(completed_stage) if completed_stage in stages else 0
    next_stage = stages[curr_idx + 1] if curr_idx + 1 < len(stages) else "COMPLETED"

    return {
        "case_id": case_id,
        "previous_stage": completed_stage,
        "current_stage": next_stage,
        "workflow_completed": next_stage == "COMPLETED"
    }
