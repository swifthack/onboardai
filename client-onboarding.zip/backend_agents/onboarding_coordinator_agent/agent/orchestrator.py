from typing import Dict, Any
from ..tools.workflow_state_machine import advance_onboarding_stage

class OnboardingCoordinatorOrchestrator:
    def coordinate_case(self, case_id: str, current_stage: str) -> Dict[str, Any]:
        workflow_state = advance_onboarding_stage(case_id, current_stage)
        return {
            "case_id": case_id,
            "coordination_status": workflow_state
        }
