import json
from agent.orchestrator import TaxComplianceOrchestrator

def main():
    orchestrator = TaxComplianceOrchestrator()
    sample_entity = {"company_name": "ACME GLOBAL PTE LTD", "jurisdiction": "SG", "is_us_person": False, "passive_income_over_50pct": False}
    result = orchestrator.evaluate_tax_status(sample_entity)
    print("=== TAX COMPLIANCE AGENT RESULT ===")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
