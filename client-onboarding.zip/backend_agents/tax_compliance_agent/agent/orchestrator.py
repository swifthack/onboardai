from typing import Dict, Any
from ..tools.fatca_classifier import classify_fatca_status

class TaxComplianceOrchestrator:
    def evaluate_tax_status(self, entity_data: Dict[str, Any]) -> Dict[str, Any]:
        fatca_status = classify_fatca_status(
            jurisdiction=entity_data.get("jurisdiction", "SG"),
            is_us_person=entity_data.get("is_us_person", False),
            produces_passive_income=entity_data.get("passive_income_over_50pct", False)
        )
        return {
            "entity": entity_data.get("company_name"),
            "fatca_classification": fatca_status,
            "crs_reportable": fatca_status == "PASSIVE_NFFE",
            "form_w8_required": "W-8BEN-E"
        }
