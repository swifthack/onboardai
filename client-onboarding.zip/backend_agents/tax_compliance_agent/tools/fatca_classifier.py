from typing import Dict, Any

def classify_fatca_status(jurisdiction: str, is_us_person: bool, produces_passive_income: bool) -> str:
    """Classifies entity into FATCA categories (Active NFFE, Passive NFFE, FFI, US Person)."""
    if is_us_person:
        return "SPECIFIED_US_PERSON"
    elif produces_passive_income:
        return "PASSIVE_NFFE"
    else:
        return "ACTIVE_NFFE"
