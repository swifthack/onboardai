---
name: onboarding-system
description: Guidelines, knowledge base, and workflows for Onboard.ai institutional onboarding, OCR document verification, customer portal layouts, and RM action notification centers.
---

# Onboard.ai System Skill & Knowledge Base

Use this skill when modifying or extending features for the Onboard.ai Institutional KYC & Client Onboarding system.

## Key Architecture & Design Patterns

### 1. Customer Portal Layout
- Keep the Customer Portal clean and full-width.
- Do not render persistent side copilot panels or guidance bars in the customer view unless requested.

### 2. Document OCR & Verification Workflow
- When documents are uploaded or scanned, open the interactive on-screen OCR Key-Value panel.
- Customers verify/edit key-value pairs before dispatching to RM.
- Generate a system notification (`SystemNotification`) with `actionRequired: true` attached to the client ID.

### 3. RM Action & Notification Center
- RMs view pending notifications with extracted document attributes in `NotificationsView`.
- Clicking "Approve & Proceed to Next Step":
  1. Sets notification `actioned: true`.
  2. Updates target client's workflow node (`doc_verification`) to `completed`.
  3. Advances the next pending node in sequence.
  4. Appends explicit audit log messages to the node's `logs` array.

### 4. Data State & Types
- Types defined in `/src/types.ts`: `ClientProfile`, `WorkflowNode`, `UploadedDocument`, `SystemNotification`.
- Persistent local storage keys: `onboarding_clients_v2`, `onboarding_system_notifications`.
