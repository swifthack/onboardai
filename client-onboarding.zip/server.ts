import express from 'express';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

import { createOnboardingRouter } from './server/routes/onboarding';
import { createCopilotRouter } from './server/routes/copilots';
import { createAdminRouter } from './server/routes/admin';
import { createBlockchainRouter } from './server/routes/blockchain';
import { createRegistryRouter } from './server/routes/registry';
import { createSanctionsRouter } from './server/routes/sanctions';

// Load environment variables
dotenv.config();

// Initialize the modern GenAI SDK
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
    timeout: 30000 // 30 seconds timeout to prevent long gateway stalls
  }
});

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Mount Modular API Routers
app.use('/api/onboarding', createOnboardingRouter(ai));
app.use('/api', createCopilotRouter(ai));
app.use('/api/admin', createAdminRouter(ai));
app.use('/api/blockchain', createBlockchainRouter());
app.use('/api/registry', createRegistryRouter());
app.use('/api/sanctions', createSanctionsRouter());

// Serve health route
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date() });
});

// Vite Middleware Configuration for Dev / Static Asset Server for Production
async function setupServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
    console.log('Dev server initialized with Vite middleware.');
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
    console.log('Production server initialized serving /dist folder.');
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Express custom server running on http://localhost:${PORT}`);
  });
}

setupServer().catch((err) => {
  console.error('Failed to initialize server:', err);
});
