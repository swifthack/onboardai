/**
 * Tool Schemas and MCP Tool Definitions
 * Provides JSON Schemas and TypeScript interfaces for agent tool calls and MCP integration.
 */

export interface ToolParameterSchema {
  type: string;
  description?: string;
  enum?: string[];
  properties?: Record<string, ToolParameterSchema>;
  required?: string[];
  items?: ToolParameterSchema;
  default?: any;
}

export interface ToolDefinition {
  name: string;
  description: string;
  category: 'blockchain' | 'registry' | 'sanctions' | 'kyc' | 'kyb' | 'underwriting' | 'mcp';
  parameters: {
    type: 'object';
    properties: Record<string, ToolParameterSchema>;
    required?: string[];
  };
  mcpServerEndpoint?: string;
}

// Global System Tool Schemas
export const BLOCKCHAIN_VERIFY_TOOL_SCHEMA: ToolDefinition = {
  name: 'verify_evm_wallet',
  description: 'Queries live public RPC nodes to retrieve EVM address balance, contract status, tx count, and sanction status.',
  category: 'blockchain',
  parameters: {
    type: 'object',
    properties: {
      address: {
        type: 'string',
        description: '42-character EVM hex address starting with 0x'
      }
    },
    required: ['address']
  }
};

export const REGISTRY_LOOKUP_TOOL_SCHEMA: ToolDefinition = {
  name: 'lookup_entity_registry',
  description: 'Queries official GLEIF LEI registers and SEC EDGAR APIs for corporate legal status and CIK identifiers.',
  category: 'registry',
  parameters: {
    type: 'object',
    properties: {
      query: {
        type: 'string',
        description: 'Legal company name or 20-character LEI string'
      },
      type: {
        type: 'string',
        enum: ['lei', 'name', 'cik'],
        description: 'Lookup filter type'
      }
    },
    required: ['query']
  }
};

export const SANCTIONS_SCREENING_TOOL_SCHEMA: ToolDefinition = {
  name: 'screen_sanctions_pep',
  description: 'Performs global screening against UN, OFAC SDN, EU Consolidated, and HMT Treasury lists via OpenSanctions feeds.',
  category: 'sanctions',
  parameters: {
    type: 'object',
    properties: {
      query: {
        type: 'string',
        description: 'Individual person name or entity title to screen'
      }
    },
    required: ['query']
  }
};

export const MCP_TOOL_SCHEMAS: Record<string, ToolDefinition> = {
  verify_evm_wallet: BLOCKCHAIN_VERIFY_TOOL_SCHEMA,
  lookup_entity_registry: REGISTRY_LOOKUP_TOOL_SCHEMA,
  screen_sanctions_pep: SANCTIONS_SCREENING_TOOL_SCHEMA
};
