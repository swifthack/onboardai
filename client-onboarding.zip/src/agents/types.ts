/**
 * Agent and Orchestration Type Definitions
 */

export interface GuardrailsConfig {
  inputGuardrails: {
    piiMasking: boolean;
    profanityFilter: boolean;
    sqlInjectionPrevention: boolean;
    allowedLanguages: string[];
  };
  promptGuardrails: {
    jailbreakProtection: boolean;
    systemPromptEnforcement: boolean;
    maxPromptTokens: number;
  };
  retrievalGuardrails: {
    minRelevanceScore: number;
    maxRetrievalDocuments: number;
    vectorSearchFilter: string;
  };
  toolGuardrails: {
    approvedToolsOnly: boolean;
    sandboxedExecution: boolean;
    requireApprovalForDestructive: boolean;
  };
  outputGuardrails: {
    pciDssCompliance: boolean;
    hallucinationCheck: boolean;
    regexEnforcement: string;
  };
  runtimeGuardrails: {
    maxConcurrency: number;
    fallbackAgentId: string;
    alertOnAnomaly: boolean;
  };
  memoryGuardrails: {
    shortTermMemoryLimit: number;
    vectorMemoryEnabled: boolean;
    dataRetentionDays: number;
  };
  tokenomicsTimeout: {
    maxTokensPerCall: number;
    dailySpendLimitUsd: number;
    timeoutMs: number;
  };
}

export interface OrchestrationAgent {
  id: string;
  name: string;
  description: string;
  category: string;
  isEnabled: boolean;
  agentClass: 'super' | 'normal';
  usesGoogleProtocol: boolean;
  nodeType?: 'agent' | 'mcp' | 'api' | 'email' | 'database';
  apiEndpoint?: string;
  httpMethod?: 'GET' | 'POST' | 'PUT' | 'DELETE';
  emailRecipient?: string;
  emailSubject?: string;
  dbTable?: string;
  mcpServerUrl?: string;
  mcpApis?: string[];
  mcpConnectedSources?: string[];
  subAgents?: string[];
  icon?: string;
  position?: { x: number; y: number };
  version?: string;
  owner?: string;
  model?: string;
  riskLevel?: 'Low' | 'Medium' | 'High';
  status?: 'Active' | 'Deprecated' | 'Draft';
  lastUpdated?: string;
  inputSchema?: string;
  outputSchema?: string;
  canBeAskedBy?: string[];
  canAsk?: string[];
  metrics?: {
    avgLatency: string;
    successRate: string;
    avgCost: string;
    sparklineData: number[];
  };
  guardrails?: GuardrailsConfig;
}

export interface HybridStage {
  id: string;
  name: string;
  executionMode: 'parallel' | 'sequential';
  agentIds: string[];
}

export interface AgentOrchestration {
  id: string;
  name: string;
  description: string;
  type?: 'corporate' | 'funds' | 'custom';
  agentIds?: string[];
  connections?: { from: string; to: string }[];
  strategy?: 'sequential' | 'parallel' | 'hub_and_spoke' | 'hybrid';
  hybridStages?: HybridStage[];
  stages?: HybridStage[];
}

