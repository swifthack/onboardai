import { useState, useCallback } from 'react';
import { ClientProfile, UploadedDocument, WorkflowNode, NodeStatus } from '../types';
import { MOCK_CLIENTS } from '../mockData';

export function useClients() {
  const [clients, setClients] = useState<ClientProfile[]>(MOCK_CLIENTS);
  const [selectedClientId, setSelectedClientId] = useState<string>(MOCK_CLIENTS[0].id);

  const activeClient = clients.find(c => c.id === selectedClientId) || clients[0] || null;

  const handleUpdateClient = useCallback((updatedClient: ClientProfile) => {
    setClients(prev => prev.map(c => c.id === updatedClient.id ? updatedClient : c));
  }, []);

  const handleAddClient = useCallback((newClient: ClientProfile) => {
    setClients(prev => [newClient, ...prev]);
    setSelectedClientId(newClient.id);
  }, []);

  const handleAddDocument = useCallback((doc: UploadedDocument, clientId?: string) => {
    const targetId = clientId || selectedClientId;
    setClients(prev => prev.map(c => {
      if (c.id !== targetId) return c;
      return {
        ...c,
        documents: [doc, ...c.documents]
      };
    }));
  }, [selectedClientId]);

  const handleDeleteDocument = useCallback((docId: string, clientId?: string) => {
    const targetId = clientId || selectedClientId;
    setClients(prev => prev.map(c => {
      if (c.id !== targetId) return c;
      return {
        ...c,
        documents: c.documents.filter(d => d.id !== docId)
      };
    }));
  }, [selectedClientId]);

  const handleResetClients = useCallback(() => {
    setClients(MOCK_CLIENTS);
    setSelectedClientId(MOCK_CLIENTS[0].id);
  }, []);

  return {
    clients,
    setClients,
    selectedClientId,
    setSelectedClientId,
    activeClient,
    handleUpdateClient,
    handleAddClient,
    handleAddDocument,
    handleDeleteDocument,
    handleResetClients
  };
}
