import React, { useState, useCallback } from 'react';
import { ClientProfile, WorkflowNode, NodeStatus, UploadedDocument } from '../types';
import { apiService } from '../services/apiService';
import { evaluateNodeWithLocalRules } from '../utils/rulesEngine';

interface UseWorkflowProps {
  clients: ClientProfile[];
  setClients: React.Dispatch<React.SetStateAction<ClientProfile[]>>;
  selectedClientId: string;
  handleAddDocument: (doc: UploadedDocument, clientId?: string) => void;
}

export function useWorkflow({
  clients,
  setClients,
  selectedClientId,
  handleAddDocument
}: UseWorkflowProps) {
  const [activeRunningNodeId, setActiveRunningNodeId] = useState<string | undefined>(undefined);

  const handleUpdateNode = useCallback((
    nodeId: string, 
    updates: Partial<WorkflowNode>, 
    targetClientId?: string
  ) => {
    const targetId = targetClientId || selectedClientId;
    setClients(prev => prev.map(c => {
      if (c.id !== targetId) return c;
      const updatedNodes = c.workflowNodes.map(node => {
        if (node.id === nodeId) {
          return {
            ...node,
            ...updates,
            lastUpdated: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          };
        }
        return node;
      });

      // Recalculate overall status based on nodes
      let overallStatus = c.overallStatus;
      const allCompleted = updatedNodes.every(n => n.status === 'completed');
      const hasFlagged = updatedNodes.some(n => n.status === 'flagged');

      if (hasFlagged) {
        overallStatus = 'in_progress';
      } else if (allCompleted) {
        overallStatus = 'approved';
      } else if (updatedNodes.some(n => n.status === 'running' || n.status === 'completed')) {
        overallStatus = 'in_progress';
      }

      return {
        ...c,
        workflowNodes: updatedNodes,
        overallStatus
      };
    }));
  }, [selectedClientId, setClients]);

  const handleRunAutonomousNode = useCallback(async (nodeId: string, targetClientId?: string): Promise<boolean> => {
    const targetId = targetClientId || selectedClientId;
    const currentTarget = clients.find(c => c.id === targetId);
    if (!currentTarget) return false;

    setActiveRunningNodeId(nodeId);

    // Set status to running
    handleUpdateNode(nodeId, {
      status: 'running',
      logs: ['Triggering autonomous module sequence...', 'Connecting securely to global compliance data pools...']
    }, targetId);

    const maxRetries = 3;
    const initialBackoffMs = 1000;
    let attempt = 0;
    let apiSuccess = false;
    let data: any = null;
    const retryLogs: string[] = [];

    while (attempt < maxRetries && !apiSuccess) {
      try {
        data = await apiService.analyzeNode({
          client: currentTarget,
          nodeId
        });
        apiSuccess = true;
      } catch (err: any) {
        attempt++;
        if (attempt < maxRetries) {
          const backoffMs = initialBackoffMs * Math.pow(2, attempt - 1);
          const retryLog = `⚠️ [Retry ${attempt}/${maxRetries}] Connection/API error (${err.message || 'Server error'}). Retrying node '${nodeId}' after exponential backoff (${backoffMs}ms)...`;
          retryLogs.push(retryLog);

          handleUpdateNode(nodeId, {
            status: 'running',
            logs: ['Triggering autonomous module sequence...', ...retryLogs]
          }, targetId);

          await new Promise(res => setTimeout(res, backoffMs));
        } else {
          break;
        }
      }
    }

    if (apiSuccess && data) {
      handleUpdateNode(nodeId, {
        status: data.status as NodeStatus,
        logs: [
          'Triggering autonomous module sequence...',
          'Connecting securely to global compliance data pools...',
          ...retryLogs,
          ...data.logs
        ],
        results: {
          summary: data.summary,
          metrics: data.metrics,
          findings: data.findings
        }
      }, targetId);

      setActiveRunningNodeId(undefined);
      return data.status === 'completed';
    }

    // Fallback to local rules evaluation
    console.warn(`Gemini server unavailable after retry attempts. Executing local rules engine for node: ${nodeId}`);
    const localResult = evaluateNodeWithLocalRules(nodeId, currentTarget);

    if (localResult.autoDocument) {
      handleAddDocument(localResult.autoDocument, targetId);
    }

    handleUpdateNode(nodeId, {
      status: localResult.status,
      logs: [
        'Triggering backup rules processor...',
        ...retryLogs,
        ...localResult.logs
      ],
      results: {
        summary: localResult.summary,
        metrics: localResult.metrics,
        findings: localResult.findings
      }
    }, targetId);

    setActiveRunningNodeId(undefined);
    return localResult.status === 'completed';
  }, [clients, selectedClientId, handleUpdateNode, handleAddDocument]);

  const handleNodeAutoExecute = useCallback(async (targetClientId?: string) => {
    const targetId = targetClientId || selectedClientId;
    const currentTarget = clients.find(c => c.id === targetId);
    if (!currentTarget) return;

    // Find pending nodes whose dependencies are satisfied
    const pendingNodes = currentTarget.workflowNodes.filter(n => {
      if (n.status !== 'pending') return false;
      if (n.dependsOn.length === 0) return true;
      return n.dependsOn.every(depId => {
        const depNode = currentTarget.workflowNodes.find(dn => dn.id === depId);
        return depNode?.status === 'completed';
      });
    });

    for (const node of pendingNodes) {
      await handleRunAutonomousNode(node.id, targetId);
    }
  }, [clients, selectedClientId, handleRunAutonomousNode]);

  return {
    activeRunningNodeId,
    handleUpdateNode,
    handleRunAutonomousNode,
    handleNodeAutoExecute
  };
}
