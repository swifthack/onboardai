import { Journey, JourneyStage } from '../components/common/PersonaSubviews';
import { OrchestrationAgent } from '../types';

export interface BpmnNodeInfo {
  id: string;
  name: string;
  type: 'startEvent' | 'endEvent' | 'serviceTask' | 'userTask' | 'sendTask' | 'receiveTask' | 'parallelGateway' | 'exclusiveGateway' | 'subProcess';
  laneId: 'Lane_RM' | 'Lane_AI_Agents' | 'Lane_Compliance' | 'Lane_Provisioning';
  x: number;
  y: number;
  width: number;
  height: number;
  stageRef?: JourneyStage;
  agentRefs?: string[];
  description?: string;
}

export interface BpmnFlowInfo {
  id: string;
  sourceRef: string;
  targetRef: string;
  name?: string;
  condition?: string;
}

/**
 * Escapes special XML characters to prevent malformed XML.
 */
function escapeXml(unsafe: string = ''): string {
  return unsafe
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

/**
 * Determines the swimlane assignment based on the stage's domain, agents, and name.
 */
function getStageLane(stage: JourneyStage): 'Lane_RM' | 'Lane_AI_Agents' | 'Lane_Compliance' | 'Lane_Provisioning' {
  const upperName = (stage.name || '').toUpperCase();
  const desc = (stage.description || '').toUpperCase();
  const agents = (stage.attachedAgentIds || []).join(' ').toUpperCase();

  if (
    upperName.includes('PROSPECT') ||
    upperName.includes('OUTREACH') ||
    upperName.includes('LEAD') ||
    agents.includes('CLIENT_OUTREACH') ||
    agents.includes('LEAD_INTELLIGENCE')
  ) {
    return 'Lane_RM';
  }

  if (
    upperName.includes('SCREENING') ||
    upperName.includes('RISK') ||
    upperName.includes('COMPLIANCE') ||
    upperName.includes('APPROVAL') ||
    upperName.includes('REVIEW') ||
    stage.transitionRule === 'approval_gate' ||
    agents.includes('APPROVAL_GATEWAY') ||
    agents.includes('SANCTIONS') ||
    agents.includes('RISK_ASSESSMENT')
  ) {
    return 'Lane_Compliance';
  }

  if (
    upperName.includes('PROVISION') ||
    upperName.includes('TRADE') ||
    upperName.includes('RTT') ||
    upperName.includes('ACCOUNT') ||
    agents.includes('PROVISIONING') ||
    agents.includes('RTT_VALIDATION')
  ) {
    return 'Lane_Provisioning';
  }

  return 'Lane_AI_Agents';
}

/**
 * Y-axis center coordinate for each lane.
 */
const LANE_Y_CENTERS = {
  Lane_RM: 140,
  Lane_AI_Agents: 320,
  Lane_Compliance: 530,
  Lane_Provisioning: 720,
};

/**
 * Generates standards-compliant BPMN 2.0 XML with complete BPMNDI layout information
 * from any Onboarding Journey model.
 */
export function generateJourneyBpmnXml(
  journey: Journey,
  availableAgents: OrchestrationAgent[] = []
): string {
  const journeyId = (journey.id || 'journey_default').replace(/[^a-zA-Z0-9_]/g, '_');
  const safeJourneyName = escapeXml(journey.name || 'Client Onboarding Journey');
  const stages = journey.stages || [];

  const nodes: BpmnNodeInfo[] = [];
  const flows: BpmnFlowInfo[] = [];

  let currentX = 220;
  const startY = LANE_Y_CENTERS.Lane_RM - 18;

  // 1. Start Event
  const startEventId = `StartEvent_${journeyId}`;
  nodes.push({
    id: startEventId,
    name: 'Client Onboarding Initiated',
    type: 'startEvent',
    laneId: 'Lane_RM',
    x: currentX,
    y: startY,
    width: 36,
    height: 36,
    description: 'Onboarding request captured via CRM or Customer Self-Service Portal'
  });

  currentX += 100;
  let lastNodeId = startEventId;
  let flowCounter = 1;

  // 2. Iterate through Stages
  stages.forEach((stage, stageIdx) => {
    const rawStageId = stage.id || `stage_${stageIdx + 1}`;
    const safeStageId = rawStageId.replace(/[^a-zA-Z0-9_]/g, '_');
    const laneId = getStageLane(stage);
    const stageYCenter = LANE_Y_CENTERS[laneId];
    const isParallel = stage.executionMode === 'parallel' && (stage.attachedAgentIds?.length || 0) > 1;

    if (isParallel) {
      // Split Gateway (AND)
      const splitGwId = `Gateway_Split_${safeStageId}`;
      nodes.push({
        id: splitGwId,
        name: `Parallel Split: ${stage.name}`,
        type: 'parallelGateway',
        laneId,
        x: currentX,
        y: stageYCenter - 25,
        width: 50,
        height: 50,
        description: 'Parallel Agent Fan-Out Execution'
      });

      flows.push({
        id: `Flow_${flowCounter++}`,
        sourceRef: lastNodeId,
        targetRef: splitGwId
      });

      currentX += 110;

      // Create parallel branch tasks for sub-agents or pipelines
      const agentIds = stage.attachedAgentIds || [];
      const branchTaskIds: string[] = [];
      const branchCount = Math.min(agentIds.length, 3);

      for (let i = 0; i < branchCount; i++) {
        const agId = agentIds[i];
        const agentObj = availableAgents.find(a => a.id === agId);
        const taskName = agentObj?.name || agId.replace(/_/g, ' ').toUpperCase();
        const taskId = `Task_${safeStageId}_branch_${i + 1}`;
        const yOffset = (i - (branchCount - 1) / 2) * 95;

        nodes.push({
          id: taskId,
          name: taskName,
          type: 'serviceTask',
          laneId,
          x: currentX,
          y: stageYCenter - 40 + yOffset,
          width: 140,
          height: 80,
          stageRef: stage,
          agentRefs: [agId],
          description: agentObj?.description || stage.description
        });

        flows.push({
          id: `Flow_${flowCounter++}`,
          sourceRef: splitGwId,
          targetRef: taskId
        });

        branchTaskIds.push(taskId);
      }

      currentX += 180;

      // Join Gateway (AND)
      const joinGwId = `Gateway_Join_${safeStageId}`;
      nodes.push({
        id: joinGwId,
        name: `Parallel Join: ${stage.name}`,
        type: 'parallelGateway',
        laneId,
        x: currentX,
        y: stageYCenter - 25,
        width: 50,
        height: 50,
        description: 'Synchronize Parallel Branches'
      });

      branchTaskIds.forEach(bId => {
        flows.push({
          id: `Flow_${flowCounter++}`,
          sourceRef: bId,
          targetRef: joinGwId
        });
      });

      lastNodeId = joinGwId;
      currentX += 110;
    } else {
      // Single Stage Task
      const taskId = `Activity_${safeStageId}`;
      let taskType: BpmnNodeInfo['type'] = 'serviceTask';

      if (stage.transitionRule === 'approval_gate') {
        taskType = 'userTask';
      } else if (stage.name.includes('OUTREACH') || stage.name.includes('DOCUMENT COLLECTION')) {
        taskType = 'sendTask';
      }

      nodes.push({
        id: taskId,
        name: stage.name,
        type: taskType,
        laneId,
        x: currentX,
        y: stageYCenter - 40,
        width: 150,
        height: 80,
        stageRef: stage,
        agentRefs: stage.attachedAgentIds,
        description: stage.description
      });

      flows.push({
        id: `Flow_${flowCounter++}`,
        sourceRef: lastNodeId,
        targetRef: taskId
      });

      lastNodeId = taskId;
      currentX += 180;

      // If transition rule is risk_check or approval_gate, add an Exclusive Gateway decision
      if (stage.transitionRule === 'risk_check' || stage.transitionRule === 'approval_gate') {
        const gwId = `Gateway_Decision_${safeStageId}`;
        const gwName = stage.transitionRule === 'risk_check' ? 'Risk & Sanctions Clearance?' : 'Compliance Approved?';
        
        nodes.push({
          id: gwId,
          name: gwName,
          type: 'exclusiveGateway',
          laneId,
          x: currentX,
          y: stageYCenter - 25,
          width: 50,
          height: 50,
          description: 'Automated policy threshold evaluation'
        });

        flows.push({
          id: `Flow_${flowCounter++}`,
          sourceRef: lastNodeId,
          targetRef: gwId,
          name: 'Evaluate Gate'
        });

        lastNodeId = gwId;
        currentX += 110;
      }
    }
  });

  // 3. End Event
  const endEventId = `EndEvent_${journeyId}`;
  nodes.push({
    id: endEventId,
    name: 'Client Onboarding Complete (Active & Ready to Trade)',
    type: 'endEvent',
    laneId: 'Lane_Provisioning',
    x: currentX,
    y: LANE_Y_CENTERS.Lane_Provisioning - 18,
    width: 36,
    height: 36,
    description: 'Entity active in core banking and trading systems'
  });

  flows.push({
    id: `Flow_${flowCounter++}`,
    sourceRef: lastNodeId,
    targetRef: endEventId,
    name: 'Finalize Lifecycle'
  });

  // Calculate pool total width
  const totalPoolWidth = Math.max(1600, currentX + 160);

  // Swimlanes definitions
  const laneRM = nodes.filter(n => n.laneId === 'Lane_RM');
  const laneAI = nodes.filter(n => n.laneId === 'Lane_AI_Agents');
  const laneComp = nodes.filter(n => n.laneId === 'Lane_Compliance');
  const laneProv = nodes.filter(n => n.laneId === 'Lane_Provisioning');

  // Build XML string
  return `<?xml version="1.0" encoding="UTF-8"?>
<bpmn:definitions 
  xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" 
  xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" 
  xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" 
  xmlns:di="http://www.omg.org/spec/DD/20100524/DI" 
  xmlns:camunda="http://camunda.org/schema/1.0/bpmn"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
  id="Definitions_Onboarding_${journeyId}" 
  targetNamespace="http://bpmn.io/schema/bpmn" 
  exporter="Onboard.ai BPMN 2.0 Studio" 
  exporterVersion="2.4.0">

  <bpmn:collaboration id="Collaboration_${journeyId}">
    <bpmn:participant id="Participant_${journeyId}" name="${safeJourneyName}" processRef="Process_${journeyId}" />
  </bpmn:collaboration>

  <bpmn:process id="Process_${journeyId}" name="${safeJourneyName}" isExecutable="true">
    <bpmn:documentation>${escapeXml(journey.description || 'Institutional Client Onboarding Lifecycle')}</bpmn:documentation>
    
    <bpmn:laneSet id="LaneSet_${journeyId}">
      <bpmn:lane id="Lane_RM" name="Relationship Management &amp; Client Outreach">
        ${laneRM.map(n => `<bpmn:flowNodeRef>${n.id}</bpmn:flowNodeRef>`).join('\n        ')}
      </bpmn:lane>
      <bpmn:lane id="Lane_AI_Agents" name="Autonomous AI Agent Swarm &amp; Data Verification">
        ${laneAI.map(n => `<bpmn:flowNodeRef>${n.id}</bpmn:flowNodeRef>`).join('\n        ')}
      </bpmn:lane>
      <bpmn:lane id="Lane_Compliance" name="Senior Compliance, Sanctions &amp; Risk Policy Gates">
        ${laneComp.map(n => `<bpmn:flowNodeRef>${n.id}</bpmn:flowNodeRef>`).join('\n        ')}
      </bpmn:lane>
      <bpmn:lane id="Lane_Provisioning" name="Product Provisioning &amp; Core Banking Integration">
        ${laneProv.map(n => `<bpmn:flowNodeRef>${n.id}</bpmn:flowNodeRef>`).join('\n        ')}
      </bpmn:lane>
    </bpmn:laneSet>

    <!-- Flow Nodes -->
${nodes.map(node => {
  const safeName = escapeXml(node.name);
  const safeDoc = escapeXml(node.description || '');
  const agentTags = (node.agentRefs || []).map(a => `<camunda:property name="agent" value="${escapeXml(a)}" />`).join('\n          ');
  const extElements = node.agentRefs?.length ? `
      <bpmn:extensionElements>
        <camunda:properties>
          ${agentTags}
        </camunda:properties>
      </bpmn:extensionElements>` : '';

  switch (node.type) {
    case 'startEvent':
      return `    <bpmn:startEvent id="${node.id}" name="${safeName}">
      <bpmn:documentation>${safeDoc}</bpmn:documentation>
    </bpmn:startEvent>`;
    case 'endEvent':
      return `    <bpmn:endEvent id="${node.id}" name="${safeName}">
      <bpmn:documentation>${safeDoc}</bpmn:documentation>
    </bpmn:endEvent>`;
    case 'serviceTask':
      return `    <bpmn:serviceTask id="${node.id}" name="${safeName}" camunda:type="external" camunda:topic="agent_task">${extElements}
      <bpmn:documentation>${safeDoc}</bpmn:documentation>
    </bpmn:serviceTask>`;
    case 'userTask':
      return `    <bpmn:userTask id="${node.id}" name="${safeName}" camunda:candidateGroups="COMPLIANCE_OFFICERS">${extElements}
      <bpmn:documentation>${safeDoc}</bpmn:documentation>
    </bpmn:userTask>`;
    case 'sendTask':
      return `    <bpmn:sendTask id="${node.id}" name="${safeName}">${extElements}
      <bpmn:documentation>${safeDoc}</bpmn:documentation>
    </bpmn:sendTask>`;
    case 'receiveTask':
      return `    <bpmn:receiveTask id="${node.id}" name="${safeName}">${extElements}
      <bpmn:documentation>${safeDoc}</bpmn:documentation>
    </bpmn:receiveTask>`;
    case 'parallelGateway':
      return `    <bpmn:parallelGateway id="${node.id}" name="${safeName}">
      <bpmn:documentation>${safeDoc}</bpmn:documentation>
    </bpmn:parallelGateway>`;
    case 'exclusiveGateway':
      return `    <bpmn:exclusiveGateway id="${node.id}" name="${safeName}">
      <bpmn:documentation>${safeDoc}</bpmn:documentation>
    </bpmn:exclusiveGateway>`;
    default:
      return `    <bpmn:task id="${node.id}" name="${safeName}">
      <bpmn:documentation>${safeDoc}</bpmn:documentation>
    </bpmn:task>`;
  }
}).join('\n')}

    <!-- Sequence Flows -->
${flows.map(flow => {
  const nameAttr = flow.name ? ` name="${escapeXml(flow.name)}"` : '';
  return `    <bpmn:sequenceFlow id="${flow.id}" sourceRef="${flow.sourceRef}" targetRef="${flow.targetRef}"${nameAttr} />`;
}).join('\n')}

  </bpmn:process>

  <!-- Diagram Visual Interchange (BPMNDI) -->
  <bpmndi:BPMNDiagram id="BPMNDiagram_${journeyId}">
    <bpmndi:BPMNPlane id="BPMNPlane_${journeyId}" bpmnElement="Collaboration_${journeyId}">
      
      <!-- Collaboration Participant Pool -->
      <bpmndi:BPMNShape id="Participant_${journeyId}_di" bpmnElement="Participant_${journeyId}" isHorizontal="true">
        <dc:Bounds x="120" y="40" width="${totalPoolWidth}" height="760" />
      </bpmndi:BPMNShape>

      <!-- Swimlanes -->
      <bpmndi:BPMNShape id="Lane_RM_di" bpmnElement="Lane_RM" isHorizontal="true">
        <dc:Bounds x="150" y="40" width="${totalPoolWidth - 30}" height="180" />
      </bpmndi:BPMNShape>
      
      <bpmndi:BPMNShape id="Lane_AI_Agents_di" bpmnElement="Lane_AI_Agents" isHorizontal="true">
        <dc:Bounds x="150" y="220" width="${totalPoolWidth - 30}" height="200" />
      </bpmndi:BPMNShape>

      <bpmndi:BPMNShape id="Lane_Compliance_di" bpmnElement="Lane_Compliance" isHorizontal="true">
        <dc:Bounds x="150" y="420" width="${totalPoolWidth - 30}" height="200" />
      </bpmndi:BPMNShape>

      <bpmndi:BPMNShape id="Lane_Provisioning_di" bpmnElement="Lane_Provisioning" isHorizontal="true">
        <dc:Bounds x="150" y="620" width="${totalPoolWidth - 30}" height="180" />
      </bpmndi:BPMNShape>

      <!-- Flow Nodes Shapes -->
${nodes.map(node => {
  return `      <bpmndi:BPMNShape id="${node.id}_di" bpmnElement="${node.id}">
        <dc:Bounds x="${node.x}" y="${node.y}" width="${node.width}" height="${node.height}" />
      </bpmndi:BPMNShape>`;
}).join('\n')}

      <!-- Sequence Flow Edges with Automatic Waypoints -->
${flows.map(flow => {
  const sourceNode = nodes.find(n => n.id === flow.sourceRef);
  const targetNode = nodes.find(n => n.id === flow.targetRef);
  if (!sourceNode || !targetNode) return '';

  const sourceCenterX = sourceNode.x + sourceNode.width;
  const sourceCenterY = sourceNode.y + sourceNode.height / 2;
  const targetCenterX = targetNode.x;
  const targetCenterY = targetNode.y + targetNode.height / 2;

  // Calculate clean orthogonal or straight waypoints
  const waypoints: { x: number; y: number }[] = [];
  if (Math.abs(sourceCenterY - targetCenterY) < 5) {
    waypoints.push({ x: sourceCenterX, y: sourceCenterY });
    waypoints.push({ x: targetCenterX, y: targetCenterY });
  } else {
    const midX = Math.round((sourceCenterX + targetCenterX) / 2);
    waypoints.push({ x: sourceCenterX, y: sourceCenterY });
    waypoints.push({ x: midX, y: sourceCenterY });
    waypoints.push({ x: midX, y: targetCenterY });
    waypoints.push({ x: targetCenterX, y: targetCenterY });
  }

  return `      <bpmndi:BPMNEdge id="${flow.id}_di" bpmnElement="${flow.id}">
${waypoints.map(wp => `        <di:waypoint x="${wp.x}" y="${wp.y}" />`).join('\n')}
      </bpmndi:BPMNEdge>`;
}).filter(Boolean).join('\n')}

    </bpmndi:BPMNPlane>
  </bpmndi:BPMNDiagram>
</bpmn:definitions>`;
}
