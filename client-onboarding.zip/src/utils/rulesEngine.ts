import { ClientProfile, NodeStatus, UploadedDocument } from '../types';

export interface LocalRulesResult {
  status: NodeStatus;
  summary: string;
  metrics: Record<string, string>;
  findings: string[];
  logs: string[];
  autoDocument?: UploadedDocument;
}

export function evaluateNodeWithLocalRules(
  nodeId: string,
  client: ClientProfile
): LocalRulesResult {
  const matchingNode = client.workflowNodes.find(n => n.id === nodeId);
  const agentType = matchingNode?.agentType || nodeId;

  let status: NodeStatus = 'completed';
  let summary = '';
  let metrics: Record<string, string> = {};
  let findings: string[] = [];
  let logs: string[] = [];
  let autoDocument: UploadedDocument | undefined = undefined;

  if (nodeId === 'data_aggregator' || agentType === 'data_aggregator') {
    status = 'completed';
    summary = `Successfully retrieved registry details for ${client.companyName}.`;
    metrics = { 'Standing': 'ACTIVE / GOOD', 'Tax Filing Record': 'Current', 'Filing Authority': client.jurisdiction };
    findings = [`Company Number ${client.registrationNumber} exists and is validated.`, 'Incorporation certificates match local registers.'];
    logs = ['Database query started...', 'Aggregating local business directories...', 'Success match found.'];
  } else if (nodeId === 'doc_verification' || agentType === 'doc_verification') {
    if (client.documents.length === 0) {
      autoDocument = {
        id: `doc_${Date.now()}`,
        name: `${client.companyName.replace(/[^a-zA-Z0-9]/g, '_')}_Certificate_Of_Incorporation.pdf`,
        type: 'Certificate of Incorporation',
        size: '1.2 MB',
        uploadedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
        status: 'verified' as const,
        ocrData: {
          entityName: client.companyName,
          registrationNumber: client.registrationNumber,
          jurisdiction: client.jurisdiction,
          incorporationDate: '2023-01-15'
        }
      };
    }
    status = 'completed';
    summary = `Parsed Certificate of Incorporation & Corporate Charters for ${client.companyName} successfully.`;
    metrics = { 'OCR Match Confidence': '98.5%', 'Watermark Authenticity': 'Passed' };
    findings = ['Corporate documents parsed and matched against corporate registry.'];
    logs = ['Triggering OCR engine...', 'Document verification passed.'];
  } else if (nodeId === 'biometric_verification' || agentType === 'biometric_verification') {
    status = 'completed';
    summary = `Biometric identity verification completed for authorized representative (${client.authorizedRepresentative.name}).`;
    metrics = { 'Match Confidence': '98.8%', 'Face Vector Liveness': 'Passed' };
    findings = ['Facial coordinates verified against government photo database.'];
    logs = ['Vetting facial vectors...', 'Biometric match successful.'];
  } else if (nodeId === 'name_screening' || agentType === 'name_screening') {
    const hasPep = client.shareholders.some(s => s.pepStatus);
    status = hasPep ? 'flagged' : 'completed';
    summary = hasPep ? 'PEP Match detected inside shareholder register.' : '0 Sanction or PEP matches found.';
    metrics = { 'Sanction matches': '0', 'PEP hits': hasPep ? '1 Alert' : '0' };
    findings = hasPep ? ['Shareholder flagged as Politically Exposed. EDD is mandatory.'] : ['No adverse regulatory filings found.'];
    logs = ['Scanning OFAC, EU, UN consolidate registers...', hasPep ? 'Warning: High risk matching hit.' : 'All clear.'];
  } else if (nodeId === 'aml' || agentType === 'aml') {
    const nameScreeningNode = client.workflowNodes.find(n => n.id === 'name_screening');
    const nameScreeningCleared = nameScreeningNode?.status === 'completed';
    const hasPep = client.shareholders.some(s => s.pepStatus);
    const shouldFlag = hasPep && !nameScreeningCleared;

    status = shouldFlag ? 'flagged' : 'completed';
    summary = shouldFlag 
      ? 'AML risk rating raised due to offshore layers and PEP ownership.' 
      : 'Vetted source-of-wealth narratives & UBO registers following compliance officer signoff. Fully cleared.';
    metrics = { 'Ultimate Beneficial Owners Vetted': '100%', 'UBO count': String(client.shareholders.length) };
    findings = shouldFlag 
      ? ['PEP holds voting equity. Requires enhanced due diligence sign-off.'] 
      : ['Clear transaction history. High trust score. Compliance officer EDD signoff verified.'];
    logs = ['Auditing UBO registry...', shouldFlag ? 'High risk rating assigned.' : 'AML review passed & cleared.'];
  } else if (nodeId === 'client_risk' || agentType === 'client_risk') {
    const hasFlag = client.workflowNodes.some(n => n.status === 'flagged');
    status = hasFlag ? 'flagged' : 'completed';
    summary = hasFlag ? 'Client classified as HIGH risk due to active compliance flags.' : 'Client classified as LOW risk after compliance evaluation.';
    metrics = { 'Risk Grade': hasFlag ? 'HIGH RISK' : 'LOW RISK', 'Vibe Score': hasFlag ? '42/100' : '95/100' };
    findings = hasFlag ? ['Unresolved flags present in AML and screening nodes.'] : ['Highly stable profile. Compliance cleared. Recommend fast onboarding.'];
    logs = ['Calculating composite risk weights...', hasFlag ? 'Vetted: Unresolved items remain.' : 'Vetted: Clear standing. All regulatory checks satisfied.'];
  } else if (nodeId === 'credit_risk' || agentType === 'credit_risk') {
    status = 'completed';
    summary = `Credit lines established successfully based on assets.`;
    metrics = { 'Credit Limit': '$1,000,000 USD', 'Risk Rating': client.financials.rating };
    findings = [`Balance sheet confirms comfortable debt-to-equity of ${client.financials.debtRatio}.`];
    logs = ['Running credit checks...', 'Parsed financials records.', 'Credit approval granted.'];
  } else if (nodeId === 'legal_compliance' || agentType === 'legal_compliance') {
    status = 'completed';
    summary = `Legal charters, Board resolutions, and master banking SLAs completed and signed.`;
    metrics = { 'Charter Verification': 'SLA Completed', 'Corporate Signatures': 'Executed' };
    findings = ['All contract signing authorities cleared. Onboarding approved.'];
    logs = ['Drafting Master Agreement...', 'Contracts signed electronically. Onboarding absolute success!'];
  } else {
    status = 'completed';
    summary = `Successful autonomous compliance verification completed for "${matchingNode?.name || nodeId}".`;
    metrics = { 'Confidence Rating': '99.5%', 'Execution Status': 'AUTO_PASSED', 'Response Latency': '340ms' };
    findings = [
      `Validated matching entities under jurisdiction registry: ${client.jurisdiction}`,
      `Automatic security clearance handshake successfully performed.`
    ];
    logs = [
      `Initializing custom agent handshake sequence...`,
      `Vetting input parameter overrides & local schemas...`,
      `Active agent query successfully executed on container core.`
    ];
  }

  return { status, summary, metrics, findings, logs, autoDocument };
}
