import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  ClientProfile, 
  WorkflowNode, 
  AppPersona, 
  NodeStatus,
  OrchestrationAgent,
  AgentOrchestration,
  SystemNotification,
  UploadedDocument
} from './types';
import { 
  MOCK_CLIENTS, 
  PERSONAS, 
  createInitialWorkflowNodes,
  INITIAL_AGENTS,
  INITIAL_ORCHESTRATIONS
} from './mockData';
import { PERSONA_TABS } from './constants/personaTabs';
import {
  Sidebar,
  RMTopHeader,
  JourneyWorkspace,
  PersonaSelector,
  AdminDashboard,
  CorporateOnboardingWorklist,
  AgentOrchestrator,
  AgentManager,
  McpServersView, 
  MarketplaceView, 
  GovernanceView, 
  NotificationsView, 
  ReviewQueueView, 
  OperationsQueueView,
  OperationsHub,
  DocVerificationHubView,
  ScreeningResultsView, 
  EscalationsView, 
  JourneysView, 
  PolicyEngineView, 
  Customer360View,
  DigitalTwinExplorer,
  CopilotChatPanel,
  CustomerDashboard,
  CustomerLoginGate,
  ClientCreator,
  JourneyInitiator,
  AgentGeneratorView,
  GuardrailsView,
  McpGatewayView,
  ApiCatalogView
} from './components';
import { OutreachDraftModal } from './components/common/OutreachDraftModal';

import { 
  Mail, 
  Bot
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [clients, setClients] = useState<ClientProfile[]>(() => {
    const saved = localStorage.getItem('onboarding_clients');
    let loaded: ClientProfile[] = MOCK_CLIENTS;
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as ClientProfile[];
        if (Array.isArray(parsed) && parsed.length > 0) {
          const missing = MOCK_CLIENTS.filter(mc => !parsed.some(p => p.id === mc.id));
          loaded = [...parsed, ...missing];
        }
      } catch (e) {
        loaded = MOCK_CLIENTS;
      }
    }
    return loaded.filter((c, index, self) => index === self.findIndex(t => t.id === c.id));
  });

  const [agents, setAgents] = useState<OrchestrationAgent[]>(() => {
    const saved = localStorage.getItem('orchestration_agents');
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as OrchestrationAgent[];
        const synced = parsed
          .filter(pa => INITIAL_AGENTS.some(ia => ia.id === pa.id))
          .map(pa => {
            const matchingDefault = INITIAL_AGENTS.find(ia => ia.id === pa.id);
            if (matchingDefault) {
              return {
                ...matchingDefault,
                ...pa,
                agentClass: pa.agentClass || matchingDefault.agentClass || 'normal',
                usesGoogleProtocol: pa.usesGoogleProtocol !== undefined ? pa.usesGoogleProtocol : (matchingDefault.usesGoogleProtocol !== undefined ? matchingDefault.usesGoogleProtocol : true),
                mcpApis: pa.mcpApis || matchingDefault.mcpApis,
                mcpConnectedSources: pa.mcpConnectedSources || matchingDefault.mcpConnectedSources,
              };
            }
            return pa;
          });
        const missing = INITIAL_AGENTS.filter(ia => !synced.some(pa => pa.id === ia.id));
        return missing.length > 0 ? [...synced, ...missing] : synced;
      } catch (e) {
        console.error('Failed to parse orchestration_agents', e);
      }
    }
    return INITIAL_AGENTS;
  });

  const [orchestrations, setOrchestrations] = useState<AgentOrchestration[]>(() => {
    const saved = localStorage.getItem('agent_orchestrations');
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as AgentOrchestration[];
        const valid = parsed.filter(p => INITIAL_ORCHESTRATIONS.some(io => io.id === p.id));
        const missing = INITIAL_ORCHESTRATIONS.filter(io => !valid.some(vp => vp.id === io.id));
        if (valid.length > 0 || missing.length > 0) {
          return [...valid, ...missing];
        }
      } catch (e) {
        console.error('Failed to parse agent_orchestrations from localStorage', e);
      }
    }
    return INITIAL_ORCHESTRATIONS;
  });

  const [selectedClientId, setSelectedClientId] = useState<string>(() => clients.find(c => c.id === 'client_meridian')?.id || clients[0]?.id || 'client_meridian');
  const [selectedNodeId, setSelectedNodeId] = useState<string>('data_aggregator');
  const [activePersona, setActivePersona] = useState<AppPersona | null>(null);
  const [isCustomerVerified, setIsCustomerVerified] = useState<boolean>(false);
  const [isViewingAgentGenerator, setIsViewingAgentGenerator] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>('my_pipeline');
  const [isCreatingClient, setIsCreatingClient] = useState(false);
  const [isInitiatingJourney, setIsInitiatingJourney] = useState(false);
  const [isAutoProcessing, setIsAutoProcessing] = useState(false);
  const isAutoProcessingRef = useRef(false);

  const setAutoProcessing = (val: boolean) => {
    isAutoProcessingRef.current = val;
    setIsAutoProcessing(val);
  };

  const [activeRunningNodeId, setActiveRunningNodeId] = useState<string | undefined>(undefined);
  const clientsRef = useRef<ClientProfile[]>(clients);

  useEffect(() => {
    clientsRef.current = clients;
  }, [clients]);

  const [sentEmails, setSentEmails] = useState<{
    id: string;
    clientName: string;
    email: string;
    subject: string;
    body: string;
    date: string;
    clientId: string;
    status: 'sent' | 'delivered' | 'opened' | 'clicked';
    sentAt?: string;
    deliveredAt?: string;
    openedAt?: string;
    clickedAt?: string;
  }[]>(() => {
    const saved = localStorage.getItem('onboarding_sent_emails');
    return saved ? JSON.parse(saved) : [];
  });

  const [systemNotifications, setSystemNotifications] = useState<SystemNotification[]>(() => {
    const saved = localStorage.getItem('onboarding_system_notifications');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return [
      {
        id: 'notif-1',
        type: 'critical',
        title: 'PEP Screening Alert',
        msg: 'AML PEP Alert: Shareholder detected in sanctions adverse registers.',
        time: '10 mins ago',
        node: 'aml',
        clientId: 'client_1',
        clientName: 'Nexus Tech Solutions',
        actionRequired: false,
        actioned: false
      },
      {
        id: 'notif-2',
        type: 'info',
        title: 'Biometrics Verification Passed',
        msg: 'Biometric FaceID Passed: Representative Dr. Evelyn Chen facial matches completed successfully.',
        time: '1 hour ago',
        node: 'biometric_verification',
        clientId: 'client_1',
        clientName: 'Nexus Tech Solutions',
        actionRequired: false,
        actioned: false
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem('onboarding_system_notifications', JSON.stringify(systemNotifications));
  }, [systemNotifications]);

  const handleAddNotification = (notif: SystemNotification) => {
    setSystemNotifications(prev => [notif, ...prev]);
  };

  const handleActionNotification = (notifId: string, action: 'approve' | 'reject') => {
    setSystemNotifications(prev => prev.map(n => {
      if (n.id === notifId) {
        return { ...n, actioned: true, actionRequired: false };
      }
      return n;
    }));

    const targetNotif = systemNotifications.find(n => n.id === notifId);
    if (!targetNotif) return;

    if (action === 'approve') {
      setClients(prevClients => prevClients.map(client => {
        if (client.id === targetNotif.clientId) {
          const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
          
          const targetNodeIdx = client.workflowNodes.findIndex(n => n.id === targetNotif.node || n.id === 'doc_verification');

          const updatedNodes = client.workflowNodes.map((node, idx) => {
            if (node.id === 'doc_verification' || node.id === targetNotif.node) {
              return {
                ...node,
                status: 'completed' as NodeStatus,
                logs: [
                  ...node.logs,
                  `[${timeStr}] 👨‍💼 RM ACTION TAKEN: Relationship Manager reviewed & approved document verification notification.`,
                  `[${timeStr}] 🟢 Node status transitioned to COMPLETED.`
                ]
              };
            }
            if (targetNodeIdx !== -1 && idx === targetNodeIdx + 1 && node.status === 'pending') {
              return {
                ...node,
                status: 'completed' as NodeStatus,
                logs: [
                  ...node.logs,
                  `[${timeStr}] ⚡ AUTONOMOUS STEP ADVANCED: Proceeding to next step (${node.name}) following RM approval.`,
                  `[${timeStr}] 🟢 Node completed successfully.`
                ]
              };
            }
            return node;
          });

          const allNodesDone = updatedNodes.every(n => n.status === 'completed');

          return {
            ...client,
            workflowNodes: updatedNodes,
            overallStatus: allNodesDone ? 'approved' : 'in_progress'
          };
        }
        return client;
      }));
    }
  };

  const [showSimulatedMailbox, setShowSimulatedMailbox] = useState(false);
  const [showRmCopilot, setShowRmCopilot] = useState(false);
  const [showPersonaDropdown, setShowPersonaDropdown] = useState(false);

  // Responsive window tracking to keep copilot and middle content balanced without wrapping
  const [windowWidth, setWindowWidth] = useState<number>(
    typeof window !== 'undefined' ? window.innerWidth : 1200
  );

  useEffect(() => {
    const handleResize = () => setWindowWidth(window.innerWidth);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const [copilotWidthMode, setCopilotWidthMode] = useState<'auto' | 'compact' | 'standard' | 'wide' | 'custom'>('auto');
  const [copilotCustomWidth, setCopilotCustomWidth] = useState<number | null>(null);
  const [copilotIsFloating, setCopilotIsFloating] = useState<boolean>(false);

  // Dynamic responsive width scale tailored to window size:
  // Dynamically responsive to layout size so middle content never wraps heavily!
  const getAutoCopilotWidth = (w: number) => {
    if (w < 640) return Math.min(w - 16, 360); // Mobile: full width overlay
    if (w < 1024) return 360; // Tablet / small window: overlay drawer
    if (w < 1280) return 380; // Small desktop: overlay drawer (<1280px preserves middle space)
    if (w < 1440) return Math.min(310, Math.round(w * 0.22)); // 1280px-1439px: docked sleekly
    if (w < 1680) return Math.min(360, Math.round(w * 0.22)); // 1440px-1679px: comfortable
    if (w < 1920) return Math.min(400, Math.round(w * 0.22)); // 1680px-1919px: widescreen
    return 440; // 1920px+: ultra-wide display
  };

  const effectiveCopilotWidth = useMemo(() => {
    if (copilotWidthMode === 'compact') return 290;
    if (copilotWidthMode === 'standard') return 350;
    if (copilotWidthMode === 'wide') return 430;
    if (copilotWidthMode === 'custom' && copilotCustomWidth) {
      const sidebarWidth = windowWidth >= 768 ? 256 : 0;
      const maxAllowed = Math.max(280, windowWidth - sidebarWidth - 400);
      return Math.min(Math.max(270, copilotCustomWidth), maxAllowed);
    }
    return getAutoCopilotWidth(windowWidth);
  }, [copilotWidthMode, copilotCustomWidth, windowWidth]);

  // When screen width is below 1280px, float as overlay drawer so the middle content NEVER wraps!
  const isSmallScreen = windowWidth < 1280;
  const isFloating = isSmallScreen || copilotIsFloating;

  // Drag-to-resize on left edge when docked
  const handleMouseDownResize = (e: React.MouseEvent) => {
    e.preventDefault();
    const startX = e.clientX;
    const startWidth = effectiveCopilotWidth;

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const deltaX = moveEvent.clientX - startX;
      const newWidth = startWidth - deltaX;
      const sidebarWidth = window.innerWidth >= 768 ? 256 : 0;
      const maxAllowed = Math.max(280, window.innerWidth - sidebarWidth - 400);
      const clamped = Math.min(Math.max(270, newWidth), maxAllowed);
      setCopilotWidthMode('custom');
      setCopilotCustomWidth(clamped);
    };

    const handleMouseUp = () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
  };

  const [draftClient, setDraftClient] = useState<ClientProfile | null>(null);
  const [isDraftModalOpen, setIsDraftModalOpen] = useState(false);

  const mainContentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (mainContentRef.current) {
      mainContentRef.current.scrollTop = 0;
    }
  }, [activePersona, activeTab]);

  useEffect(() => {
    // Except customer self service, for all other personas, copilot should be minimised
    if (activePersona === 'customer') {
      setShowRmCopilot(true);
    } else {
      setShowRmCopilot(false);
    }
  }, [activePersona]);

  useEffect(() => {
    localStorage.setItem('onboarding_clients', JSON.stringify(clients));
  }, [clients]);

  useEffect(() => {
    localStorage.setItem('orchestration_agents', JSON.stringify(agents));
  }, [agents]);

  useEffect(() => {
    localStorage.setItem('agent_orchestrations', JSON.stringify(orchestrations));
  }, [orchestrations]);

  useEffect(() => {
    localStorage.setItem('onboarding_sent_emails', JSON.stringify(sentEmails));
  }, [sentEmails]);

  const activeClient = useMemo(() => {
    return clients.find(c => c.id === selectedClientId) || clients[0];
  }, [clients, selectedClientId]);

  const updateActiveClient = (updatedFields: Partial<ClientProfile>, targetClientId?: string) => {
    const targetId = targetClientId || selectedClientId;
    const next = clientsRef.current.map(c => c.id === targetId ? { ...c, ...updatedFields } : c);
    clientsRef.current = next;
    setClients(next);
  };

  const handleAddDirector = (clientId: string, name: string, role: string, nationality: string) => {
    setClients(prev => prev.map(c => {
      if (c.id === clientId) {
        const directors = c.directors || [];
        return {
          ...c,
          directors: [...directors, { name, role, nationality, appointmentDate: new Date().toISOString().split('T')[0] }]
        };
      }
      return c;
    }));
  };

  const handleAddRelatedParty = (clientId: string, name: string, relationType: string, riskLevel: 'Low' | 'Medium' | 'High') => {
    setClients(prev => prev.map(c => {
      if (c.id === clientId) {
        const relatedParties = c.relatedParties || [];
        return { ...c, relatedParties: [...relatedParties, { name, relationType, riskLevel }] };
      }
      return c;
    }));
  };

  const handleTriggerKycReview = (clientId: string, alert: { type: string; title: string; severity: string; details: string }) => {
    setClients(prev => prev.map(c => {
      if (c.id === clientId) {
        const existingAlerts = c.alerts || [];
        const newAlert = {
          id: `alert_${Date.now()}`,
          type: alert.type,
          title: alert.title,
          severity: alert.severity,
          description: alert.details,
          date: new Date().toISOString().replace('T', ' ').substring(0, 19),
          status: 'active' as const
        };

        const updatedNodes = c.workflowNodes.map(node => {
          if (alert.severity === 'critical' && (node.id === 'name_screening' || node.id === 'aml' || node.id === 'client_risk')) {
            return {
              ...node,
              status: 'flagged' as const,
              logs: [
                ...node.logs,
                `[Urgent KYC Review Triggered] Category: ${alert.type.toUpperCase()}`,
                `Alert: "${alert.title}"`,
                `Evidence details: "${alert.details}"`,
                `Action taken: Locked node and raised compliance escalations queue.`
              ],
              results: {
                summary: `Adverse media or payment anomaly flagged: ${alert.title}`,
                metrics: { 'Vibe Score': '35/100', 'Threat Category': alert.type === 'adverse_media' ? 'ADVERSE_MEDIA_LEAK' : 'TRANSACTION_ANOMALY', 'Audit Status': 'URGENT REVIEW' },
                findings: [`Triggered dynamically by operational agent: "${alert.details}"`, 'Lock status: Active restriction. Requires supervisor sign-off to override.']
              }
            };
          }
          return node;
        });

        return {
          ...c,
          alerts: [newAlert, ...existingAlerts],
          workflowNodes: updatedNodes,
          overallStatus: alert.severity === 'critical' ? 'in_progress' as const : c.overallStatus
        };
      }
      return c;
    }));
  };

  const handleUpdateNode = (nodeId: string, updatedFields: Partial<WorkflowNode>, targetClientId?: string) => {
    const cId = targetClientId || selectedClientId;
    const isManualCompletion = updatedFields.status === 'completed' && !isAutoProcessingRef.current;

    const nextClients = clientsRef.current.map(c => {
      if (c.id === cId) {
        const updatedNodes = c.workflowNodes.map(node => {
          if (node.id === nodeId) {
            return { ...node, ...updatedFields, lastUpdated: new Date().toISOString().replace('T', ' ').substring(0, 16) };
          }
          return node;
        });

        const allCompleted = updatedNodes.every(n => n.status === 'completed');
        const anyFlagged = updatedNodes.some(n => n.status === 'flagged');

        return {
          ...c,
          workflowNodes: updatedNodes,
          overallStatus: allCompleted ? 'approved' as const : anyFlagged ? 'in_progress' as const : 'in_progress' as const
        };
      }
      return c;
    });

    clientsRef.current = nextClients;
    setClients(nextClients);

    if (isManualCompletion) {
      setTimeout(() => {
        const targetClient = clientsRef.current.find(c => c.id === cId);
        if (targetClient) handleTriggerAutonomousFlow(targetClient);
      }, 100);
    }
  };

  const handleReorderNodes = (reorderedNodes: WorkflowNode[], targetClientId?: string) => {
    const cId = targetClientId || selectedClientId;
    const nextClients = clientsRef.current.map(c => {
      if (c.id === cId) {
        return { ...c, workflowNodes: reorderedNodes };
      }
      return c;
    });
    clientsRef.current = nextClients;
    setClients(nextClients);
  };

  const handleAddDocument = (newDoc: any, targetClientId?: string) => {
    const cId = targetClientId || selectedClientId;
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    const completeDoc: UploadedDocument = {
      id: newDoc.id || `doc_${Date.now()}`,
      name: newDoc.name || 'Document.pdf',
      type: newDoc.type || 'Institutional Corporate Record',
      size: newDoc.size || '1.2 MB',
      uploadedAt: newDoc.uploadedAt || new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: newDoc.status || 'verified',
      ocrData: newDoc.ocrData || {},
      source: newDoc.source || 'customer_provided',
      sourceDetails: newDoc.sourceDetails || 'Uploaded via Copilot Assistant'
    };

    setClients(prev => prev.map(c => {
      if (c.id === cId) {
        const updatedDocs = [...c.documents, completeDoc];
        const updatedNodes = c.workflowNodes.map(n => {
          if (n.id === 'doc_verification' || n.agentType === 'doc_verification') {
            return {
              ...n,
              status: 'completed' as const,
              logs: [...n.logs, `[${timeStr}] 📂 Upload Received via Copilot: "${completeDoc.name}" (${completeDoc.source === 'externally_sourced' ? 'Externally Sourced' : 'Customer Provided'}). Executing OCR models...`],
              results: {
                summary: `OCR extraction and authenticity checks completed for ${completeDoc.name}.`,
                metrics: { 'OCR Trust Score': '99.4%', 'Digital Signature Vetted': 'Valid' },
                findings: [`Parsed fields matched government registry records.`, `Document digital signature verified.`]
              }
            };
          }
          return n;
        });

        return { ...c, documents: updatedDocs, workflowNodes: updatedNodes, overallStatus: updatedNodes.every(n => n.status === 'completed') ? 'approved' : 'in_progress' };
      }
      return c;
    }));
  };

  const handleDeleteDocument = (docId: string) => {
    updateActiveClient({ documents: activeClient.documents.filter(d => d.id !== docId) });
  };

  const handleBiometricComplete = (score: number, photoUrl: string) => {
    updateActiveClient({
      authorizedRepresentative: {
        ...activeClient.authorizedRepresentative,
        biometricVerified: true,
        biometricMatchScore: score,
        biometricSelfieUrl: photoUrl
      }
    });

    const bioNode = activeClient.workflowNodes.find(n => n.id === 'biometric_verification');
    if (bioNode) {
      handleUpdateNode('biometric_verification', {
        status: 'completed',
        logs: [...bioNode.logs, 'Biometric camera session successfully established.', `Liveness verification: PASSED.`, `Match confidence metric scored: ${score}%`],
        results: {
          summary: 'Facial identity confirmed with absolute compliance clearance.',
          metrics: { 'Facial Landmarks Plotted': 68, 'Liveness Confidence': '100%', 'Identity Score Match': `${score}%` },
          findings: [`Verified authorized signee matches register records.`]
        }
      });
    }
  };

  const handleResetWorkflow = () => {
    setAutoProcessing(false);
    setActiveRunningNodeId(undefined);

    const resetNodes = activeClient.id.startsWith('client_journey_')
      ? activeClient.workflowNodes.map(node => ({
          ...node,
          status: 'pending' as NodeStatus,
          logs: [`[Journey Orchestrator] Workflow reset by Relationship Manager. Re-enqueued step.`],
          results: undefined
        }))
      : createInitialWorkflowNodes();

    updateActiveClient({
      workflowNodes: resetNodes,
      overallStatus: 'draft',
      authorizedRepresentative: { ...activeClient.authorizedRepresentative, biometricVerified: false, biometricMatchScore: 0, biometricSelfieUrl: '' }
    });

    setSelectedNodeId(resetNodes[0]?.id || 'data_aggregator');
    setTimeout(() => {
      const target = clientsRef.current.find(c => c.id === activeClient.id) || activeClient;
      handleTriggerAutonomousFlow(target);
    }, 250);
  };

  const handleCleanupRMWorkspace = () => {
    setAutoProcessing(false);
    setActiveRunningNodeId(undefined);

    const freshClients = MOCK_CLIENTS.map(c => ({
      ...c,
      overallStatus: 'draft' as const,
      workflowNodes: createInitialWorkflowNodes(),
      authorizedRepresentative: {
        ...c.authorizedRepresentative,
        biometricVerified: false,
        biometricMatchScore: 0,
        biometricSelfieUrl: ''
      }
    }));

    clientsRef.current = freshClients;
    setClients(freshClients);
    localStorage.setItem('onboarding_clients', JSON.stringify(freshClients));

    setSentEmails([]);
    localStorage.removeItem('onboarding_sent_emails');

    const cleanNotif: SystemNotification = {
      id: `notif-cleanup-${Date.now()}`,
      type: 'info',
      title: 'RM Workspace Cleaned Up',
      msg: 'RM workspace reset. Ready to initiate fresh new onboarding journeys across all jurisdictions.',
      time: 'Just now',
      node: 'data_aggregator',
      clientId: freshClients[0]?.id || 'client_1',
      clientName: freshClients[0]?.companyName || 'Nexus Tech Solutions',
      actionRequired: false,
      actioned: true
    };
    setSystemNotifications([cleanNotif]);

    if (freshClients.length > 0) {
      setSelectedClientId(freshClients[0].id);
      setSelectedNodeId(freshClients[0].workflowNodes[0]?.id || 'data_aggregator');
    }

    setIsInitiatingJourney(true);
  };

  const STAGE_SEQUENCE = [
    'data_aggregator',
    'doc_verification',
    'biometric_verification',
    'name_screening',
    'aml',
    'client_risk',
    'credit_risk',
    'legal_compliance'
  ];

  const handleRunAutonomousNode = async (nodeId: string, customClientId?: string): Promise<boolean> => {
    const targetId = customClientId || selectedClientId;
    const current = clientsRef.current.find(c => c.id === targetId) || clientsRef.current[0];
    if (!current) return false;

    handleUpdateNode(nodeId, { status: 'running' }, targetId);
    setSelectedNodeId(nodeId);
    setActiveRunningNodeId(nodeId);

    await new Promise(resolve => setTimeout(resolve, 800));

    const updatedTarget = clientsRef.current.find(c => c.id === targetId) || current;

    try {
      const response = await fetch('/api/onboarding/analyze-node', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ client: updatedTarget, nodeId, userPrompt: 'Autonomous check trigger.' })
      });

      if (response.ok) {
        const data = await response.json();
        const rawStatus = (data.status || '').toString().toLowerCase();
        const isFlagged = rawStatus === 'flagged' || rawStatus === 'failed' || rawStatus === 'rejected';
        const normStatus: NodeStatus = isFlagged ? 'flagged' : 'completed';

        handleUpdateNode(nodeId, {
          status: normStatus,
          logs: ['Triggering autonomous module sequence...', ...(data.logs || [])],
          results: {
            summary: data.summary || `Autonomous evaluation completed for node '${nodeId}'.`,
            metrics: data.metrics || { 'Trust Score': '98%', 'Status': 'VERIFIED' },
            findings: data.findings || ['Verified compliance parameters.']
          }
        }, targetId);
        setActiveRunningNodeId(undefined);
        return normStatus === 'completed';
      }
    } catch (e) {
      console.error('API call failed, running local fallback', e);
    }

    handleUpdateNode(nodeId, {
      status: 'completed',
      logs: ['Executing high-precision local verification engine...', 'Compliance checks passed.'],
      results: {
        summary: `Autonomous evaluation finished for node '${nodeId}'.`,
        metrics: { 'Trust Score': '99%', 'Status': 'VERIFIED' },
        findings: ['No regulatory blockers or sanctions matches detected.']
      }
    }, targetId);
    setActiveRunningNodeId(undefined);
    return true;
  };

  const handleTriggerAutonomousFlow = async (targetClient?: ClientProfile) => {
    if (isAutoProcessingRef.current) {
      return;
    }
    setAutoProcessing(true);

    const targetId = targetClient?.id || selectedClientId;

    while (isAutoProcessingRef.current) {
      const currentClientState = clientsRef.current.find(c => c.id === targetId);
      if (!currentClientState) break;

      const nodes = currentClientState.workflowNodes;
      
      // Find pending nodes whose dependencies are satisfied (completed or approved)
      const readyNodes = nodes.filter(node => {
        if (node.status !== 'pending') return false;
        if (!node.dependsOn || node.dependsOn.length === 0) return true;
        return node.dependsOn.every(depId => {
          const depNode = nodes.find(n => n.id === depId || n.agentType === depId || n.assignedAgentId === depId);
          return depNode && (depNode.status === 'completed' || depNode.status === 'approved');
        });
      });

      if (readyNodes.length === 0) break;

      // Sort ready nodes deterministically by STAGE_SEQUENCE index to guarantee sequence execution
      readyNodes.sort((a, b) => {
        const idxA = STAGE_SEQUENCE.indexOf(a.id);
        const idxB = STAGE_SEQUENCE.indexOf(b.id);
        return (idxA !== -1 ? idxA : 99) - (idxB !== -1 ? idxB : 99);
      });

      // Execute the single next ready node sequentially to prevent race conditions & out-of-order skipping
      const nextNode = readyNodes[0];

      const success = await handleRunAutonomousNode(nextNode.id, targetId);
      await new Promise(resolve => setTimeout(resolve, 500));

      // If node is flagged/rejected or failed, pause auto-processing so user can inspect and manually approve
      if (!success) {
        break;
      }
    }

    setAutoProcessing(false);
  };

  const handleSendOutreachEmail = (customClient?: ClientProfile) => {
    const target = customClient || activeClient;
    if (!target) return;
    setDraftClient(target);
    setIsDraftModalOpen(true);
  };

  const handleConfirmSendEmail = (emailData: {
    clientId: string;
    clientName: string;
    email: string;
    subject: string;
    body: string;
  }) => {
    const emailId = 'email_' + Date.now();
    const nowTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    const newEmail = {
      id: emailId,
      clientName: emailData.clientName,
      email: emailData.email,
      subject: emailData.subject,
      body: emailData.body,
      date: new Date().toLocaleString(),
      clientId: emailData.clientId,
      status: 'sent' as const,
      sentAt: nowTime
    };

    setSentEmails(prev => [newEmail, ...prev.filter(e => e.clientId !== emailData.clientId)]);

    setTimeout(() => {
      setSentEmails(prev => prev.map(e => e.id === emailId ? { ...e, status: 'delivered', deliveredAt: new Date().toLocaleTimeString() } : e));
    }, 2000);
    setTimeout(() => {
      setSentEmails(prev => prev.map(e => e.id === emailId ? { ...e, status: 'opened', openedAt: new Date().toLocaleTimeString() } : e));
    }, 4500);
    setTimeout(() => {
      setSentEmails(prev => prev.map(e => e.id === emailId ? { ...e, status: 'clicked', clickedAt: new Date().toLocaleTimeString() } : e));
    }, 7500);
  };

  const handleSelectPersona = (p: AppPersona, autoVerifyCustomer: boolean = false) => {
    setActivePersona(p);
    setIsCustomerVerified(autoVerifyCustomer);
    if (p === 'customer') {
      setShowRmCopilot(true);
    } else {
      setShowRmCopilot(false);
    }
    const tabs = PERSONA_TABS[p];
    if (tabs && tabs.length > 0) setActiveTab(tabs[0].id);
  };

  const handleSelectClient = (clientId: string) => {
    setSelectedClientId(clientId);
    const target = clientsRef.current.find(c => c.id === clientId) || clients.find(c => c.id === clientId);
    if (target && target.workflowNodes && target.workflowNodes.length > 0) {
      const activeOrPending = target.workflowNodes.find(n => n.status === 'running' || n.status === 'pending');
      setSelectedNodeId(activeOrPending ? activeOrPending.id : target.workflowNodes[0].id);
    }
  };

  const handleClientCreated = (newClient: ClientProfile) => {
    const initializedClient: ClientProfile = {
      ...newClient,
      workflowNodes: newClient.workflowNodes && newClient.workflowNodes.length > 0 ? newClient.workflowNodes : createInitialWorkflowNodes()
    };

    const filteredRef = clientsRef.current.filter(c => c.id !== initializedClient.id);
    clientsRef.current = [initializedClient, ...filteredRef];
    setClients(prev => [initializedClient, ...prev.filter(c => c.id !== initializedClient.id)]);
    setSelectedClientId(initializedClient.id);
    setSelectedNodeId(initializedClient.workflowNodes[0]?.id || 'data_aggregator');

    handleSendOutreachEmail(initializedClient);
    setIsInitiatingJourney(false);
    setIsCreatingClient(false);
    setActivePersona('rm');
    setActiveTab('journey_workspace');

    setTimeout(() => handleTriggerAutonomousFlow(initializedClient), 200);
  };

  const currentPersonaInfo = useMemo(() => {
    return PERSONAS.find(p => p.id === activePersona) || PERSONAS[0];
  }, [activePersona]);

  const activeTabLabel = useMemo(() => {
    if (!activePersona) return 'Dashboard';
    const list = PERSONA_TABS[activePersona] || [];
    return list.find(t => t.id === activeTab)?.label || 'Dashboard';
  }, [activePersona, activeTab]);

  if (isViewingAgentGenerator) {
    return (
      <AgentGeneratorView 
        onBackToLanding={() => setIsViewingAgentGenerator(false)} 
        onSelectPersona={(persona) => {
          setIsViewingAgentGenerator(false);
          handleSelectPersona(persona);
        }}
      />
    );
  }

  if (!activePersona) {
    return (
      <PersonaSelector 
        onSelect={handleSelectPersona} 
        activePersona={activePersona} 
        onOpenAgentGenerator={() => setIsViewingAgentGenerator(true)}
      />
    );
  }

  if (activePersona === 'customer' && !isCustomerVerified) {
    return (
      <CustomerLoginGate
        clients={clients}
        initialClientId={selectedClientId}
        onLoginSuccess={(clientId) => {
          setSelectedClientId(clientId);
          setIsCustomerVerified(true);
          setShowRmCopilot(true);
        }}
        onBackToPersonas={() => {
          setActivePersona(null);
          setIsCustomerVerified(false);
        }}
      />
    );
  }

  return (
    <div className="min-h-screen font-sans flex flex-col md:flex-row antialiased transition-colors duration-200 bg-white text-slate-900">
      
      {/* Persistent Left Sidebar Navigation for ALL personas */}
      {activePersona && (
        <Sidebar
          activePersona={activePersona}
          currentPersonaInfo={currentPersonaInfo}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          onSwitchPersona={() => {
            setActivePersona(null);
            setIsCustomerVerified(false);
          }}
          activeClient={activeClient}
          clients={clients}
          onSelectClient={handleSelectClient}
          unreadNotifCount={systemNotifications.filter(n => !n.read).length}
          onInitiateJourney={() => setIsInitiatingJourney(true)}
        />
      )}

      {/* Main Content Area */}
      <div ref={mainContentRef} className="flex-1 flex flex-col min-w-0 overflow-y-auto bg-white">
        
        {/* Top Header Bar with Global Search, Bell, Profile, and Logout */}
        {activePersona && (
          <RMTopHeader
            activePersona={activePersona}
            activeClient={activeClient}
            clients={clients}
            onSelectClient={handleSelectClient}
            currentPersonaInfo={currentPersonaInfo}
            unreadNotifCount={
              activePersona === 'customer'
                ? systemNotifications.filter(n => (!activeClient || !n.clientId || n.clientId === activeClient.id) && !n.read).length
                : systemNotifications.filter(n => !n.read).length
            }
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            onLogout={() => {
              setActivePersona(null);
              setIsCustomerVerified(false);
            }}
            onInitiateJourney={() => setIsInitiatingJourney(true)}
            systemNotifications={systemNotifications}
            onActionNotification={handleActionNotification}
            onMarkNotificationsAsRead={() => {
              setSystemNotifications(prev => prev.map(n => ({ ...n, read: true })));
            }}
            showCopilot={showRmCopilot}
            onToggleCopilot={() => setShowRmCopilot(prev => !prev)}
            onSwitchPersona={(p) => handleSelectPersona(p, p === 'customer')}
          />
        )}

        {/* Dynamic Subview Body Panel */}
        <div className="px-6 py-6 pb-8 flex-1 z-10 bg-white">
          <div className="bg-white rounded-2xl p-6 md:p-8 border border-slate-200 shadow-sm min-h-[800px]">
            
            {/* Platform Admin Subviews */}
            {activePersona === 'platform_admin' && (
              <>
                {activeTab === 'agent_registry' && <AgentManager agents={agents} setAgents={setAgents} />}
                {(activeTab === 'agentic_process_flows' || activeTab === 'agent_studio') && (
                  <AgentOrchestrator 
                    agents={agents}
                    setAgents={setAgents}
                    orchestrations={orchestrations}
                    setOrchestrations={setOrchestrations}
                  />
                )}
                {activeTab === 'guardrails' && <GuardrailsView />}
                {activeTab === 'mcp_gateway' && <McpGatewayView agents={agents} />}
                {activeTab === 'api_catalog' && <ApiCatalogView />}
                {activeTab === 'agent_generator' && <AgentGeneratorView />}
                {activeTab === 'mcp_servers' && <McpGatewayView agents={agents} />}
                {activeTab === 'marketplace' && <MarketplaceView />}
                {activeTab === 'governance' && <GovernanceView />}
                {activeTab === 'journeys' && (
                  <JourneysView 
                    agents={agents} 
                    orchestrations={orchestrations} 
                    onNavigateToStudio={() => setActiveTab('agentic_process_flows')} 
                  />
                )}
                {activeTab === 'policy_engine' && <GuardrailsView />}
              </>
            )}

            {/* RM, Operations & Compliance Subviews */}
            {(activePersona === 'rm' || activePersona === 'compliance_officer' || activePersona === 'operations_officer') && (
              <>
                {activePersona === 'rm' && activeTab === 'my_pipeline' && (
                  <CorporateOnboardingWorklist 
                    clients={clients} 
                    onSelectClient={(id) => {
                      handleSelectClient(id);
                      setActiveTab('journey_workspace');
                    }}
                    onInitiateJourney={() => setIsInitiatingJourney(true)}
                  />
                )}

                {activePersona === 'compliance_officer' && activeTab === 'review_queue' && (
                  <ReviewQueueView 
                    clients={clients} 
                    onSelectClient={handleSelectClient} 
                    onNavigateToWorkspace={() => setActiveTab('journey_workspace')}
                  />
                )}

                {activePersona === 'compliance_officer' && activeTab === 'screening_results' && (
                  <ScreeningResultsView activeClient={activeClient} />
                )}

                {activePersona === 'compliance_officer' && activeTab === 'escalations' && (
                  <EscalationsView />
                )}

                {activePersona === 'operations_officer' && activeTab === 'ops_queue' && (
                  <OperationsHub 
                    clients={clients} 
                    onSelectClient={handleSelectClient} 
                    onNavigateToWorkspace={() => setActiveTab('journey_workspace')}
                  />
                )}

                {activePersona === 'operations_officer' && activeTab === 'doc_verification' && (
                  <DocVerificationHubView 
                    activeClient={activeClient}
                    onApproveDocument={(docId) => {
                      handleAddDocument(
                        activeClient.documents.find(d => d.id === docId)
                          ? { ...activeClient.documents.find(d => d.id === docId)!, status: 'verified' }
                          : null,
                        activeClient.id
                      );
                    }}
                    onRejectDocument={(docId) => {
                      handleDeleteDocument(docId);
                    }}
                  />
                )}

                {activeTab === 'journey_workspace' && (
                  <JourneyWorkspace
                    activeClient={activeClient}
                    clients={clients}
                    selectedClientId={selectedClientId}
                    selectedNodeId={selectedNodeId}
                    activeRunningNodeId={activeRunningNodeId}
                    isAutoProcessing={isAutoProcessing}
                    activePersona={activePersona}
                    agents={agents}
                    handleSelectClient={handleSelectClient}
                    setIsInitiatingJourney={setIsInitiatingJourney}
                    handleSendOutreachEmail={handleSendOutreachEmail}
                    handleTriggerAutonomousFlow={handleTriggerAutonomousFlow}
                    handleResetWorkflow={handleResetWorkflow}
                    handleCleanupRMWorkspace={handleCleanupRMWorkspace}
                    setSelectedNodeId={setSelectedNodeId}
                    handleAddDocument={handleAddDocument}
                    handleDeleteDocument={handleDeleteDocument}
                    handleBiometricComplete={handleBiometricComplete}
                    handleUpdateNode={handleUpdateNode}
                    handleRunAutonomousNode={handleRunAutonomousNode}
                    handleReorderNodes={handleReorderNodes}
                  />
                )}

                {activeTab === 'customer_360' && (
                  <Customer360View 
                    clients={clients} 
                    activeClientId={selectedClientId}
                    onSelectClient={setSelectedClientId}
                    onAddDirector={handleAddDirector} 
                    onAddRelatedParty={handleAddRelatedParty} 
                    onTriggerKycReview={handleTriggerKycReview}
                  />
                )}
                {activeTab === 'digital_twin' && (
                  <DigitalTwinExplorer 
                    clients={clients}
                    activeClient={activeClient}
                    selectedClientId={selectedClientId}
                    onSelectClient={handleSelectClient}
                    onAddDocument={handleAddDocument}
                    onUpdateClient={updateActiveClient}
                  />
                )}
                {activeTab === 'notifications' && (
                  <NotificationsView 
                    notifications={systemNotifications}
                    onActionNotification={handleActionNotification}
                    onSelectClient={setSelectedClientId}
                  />
                )}
              </>
            )}

            {/* Customer Portal Subview */}
            {activePersona === 'customer' && (
              activeTab === 'notifications' ? (
                <NotificationsView 
                  notifications={systemNotifications}
                  onActionNotification={handleActionNotification}
                  onSelectClient={setSelectedClientId}
                />
              ) : (
                <CustomerDashboard
                  clients={clients}
                  activeClient={activeClient || null}
                  onUpdateClient={(updated) => setClients(prev => prev.map(c => c.id === updated.id ? updated : c))}
                  onClientCreated={handleClientCreated}
                  onSelectClient={setSelectedClientId}
                  isDarkMode={false}
                  onAddNotification={handleAddNotification}
                  onOpenCopilot={() => setShowRmCopilot(true)}
                />
              )
            )}

          </div>
        </div>

        {/* Modal Dialogs */}
        <AnimatePresence>
          {isCreatingClient && (
            <motion.div
              key="modal-create-client"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50"
            >
              <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} className="w-full max-w-xl">
                <ClientCreator onClientCreated={handleClientCreated} onClose={() => setIsCreatingClient(false)} />
              </motion.div>
            </motion.div>
          )}

          {isInitiatingJourney && (
            <motion.div
              key="modal-initiate-journey"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto"
            >
              <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} className="w-full max-w-4xl my-auto">
                <JourneyInitiator onClientCreated={handleClientCreated} onClose={() => setIsInitiatingJourney(false)} />
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Prompt-Driven Copilot Right Panel for Personas (including RM and Customer when toggled) */}
      {showRmCopilot && activePersona !== 'platform_admin' && (
        isFloating ? (
          /* FLOATING / SLIDE-OVER DRAWER (Prevents middle content from wrapping on small screens) */
          <div className="fixed inset-0 z-50 pointer-events-none flex justify-end">
            {/* Backdrop: Clicking closes or dims background */}
            <div 
              className="fixed inset-0 bg-slate-900/30 backdrop-blur-2xs transition-opacity pointer-events-auto cursor-pointer"
              onClick={() => setShowRmCopilot(false)}
              title="Click backdrop to close Copilot"
            />
            {/* Drawer Container */}
            <div 
              style={{ width: `${Math.min(effectiveCopilotWidth, windowWidth)}px` }}
              className="relative pointer-events-auto h-full shadow-2xl z-50 flex flex-col bg-white border-l border-slate-200 animate-in slide-in-from-right duration-200"
            >
              <CopilotChatPanel 
                activePersona={activePersona}
                activeClient={activeClient} 
                clients={clients}
                onSelectClient={handleSelectClient}
                activeTab={activeTab}
                onNavigateTab={(tabId) => setActiveTab(tabId)}
                onAddDocument={handleAddDocument}
                onExecuteCommand={(command, args) => {
                  if (command === 'trigger_check') handleTriggerAutonomousFlow();
                  if (command === 'navigate' && args?.tabId) setActiveTab(args.tabId);
                  if (command === 'onboard_agent') {
                    setActiveTab('agent_registry');
                    window.dispatchEvent(new CustomEvent('open_onboard_agent_form', { detail: args }));
                  }
                }}
                onClose={() => setShowRmCopilot(false)}
                widthMode={copilotWidthMode}
                onSetWidthMode={(mode) => {
                  setCopilotWidthMode(mode);
                  if (mode !== 'custom') setCopilotCustomWidth(null);
                }}
                isFloating={isFloating}
                onToggleFloating={() => setCopilotIsFloating(prev => !prev)}
                currentWidth={effectiveCopilotWidth}
              />
            </div>
          </div>
        ) : (
          /* DOCKED SIDE-BY-SIDE RESPONSIVE PANEL (On big screens, sized gracefully so middle content never wraps) */
          <div 
            style={{ width: `${effectiveCopilotWidth}px` }}
            className="shrink-0 h-screen sticky top-0 z-30 shadow-2xl border-l border-[#00A3E0]/20 bg-slate-950 relative flex flex-col transition-[width] duration-150 ease-out"
          >
            {/* Drag handle on the left edge */}
            <div
              onMouseDown={handleMouseDownResize}
              className="absolute -left-1.5 top-0 bottom-0 w-3 cursor-col-resize z-40 group flex items-center justify-center hover:bg-blue-500/20 transition-all select-none"
              title="Drag left/right to resize Copilot width"
            >
              <div className="w-1 h-12 rounded-full bg-slate-400/60 group-hover:bg-blue-500 group-hover:h-16 transition-all" />
            </div>

            <CopilotChatPanel 
              activePersona={activePersona}
              activeClient={activeClient} 
              clients={clients}
              onSelectClient={handleSelectClient}
              activeTab={activeTab}
              onNavigateTab={(tabId) => setActiveTab(tabId)}
              onAddDocument={handleAddDocument}
              onExecuteCommand={(command, args) => {
                if (command === 'trigger_check') handleTriggerAutonomousFlow();
                if (command === 'navigate' && args?.tabId) setActiveTab(args.tabId);
                if (command === 'onboard_agent') {
                  setActiveTab('agent_registry');
                  window.dispatchEvent(new CustomEvent('open_onboard_agent_form', { detail: args }));
                }
              }}
              onClose={() => setShowRmCopilot(false)}
              widthMode={copilotWidthMode}
              onSetWidthMode={(mode) => {
                setCopilotWidthMode(mode);
                if (mode !== 'custom') setCopilotCustomWidth(null);
              }}
              isFloating={isFloating}
              onToggleFloating={() => setCopilotIsFloating(prev => !prev)}
              currentWidth={effectiveCopilotWidth}
            />
          </div>
        )
      )}

      {/* Floating Copilot Button for Personas */}
      {!showRmCopilot && activePersona !== 'platform_admin' && (
        <button
          onClick={() => setShowRmCopilot(true)}
          className="fixed bottom-6 right-6 z-40 bg-[#008752] hover:bg-[#006e42] text-white px-4 py-3 rounded-full shadow-2xl flex items-center gap-2.5 font-bold text-sm cursor-pointer border border-emerald-400/40 transition-all hover:scale-105"
          title={activePersona === 'customer' ? 'Open Customer Copilot' : 'Open RM Copilot'}
        >
          <Bot className="w-5 h-5" />
          <span className="font-sans">{activePersona === 'customer' ? 'Customer Copilot' : 'Copilot'}</span>
        </button>
      )}

      {/* Outreach Email Verification Draft Modal */}
      <OutreachDraftModal
        isOpen={isDraftModalOpen}
        client={draftClient}
        activePersona={activePersona}
        onClose={() => setIsDraftModalOpen(false)}
        onSend={handleConfirmSendEmail}
      />
    </div>
  );
}
