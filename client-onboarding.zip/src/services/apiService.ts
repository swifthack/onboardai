import { ClientProfile } from '../types';

export interface AnalyzeNodePayload {
  client: ClientProfile;
  nodeId: string;
  userPrompt?: string;
}

export interface AnalyzeNodeResponse {
  status: string;
  logs: string[];
  findings?: string[];
  summary?: string;
  metrics?: Record<string, any>;
  aiAnalysis?: string;
}

export interface GenerateClientPayload {
  companyName: string;
  jurisdiction: string;
  industry: string;
  authorizerName: string;
  authorizerEmail: string;
}

export interface CopilotMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface CopilotResponse {
  reply: string;
  action?: {
    type: string;
    params?: Record<string, any>;
  };
}

export const apiService = {
  /**
   * Analyze node with server-side Gemini intelligence
   */
  async analyzeNode(payload: AnalyzeNodePayload): Promise<AnalyzeNodeResponse> {
    const response = await fetch('/api/onboarding/analyze-node', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData.error || `HTTP ${response.status} API response error`);
    }

    return response.json();
  },

  /**
   * Generate AI-synthesized client profile
   */
  async generateClient(payload: GenerateClientPayload): Promise<{ client: ClientProfile; summary: string }> {
    const response = await fetch('/api/onboarding/generate-client', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData.error || `HTTP ${response.status} failed to generate client`);
    }

    return response.json();
  },

  /**
   * Ask Relationship Manager Copilot
   */
  async askRmCopilot(messages: CopilotMessage[], clientContext: ClientProfile | null): Promise<CopilotResponse> {
    const response = await fetch('/api/rm/copilot', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages, clientContext })
    });

    if (!response.ok) {
      throw new Error('Server connection error while consulting RM Copilot');
    }

    return response.json();
  },

  /**
   * Ask Customer Copilot
   */
  async askCustomerCopilot(messages: CopilotMessage[], clientContext: ClientProfile): Promise<CopilotResponse> {
    const response = await fetch('/api/customer/copilot', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages, clientContext })
    });

    if (!response.ok) {
      throw new Error('Server connection error while consulting Customer Copilot');
    }

    return response.json();
  }
};
