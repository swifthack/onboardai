import React from 'react';
import { 
  Search, 
  Mail, 
  X, 
  Bot, 
  Lock,
  LogOut,
  ExternalLink 
} from 'lucide-react';
import { AppPersona, PersonaConfig } from '../types';

export interface SentEmail {
  id: string;
  clientName: string;
  email: string;
  subject: string;
  body: string;
  date: string;
  clientId: string;
  status: 'sent' | 'delivered' | 'opened' | 'clicked';
  sentAt?: string;
  deliveredAt?: string;
  openedAt?: string;
  clickedAt?: string;
}

interface HeaderNavbarProps {
  activePersona: AppPersona;
  activeTab: string;
  activeTabsList: { id: string; label: string; icon: React.ComponentType<any> }[];
  currentPersonaInfo: PersonaConfig;
  showSimulatedMailbox: boolean;
  setShowSimulatedMailbox: (val: boolean) => void;
  showRmCopilot: boolean;
  setShowRmCopilot: (val: boolean) => void;
  sentEmails: SentEmail[];
  setSentEmails: React.Dispatch<React.SetStateAction<SentEmail[]>>;
  onLogout?: () => void;
  onSelectPersona?: (p: AppPersona) => void;
  setSelectedClientId: (clientId: string) => void;
}

export function HeaderNavbar({
  activePersona,
  activeTab,
  activeTabsList,
  currentPersonaInfo,
  showSimulatedMailbox,
  setShowSimulatedMailbox,
  showRmCopilot,
  setShowRmCopilot,
  sentEmails,
  setSentEmails,
  onLogout,
  onSelectPersona,
  setSelectedClientId
}: HeaderNavbarProps) {
  const currentTabLabel = activeTabsList.find(t => t.id === activeTab)?.label || 'Dashboard';

  return (
    <header className="relative z-40 w-full bg-[#1a3070] border-b border-[#00A3E0]/30 shadow-md text-white px-6 py-3.5 transition-all duration-200">
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Left side: Breadcrumbs */}
        <div className="flex flex-col text-left self-start md:self-center">
          <span className="text-[10px] font-mono tracking-wider text-[#00A3E0] uppercase font-bold">
            Pages / {currentTabLabel}
          </span>
          <h1 className="text-sm font-bold tracking-tight text-white mt-0.5">
            {currentTabLabel}
          </h1>
        </div>

        {/* Right side: controls, theme toggler, user info */}
        <div className="flex items-center gap-3 self-end md:self-center">
          {/* Search input */}
          <div className="relative w-48 md:w-64">
            <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-[#00A3E0]" />
            <input
              type="text"
              placeholder="Search assets..."
              className="w-full bg-[#0B2545]/60 border border-[#00A3E0]/40 rounded-xl pl-9 pr-4 py-1.5 text-xs outline-none text-white placeholder-[#F4F6F8]/70 focus:ring-1 focus:ring-[#00A3E0] transition-all duration-150"
              disabled
            />
          </div>

          <div className="h-4 w-px bg-[#00A3E0]/30" />

          {/* Simulated Outreach Mailbox */}
          {activePersona !== 'platform_admin' && (
            <div className="relative">
              <button
                onClick={() => setShowSimulatedMailbox(!showSimulatedMailbox)}
              className="relative px-3 py-1.5 bg-[#008752] hover:bg-[#006e42] border border-[#008752] rounded-xl text-white transition cursor-pointer flex items-center gap-2 text-xs font-semibold shadow-sm"
              title="Customer Outreach Mailbox (Simulation)"
            >
              <Mail className="w-4 h-4 text-white" />
              <span>Outreach Inbox</span>
              {sentEmails.length > 0 ? (
                <span className="px-1.5 py-0.5 bg-[#EB001B] text-[10px] font-bold text-white rounded-full">
                  {sentEmails.length}
                </span>
              ) : (
                <span className="px-1.5 py-0.2 bg-[#0B2545] text-[9px] font-mono text-[#00A3E0] rounded-full">
                  0
                </span>
              )}
            </button>

            {showSimulatedMailbox && (
              <>
                <div 
                  className="fixed inset-0 z-[90] bg-black/20 backdrop-blur-[1px]" 
                  onClick={() => setShowSimulatedMailbox(false)} 
                />
                <div className="fixed top-16 right-4 md:right-10 w-[450px] max-w-[92vw] bg-white border-2 border-[#00A3E0] rounded-2xl shadow-2xl z-[100] p-4 text-left overflow-hidden">
                  <div className="flex items-center justify-between pb-3 border-b border-[#F4F6F8] mb-3">
                    <div className="flex items-center gap-2">
                      <Mail className="w-4.5 h-4.5 text-[#008752]" />
                      <h4 className="text-xs font-bold text-[#1C1C1C] font-sans">Simulated Outreach Email Inbox</h4>
                    </div>
                    <div className="flex items-center gap-2">
                      {sentEmails.length > 0 && (
                        <button
                          onClick={() => setSentEmails([])}
                          className="text-[10px] text-[#EB001B] hover:text-rose-700 font-bold uppercase tracking-wider cursor-pointer font-mono"
                        >
                          Clear
                        </button>
                      )}
                      <button
                        onClick={() => setShowSimulatedMailbox(false)}
                        className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-[#F4F6F8] transition"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="max-h-[460px] overflow-y-auto space-y-3 pr-1">
                    {sentEmails.length === 0 ? (
                      <div className="text-center py-8 text-slate-400">
                        <p className="text-xs italic">Simulated mailbox is empty.</p>
                        <p className="text-[10px] mt-2 leading-relaxed">
                          To trigger, select RM persona and click <strong>Initiate Journey</strong> or click <strong>Trigger Client Outreach Email</strong> inside a client's workspace.
                        </p>
                      </div>
                    ) : (
                      sentEmails.map((email) => (
                        <div
                          key={email.id}
                          className="p-3 bg-[#F4F6F8] border border-[#00A3E0]/40 rounded-xl hover:border-[#008752] transition shadow-sm"
                        >
                          <div className="flex justify-between items-start mb-1">
                            <span className="text-[10px] font-bold font-mono text-[#008752] uppercase tracking-wide">
                              TO: {email.clientName}
                            </span>
                            <span className="text-[9px] text-[#4A6572] font-mono">
                              {email.date.split(',')[1] || email.date}
                            </span>
                          </div>
                          <p className="text-xs font-bold text-[#1C1C1C] line-clamp-1">{email.subject}</p>
                          <p className="text-[11px] text-[#1C1C1C] mt-1 whitespace-pre-line bg-white p-2.5 rounded-lg border border-slate-200/80 font-sans leading-relaxed">
                            {email.body}
                          </p>

                          {/* Email engagement tracking tags */}
                          <div className="mt-2.5 pt-2 border-t border-slate-200/80 flex items-center justify-between text-[9px] font-mono">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="px-1.5 py-0.5 bg-emerald-100 text-[#008752] font-bold rounded">
                                SENT ({email.sentAt})
                              </span>
                              {email.deliveredAt && (
                                <span className="px-1.5 py-0.5 bg-blue-100 text-[#002D62] font-bold rounded">
                                  DELIVERED ({email.deliveredAt})
                                </span>
                              )}
                              {email.openedAt && (
                                <span className="px-1.5 py-0.5 bg-cyan-100 text-[#00A3E0] font-bold rounded">
                                  OPENED ({email.openedAt})
                                </span>
                              )}
                              {email.clickedAt && (
                                <span className="px-1.5 py-0.5 bg-emerald-100 text-[#008752] font-bold rounded">
                                  CLICKED ({email.clickedAt})
                                </span>
                              )}
                            </div>

                            <button
                              onClick={() => {
                                setShowSimulatedMailbox(false);
                                if (onSelectPersona) onSelectPersona('customer');
                                setSelectedClientId(email.clientId);
                              }}
                              className="py-1 px-2.5 bg-[#008752] hover:bg-[#006e42] text-white rounded-lg text-[10px] font-bold tracking-wider uppercase transition flex items-center gap-1 cursor-pointer shadow-sm"
                            >
                              <Lock className="w-3 h-3" /> Client Portal
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </>
            )}
          </div>
          )}

          <div className="h-4 w-px bg-[#00A3E0]/30" />

          {/* Copilot Toggle Button - Hidden for Platform Admin Persona */}
          {activePersona !== 'platform_admin' && (
            <button
              onClick={() => setShowRmCopilot(!showRmCopilot)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border ${
                showRmCopilot
                  ? 'bg-[#008752] text-white border-[#008752] shadow-sm'
                  : 'bg-[#0B2545] text-[#00A3E0] border-[#00A3E0]/40 hover:text-white hover:bg-[#002D62]'
              }`}
              title={showRmCopilot ? "Hide Copilot Panel" : "Show Copilot Panel"}
            >
              <Bot className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{showRmCopilot ? 'Hide Copilot' : 'Copilot'}</span>
            </button>
          )}

          <div className="h-4 w-px bg-[#00A3E0]/30" />

          {/* User Profile Badge (Static - No Dropdown) */}
          <div className="flex items-center gap-2 p-1.5 px-3 rounded-xl bg-[#0B2545]/80 border border-[#00A3E0]/30 text-left">
            <div className="h-7 w-7 rounded-full bg-[#008752] text-white flex items-center justify-center font-bold text-xs shadow-sm border border-[#00A3E0]/40 shrink-0">
              {currentPersonaInfo.name.split(' ').map(n => n[0]).join('')}
            </div>
            <div className="hidden md:block">
              <span className="text-xs font-bold text-white block leading-none">{currentPersonaInfo.name}</span>
              <span className="text-[10px] text-[#00A3E0] block mt-1 leading-none font-mono">{currentPersonaInfo.role}</span>
            </div>
          </div>

          {/* Logout Button */}
          <button
            onClick={onLogout}
            className="px-3 py-1.5 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white border border-rose-500/50 shadow-sm transition flex items-center gap-1.5 cursor-pointer"
            title="Log out of current session"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Logout</span>
          </button>
        </div>
      </div>
    </header>
  );
}
