import React, { useState, useEffect, useRef } from 'react';
import { 
  Scan, 
  X, 
  RefreshCw, 
  Trash2, 
  Plus, 
  CheckCircle2,
  Maximize2,
  Minimize2,
  Sparkles,
  ZoomIn,
  ZoomOut,
  RotateCw,
  Lock,
  Copy,
  CheckCheck,
  FileCheck
} from 'lucide-react';
import { UploadedDocument, ClientProfile } from '../../types';
import { DocumentPreviewCanvas } from '../common/DocumentViewerModal';

export interface OcrVerificationPanelProps {
  document: UploadedDocument;
  client: ClientProfile;
  editableOcrData: Record<string, string>;
  onUpdateField: (key: string, value: string) => void;
  onDeleteField: (key: string) => void;
  onAddField: (key: string, value: string) => void;
  isVerifyingOcr: boolean;
  ocrScanningProgress: number | null;
  onSubmitToRm: () => void;
  onOpenFullPreview?: (doc: UploadedDocument) => void;
  onClose: () => void;
  isModal?: boolean;
  onToggleModal?: () => void;
  autoScroll?: boolean;
}

export function OcrVerificationPanel({
  document: doc,
  client,
  editableOcrData,
  onUpdateField,
  onDeleteField,
  onAddField,
  isVerifyingOcr,
  ocrScanningProgress,
  onSubmitToRm,
  onClose,
  isModal = false,
  onToggleModal,
  autoScroll = true
}: OcrVerificationPanelProps) {
  const panelRef = useRef<HTMLDivElement>(null);
  const firstInputRef = useRef<HTMLInputElement>(null);

  const [newKey, setNewKey] = useState('');
  const [newVal, setNewVal] = useState('');
  const [zoomLevel, setZoomLevel] = useState(100);
  const [rotation, setRotation] = useState(0);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Auto-focus and scroll into view when initialized
  useEffect(() => {
    const timer = setTimeout(() => {
      if (panelRef.current) {
        if (autoScroll && !isModal) {
          panelRef.current.scrollIntoView({ 
            behavior: 'smooth', 
            block: 'nearest' 
          });
        }
        panelRef.current.focus({ preventScroll: true });
      }
    }, 60);

    return () => clearTimeout(timer);
  }, [doc.id, isModal, autoScroll]);

  const handleAdd = () => {
    if (!newKey.trim()) return;
    onAddField(newKey.trim(), newVal.trim());
    setNewKey('');
    setNewVal('');
  };

  const handleKeyDownAdd = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAdd();
    }
  };

  const handleZoomIn = () => setZoomLevel(prev => Math.min(prev + 10, 180));
  const handleZoomOut = () => setZoomLevel(prev => Math.max(prev - 10, 50));
  const handleRotate = () => setRotation(prev => (prev + 90) % 360);

  const handleCopy = (key: string, value: string) => {
    navigator.clipboard.writeText(value);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const mergedDocWithCurrentOcr: UploadedDocument = {
    ...doc,
    ocrData: editableOcrData
  };

  const content = (
    <div 
      ref={panelRef}
      tabIndex={-1}
      role="region"
      aria-label={`Full OCR Verification & Document Preview for ${doc.name}`}
      className={`bg-white rounded-2xl text-left flex flex-col focus:outline-none transition-all ${
        isModal 
          ? 'w-full h-full overflow-hidden' 
          : 'w-full h-[660px] border-2 border-blue-500 shadow-2xl ring-4 ring-blue-500/15 overflow-hidden mt-3'
      }`}
    >
      {/* Top Header Bar */}
      <div className="bg-slate-900 text-white px-4 sm:px-6 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0 border-b border-slate-800">
        <div className="flex items-center gap-3 min-w-0">
          <div className="p-2 sm:p-2.5 rounded-xl bg-blue-600 text-white shadow-md shrink-0">
            <Scan className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-sm sm:text-base font-black tracking-tight truncate" title={doc.name}>
                {doc.name}
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 text-[10px] font-mono font-bold border border-blue-400/30 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-blue-400" />
                AI Extraction (99.4% Match)
              </span>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-mono font-semibold border border-emerald-400/30">
                Full Document Preview
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5 truncate">
              {client.companyName} • {client.jurisdiction} • {doc.type}
            </p>
          </div>
        </div>

        {/* Header Controls: Zoom, Rotate, Popout, Close */}
        <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
          {/* Zoom controls */}
          <div className="flex items-center bg-slate-800 rounded-xl p-0.5 border border-slate-700">
            <button
              type="button"
              onClick={handleZoomOut}
              disabled={zoomLevel <= 50}
              className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-700 rounded-lg transition cursor-pointer disabled:opacity-40"
              title="Zoom Out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setZoomLevel(100)}
              className="text-[11px] font-mono font-bold px-2 text-slate-300 hover:text-white transition cursor-pointer"
              title="Reset Zoom to 100%"
            >
              {zoomLevel}%
            </button>
            <button
              type="button"
              onClick={handleZoomIn}
              disabled={zoomLevel >= 180}
              className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-700 rounded-lg transition cursor-pointer disabled:opacity-40"
              title="Zoom In"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
          </div>

          {/* Rotate control */}
          <button
            type="button"
            onClick={handleRotate}
            className="p-2 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 transition cursor-pointer"
            title="Rotate 90°"
          >
            <RotateCw className="w-4 h-4" />
          </button>

          {/* Toggle Modal / Inline if available */}
          {onToggleModal && (
            <button
              type="button"
              onClick={onToggleModal}
              className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer border border-slate-700"
              title={isModal ? 'Dock inline' : 'Expand full screen'}
            >
              {isModal ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
              <span className="hidden md:inline">{isModal ? 'Dock In-Place' : 'Full Screen'}</span>
            </button>
          )}

          {/* Close button */}
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition cursor-pointer border border-transparent hover:border-slate-700"
            title="Close OCR Preview"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Body Split: Full Document Preview (Left) vs Interactive OCR Attributes (Right) */}
      <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-12 bg-white overflow-hidden">
        
        {/* LEFT COLUMN: FULL HIGH-RESOLUTION DOCUMENT PREVIEW */}
        <div className="lg:col-span-7 h-full flex flex-col bg-slate-100/70 border-r border-slate-200 overflow-hidden min-h-0">
          {/* Subheader bar for document canvas */}
          <div className="bg-slate-200/70 border-b border-slate-300/80 px-4 py-2 flex items-center justify-between text-[11px] font-mono text-slate-600 shrink-0">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-slate-900 text-white text-[10px] font-bold tracking-wider uppercase">
                CERTIFIED TRUE COPY
              </span>
              <span className="text-slate-500 font-sans hidden sm:inline">Official Vault Record</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-slate-500">{doc.size || '2.4 MB'}</span>
              <span className="flex items-center gap-1 text-emerald-700 font-semibold">
                <Lock className="w-3 h-3 text-emerald-600" /> Tamper-Evident SHA-256
              </span>
            </div>
          </div>

          {/* Document Preview Canvas Scrollport */}
          <div className="flex-1 overflow-y-auto overflow-x-auto p-4 sm:p-8 flex justify-center items-start relative select-none">
            {/* Live scanning progress laser animation */}
            {ocrScanningProgress !== null && (
              <div className="absolute inset-x-0 top-0 z-20 pointer-events-none flex flex-col items-center">
                <div className="w-full h-1 bg-gradient-to-r from-transparent via-blue-500 to-transparent animate-pulse shadow-lg shadow-blue-500/50" />
                <div className="mt-4 px-3 py-1.5 rounded-full bg-blue-600/90 text-white text-xs font-mono font-bold flex items-center gap-2 shadow-xl backdrop-blur-xs">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  Extracting OCR Features ({ocrScanningProgress}%)...
                </div>
              </div>
            )}

            {/* High-Resolution Document Canvas */}
            <DocumentPreviewCanvas 
              document={mergedDocWithCurrentOcr} 
              zoomLevel={zoomLevel} 
              rotation={rotation} 
            />
          </div>
        </div>

        {/* RIGHT COLUMN: INTERACTIVE OCR KEY-VALUE ATTRIBUTES */}
        <div className="lg:col-span-5 h-full flex flex-col bg-white overflow-hidden min-h-0 text-left">
          {/* Subheader for OCR Attributes */}
          <div className="p-4 border-b border-slate-100 flex items-center justify-between shrink-0 bg-slate-50/50">
            <div>
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider font-mono flex items-center gap-1.5">
                <FileCheck className="w-4 h-4 text-blue-600" />
                <span>Extracted Key-Value Attributes</span>
              </h4>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Review and edit parsed values before submitting to Relationship Manager.
              </p>
            </div>
            <span className="px-2.5 py-1 rounded-full text-[10px] font-mono font-bold bg-blue-50 text-blue-800 border border-blue-200">
              {Object.keys(editableOcrData).length} Fields
            </span>
          </div>

          {/* Real-time OCR scanning progress bar */}
          {ocrScanningProgress !== null && (
            <div className="p-3 bg-blue-50 border-b border-blue-200 space-y-1.5 shrink-0 animate-pulse">
              <div className="flex items-center justify-between text-xs font-mono font-bold text-blue-900">
                <span className="flex items-center gap-1.5">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-blue-600" />
                  Running Neural Extraction Pipeline...
                </span>
                <span>{ocrScanningProgress}%</span>
              </div>
              <div className="w-full bg-blue-200 rounded-full h-1.5 overflow-hidden">
                <div 
                  className="bg-blue-600 h-1.5 rounded-full transition-all duration-300"
                  style={{ width: `${ocrScanningProgress}%` }}
                />
              </div>
            </div>
          )}

          {/* Scrollable Editable Key-Value Attributes List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-2.5 min-h-0">
            {Object.entries(editableOcrData).map(([key, val], idx) => (
              <div 
                key={key} 
                className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5 hover:border-blue-300 transition-colors group"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[11px] font-bold text-slate-700 font-mono uppercase tracking-wider truncate" title={key}>
                    {key}
                  </span>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleCopy(key, String(val))}
                      className="text-[10px] text-slate-400 hover:text-blue-600 font-medium flex items-center gap-1 cursor-pointer transition p-1 rounded hover:bg-slate-200"
                      title="Copy value"
                    >
                      {copiedKey === key ? (
                        <span className="text-emerald-600 font-bold flex items-center gap-1">
                          <CheckCheck className="w-3 h-3" /> Copied
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 opacity-60 group-hover:opacity-100">
                          <Copy className="w-3 h-3" />
                        </span>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteField(key)}
                      className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition cursor-pointer"
                      title="Remove field"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <input
                  ref={idx === 0 ? firstInputRef : undefined}
                  type="text"
                  value={val}
                  onChange={(e) => onUpdateField(key, e.target.value)}
                  className="w-full text-xs font-semibold text-slate-900 bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono transition"
                />
              </div>
            ))}

            {/* Add New Key-Value Field Row */}
            <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl space-y-2 mt-3">
              <span className="text-[10px] font-bold text-blue-900 uppercase font-mono block">
                + Add Custom Extracted Attribute
              </span>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Key (e.g. Authorized Shareholder)"
                  value={newKey}
                  onChange={(e) => setNewKey(e.target.value)}
                  onKeyDown={handleKeyDownAdd}
                  className="w-2/5 text-xs bg-white border border-blue-200 rounded-lg px-2.5 py-1.5 outline-none focus:ring-1 focus:ring-blue-500 text-slate-800 font-medium"
                />
                <input
                  type="text"
                  placeholder="Attribute Value"
                  value={newVal}
                  onChange={(e) => setNewVal(e.target.value)}
                  onKeyDown={handleKeyDownAdd}
                  className="flex-1 text-xs bg-white border border-blue-200 rounded-lg px-2.5 py-1.5 outline-none focus:ring-1 focus:ring-blue-500 text-slate-800 font-medium"
                />
                <button
                  type="button"
                  onClick={handleAdd}
                  disabled={!newKey.trim()}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white text-xs font-bold rounded-lg transition flex items-center gap-1 shrink-0 cursor-pointer shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Add
                </button>
              </div>
            </div>
          </div>

          {/* Institutional Note in Right Column */}
          <div className="p-3 bg-slate-50 border-t border-slate-200 text-slate-600 text-[11px] leading-relaxed shrink-0">
            <p className="flex items-center gap-1.5 font-medium text-slate-700">
              <Lock className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span>Direct edit mode enables customer attestation before compliance sign-off.</span>
            </p>
          </div>
        </div>
      </div>

      {/* Bottom Footer Actions */}
      <div className="bg-white border-t border-slate-200 px-4 sm:px-6 py-3.5 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-2 text-xs text-slate-600">
          <span className="w-2 h-2 rounded-full bg-blue-500 animate-ping" />
          <p className="text-[11px] sm:text-xs">
            Submitting validates <strong className="text-slate-900 font-mono">{Object.keys(editableOcrData).length} attributes</strong> and dispatches to Relationship Manager.
          </p>
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 sm:flex-none px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer border border-slate-200"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onSubmitToRm}
            disabled={isVerifyingOcr}
            className="flex-1 sm:flex-none px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
          >
            {isVerifyingOcr ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Dispatching to RM Action Center...</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Confirm &amp; Submit to RM Review</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );

  // If modal mode, render in a backdrop overlay
  if (isModal) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
        <div 
          className="fixed inset-0 cursor-pointer" 
          onClick={onClose} 
          title="Click backdrop to close" 
        />
        <div className="relative z-10 w-full max-w-7xl h-[92vh] max-h-[94vh] flex flex-col bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-150">
          {content}
        </div>
      </div>
    );
  }

  return content;
}
