import React, { useState, useMemo } from 'react';
import { 
  Building2, 
  Search, 
  ArrowRight, 
  Clock, 
  ShieldCheck, 
  AlertCircle, 
  TrendingUp, 
  CheckCircle2, 
  MapPin, 
  Calendar, 
  ChevronRight,
  Plus,
  Filter,
  Check,
  Briefcase
} from 'lucide-react';
import { ClientProfile } from '../../types';

export interface WorklistCase {
  id: string;
  reference: string;
  status: 'In Progress' | 'Action Required' | 'Awaiting Client response' | 'Approved';
  statusColor: string;
  riskTier: 'Low Risk' | 'Medium Risk' | 'High Risk (EDD)';
  riskColor: string;
  jurisdiction: string;
  entityName: string;
  clientTier: 'Platinum' | 'Gold' | 'Silver';
  lei: string;
  targetLive: string;
  contactName: string;
  contactRole: string;
  annualTurnover: string;
  progressPercent: number;
  totalStages: number;
  completedStages: number;
  stagesCompletedText: string;
  slaStatus: string;
  attentionNote?: string;
  clientId: string;
}

const DEFAULT_CASES: WorklistCase[] = [
  {
    id: 'case-1',
    reference: 'ONB-2025-8841',
    status: 'In Progress',
    statusColor: 'bg-blue-50 text-blue-700 border-blue-200',
    riskTier: 'Medium Risk',
    riskColor: 'bg-amber-50 text-amber-700 border-amber-200',
    jurisdiction: 'United Kingdom / England & Wales',
    entityName: 'Meridian Components International Ltd.',
    clientTier: 'Platinum',
    lei: '5493001KJTIIGC8Y1R12',
    targetLive: '2025-03-31',
    contactName: 'Julian Vance, CFA',
    contactRole: 'Group Chief Financial Officer',
    annualTurnover: '£285,000,000 / annum',
    progressPercent: 68,
    totalStages: 6,
    completedStages: 1,
    stagesCompletedText: '1 of 6 stages completed',
    slaStatus: 'SLA: On Track',
    clientId: 'client_meridian'
  },
  {
    id: 'case-2',
    reference: 'ONB-2025-9102',
    status: 'Action Required',
    statusColor: 'bg-rose-50 text-rose-700 border-rose-200',
    riskTier: 'Low Risk',
    riskColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    jurisdiction: 'United States / Delaware',
    entityName: 'Apex Quantum Logistics Corp.',
    clientTier: 'Silver',
    lei: '9845009B8A712EF90123',
    targetLive: '2025-04-15',
    contactName: 'Claire Theriot',
    contactRole: 'Head of Global Treasury',
    annualTurnover: '$410,000,000 / annum',
    progressPercent: 42,
    totalStages: 6,
    completedStages: 1,
    stagesCompletedText: '1 of 6 stages completed',
    slaStatus: 'SLA: On Track',
    attentionNote: 'W-9 review',
    clientId: 'client_apex'
  },
  {
    id: 'case-3',
    reference: 'ONB-2025-9430',
    status: 'Awaiting Client response',
    statusColor: 'bg-sky-50 text-sky-700 border-sky-200',
    riskTier: 'High Risk (EDD)',
    riskColor: 'bg-rose-50 text-rose-700 border-rose-200',
    jurisdiction: 'Switzerland / Geneva',
    entityName: 'Aethelgard Energy Partners SA',
    clientTier: 'Gold',
    lei: '2138006E881479FABC54',
    targetLive: '2025-03-20',
    contactName: 'Dr. Beatrix Von Berg',
    contactRole: 'Managing Director & General Counsel',
    annualTurnover: 'CHF 620,000,000 / annum',
    progressPercent: 91,
    totalStages: 6,
    completedStages: 4,
    stagesCompletedText: '4 of 6 stages completed',
    slaStatus: 'SLA: On Track',
    clientId: 'client_aethelgard'
  },
  {
    id: 'case-4',
    reference: 'ONB-2025-9755',
    status: 'Approved',
    statusColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    riskTier: 'Low Risk',
    riskColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    jurisdiction: 'Singapore / Central Region',
    entityName: 'Aether Aero-Tech Pte Ltd',
    clientTier: 'Platinum',
    lei: '54930099K11002233445',
    targetLive: '2025-05-10',
    contactName: 'Dr. Evelyn Chen',
    contactRole: 'Chief Executive Officer',
    annualTurnover: '$140,000,000 / annum',
    progressPercent: 100,
    totalStages: 6,
    completedStages: 6,
    stagesCompletedText: '6 of 6 stages completed',
    slaStatus: 'SLA: On Track',
    clientId: 'client_1'
  }
];

interface CorporateOnboardingWorklistProps {
  clients: ClientProfile[];
  onSelectClient: (clientId: string) => void;
  onInitiateJourney?: () => void;
}

export default function CorporateOnboardingWorklist({
  clients,
  onSelectClient,
  onInitiateJourney
}: CorporateOnboardingWorklistProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [tierFilter, setTierFilter] = useState('all');
  const [riskFilter, setRiskFilter] = useState('all');

  // Map cases to match actual loaded clients if they exist, or use default cases
  const cases = useMemo(() => {
    return DEFAULT_CASES.map(dc => {
      // Find matching client if available
      const matchedClient = clients.find(
        c => c.companyName.toLowerCase() === dc.entityName.toLowerCase() || c.id === dc.clientId
      );
      if (matchedClient) {
        const totalNodes = matchedClient.workflowNodes?.length || dc.totalStages || 6;
        const completedNodes = matchedClient.workflowNodes
          ? matchedClient.workflowNodes.filter(n => n.status === 'completed').length
          : dc.completedStages;
        return {
          ...dc,
          clientId: matchedClient.id,
          totalStages: totalNodes,
          completedStages: completedNodes,
          stagesCompletedText: `${completedNodes} of ${totalNodes} stages completed`
        };
      }
      return dc;
    });
  }, [clients]);

  // Filter cases
  const filteredCases = useMemo(() => {
    return cases.filter(c => {
      const q = searchTerm.toLowerCase().trim();
      const matchesSearch = !q || 
        c.entityName.toLowerCase().includes(q) ||
        c.reference.toLowerCase().includes(q) ||
        c.lei.toLowerCase().includes(q) ||
        c.jurisdiction.toLowerCase().includes(q) ||
        c.contactName.toLowerCase().includes(q);

      const matchesStatus = statusFilter === 'all' || c.status === statusFilter;
      const matchesTier = tierFilter === 'all' || c.clientTier === tierFilter;
      const matchesRisk = riskFilter === 'all' || c.riskTier === riskFilter;

      return matchesSearch && matchesStatus && matchesTier && matchesRisk;
    });
  }, [cases, searchTerm, statusFilter, tierFilter, riskFilter]);

  const handleOpenCase = (caseItem: WorklistCase) => {
    // If client is already in clients list, select it
    const existing = clients.find(c => c.id === caseItem.clientId || c.companyName.toLowerCase() === caseItem.entityName.toLowerCase());
    if (existing) {
      onSelectClient(existing.id);
    } else if (clients.length > 0) {
      // Fallback to active first client
      onSelectClient(clients[0].id);
    }
  };

  return (
    <div className="space-y-6 text-left">
      {/* HEADER BAR */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Corporate Onboarding Worklist
          </h1>
          <p className="text-sm text-slate-500 mt-1 max-w-3xl leading-relaxed">
            Drive end-to-end institutional client onboarding, orchestrate multi-stage KYC/AML compliance, and inspect multi-entity structural knowledge graphs.
          </p>
        </div>

        {onInitiateJourney && (
          <button
            type="button"
            onClick={onInitiateJourney}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition shadow-xs cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4" />
            Initiate Onboarding Journey
          </button>
        )}
      </div>

      {/* 5 TOP METRIC KPI CARDS (ALL LIGHT/WHITE BACKGROUNDS) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Active Portfolio Pipeline */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4.5 shadow-xs flex flex-col justify-between hover:border-slate-300 transition">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Active Portfolio Pipeline
          </span>
          <div className="mt-2.5">
            <div className="text-2xl font-black text-slate-900 tracking-tight font-sans">
              £1.45 Billion
            </div>
            <p className="text-xs font-medium text-slate-500 mt-0.5">
              Total ARR
            </p>
          </div>
        </div>

        {/* Active Onboardings */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4.5 shadow-xs flex flex-col justify-between hover:border-slate-300 transition">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Active Onboardings
          </span>
          <div className="mt-2.5">
            <div className="text-2xl font-black text-slate-900 tracking-tight font-sans">
              4 cases
            </div>
            <p className="text-xs font-medium text-slate-500 mt-0.5">
              3 in high velocity pipeline
            </p>
          </div>
        </div>

        {/* Average Cycle Time */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4.5 shadow-xs flex flex-col justify-between hover:border-slate-300 transition">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Average Cycle Time
          </span>
          <div className="mt-2.5">
            <div className="text-2xl font-black text-slate-900 tracking-tight font-sans">
              21.4 days
            </div>
            <p className="text-xs font-semibold text-emerald-600 mt-0.5 flex items-center gap-1">
              <span>-3.6 days vs 25-day benchmark</span>
            </p>
          </div>
        </div>

        {/* Sanctions & Screening */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4.5 shadow-xs flex flex-col justify-between hover:border-slate-300 transition">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Sanctions & Screening
          </span>
          <div className="mt-2.5">
            <div className="text-2xl font-black text-emerald-600 tracking-tight font-sans">
              100% clean
            </div>
            <p className="text-xs font-medium text-slate-500 mt-0.5">
              0 unresolved regulatory blocks
            </p>
          </div>
        </div>

        {/* Action Attention */}
        <div className="bg-white border border-amber-200/80 bg-amber-50/20 rounded-2xl p-4.5 shadow-xs flex flex-col justify-between hover:border-amber-300 transition">
          <span className="text-xs font-semibold text-amber-700 uppercase tracking-wider flex items-center gap-1">
            <AlertCircle className="w-3.5 h-3.5 text-amber-600" /> Action Attention
          </span>
          <div className="mt-2.5">
            <div className="text-2xl font-black text-amber-900 tracking-tight font-sans">
              1 case
            </div>
            <p className="text-xs font-semibold text-amber-700 mt-0.5">
              Apex Quantum (W-9 review)
            </p>
          </div>
        </div>
      </div>

      {/* FILTER & SEARCH CONTROLS */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Search Bar */}
        <div className="relative flex-1 min-w-[280px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by legal entity name, trading name, LEI, or reference..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Status Filter */}
          <div className="relative">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="appearance-none bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl px-3.5 py-2 pr-8 text-xs font-semibold text-slate-700 cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Statuses (4)</option>
              <option value="In Progress">In Progress</option>
              <option value="Action Required">Action Required</option>
              <option value="Awaiting Client response">Awaiting Client response</option>
              <option value="Approved">Approved</option>
            </select>
            <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 text-[10px]">
              ▼
            </div>
          </div>

          {/* Client Tier Filter */}
          <div className="relative">
            <select
              value={tierFilter}
              onChange={(e) => setTierFilter(e.target.value)}
              className="appearance-none bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl px-3.5 py-2 pr-8 text-xs font-semibold text-slate-700 cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Client Tiers</option>
              <option value="Platinum">Platinum</option>
              <option value="Gold">Gold</option>
              <option value="Silver">Silver</option>
            </select>
            <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 text-[10px]">
              ▼
            </div>
          </div>

          {/* Risk Tier Filter */}
          <div className="relative">
            <select
              value={riskFilter}
              onChange={(e) => setRiskFilter(e.target.value)}
              className="appearance-none bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl px-3.5 py-2 pr-8 text-xs font-semibold text-slate-700 cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Risk Tiers</option>
              <option value="Low Risk">Low Risk</option>
              <option value="Medium Risk">Medium Risk</option>
              <option value="High Risk (EDD)">High Risk (EDD)</option>
            </select>
            <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 text-[10px]">
              ▼
            </div>
          </div>

          {/* Reset button if active */}
          {(searchTerm || statusFilter !== 'all' || tierFilter !== 'all' || riskFilter !== 'all') && (
            <button
              type="button"
              onClick={() => {
                setSearchTerm('');
                setStatusFilter('all');
                setTierFilter('all');
                setRiskFilter('all');
              }}
              className="text-xs font-semibold text-rose-600 hover:text-rose-700 px-2 py-1 transition cursor-pointer"
            >
              Reset
            </button>
          )}
        </div>
      </div>

      {/* CORPORATE CASE CARDS LIST */}
      <div className="space-y-4">
        {filteredCases.length > 0 ? (
          filteredCases.map((caseItem) => (
            <div
              key={caseItem.id}
              className="bg-white border border-slate-200 hover:border-blue-300 rounded-2xl p-6 shadow-xs hover:shadow-md transition duration-200 group"
            >
              {/* TOP CASE META LINE */}
              <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-mono text-xs font-bold px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 border border-slate-200">
                    {caseItem.reference}
                  </span>

                  <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full border ${caseItem.statusColor}`}>
                    {caseItem.status}
                  </span>

                  <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full border ${caseItem.riskColor}`}>
                    {caseItem.riskTier}
                  </span>
                </div>

                <div className="flex items-center gap-1.5 text-xs font-medium text-slate-500">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span>{caseItem.jurisdiction}</span>
                </div>
              </div>

              {/* MAIN ENTITY DETAILS & ONBOARDING JOURNEY CARD */}
              <div className="py-4 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                {/* Left side: Entity information, badges, contact & turnover */}
                <div className="flex-1 min-w-0 space-y-3">
                  <h2 className="text-xl font-bold text-slate-900 tracking-tight group-hover:text-blue-600 transition">
                    {caseItem.entityName}
                  </h2>

                  {/* Sub-pills: Client Tier, LEI, Target Live */}
                  <div className="flex flex-wrap items-center gap-2.5 text-xs text-slate-600">
                    <span className="inline-flex items-center gap-1 font-medium bg-slate-50 px-2.5 py-1 rounded-md border border-slate-200">
                      <span className="text-slate-400">Client Tier:</span>
                      <strong className="text-slate-800">{caseItem.clientTier}</strong>
                    </span>

                    <span className="inline-flex items-center gap-1 font-mono text-[11px] bg-slate-50 px-2.5 py-1 rounded-md border border-slate-200">
                      <span className="text-slate-400">LEI:</span>
                      <span className="text-slate-700 font-semibold">{caseItem.lei}</span>
                    </span>

                    <span className="inline-flex items-center gap-1 font-medium bg-slate-50 px-2.5 py-1 rounded-md border border-slate-200">
                      <span className="text-slate-400">Target Live:</span>
                      <strong className="text-slate-800">{caseItem.targetLive}</strong>
                    </span>
                  </div>

                  {/* Contact & Turnover Line */}
                  <div className="pt-1 text-xs text-slate-600 flex flex-wrap items-center gap-x-2 gap-y-1">
                    <span className="font-semibold text-slate-700">Contact:</span>
                    <span>{caseItem.contactName} ({caseItem.contactRole})</span>
                    <span className="text-slate-300">·</span>
                    <span className="font-semibold text-slate-700">Annual Turnover:</span>
                    <span className="font-bold text-slate-900">{caseItem.annualTurnover}</span>
                  </div>
                </div>

                {/* Right side: Small card layout just above "Open Onboarding Case" */}
                <div className="w-full lg:w-80 shrink-0 flex flex-col gap-2.5">
                  {/* Small Onboarding Journey Card */}
                  <div className="bg-slate-50/90 border border-slate-200/90 rounded-xl p-3.5 shadow-2xs text-left">
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="font-bold text-slate-800">
                        Onboarding Journey
                      </span>
                      <span className="font-black text-blue-600 font-mono text-sm">
                        {caseItem.progressPercent}%
                      </span>
                    </div>

                    <div className="text-[11px] text-slate-500 font-medium mb-2">
                      {caseItem.stagesCompletedText}
                    </div>

                    {/* Segmented Progress Bar: pieces based on number of stages */}
                    <div className="flex items-center gap-1.5 w-full mb-2.5">
                      {Array.from({ length: caseItem.totalStages || 6 }).map((_, idx) => {
                        const isCompleted = idx < (caseItem.completedStages ?? 0);
                        return (
                          <div
                            key={idx}
                            className={`h-2 flex-1 rounded-full transition-all duration-300 ${
                              isCompleted
                                ? 'bg-emerald-500 shadow-2xs'
                                : 'bg-slate-200'
                            }`}
                            title={`Stage ${idx + 1} of ${caseItem.totalStages || 6}: ${
                              isCompleted ? 'Completed' : 'Pending'
                            }`}
                          />
                        );
                      })}
                    </div>

                    {/* SLA & Attention Indicators */}
                    <div className="flex items-center justify-between text-[11px]">
                      <div className="flex items-center gap-1.5 font-semibold text-emerald-600">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                        <span>{caseItem.slaStatus}</span>
                      </div>
                      {caseItem.attentionNote && (
                        <span className="text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded text-[10px] font-bold border border-amber-200">
                          {caseItem.attentionNote}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Open Case Action Button (just below the small card) */}
                  <button
                    type="button"
                    onClick={() => handleOpenCase(caseItem)}
                    className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-xs hover:shadow-md transition cursor-pointer"
                  >
                    <span>Open Onboarding Case</span>
                    <ArrowRight className="w-3.5 h-3.5 transition group-hover:translate-x-0.5" />
                  </button>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center">
            <p className="text-xs font-mono text-slate-400">
              No institutional onboarding cases match the current filter criteria.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
