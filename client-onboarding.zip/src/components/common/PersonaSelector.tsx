import React, { useState, useRef, useEffect } from 'react';
import { AppPersona } from '../../types';
import { 
  Lock, 
  Mail, 
  ArrowRight, 
  ChevronDown, 
  Check, 
  UserCheck, 
  ShieldCheck, 
  ClipboardCheck, 
  Sliders, 
  User, 
  Sparkles 
} from 'lucide-react';

interface PersonaSelectorProps {
  onSelect: (persona: AppPersona, autoVerifyCustomer?: boolean) => void;
  activePersona: AppPersona | null;
  onOpenAgentGenerator?: () => void;
}

interface PersonaOption {
  id: AppPersona;
  label: string;
  role: string;
  email: string;
  badge: string;
  icon: React.ElementType;
}

const PERSONAS_LIST: PersonaOption[] = [
  {
    id: 'rm',
    label: 'Relationship Manager',
    role: 'Manage customer journeys & pipeline',
    email: 's.jenkins@meridian-global.bank',
    badge: 'bg-indigo-100 text-indigo-700 border border-indigo-200',
    icon: UserCheck
  },
  {
    id: 'compliance_officer',
    label: 'Compliance Officer',
    role: 'AML/PEP screening & escalations',
    email: 'd.vance@compliance-risk.org',
    badge: 'bg-rose-100 text-rose-700 border border-rose-200',
    icon: ShieldCheck
  },
  {
    id: 'operations_officer',
    label: 'Operations Officer',
    role: 'Document verification & operational sign-offs',
    email: 'e.rostova@operations-ops.corp',
    badge: 'bg-amber-100 text-amber-700 border border-amber-200',
    icon: ClipboardCheck
  },
  {
    id: 'platform_admin',
    label: 'Platform Admin',
    role: 'System health, telemetry & topology',
    email: 'alex.mercer@onboard.ai',
    badge: 'bg-blue-100 text-blue-700 border border-blue-200',
    icon: Sliders
  },
  {
    id: 'customer',
    label: 'Customer Portal',
    role: 'Self-service verification & document vault',
    email: 'julian.vance@meridian-holding.co.uk',
    badge: 'bg-emerald-100 text-emerald-700 border border-emerald-200',
    icon: User
  }
];

export default function PersonaSelector({ onSelect, onOpenAgentGenerator }: PersonaSelectorProps) {
  const [selectedPersona, setSelectedPersona] = useState<AppPersona>('rm');
  const [email, setEmail] = useState<string>('s.jenkins@meridian-global.bank');
  const [password, setPassword] = useState<string>('••••••••••••');
  const [isDropdownOpen, setIsDropdownOpen] = useState<boolean>(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Close dropdown on Escape key
  useEffect(() => {
    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        setIsDropdownOpen(false);
      }
    }
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  const handleSelectPersona = (p: AppPersona) => {
    setSelectedPersona(p);
    const found = PERSONAS_LIST.find((item) => item.id === p);
    if (found) {
      setEmail(found.email);
    }
    setIsDropdownOpen(false);
  };

  const handleAuthenticate = (e: React.FormEvent) => {
    e.preventDefault();
    onSelect(selectedPersona, selectedPersona === 'customer');
  };

  const activePersonaItem = PERSONAS_LIST.find((p) => p.id === selectedPersona) || PERSONAS_LIST[0];
  const ActiveIcon = activePersonaItem.icon;

  return (
    <div className="min-h-screen w-full flex flex-col md:flex-row font-sans">
      {/* LEFT PANEL: Dark Blue Background */}
      <div className="w-full md:w-1/2 bg-[#0B1E38] text-white flex flex-col justify-between p-8 sm:p-12 lg:p-16">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-blue-600 flex items-center justify-center font-bold text-white text-lg shadow-sm">
            O
          </div>
          <span className="font-extrabold text-xl tracking-tight text-white">
            Onboard.ai
          </span>
        </div>

        <div className="my-auto py-10 max-w-xl mx-auto text-center">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight mb-6">
            Institutional Client Onboarding &amp; Intelligence
          </h1>
          <p className="text-base sm:text-lg lg:text-xl text-slate-300 leading-relaxed font-normal">
            Accelerate corporate due diligence, visualize complex ownership structures with fCoSE, and orchestrate global banking mandates from a single, secure interface.
          </p>
        </div>

        <div className="pt-6 border-t border-slate-800/80 text-xs text-slate-400 text-center">
          Enterprise Security &bull; Multi-Tenant Isolation &bull; Regulatory Compliance
        </div>
      </div>

      {/* RIGHT PANEL: Sign in to platform with persona dropdown */}
      <div className="w-full md:w-1/2 bg-slate-50 flex items-center justify-center p-6 sm:p-10 lg:p-12">
        <div className="w-full max-w-xl bg-white border border-slate-200 rounded-2xl p-8 sm:p-10 lg:p-12 shadow-sm">
          <div className="mb-7">
            <h2 className="text-2xl font-bold text-slate-900">Sign in to Platform</h2>
            <p className="text-sm text-slate-500 mt-1.5">
              Select a persona from the drop-down to populate credentials, then authenticate.
            </p>
          </div>

          {/* Persona Selection Dropdown Component */}
          <div className="mb-6 relative" ref={dropdownRef}>
            <div className="flex items-center justify-between mb-2">
              <label htmlFor="persona-select-button" className="block text-sm font-semibold text-slate-700">
                Select Persona
              </label>
              <span className="text-[11px] font-mono text-slate-400">
                {PERSONAS_LIST.length} Personas Available
              </span>
            </div>

            {/* Synchronized Accessible Native Select */}
            <select
              id="persona-select"
              aria-label="Select Persona Dropdown"
              value={selectedPersona}
              onChange={(e) => handleSelectPersona(e.target.value as AppPersona)}
              className="sr-only"
            >
              {PERSONAS_LIST.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.label} - {p.email}
                </option>
              ))}
            </select>

            {/* Dropdown Trigger Button */}
            <button
              id="persona-select-button"
              type="button"
              onClick={() => setIsDropdownOpen((prev) => !prev)}
              className={`w-full px-4 py-3 bg-white border rounded-xl text-left flex items-center justify-between transition cursor-pointer shadow-2xs ${
                isDropdownOpen
                  ? 'border-blue-600 ring-2 ring-blue-500/20'
                  : 'border-slate-300 hover:border-blue-400'
              }`}
              aria-haspopup="listbox"
              aria-expanded={isDropdownOpen}
            >
              <div className="flex items-center gap-3 min-w-0 flex-1">
                <div className={`p-2 rounded-lg shrink-0 ${activePersonaItem.badge}`}>
                  <ActiveIcon className="w-4 h-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-slate-900 truncate">
                      {activePersonaItem.label}
                    </span>
                    <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200 font-bold uppercase shrink-0">
                      Active
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-500 truncate mt-0.5">
                    <span className="truncate">{activePersonaItem.role}</span>
                    <span className="text-slate-300 hidden sm:inline">•</span>
                    <span className="font-mono text-[11px] text-slate-400 shrink-0 hidden sm:inline">{activePersonaItem.email}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-1.5 pl-3 text-slate-400 shrink-0">
                <span className="text-xs font-semibold text-blue-600 hidden sm:inline">Change</span>
                <ChevronDown
                  className={`w-4 h-4 text-slate-500 transition-transform duration-200 ${
                    isDropdownOpen ? 'rotate-180 text-blue-600' : ''
                  }`}
                />
              </div>
            </button>

            {/* Dropdown Menu Options Panel */}
            {isDropdownOpen && (
              <div
                id="persona-dropdown-menu"
                className="absolute z-50 left-0 right-0 mt-2 bg-white border border-slate-200 rounded-2xl shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-100 divide-y divide-slate-100"
                role="listbox"
              >
                <div className="p-2 space-y-1 max-h-80 overflow-y-auto">
                  {PERSONAS_LIST.map((p) => {
                    const isSelected = selectedPersona === p.id;
                    const OptionIcon = p.icon;
                    return (
                      <button
                        key={p.id}
                        type="button"
                        role="option"
                        aria-selected={isSelected}
                        onClick={() => handleSelectPersona(p.id)}
                        className={`w-full p-3 rounded-xl text-left flex items-center justify-between gap-3 transition cursor-pointer ${
                          isSelected
                            ? 'bg-blue-50/80 border border-blue-200 text-blue-900 font-semibold'
                            : 'hover:bg-slate-50 border border-transparent text-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0 flex-1">
                          <div className={`p-2 rounded-lg shrink-0 ${p.badge}`}>
                            <OptionIcon className="w-4 h-4" />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-bold text-slate-900 truncate">
                                {p.label}
                              </span>
                              {isSelected && (
                                <span className="text-[9px] font-mono px-1.5 py-0.5 bg-blue-100 text-blue-800 rounded font-bold uppercase">
                                  Current
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-slate-500 truncate mt-0.5">
                              {p.role}
                            </p>
                            <p className="text-[10px] text-slate-400 font-mono truncate">
                              {p.email}
                            </p>
                          </div>
                        </div>

                        {isSelected ? (
                          <div className="p-1 rounded-full bg-blue-600 text-white shrink-0">
                            <Check className="w-3.5 h-3.5" />
                          </div>
                        ) : (
                          <span className="text-xs text-slate-400 font-medium shrink-0 hidden sm:block">
                            Select
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Login Credentials Form */}
          <form onSubmit={handleAuthenticate} className="space-y-5">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1.5">
                Email
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-3.5 py-2.5 sm:py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition"
                  placeholder="user@bank.com"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1.5">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-3.5 py-2.5 sm:py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition"
                  placeholder="••••••••••••"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 px-5 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white text-sm font-bold rounded-xl shadow-sm flex items-center justify-center gap-2 transition cursor-pointer mt-3"
            >
              <span>Authenticate as {activePersonaItem.label}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Optional Generator Link */}
          {onOpenAgentGenerator && (
            <div className="mt-6 pt-5 border-t border-slate-100 text-center">
              <button
                type="button"
                onClick={onOpenAgentGenerator}
                className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center justify-center gap-1.5 mx-auto transition cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Open Autonomous Agent Topology Designer</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
