import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  Search, 
  X, 
  Building2, 
  FileText, 
  Bot, 
  Compass, 
  Bell, 
  LogOut, 
  ArrowRight,
  Sparkles,
  Users,
  ShieldCheck,
  CheckCircle2,
  FolderOpen,
  Clock,
  AlertTriangle,
  CheckCheck,
  ChevronDown,
  Check,
  UserCheck,
  Sliders,
  User
} from 'lucide-react';
import { ClientProfile, AppPersona, SystemNotification } from '../../types';

export interface RMTopHeaderProps {
  activeClient: ClientProfile | null;
  clients?: ClientProfile[];
  onSelectClient?: (clientId: string) => void;
  currentPersonaInfo?: { name: string; role: string };
  unreadNotifCount?: number;
  activeTab?: string;
  setActiveTab?: (tabId: string) => void;
  onLogout: () => void;
  onInitiateJourney?: () => void;
  activePersona?: AppPersona;
  systemNotifications?: SystemNotification[];
  onActionNotification?: (notificationId: string, action?: 'approve' | 'reject') => void;
  onMarkNotificationsAsRead?: () => void;
  showCopilot?: boolean;
  onToggleCopilot?: () => void;
  onSwitchPersona?: (persona: AppPersona) => void;
}

export const RMTopHeader: React.FC<RMTopHeaderProps> = ({
  activeClient,
  clients = [],
  onSelectClient,
  currentPersonaInfo,
  unreadNotifCount = 0,
  activeTab,
  setActiveTab,
  onLogout,
  onInitiateJourney,
  activePersona = 'rm',
  systemNotifications = [],
  onActionNotification,
  onMarkNotificationsAsRead,
  showCopilot = false,
  onToggleCopilot,
  onSwitchPersona
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [isPersonaMenuOpen, setIsPersonaMenuOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'clients' | 'pages' | 'documents' | 'agents'>('all');
  
  const searchInputRef = useRef<HTMLInputElement>(null);
  const searchContainerRef = useRef<HTMLDivElement>(null);
  const notifContainerRef = useRef<HTMLDivElement>(null);
  const personaMenuRef = useRef<HTMLDivElement>(null);

  const getInitials = (name?: string) => {
    if (!name) return 'US';
    return name
      .split(' ')
      .map(part => part[0])
      .slice(0, 2)
      .join('')
      .toUpperCase();
  };

  // Keyboard shortcut listener for Cmd+K / Ctrl+K and Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchOpen(true);
        setIsNotifOpen(false);
        searchInputRef.current?.focus();
      } else if (e.key === 'Escape') {
        setIsSearchOpen(false);
        setIsNotifOpen(false);
        searchInputRef.current?.blur();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Click outside listener to close search dropdown, notification popover, and persona dropdown
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setIsSearchOpen(false);
      }
      if (notifContainerRef.current && !notifContainerRef.current.contains(e.target as Node)) {
        setIsNotifOpen(false);
      }
      if (personaMenuRef.current && !personaMenuRef.current.contains(e.target as Node)) {
        setIsPersonaMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const personaDropdownOptions: { id: AppPersona; label: string; role: string; icon: React.ComponentType<{ className?: string }>; badge: string }[] = [
    { id: 'rm', label: 'Relationship Manager', role: 'Manage journeys & pipeline', icon: UserCheck, badge: 'bg-indigo-100 text-indigo-700' },
    { id: 'compliance_officer', label: 'Compliance Officer', role: 'AML/PEP screening & audit', icon: ShieldCheck, badge: 'bg-rose-100 text-rose-700' },
    { id: 'operations_officer', label: 'Operations Officer', role: 'Document review & sign-offs', icon: FileText, badge: 'bg-amber-100 text-amber-700' },
    { id: 'platform_admin', label: 'Platform Admin', role: 'System topology & telemetry', icon: Sliders, badge: 'bg-blue-100 text-blue-700' },
    { id: 'customer', label: 'Customer Self-Service', role: 'Corporate verification & vault', icon: User, badge: 'bg-emerald-100 text-emerald-700' }
  ];

  // Compute display name and role based on activePersona
  const displayName = useMemo(() => {
    if (activePersona === 'customer') {
      return activeClient?.authorizedRepresentative?.name || currentPersonaInfo?.name || 'Julian Vance';
    }
    return currentPersonaInfo?.name || 'Sarah Jenkins';
  }, [activePersona, activeClient, currentPersonaInfo]);

  const displayRole = useMemo(() => {
    if (activePersona === 'customer') {
      const comp = activeClient?.companyName || 'Corporate Client';
      const role = activeClient?.authorizedRepresentative?.role || 'Authorized Signatory';
      return `${comp} • ${role}`;
    }
    return currentPersonaInfo?.role || 'Senior RM - Corporate Banking';
  }, [activePersona, activeClient, currentPersonaInfo]);

  // Navigable platform pages (tailored for customer vs staff)
  const platformPages = useMemo(() => {
    if (activePersona === 'customer') {
      return [
        { id: 'self_service_dashboard', label: 'Customer Self-Service Portal', category: 'pages', icon: Compass, description: 'Overview, category breakdown & onboarding readiness' },
        { id: 'category1_registry', label: '1. External Registry Data (Read-Only)', category: 'pages', icon: Building2, description: 'ACRA, MyInfo Business & government registry records' },
        { id: 'category2_internal', label: '2. Organization & Signatories', category: 'pages', icon: Users, description: 'Authorized representatives, operational signatories, tax self-cert' },
        { id: 'category3_deliverables', label: '3. Required Deliverables & OCR Vault', category: 'pages', icon: FolderOpen, description: 'Document verification, OCR extraction, live biometric verification' },
        { id: 'notifications', label: 'Portal Notifications & Alerts', category: 'pages', icon: Bell, description: 'Status updates, document review decisions, RM notices' }
      ];
    }
    return [
      { id: 'journey_workspace', label: 'Journey Workspace', category: 'pages', icon: Compass, description: 'Active client onboarding journey, verified content & dependency graph' },
      { id: 'my_pipeline', label: 'Corporate Onboarding Worklist', category: 'pages', icon: Building2, description: 'Client portfolio pipeline, risk triage & stage SLA tracking' },
      { id: 'customer_360', label: 'Customer 360 View', category: 'pages', icon: Users, description: 'Institutional hierarchy, UBO graph & transactional footprint' },
      { id: 'notifications', label: 'Action Center & Notifications', category: 'pages', icon: Bell, description: 'Pending supervisor reviews, customer OCR verifications & alerts' },
      { id: 'review_queue', label: 'Compliance Review Queue', category: 'pages', icon: ShieldCheck, description: 'AML/PEP flags, sanction audit trails & approval queue' },
      { id: 'screening_results', label: 'Sanctions & Adverse Media Screening', category: 'pages', icon: ShieldCheck, description: 'OFAC, UN, EU, UK HMT real-time compliance results' },
      { id: 'agentic_process_flows', label: 'Agent Studio & Process Flows', category: 'pages', icon: Bot, description: 'Autonomous agent topology & multi-agent orchestration' },
      { id: 'doc_verification', label: 'Document Verification Hub', category: 'pages', icon: FolderOpen, description: 'LayoutLMv3 OCR extraction & document approval vault' }
    ];
  }, [activePersona]);

  // System Autonomous Agents (omitted from search for customer)
  const platformAgents = useMemo(() => {
    if (activePersona === 'customer') return [];
    return [
      { id: 'agent_outreach', name: 'Autonomous Client Outreach Agent', category: 'agents', description: 'Dispatches secure onboarding credentials & self-service links' },
      { id: 'agent_ocr', name: 'LayoutLMv3 Document Extraction Agent', category: 'agents', description: 'Extracts certificate key-value pairs with 99.4% OCR confidence' },
      { id: 'agent_sanctions', name: 'Real-Time Sanctions Screening Agent', category: 'agents', description: 'Screening across OFAC, UN, EU, UK HMT databases' },
      { id: 'agent_underwriting', name: 'Balance Sheet & Credit Underwriting Agent', category: 'agents', description: 'Automated financial ratio analysis & AAA rating assignment' },
      { id: 'agent_ubo', name: 'fCoSE Ownership & UBO Unraveling Agent', category: 'agents', description: 'Traverses multi-tiered legal entities to identify ultimate owners' },
      { id: 'agent_audit', name: 'Perpetual Compliance & Audit Trail Agent', category: 'agents', description: 'Continuous transaction monitoring & supervisory log recorder' }
    ];
  }, [activePersona]);

  // Ingested documents (from activeClient or default)
  const clientDocuments = useMemo(() => {
    if (activeClient?.documents && activeClient.documents.length > 0) {
      return activeClient.documents.map(d => ({
        id: d.id,
        name: d.name,
        type: d.type,
        status: d.status,
        clientName: activeClient.companyName,
        category: 'documents'
      }));
    }
    return [
      { id: 'doc_inc', name: 'Certificate of Incorporation', type: 'PDF', status: 'verified', clientName: activeClient?.companyName || 'Meridian Components', category: 'documents' },
      { id: 'doc_art', name: 'Articles of Association', type: 'PDF', status: 'verified', clientName: activeClient?.companyName || 'Meridian Components', category: 'documents' },
      { id: 'doc_fin', name: 'Audited Financial Statements (FY2024)', type: 'PDF', status: 'verified', clientName: activeClient?.companyName || 'Meridian Components', category: 'documents' },
      { id: 'doc_ubo', name: 'Certified Register of Shareholders & UBO Declaration', type: 'PDF', status: 'verified', clientName: activeClient?.companyName || 'Meridian Components', category: 'documents' },
      { id: 'doc_board', name: 'Board Resolution for Banking Mandate', type: 'PDF', status: 'pending', clientName: activeClient?.companyName || 'Meridian Components', category: 'documents' }
    ];
  }, [activeClient]);

  // Available search category chips
  const categoryChips = useMemo(() => {
    if (activePersona === 'customer') {
      return ['all', 'pages', 'documents'] as const;
    }
    return ['all', 'clients', 'pages', 'documents', 'agents'] as const;
  }, [activePersona]);

  // Filtered search results
  const searchResults = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();

    // 1. Clients (only for staff personas)
    const matchedClients = activePersona === 'customer' ? [] : clients.filter(c => 
      !q || 
      c.companyName.toLowerCase().includes(q) ||
      (c.registrationNumber && c.registrationNumber.toLowerCase().includes(q)) ||
      (c.jurisdiction && c.jurisdiction.toLowerCase().includes(q)) ||
      (c.industry && c.industry.toLowerCase().includes(q))
    ).map(c => ({
      type: 'client' as const,
      id: c.id,
      title: c.companyName,
      subtitle: `UEN: ${c.registrationNumber || 'N/A'} • ${c.jurisdiction || 'Singapore'}`,
      badge: c.overallStatus === 'approved' ? 'Approved' : 'In Progress',
      badgeColor: c.overallStatus === 'approved' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-amber-50 text-amber-700 border-amber-200',
      client: c
    }));

    // 2. Pages
    const matchedPages = platformPages.filter(p =>
      !q ||
      p.label.toLowerCase().includes(q) ||
      p.description.toLowerCase().includes(q)
    ).map(p => ({
      type: 'page' as const,
      id: p.id,
      title: p.label,
      subtitle: p.description,
      icon: p.icon
    }));

    // 3. Documents
    const matchedDocs = clientDocuments.filter(d =>
      !q ||
      d.name.toLowerCase().includes(q) ||
      d.type.toLowerCase().includes(q)
    ).map(d => ({
      type: 'document' as const,
      id: d.id,
      title: d.name,
      subtitle: `${d.type} • ${d.clientName}`,
      badge: d.status,
      badgeColor: d.status === 'verified' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-blue-50 text-blue-700 border-blue-200'
    }));

    // 4. Agents (only for staff personas)
    const matchedAgents = activePersona === 'customer' ? [] : platformAgents.filter(a =>
      !q ||
      a.name.toLowerCase().includes(q) ||
      a.description.toLowerCase().includes(q)
    ).map(a => ({
      type: 'agent' as const,
      id: a.id,
      title: a.name,
      subtitle: a.description
    }));

    return {
      clients: matchedClients,
      pages: matchedPages,
      documents: matchedDocs,
      agents: matchedAgents,
      totalCount: matchedClients.length + matchedPages.length + matchedDocs.length + matchedAgents.length
    };
  }, [searchQuery, clients, platformPages, clientDocuments, platformAgents, activePersona]);

  const handleSelectClientResult = (clientId: string) => {
    if (onSelectClient) {
      onSelectClient(clientId);
    }
    if (setActiveTab) {
      setActiveTab('journey_workspace');
    }
    setIsSearchOpen(false);
    setSearchQuery('');
  };

  const handleSelectPageResult = (tabId: string) => {
    if (activePersona === 'customer') {
      if (tabId === 'notifications') {
        if (setActiveTab) setActiveTab('notifications');
      } else if (tabId.startsWith('category')) {
        if (setActiveTab) setActiveTab('self_service_dashboard');
        window.dispatchEvent(new CustomEvent('customer_navigate_category', { detail: { category: tabId } }));
      } else {
        if (setActiveTab) setActiveTab('self_service_dashboard');
      }
    } else {
      if (setActiveTab) {
        setActiveTab(tabId);
      }
    }
    setIsSearchOpen(false);
    setSearchQuery('');
  };

  const handleSelectDocResult = (docId?: string) => {
    if (activePersona === 'customer') {
      if (setActiveTab) setActiveTab('self_service_dashboard');
      window.dispatchEvent(new CustomEvent('customer_navigate_category', { 
        detail: { category: 'category3_deliverables', docId } 
      }));
    } else {
      if (setActiveTab) {
        setActiveTab('journey_workspace');
      }
    }
    setIsSearchOpen(false);
    setSearchQuery('');
  };

  const handleSelectAgentResult = () => {
    if (setActiveTab) {
      setActiveTab('agentic_process_flows');
    }
    setIsSearchOpen(false);
    setSearchQuery('');
  };

  // Filter notifications relevant to the active view
  const displayNotifications = useMemo(() => {
    if (systemNotifications.length > 0) {
      if (activePersona === 'customer' && activeClient) {
        const clientNotifs = systemNotifications.filter(n => !n.clientId || n.clientId === activeClient.id);
        return clientNotifs.length > 0 ? clientNotifs : systemNotifications;
      }
      return systemNotifications;
    }
    // Fallback simulated notifications if none exists
    return [
      {
        id: 'fallback-1',
        type: 'info' as const,
        title: 'Biometric FaceID Passed',
        msg: 'Representative facial verification completed successfully.',
        time: 'Just now',
        node: 'biometrics',
        clientId: activeClient?.id || 'client_1',
        clientName: activeClient?.companyName || 'Meridian Components'
      },
      {
        id: 'fallback-2',
        type: 'warning' as const,
        title: 'Document OCR Pending Verification',
        msg: 'Certificate of Incorporation requires key-value pair review.',
        time: '1 hour ago',
        node: 'doc_verification',
        clientId: activeClient?.id || 'client_1',
        clientName: activeClient?.companyName || 'Meridian Components',
        actionRequired: true
      }
    ];
  }, [systemNotifications, activePersona, activeClient]);

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200 px-4 sm:px-6 py-2.5 flex items-center justify-between gap-4 shadow-xs">
      {/* Global Search Bar */}
      <div ref={searchContainerRef} className="relative flex-1 max-w-2xl">
        <div 
          onClick={() => {
            setIsSearchOpen(true);
            setIsNotifOpen(false);
            searchInputRef.current?.focus();
          }}
          className={`relative flex items-center w-full bg-slate-50 hover:bg-slate-100/80 border rounded-xl transition-all duration-150 cursor-text ${
            isSearchOpen ? 'bg-white border-blue-500 ring-2 ring-blue-500/20 shadow-xs' : 'border-slate-200 shadow-2xs'
          }`}
        >
          <div className="pl-3.5 pr-2 text-slate-400 flex items-center pointer-events-none">
            <Search className="w-4 h-4 text-slate-400" />
          </div>

          <input
            ref={searchInputRef}
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              if (!isSearchOpen) setIsSearchOpen(true);
            }}
            onFocus={() => {
              setIsSearchOpen(true);
              setIsNotifOpen(false);
            }}
            placeholder={
              activePersona === 'customer'
                ? "Search documents, registry data, or portal sections... (⌘K)"
                : "Search clients, documents, agents, or pages... (⌘K)"
            }
            className="w-full py-2 pr-10 text-xs sm:text-sm font-medium text-slate-800 placeholder:text-slate-400 bg-transparent focus:outline-none"
          />

          <div className="flex items-center gap-1 pr-2.5">
            {searchQuery && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setSearchQuery('');
                  searchInputRef.current?.focus();
                }}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-md transition-colors cursor-pointer"
                title="Clear search"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
            <kbd className="hidden sm:inline-flex items-center text-[10px] font-mono font-semibold text-slate-400 bg-white border border-slate-200 px-1.5 py-0.5 rounded shadow-2xs">
              ⌘K
            </kbd>
          </div>
        </div>

        {/* Search Results Dropdown Overlay */}
        {isSearchOpen && (
          <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-slate-200 rounded-2xl shadow-xl z-50 overflow-hidden text-left animate-in fade-in-50 zoom-in-95 duration-100 max-h-[500px] flex flex-col">
            {/* Filter Category Chips */}
            <div className="p-2.5 border-b border-slate-100 bg-slate-50/70 flex items-center gap-1.5 overflow-x-auto scrollbar-none">
              {categoryChips.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold capitalize transition cursor-pointer shrink-0 ${
                    selectedCategory === cat 
                      ? 'bg-blue-600 text-white shadow-xs' 
                      : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Scrollable Results List */}
            <div className="overflow-y-auto p-2 space-y-4 max-h-[380px]">
              {searchResults.totalCount === 0 ? (
                <div className="py-8 text-center text-slate-500">
                  <p className="text-xs font-medium">No results found for "{searchQuery}"</p>
                  <p className="text-[11px] text-slate-400 mt-1">Try searching for a document, registry record, or system page.</p>
                </div>
              ) : (
                <>
                  {/* Pages Section */}
                  {(selectedCategory === 'all' || selectedCategory === 'pages') && searchResults.pages.length > 0 && (
                    <div className="space-y-1">
                      <div className="px-2 py-1 text-[10px] font-bold font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                        <Compass className="w-3 h-3" />
                        <span>Platform Pages ({searchResults.pages.length})</span>
                      </div>
                      {searchResults.pages.map((p) => {
                        const IconComponent = p.icon || Compass;
                        return (
                          <div
                            key={p.id}
                            onClick={() => handleSelectPageResult(p.id)}
                            className="group flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 border border-transparent hover:border-slate-200 transition cursor-pointer"
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div className="w-7 h-7 rounded-lg bg-indigo-50 border border-indigo-100 text-indigo-600 flex items-center justify-center shrink-0">
                                <IconComponent className="w-3.5 h-3.5" />
                              </div>
                              <div className="min-w-0">
                                <p className="text-xs font-bold text-slate-900 group-hover:text-blue-600 truncate transition-colors">
                                  {p.title}
                                </p>
                                <p className="text-[11px] text-slate-500 truncate">
                                  {p.subtitle}
                                </p>
                              </div>
                            </div>
                            <ArrowRight className="w-3.5 h-3.5 text-slate-300 group-hover:text-blue-600 transition-colors shrink-0 ml-2" />
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Documents Section */}
                  {(selectedCategory === 'all' || selectedCategory === 'documents') && searchResults.documents.length > 0 && (
                    <div className="space-y-1">
                      <div className="px-2 py-1 text-[10px] font-bold font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                        <FileText className="w-3 h-3" />
                        <span>Documents & Vault ({searchResults.documents.length})</span>
                      </div>
                      {searchResults.documents.map((d) => (
                        <div
                          key={d.id}
                          onClick={() => handleSelectDocResult(d.id)}
                          className="group flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 border border-transparent hover:border-slate-200 transition cursor-pointer"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <div className="w-7 h-7 rounded-lg bg-sky-50 border border-sky-100 text-sky-600 flex items-center justify-center shrink-0">
                              <FileText className="w-3.5 h-3.5" />
                            </div>
                            <div className="min-w-0">
                              <p className="text-xs font-bold text-slate-900 group-hover:text-blue-600 truncate transition-colors">
                                {d.title}
                              </p>
                              <p className="text-[11px] text-slate-500 truncate">
                                {d.subtitle}
                              </p>
                            </div>
                          </div>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border shrink-0 ml-2 uppercase font-mono ${d.badgeColor}`}>
                            {d.badge}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Clients Section (staff only) */}
                  {activePersona !== 'customer' && (selectedCategory === 'all' || selectedCategory === 'clients') && searchResults.clients.length > 0 && (
                    <div className="space-y-1">
                      <div className="px-2 py-1 text-[10px] font-bold font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                        <Building2 className="w-3 h-3" />
                        <span>Corporate Clients ({searchResults.clients.length})</span>
                      </div>
                      {searchResults.clients.map((c) => (
                        <div
                          key={c.id}
                          onClick={() => handleSelectClientResult(c.id)}
                          className="group flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 border border-transparent hover:border-slate-200 transition cursor-pointer"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <div className="w-7 h-7 rounded-lg bg-blue-50 border border-blue-100 text-blue-600 flex items-center justify-center shrink-0">
                              <Building2 className="w-3.5 h-3.5" />
                            </div>
                            <div className="min-w-0">
                              <p className="text-xs font-bold text-slate-900 group-hover:text-blue-600 truncate transition-colors">
                                {c.title}
                              </p>
                              <p className="text-[11px] text-slate-500 truncate">
                                {c.subtitle}
                              </p>
                            </div>
                          </div>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border shrink-0 ml-2 uppercase font-mono ${c.badgeColor}`}>
                            {c.badge}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Autonomous Agents Section (staff only) */}
                  {activePersona !== 'customer' && (selectedCategory === 'all' || selectedCategory === 'agents') && searchResults.agents.length > 0 && (
                    <div className="space-y-1">
                      <div className="px-2 py-1 text-[10px] font-bold font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                        <Bot className="w-3 h-3" />
                        <span>Autonomous Agents ({searchResults.agents.length})</span>
                      </div>
                      {searchResults.agents.map((a) => (
                        <div
                          key={a.id}
                          onClick={handleSelectAgentResult}
                          className="group flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 border border-transparent hover:border-slate-200 transition cursor-pointer"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <div className="w-7 h-7 rounded-lg bg-emerald-50 border border-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
                              <Sparkles className="w-3.5 h-3.5" />
                            </div>
                            <div className="min-w-0">
                              <p className="text-xs font-bold text-slate-900 group-hover:text-blue-600 truncate transition-colors">
                                {a.title}
                              </p>
                              <p className="text-[11px] text-slate-500 truncate">
                                {a.subtitle}
                              </p>
                            </div>
                          </div>
                          <ArrowRight className="w-3.5 h-3.5 text-slate-300 group-hover:text-blue-600 transition-colors shrink-0 ml-2" />
                        </div>
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>

            {/* Search Footer */}
            <div className="p-2 border-t border-slate-100 bg-slate-50/50 flex items-center justify-between text-[11px] text-slate-400">
              <span className="font-mono">Press ESC to dismiss</span>
              <span>Showing {searchResults.totalCount} matches</span>
            </div>
          </div>
        )}
      </div>

      {/* Right Controls: Copilot Toggle, Notification Bell, Persona, and Logout */}
      <div className="flex items-center gap-2.5 shrink-0">
        
        {/* Copilot Assistant Toggle Button */}
        {onToggleCopilot && (
          <button
            type="button"
            id="btn-top-copilot"
            onClick={onToggleCopilot}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-xs border ${
              showCopilot
                ? activePersona === 'customer'
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm ring-2 ring-emerald-500/20'
                  : 'bg-blue-600 text-white border-blue-600 shadow-sm ring-2 ring-blue-500/20'
                : 'bg-white text-slate-700 hover:text-slate-900 border-slate-200 hover:bg-slate-50'
            }`}
            title={showCopilot ? 'Close Copilot Panel' : (activePersona === 'customer' ? 'Open Customer Copilot' : 'Open Copilot Panel')}
            aria-label="Toggle Copilot"
          >
            <Bot className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">
              {activePersona === 'customer' ? 'Customer Copilot' : 'Copilot'}
            </span>
            <span className={`w-1.5 h-1.5 rounded-full ${
              showCopilot ? 'bg-emerald-300 animate-pulse' : 'bg-slate-300'
            }`} />
          </button>
        )}

        {/* Action Center Notifications Bell & Dropdown */}
        <div ref={notifContainerRef} className="relative">
          <button
            type="button"
            id="btn-top-notifications"
            onClick={() => {
              setIsNotifOpen(prev => !prev);
              setIsSearchOpen(false);
            }}
            className={`relative p-2 rounded-xl border transition-all cursor-pointer flex items-center justify-center shadow-xs ${
              isNotifOpen || activeTab === 'notifications'
                ? 'bg-blue-600 text-white border-blue-600 shadow-sm ring-2 ring-blue-500/20'
                : 'bg-white text-slate-600 hover:text-slate-900 border-slate-200 hover:bg-slate-50'
            }`}
            title={`Action Center Notifications (${unreadNotifCount} unread)`}
            aria-label="Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadNotifCount > 0 && (
              <span className="absolute -top-1 -right-1 px-1.5 py-0.2 bg-rose-600 text-[9px] font-black text-white rounded-full min-w-4 text-center leading-tight shadow-xs">
                {unreadNotifCount}
              </span>
            )}
          </button>

          {/* Notifications Dropdown Popover */}
          {isNotifOpen && (
            <div className="absolute right-0 top-full mt-2 w-80 sm:w-96 bg-white border border-slate-200 rounded-2xl shadow-xl z-50 overflow-hidden text-left animate-in fade-in-50 zoom-in-95 duration-100 flex flex-col max-h-[480px]">
              {/* Header */}
              <div className="p-3.5 border-b border-slate-100 bg-slate-50/80 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-md bg-blue-100 text-blue-600 flex items-center justify-center">
                    <Bell className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 leading-tight">Notifications & Alerts</h3>
                    <p className="text-[10px] text-slate-500">{displayNotifications.length} recent system updates</p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  {unreadNotifCount > 0 && onMarkNotificationsAsRead && (
                    <button
                      type="button"
                      onClick={() => onMarkNotificationsAsRead()}
                      className="text-[10px] font-semibold text-blue-600 hover:text-blue-700 px-2 py-0.5 rounded hover:bg-blue-50 transition cursor-pointer flex items-center gap-1"
                      title="Mark all as read"
                    >
                      <CheckCheck className="w-3 h-3" />
                      Mark read
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => setIsNotifOpen(false)}
                    className="p-1 rounded-md text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Notification Items List */}
              <div className="overflow-y-auto p-2 space-y-1.5 divide-y divide-slate-100 max-h-[320px]">
                {displayNotifications.length === 0 ? (
                  <div className="py-8 text-center text-slate-500">
                    <Bell className="w-6 h-6 text-slate-300 mx-auto mb-1.5" />
                    <p className="text-xs font-medium">All caught up!</p>
                    <p className="text-[10px] text-slate-400">No unread notifications at this time.</p>
                  </div>
                ) : (
                  displayNotifications.slice(0, 6).map((notif) => {
                    const isWarning = notif.type === 'warning' || notif.actionRequired;
                    const isCritical = notif.type === 'critical';
                    const isSuccess = notif.type === 'success' || notif.type === 'info';

                    return (
                      <div 
                        key={notif.id}
                        className={`p-2.5 rounded-xl transition ${
                          notif.actionRequired && !notif.actioned 
                            ? 'bg-amber-50/50 border border-amber-200/60' 
                            : 'hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-start gap-2.5">
                          <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
                            isCritical 
                              ? 'bg-rose-100 text-rose-600 border border-rose-200' 
                              : isWarning 
                                ? 'bg-amber-100 text-amber-700 border border-amber-200' 
                                : 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                          }`}>
                            {isCritical ? (
                              <AlertTriangle className="w-3.5 h-3.5" />
                            ) : isWarning ? (
                              <Clock className="w-3.5 h-3.5" />
                            ) : (
                              <CheckCircle2 className="w-3.5 h-3.5" />
                            )}
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center justify-between gap-1 mb-0.5">
                              <p className="text-xs font-bold text-slate-900 truncate">
                                {notif.title}
                              </p>
                              <span className="text-[9px] font-mono text-slate-400 shrink-0">
                                {notif.time}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-600 line-clamp-2 leading-relaxed">
                              {notif.msg}
                            </p>
                            {notif.clientName && (
                              <div className="mt-1 flex items-center justify-between">
                                <span className="text-[9px] font-mono text-slate-500 bg-slate-100 px-1.5 py-0.2 rounded">
                                  {notif.clientName}
                                </span>
                                {notif.actionRequired && !notif.actioned && onActionNotification && (
                                  <button
                                    type="button"
                                    onClick={() => onActionNotification(notif.id, 'approve')}
                                    className="text-[10px] font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-2 py-0.5 rounded transition cursor-pointer"
                                  >
                                    Approve
                                  </button>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Popover Footer */}
              <div className="p-2.5 border-t border-slate-100 bg-slate-50/50 flex items-center justify-between">
                <span className="text-[10px] font-mono text-slate-400">Real-time sync</span>
                <button
                  type="button"
                  onClick={() => {
                    if (setActiveTab) {
                      setActiveTab('notifications');
                    }
                    setIsNotifOpen(false);
                  }}
                  className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 transition cursor-pointer"
                >
                  Open Full Action Center
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Persona Selector Dropdown on Home Page */}
        <div ref={personaMenuRef} className="relative">
          <button
            type="button"
            id="top-header-persona-card"
            onClick={() => {
              setIsPersonaMenuOpen(prev => !prev);
              setIsSearchOpen(false);
              setIsNotifOpen(false);
            }}
            className={`flex items-center gap-2.5 px-3 py-1.5 rounded-xl border transition-all cursor-pointer shadow-xs text-left ${
              isPersonaMenuOpen
                ? 'bg-white border-blue-600 ring-2 ring-blue-500/20'
                : 'bg-slate-50 hover:bg-slate-100/90 border-slate-200 hover:border-slate-300'
            }`}
            title="Click to switch persona"
            aria-label="Select persona dropdown"
            aria-expanded={isPersonaMenuOpen}
          >
            <div className={`w-7 h-7 rounded-lg text-white font-bold text-xs flex items-center justify-center shrink-0 shadow-xs ${
              activePersona === 'customer' 
                ? 'bg-emerald-600 ring-2 ring-emerald-500/20' 
                : 'bg-blue-600 ring-2 ring-blue-500/20'
            }`}>
              {getInitials(displayName)}
            </div>
            <div className="hidden sm:block text-left max-w-[190px]">
              <div className="flex items-center gap-1.5">
                <p className="text-xs font-bold text-slate-900 leading-tight truncate">
                  {displayName}
                </p>
                <span className={`text-[8px] font-mono font-bold px-1.5 py-0.2 rounded uppercase border shrink-0 ${
                  activePersona === 'customer'
                    ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
                    : 'bg-blue-100 text-blue-800 border-blue-200'
                }`}>
                  {activePersona === 'customer' ? 'Customer' : activePersona === 'platform_admin' ? 'Admin' : activePersona === 'rm' ? 'RM' : activePersona === 'compliance_officer' ? 'Compliance' : 'Ops'}
                </span>
              </div>
              <p className="text-[10px] font-medium text-slate-500 leading-tight truncate">
                {displayRole}
              </p>
            </div>
            <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform duration-150 ${isPersonaMenuOpen ? 'rotate-180 text-blue-600' : ''}`} />
          </button>

          {/* Persona Selection Dropdown Menu */}
          {isPersonaMenuOpen && (
            <div 
              id="home-persona-dropdown-menu"
              className="absolute right-0 top-full mt-2 w-72 sm:w-80 bg-white border border-slate-200 rounded-2xl shadow-xl z-50 overflow-hidden text-left animate-in fade-in-50 zoom-in-95 duration-100"
            >
              <div className="p-3 border-b border-slate-100 bg-slate-50/90 flex items-center justify-between">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-500">
                  Switch Persona
                </span>
                <span className="text-[10px] font-mono text-slate-400">
                  Select Role
                </span>
              </div>
              <div className="p-1.5 space-y-1 max-h-72 overflow-y-auto">
                {personaDropdownOptions.map((opt) => {
                  const isCurrent = activePersona === opt.id;
                  const Icon = opt.icon;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => {
                        setIsPersonaMenuOpen(false);
                        if (onSwitchPersona) {
                          onSwitchPersona(opt.id);
                        }
                      }}
                      className={`w-full p-2 rounded-xl text-left flex items-center justify-between gap-2.5 transition cursor-pointer ${
                        isCurrent
                          ? 'bg-blue-50/80 text-blue-900 border border-blue-200 shadow-2xs'
                          : 'hover:bg-slate-50 text-slate-700 border border-transparent'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0 flex-1">
                        <div className={`p-1.5 rounded-lg shrink-0 ${opt.badge}`}>
                          <Icon className="w-3.5 h-3.5" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-bold text-slate-900 truncate">
                              {opt.label}
                            </span>
                            {isCurrent && (
                              <span className="text-[8px] font-mono px-1 py-0.2 rounded bg-blue-100 text-blue-800 font-bold uppercase">
                                Active
                              </span>
                            )}
                          </div>
                          <p className="text-[10px] text-slate-500 truncate leading-tight">
                            {opt.role}
                          </p>
                        </div>
                      </div>
                      {isCurrent && (
                        <Check className="w-4 h-4 text-blue-600 shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Logout Button */}
        <button
          type="button"
          id="btn-top-logout"
          onClick={onLogout}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-slate-700 hover:text-rose-600 bg-white hover:bg-rose-50 border border-slate-200 hover:border-rose-200 shadow-xs transition-colors cursor-pointer"
          title={activePersona === 'customer' ? 'Log out of customer self-service' : 'Log out of session'}
          aria-label="Logout"
        >
          <LogOut className="w-3.5 h-3.5 text-slate-500 group-hover:text-rose-600" />
          <span className="hidden sm:inline">Logout</span>
        </button>

      </div>
    </header>
  );
};

export default RMTopHeader;
