import React, { useState } from 'react';
import { 
  Video, 
  Play, 
  Clock, 
  Copy, 
  Check, 
  X, 
  ChevronRight, 
  Layers, 
  Users, 
  GitBranch, 
  Activity, 
  ShieldCheck, 
  Sparkles,
  Bot,
  FileText
} from 'lucide-react';

interface DemoScriptModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function DemoScriptModal({ isOpen, onClose }: DemoScriptModalProps) {
  const [activeSegment, setActiveSegment] = useState<number>(0);
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const scriptSegments = [
    {
      title: '1. Executive Overview & Purpose',
      timestamp: '0:00 - 0:45',
      duration: '45 Seconds',
      badge: 'Purpose',
      actionCue: 'Show the main Onboard.ai Hero Dashboard with high-contrast Dark Enterprise theme.',
      voiceover: `Welcome to Onboard.ai — the next-generation autonomous corporate client onboarding platform powered by multi-agent AI.

In commercial and investment banking, client onboarding traditionally takes anywhere from 3 to 6 weeks. It is plagued by fragmented legacy checks, manual document processing, repetitive customer outreach, and slow compliance bottlenecks.

Onboard.ai fundamentally transforms this experience. By orchestrating specialized AI agents running on the Model Context Protocol (MCP) and Gemini 2.5, Onboard.ai converts weeks of manual handoffs into a real-time, event-driven workflow that safely completes corporate onboarding in under two minutes while maintaining strict enterprise governance.`
    },
    {
      title: '2. Multi-Persona & System Functions',
      timestamp: '0:45 - 1:45',
      duration: '60 Seconds',
      badge: 'Functions',
      actionCue: 'Click through the Sidebar Personas: Platform Admin, RM, Compliance, Customer Self-Service.',
      voiceover: `To support end-to-end enterprise operations, Onboard.ai is structured across four dedicated persona environments:

First, the Platform Admin & Agent Studio: Here, architects configure autonomous agent pools — like KYB, UBO Discovery, and Sanctions Screener — defining input/output schemas, security guardrails, token limits, and hybrid parallel execution graphs.

Second, the Relationship Manager Workspace: RMs manage their onboarding pipelines, initiate new client journeys, track active portfolio health, and leverage the AI Copilot to automatically draft client outreach emails and compile compliance dossiers.

Third, the Compliance & Risk Officer Hub: Risk officers review real-time escalations, investigate PEP or sanction hits, inspect adverse media sentiment, and execute supervisor override signoffs.

And fourth, Customer Self-Service: An end-user portal where corporate signees can securely upload charters, link government identity providers like Singpass or Aadhaar, and complete live biometric verification.`
    },
    {
      title: '3. Client Workflow Journey Walkthrough',
      timestamp: '1:45 - 3:15',
      duration: '90 Seconds',
      badge: 'Workflow Journey',
      actionCue: 'Navigate to RM persona -> Journey Workspace -> Click "Trigger Autonomous Flow" or select Aether Aero-Tech Pte Ltd.',
      voiceover: `Now, let's walk through a live onboarding workflow journey for a real client: Aether Aero-Tech Pte Ltd, a Singapore-based aerospace enterprise represented by CEO Dr. Evelyn Chen.

When the Relationship Manager initiates the journey, Onboard.ai automatically executes an 8-node directed acyclic graph (DAG) in real-time:

Step 1 — Data Aggregator: The KYB Agent queries the Singapore ACRA business registry, instantly retrieving corporate standing and filing history.

Step 2 — Document Verification: Optical character recognition (OCR) models parse the Certificate of Incorporation and Board Resolutions, verifying digital seals and signing quorum.

Step 3 — Biometric Face Match: The system matches Dr. Evelyn Chen's passport chip photo against a live webcam stream, verifying 68 facial landmarks with 98.6% confidence.

Step 4 — PEP & Sanctions Screening: Global databases (OFAC, UN, EU) are screened concurrently to ensure zero regulatory hits.

Step 5 — AML & UBO Unwrapping: The UBO Discovery Agent traces multi-layered equity structures, confirming ultimate ownership above 10%.

Steps 6 through 8 — Risk Scoring, Credit Underwriting, and Legal Execution: The Risk Agent assigns a LOW composite risk grade, credit algorithms approve a $1.5M credit limit, and legal contracts are auto-drafted for e-signature.`
    },
    {
      title: '4. Deep-Dive into Journey Visual Details',
      timestamp: '3:15 - 4:00',
      duration: '45 Seconds',
      badge: 'UI Details',
      actionCue: 'Click on individual nodes (e.g., Biometrics, AML, Credit) to expand the Node Detail drawer.',
      voiceover: `Every detail in this visual workflow journey is designed for complete transparency and explainability:

First, Node Status Indicators: Green nodes represent completed automated checks, blue pulsing nodes indicate live execution, amber highlights flagged items requiring officer review, and slate nodes wait on upstream dependencies.

Second, Live Event Logs: Clicking any node exposes real-time execution logs, recording timestamped MCP API calls, registry response payloads, and AI model reasoning.

Third, Quantified Audit Metrics: The detail panel displays explicit metrics — such as 99.2% OCR confidence, 100% facial liveness, and debt-to-equity ratios — paired with structured compliance findings and supervisor signoff controls.

In conclusion, Onboard.ai replaces friction with automated intelligence, enabling financial institutions to onboard corporate clients faster, safer, and with unprecedented clarity. Thank you!`
    }
  ];

  const fullScriptText = scriptSegments.map(s => `=== ${s.title} (${s.timestamp}) ===\n[Visual Cue: ${s.actionCue}]\n\n${s.voiceover}\n`).join('\n');

  const handleCopy = () => {
    navigator.clipboard.writeText(fullScriptText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="bg-[#262B40] text-slate-100 w-full max-w-4xl rounded-2xl border border-[#5379AE]/40 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-5 bg-[#06457F] border-b border-[#2C444C] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-[#0474C4] rounded-xl text-white shadow-md">
              <Video className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-bold text-base text-white">4-Minute Demo Video Script & Storyboard</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-[#0474C4] text-white">
                  3:50 Total Duration
                </span>
              </div>
              <p className="text-xs text-[#A8C4EC] mt-0.5">
                Exact walkthrough content, purpose, functional modules, client workflow journey, and UI details
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#2C444C] hover:bg-[#5379AE] text-white text-xs font-semibold transition border border-[#5379AE]/40 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied Full Script!' : 'Copy Script'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg hover:bg-white/10 text-slate-300 hover:text-white transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs for Video Segments */}
        <div className="flex border-b border-[#2C444C] bg-[#262B40] overflow-x-auto">
          {scriptSegments.map((seg, idx) => (
            <button
              key={idx}
              onClick={() => setActiveSegment(idx)}
              className={`flex-1 min-w-[160px] px-4 py-3 text-left text-xs font-semibold border-b-2 transition flex flex-col gap-1 cursor-pointer ${
                activeSegment === idx 
                  ? 'border-[#0474C4] bg-[#06457F]/60 text-white font-bold' 
                  : 'border-transparent text-[#A8C4EC] hover:bg-[#2C444C]/40 hover:text-white'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-mono text-[10px] text-[#0474C4] font-bold">{seg.timestamp}</span>
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#2C444C] text-[#A8C4EC]">{seg.badge}</span>
              </div>
              <span className="truncate">{seg.title.split('. ')[1]}</span>
            </button>
          ))}
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 bg-[#262B40]">
          
          {/* Segment Details Header */}
          <div className="p-4 rounded-xl bg-[#06457F]/40 border border-[#5379AE]/30 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <span className="text-xs font-mono font-bold text-[#0474C4] uppercase tracking-wider block">
                SEGMENT {activeSegment + 1} OF 4 • {scriptSegments[activeSegment].timestamp}
              </span>
              <h3 className="text-lg font-bold text-white mt-0.5">
                {scriptSegments[activeSegment].title}
              </h3>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#2C444C] border border-[#5379AE]/30 shrink-0">
              <Clock className="w-4 h-4 text-[#A8C4EC]" />
              <span className="text-xs font-semibold text-white">Target Length: {scriptSegments[activeSegment].duration}</span>
            </div>
          </div>

          {/* Action Cue Box */}
          <div className="p-4 rounded-xl bg-amber-950/30 border border-amber-500/30 text-amber-200 text-xs flex items-start gap-3">
            <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-amber-300 block mb-0.5">On-Screen Visual Action Cue for Presenter:</span>
              <p className="text-amber-100/90 leading-relaxed">{scriptSegments[activeSegment].actionCue}</p>
            </div>
          </div>

          {/* Voiceover Teleprompter Box */}
          <div className="p-5 rounded-2xl bg-[#1e2336] border border-[#5379AE]/30 shadow-inner">
            <div className="flex items-center justify-between mb-3 border-b border-[#2C444C] pb-2">
              <span className="text-xs font-bold text-[#A8C4EC] flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-[#0474C4]" /> Voiceover Script (Read at standard conversational pace)
              </span>
              <span className="text-[10px] font-mono text-slate-400">
                ~{scriptSegments[activeSegment].voiceover.split(' ').length} words
              </span>
            </div>
            <p className="text-sm text-slate-100 leading-relaxed whitespace-pre-line font-serif italic selection:bg-[#0474C4] selection:text-white">
              "{scriptSegments[activeSegment].voiceover}"
            </p>
          </div>

          {/* Segment Key Points Checklist */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="p-3.5 rounded-xl bg-[#2C444C]/30 border border-[#5379AE]/20">
              <span className="text-[10px] font-bold font-mono text-[#0474C4] uppercase block mb-1">Key Concept Covered</span>
              <p className="text-xs text-slate-200">
                {activeSegment === 0 ? 'Translating 3-6 weeks of manual onboarding into sub-2-minute automated precision.' :
                 activeSegment === 1 ? 'Four personas: Platform Admin, RM, Compliance Officer, Customer Self-Service.' :
                 activeSegment === 2 ? '8-step DAG traversal for Aether Aero-Tech (ACRA, OCR, Biometrics, Sanctions, AML, Credit).' :
                 'Node status colors, real-time MCP execution logs, and quantified audit metrics.'}
              </p>
            </div>
            <div className="p-3.5 rounded-xl bg-[#2C444C]/30 border border-[#5379AE]/20">
              <span className="text-[10px] font-bold font-mono text-[#0474C4] uppercase block mb-1">Interactive Feature to Highlight</span>
              <p className="text-xs text-slate-200">
                {activeSegment === 0 ? 'Live Hero Dashboard with active pipeline stats and client status cards.' :
                 activeSegment === 1 ? 'Sidebar navigation and Agent Studio MCP configuration tabs.' :
                 activeSegment === 2 ? 'Real-time "Trigger Autonomous Flow" button and parallel execution nodes.' :
                 'Node Detail Drawer with OCR extraction, biometric match scores, and audit logs.'}
              </p>
            </div>
          </div>

        </div>

        {/* Footer Navigation Controls */}
        <div className="p-4 bg-[#06457F] border-t border-[#2C444C] flex items-center justify-between">
          <button
            disabled={activeSegment === 0}
            onClick={() => setActiveSegment(prev => prev - 1)}
            className="px-4 py-2 rounded-xl bg-[#2C444C] disabled:opacity-40 hover:bg-[#5379AE] text-white text-xs font-semibold transition cursor-pointer disabled:cursor-not-allowed"
          >
            Previous Segment
          </button>

          <div className="flex items-center gap-1.5">
            {scriptSegments.map((_, i) => (
              <div 
                key={i} 
                onClick={() => setActiveSegment(i)}
                className={`w-2.5 h-2.5 rounded-full transition cursor-pointer ${
                  activeSegment === i ? 'bg-[#0474C4] scale-125' : 'bg-slate-600 hover:bg-slate-400'
                }`}
              />
            ))}
          </div>

          <button
            disabled={activeSegment === scriptSegments.length - 1}
            onClick={() => setActiveSegment(prev => prev + 1)}
            className="px-4 py-2 rounded-xl bg-[#0474C4] disabled:opacity-40 hover:bg-[#06457F] text-white text-xs font-semibold transition flex items-center gap-1 cursor-pointer disabled:cursor-not-allowed"
          >
            <span>Next Segment</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </div>
  );
}
