import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { 
  Terminal, 
  Cpu, 
  Database, 
  Activity, 
  ShieldCheck, 
  Server, 
  Layers, 
  ShoppingBag, 
  User, 
  MessageSquare, 
  Send, 
  Bot, 
  Sparkles, 
  Bell, 
  AlertTriangle, 
  CheckCircle, 
  ChevronRight, 
  Sliders, 
  SlidersHorizontal,
  Scale, 
  Settings, 
  FileCheck, 
  Lock, 
  GitBranch, 
  GitMerge,
  GitFork,
  GripVertical,
  Move,
  ArrowLeft, 
  Play, 
  ListTodo, 
  ExternalLink,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  Clock,
  ArrowRight,
  ArrowDown,
  HelpCircle,
  Eye,
  Settings2,
  ChevronDown,
  Brain,
  Heart,
  Shield,
  FileText,
  TrendingUp,
  Users,
  Search,
  Download,
  RefreshCw,
  Globe,
  Link,
  ArrowUp,
  ChevronUp,
  Network,
  Save,
  Zap,
  Building2,
  Filter,
  CheckCircle2,
  Compass,
  ShieldAlert,
  Briefcase,
  ZoomIn,
  ZoomOut,
  RotateCw,
  Copy,
  CheckCheck,
  Maximize2
} from 'lucide-react';
import { ClientProfile, AppPersona, WorkflowNode, OrchestrationAgent, AgentOrchestration, HybridStage, SystemNotification, UploadedDocument } from '../../types';
import { INITIAL_AGENTS } from '../../agents/definitions';
import { motion, AnimatePresence } from 'motion/react';
import { DeleteConfirmModal } from './DeleteConfirmModal';
import { BpmnJourneyViewer } from '../workflow/BpmnJourneyViewer';
import { DocumentViewerModal, DocumentPreviewCanvas } from './DocumentViewerModal';

/* ==========================================================================
   1. MCP SERVERS VIEW
   ========================================================================== */
export function McpServersView() {
  const [servers, setServers] = useState([
    {
      id: 'mcp-1',
      name: 'Corporate Register Connector',
      url: 'http://localhost:3011/mcp/registry',
      status: 'online',
      apis: ['query_acra_singapore', 'query_companies_house_uk', 'query_delaware_corp'],
      sources: ['ACRA', 'UK CH', 'Delaware Secretary of State'],
      latency: '112ms',
      uptime: '99.98%'
    },
    {
      id: 'mcp-2',
      name: 'Adverse Media Watch',
      url: 'http://localhost:3012/mcp/news',
      status: 'online',
      apis: ['scan_executive_news', 'evaluate_sentiment', 'risk_sentiment_audit'],
      sources: ['Dow Jones Risk & Compliance', 'Reuters API', 'Bloomberg Terminal'],
      latency: '240ms',
      uptime: '99.95%'
    },
    {
      id: 'mcp-3',
      name: 'Document OCR Vetting Engine',
      url: 'http://localhost:3013/mcp/ocr',
      status: 'online',
      apis: ['extract_entity_text', 'vet_watermarks', 'signature_hash_verify'],
      sources: ['Azure Document Intelligence', 'Custom LayoutLMv3 Model'],
      latency: '84ms',
      uptime: '100%'
    }
  ]);

  const [newServerName, setNewServerName] = useState('');
  const [newServerUrl, setNewServerUrl] = useState('');

  const handleRegisterServer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newServerName || !newServerUrl) return;
    setServers(prev => [
      ...prev,
      {
        id: `mcp-${Date.now()}`,
        name: newServerName,
        url: newServerUrl,
        status: 'online',
        apis: ['fetch_custom_data', 'verify_mcp_auth'],
        sources: ['Custom REST Gateway'],
        latency: '150ms',
        uptime: '100%'
      }
    ]);
    setNewServerName('');
    setNewServerUrl('');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">Model Context Protocol (MCP) Gateway</h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Configure secure, server-side data bridges that allow onboarding agents to retrieve direct records from registries and premium AML networks.
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs font-mono font-medium px-3 py-1 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/30 rounded-lg">
          <Server className="w-3.5 h-3.5" />
          <span>MCP Proxy: CONNECTED</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Register Server Form */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5 font-mono uppercase tracking-wider">
            <Settings className="w-4 h-4 text-indigo-500" /> Register MCP Bridge
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Link a new context-compliant server to expand the data retrieval tools available to your active AI agent teams.
          </p>
          <form onSubmit={handleRegisterServer} className="space-y-3">
            <div>
              <label className="text-[10px] font-mono text-slate-400 uppercase block mb-1">Server Name</label>
              <input
                type="text"
                value={newServerName}
                onChange={e => setNewServerName(e.target.value)}
                placeholder="e.g. SEC Filing Scraper"
                className="w-full border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 rounded px-3 py-2 text-xs focus:ring-1 focus:ring-indigo-500 outline-none text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="text-[10px] font-mono text-slate-400 uppercase block mb-1">Connection URL</label>
              <input
                type="text"
                value={newServerUrl}
                onChange={e => setNewServerUrl(e.target.value)}
                placeholder="http://localhost:3015/mcp"
                className="w-full border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 rounded px-3 py-2 text-xs focus:ring-1 focus:ring-indigo-500 outline-none text-slate-900 dark:text-slate-100"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-lg transition"
            >
              Add Connection Endpoint
            </button>
          </form>
        </div>

        {/* Server Connections Grid */}
        <div className="lg:col-span-2 space-y-4">
          <h3 className="text-xs font-bold text-slate-700 dark:text-slate-400 uppercase tracking-wider font-mono">
            ACTIVE MCP CONNECTOR POOL ({servers.length})
          </h3>
          <div className="space-y-4">
            {servers.map(srv => (
              <div 
                key={srv.id} 
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-4"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-indigo-50 dark:bg-indigo-950/20 text-indigo-600 dark:text-indigo-400 rounded-lg border border-indigo-100 dark:border-indigo-900/30">
                      <Server className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 dark:text-white text-sm">{srv.name}</h4>
                      <p className="text-xs text-slate-400 font-mono mt-0.5">{srv.url}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
                    <span className="text-[11px] font-mono text-emerald-600 dark:text-emerald-400 uppercase font-semibold">Active</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-3 border-t border-slate-100 dark:border-slate-800/60">
                  <div>
                    <span className="text-[9px] font-mono text-slate-400 uppercase">Latency</span>
                    <strong className="text-xs text-slate-800 dark:text-slate-200 block mt-0.5 font-mono">{srv.latency}</strong>
                  </div>
                  <div>
                    <span className="text-[9px] font-mono text-slate-400 uppercase">Uptime</span>
                    <strong className="text-xs text-slate-800 dark:text-slate-200 block mt-0.5 font-mono">{srv.uptime}</strong>
                  </div>
                  <div className="col-span-2">
                    <span className="text-[9px] font-mono text-slate-400 uppercase">Exposed API Functions</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {srv.apis.map(api => (
                        <span key={api} className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800/80 text-[10px] text-slate-600 dark:text-slate-300 rounded font-mono">
                          {api}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="bg-slate-50 dark:bg-slate-950/40 rounded-lg p-3 border border-slate-100 dark:border-slate-800/40 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                  <span className="flex items-center gap-1.5">
                    <Database className="w-3.5 h-3.5 text-indigo-400" />
                    Data Sources: {srv.sources.join(', ')}
                  </span>
                  <span className="text-[10px] font-mono text-indigo-500 cursor-pointer flex items-center gap-0.5">
                    Test Handshake <ExternalLink className="w-3 h-3" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ==========================================================================
   2. MARKETPLACE VIEW
   ========================================================================== */
export function MarketplaceView() {
  const agents = [
    {
      id: 'mp-1',
      name: 'ACRA Registry Fetcher',
      description: 'Gathers live company details, registered directors, share values, and address records directly from Singapore ACRA.',
      category: 'Registry Retrieval',
      status: 'installed',
      cost: 'Included',
      provider: 'Onboard.ai Core'
    },
    {
      id: 'mp-2',
      name: 'LexisNexis Compliance Broker',
      description: 'Connects onboarding flow to LexisNexis WorldCompliance to perform automated high-end PEP, Sanctions, and media screening.',
      category: 'Screener',
      status: 'installed',
      cost: '$0.04 / Query',
      provider: 'LexisNexis API'
    },
    {
      id: 'mp-3',
      name: 'Moody’s Credit Scoring Model',
      description: 'Parses complex assets, liability ratios, and outputs customized Moody’s rating comparisons and recommend limits.',
      category: 'Risk Underwriting',
      status: 'installed',
      cost: '$0.25 / Underwrite',
      provider: 'Moody’s Analytics'
    },
    {
      id: 'mp-4',
      name: 'UK Companies House Connector',
      description: 'Direct corporate registry integration for auditing UK-incorporated SME and corporate shareholders.',
      category: 'Registry Retrieval',
      status: 'available',
      cost: 'Included',
      provider: 'Onboard.ai Core'
    },
    {
      id: 'mp-5',
      name: 'Onfido Biometric Face Verifier',
      description: 'Ensures absolute liveness checks, validates driver licenses and passports against global databases with 99.9% fraud catch rate.',
      category: 'Biometrics',
      status: 'available',
      cost: '$0.80 / Check',
      provider: 'Onfido Ltd'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Agent Marketplace</h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Explore and install specialized agent block plugins developed by Onboard.ai Core or trusted enterprise banking partners.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {agents.map(ag => (
          <div 
            key={ag.id} 
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow relative overflow-hidden"
          >
            {ag.status === 'installed' && (
              <div className="absolute top-0 right-0 bg-indigo-500 text-white font-mono text-[9px] font-bold px-2 py-0.5 rounded-bl">
                INSTALLED
              </div>
            )}
            
            <div className="space-y-3">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700/60 font-semibold tracking-wider">
                {ag.category}
              </span>
              
              <h4 className="font-bold text-slate-900 dark:text-white text-sm">{ag.name}</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-normal">{ag.description}</p>
            </div>

            <div className="pt-4 mt-4 border-t border-slate-100 dark:border-slate-800/60 flex items-center justify-between text-xs">
              <div>
                <span className="text-[10px] font-mono text-slate-400 uppercase block">Billing rate</span>
                <strong className="text-slate-800 dark:text-slate-200 font-semibold">{ag.cost}</strong>
              </div>
              <button 
                disabled={ag.status === 'installed'}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition ${
                  ag.status === 'installed' 
                    ? 'bg-slate-100 dark:bg-slate-800/80 text-slate-400 cursor-not-allowed' 
                    : 'bg-indigo-600 text-white hover:bg-indigo-700'
                }`}
              >
                {ag.status === 'installed' ? 'Active' : 'Enable Block'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ==========================================================================
   3. GOVERNANCE VIEW
   ========================================================================== */
export function GovernanceView() {
  const auditLogs = [
    { id: 'aud-1', time: '2026-07-31 19:12', agent: 'AML UBO Agent', event: 'UBO verification triggered', status: 'Passed', target: 'Aether Aero-Tech' },
    { id: 'aud-2', time: '2026-07-31 18:10', agent: 'LexisNexis PEP', event: 'Cross-reference sanctions registers', status: 'Flagged PEP', target: 'Vortex Global' },
    { id: 'aud-3', time: '2026-07-30 16:44', agent: 'Biometric FaceID', event: 'Facial vector scan verification', status: 'Passed', target: 'Aether Aero-Tech' },
    { id: 'aud-4', time: '2026-07-30 14:20', agent: 'OCR Document', event: 'Acquired registration extract details', status: 'Completed', target: 'Vortex Global' }
  ];

  // Zero-Cost Real Integration 3: Live GLEIF LEI & SEC EDGAR Lookup
  const [registryQuery, setRegistryQuery] = useState('5493001KJ92837465012');
  const [registryResult, setRegistryResult] = useState<any>(null);
  const [loadingRegistry, setLoadingRegistry] = useState(false);

  // Zero-Cost Real Integration 2: Live EVM Public RPC Wallet Screener
  const [walletAddress, setWalletAddress] = useState('0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045');
  const [walletResult, setWalletResult] = useState<any>(null);
  const [loadingWallet, setLoadingWallet] = useState(false);

  // Export state
  const [isExporting, setIsExporting] = useState(false);

  const handleRegistrySearch = async () => {
    if (!registryQuery.trim()) return;
    setLoadingRegistry(true);
    try {
      const res = await fetch('/api/registry/lookup-entity', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: registryQuery, type: 'lei' })
      });
      const data = await res.json();
      setRegistryResult(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingRegistry(false);
    }
  };

  const handleWalletSearch = async () => {
    if (!walletAddress.trim()) return;
    setLoadingWallet(true);
    try {
      const res = await fetch('/api/blockchain/verify-wallet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ address: walletAddress })
      });
      const data = await res.json();
      setWalletResult(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingWallet(false);
    }
  };

  const handleExportAuditConfig = async () => {
    setIsExporting(true);
    try {
      const res = await fetch('/api/admin/export', { method: 'POST' });
      const data = await res.json();
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Platform_Admin_Audit_Proof_${Date.now()}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error(e);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            Governance & Institutional Audit Control
            <span className="px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 text-[10px] font-mono font-bold">
              4 REAL INTEGRATIONS ACTIVE
            </span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Real-time GLEIF LEI lookup, public EVM blockchain RPC wallet verification, and cryptographic SHA-256 audit log export.
          </p>
        </div>

        <button
          onClick={handleExportAuditConfig}
          disabled={isExporting}
          className="px-4 py-2 bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-white text-white dark:text-slate-900 rounded-lg text-xs font-bold transition flex items-center gap-2 shadow-sm shrink-0 cursor-pointer"
        >
          {isExporting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4 text-emerald-500" />}
          Export SHA-256 Signed Audit Config
        </button>
      </div>

      {/* Live Public Query Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Zero-Cost Real Integration 3: Live GLEIF LEI / SEC EDGAR Corporate Registry Query */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white font-mono uppercase tracking-wider flex items-center gap-2">
              <Globe className="w-4 h-4 text-sky-500" />
              Live GLEIF LEI & SEC Open Registry Lookup
            </h3>
            <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-bold bg-emerald-50 dark:bg-emerald-950/30 px-2 py-0.5 rounded">
              FREE PUBLIC REST API
            </span>
          </div>

          <p className="text-xs text-slate-500 leading-relaxed">
            Query official global Legal Entity Identifiers (LEI) via official GLEIF API or SEC EDGAR filings with zero key costs.
          </p>

          <div className="flex items-center gap-2">
            <input
              type="text"
              value={registryQuery}
              onChange={(e) => setRegistryQuery(e.target.value)}
              placeholder="Enter 20-char LEI or Company Name..."
              className="flex-1 px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500 font-mono"
            />
            <button
              onClick={handleRegistrySearch}
              disabled={loadingRegistry}
              className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer"
            >
              {loadingRegistry ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
              Fetch LEI
            </button>
          </div>

          {registryResult && (
            <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className="p-3.5 bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 rounded-lg space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-800 dark:text-slate-100">{registryResult.legalName}</span>
                <span className="px-2 py-0.5 bg-sky-100 dark:bg-sky-950/40 text-sky-800 dark:text-sky-300 font-mono text-[10px] font-bold rounded">
                  {registryResult.status || 'VERIFIED'}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-mono">Source: {registryResult.source}</p>
              <div className="grid grid-cols-2 gap-2 text-[11px] pt-1 border-t border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 font-mono">
                <div><span className="text-slate-400">Jurisdiction:</span> {registryResult.jurisdiction}</div>
                <div><span className="text-slate-400">LEI / ID:</span> {registryResult.lei || registryResult.cik || 'N/A'}</div>
              </div>
            </motion.div>
          )}
        </div>

        {/* Zero-Cost Real Integration 2: Live EVM Blockchain RPC Wallet & Sanctions Screener */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white font-mono uppercase tracking-wider flex items-center gap-2">
              <Activity className="w-4 h-4 text-[#0474C4]" />
              Live Public EVM RPC & Crypto VASP Screener
            </h3>
            <span className="text-[10px] font-mono text-[#0474C4] font-bold bg-blue-50 dark:bg-blue-950/30 px-2 py-0.5 rounded">
              CLOUDFLARE ETH RPC
            </span>
          </div>

          <p className="text-xs text-slate-500 leading-relaxed">
            Connects to Cloudflare Ethereum Mainnet RPC to inspect real ETH balances, bytecode, nonces, and OFAC sanctions status.
          </p>

          <div className="flex items-center gap-2">
            <input
              type="text"
              value={walletAddress}
              onChange={(e) => setWalletAddress(e.target.value)}
              placeholder="0x... EVM wallet address"
              className="flex-1 px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-[#0474C4] font-mono"
            />
            <button
              onClick={handleWalletSearch}
              disabled={loadingWallet}
              className="px-4 py-2 bg-[#0474C4] hover:bg-[#06457F] text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer"
            >
              {loadingWallet ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
              Query RPC
            </button>
          </div>

          {walletResult && (
            <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className="p-3.5 bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 rounded-lg space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-800 dark:text-slate-100 font-mono">{walletResult.address.slice(0, 10)}...{walletResult.address.slice(-6)}</span>
                <span className={`px-2 py-0.5 font-mono text-[10px] font-bold rounded ${
                  walletResult.sanctionsStatus?.includes('SANCTIONED') ? 'bg-rose-100 text-rose-800 dark:bg-rose-950/50 dark:text-rose-400' : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-400'
                }`}>
                  {walletResult.sanctionsStatus}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2 text-[11px] pt-1 border-t border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 font-mono">
                <div><span className="text-slate-400 block text-[9px]">BALANCE</span>{walletResult.balanceETH}</div>
                <div><span className="text-slate-400 block text-[9px]">TYPE</span>{walletResult.walletType.split(' ')[0]}</div>
                <div><span className="text-slate-400 block text-[9px]">TX COUNT</span>{walletResult.transactionCount}</div>
              </div>
            </motion.div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Compliance checklist details */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5 font-mono uppercase tracking-wider">
            <ShieldCheck className="w-4 h-4 text-emerald-500" /> Compliance Hardening
          </h3>
          <div className="space-y-3.5 text-xs">
            <div className="flex items-center justify-between p-2.5 bg-slate-50 dark:bg-slate-950/40 rounded-lg">
              <span className="font-medium text-slate-700 dark:text-slate-300">Enterprise Agent-to-Agent</span>
              <span className="px-2 py-0.5 bg-emerald-100 dark:bg-emerald-950/30 text-emerald-800 dark:text-emerald-400 font-mono text-[10px] font-bold rounded">MANDATORY</span>
            </div>
            <div className="flex items-center justify-between p-2.5 bg-slate-50 dark:bg-slate-950/40 rounded-lg">
              <span className="font-medium text-slate-700 dark:text-slate-300">Human-In-The-Loop EDD</span>
              <span className="px-2 py-0.5 bg-emerald-100 dark:bg-emerald-950/30 text-emerald-800 dark:text-emerald-400 font-mono text-[10px] font-bold rounded">ENABLED</span>
            </div>
            <div className="flex items-center justify-between p-2.5 bg-slate-50 dark:bg-slate-950/40 rounded-lg">
              <span className="font-medium text-slate-700 dark:text-slate-300">AES-256 Data Encryption</span>
              <span className="px-2 py-0.5 bg-indigo-100 dark:bg-indigo-950/30 text-indigo-800 dark:text-indigo-400 font-mono text-[10px] font-bold rounded">L4 ACTIVE</span>
            </div>
          </div>
        </div>

        {/* Audit Logs Table */}
        <div className="md:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
          <h3 className="text-xs font-bold text-slate-700 dark:text-slate-400 uppercase tracking-wider font-mono">
            AGENT TRANSACTION AUDIT LOGS
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 font-mono text-[10px] uppercase">
                  <th className="py-2 pb-3">Time</th>
                  <th className="py-2 pb-3">Agent</th>
                  <th className="py-2 pb-3">Event Action</th>
                  <th className="py-2 pb-3">Target Profile</th>
                  <th className="py-2 pb-3 text-right">Result</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                {auditLogs.map(log => (
                  <tr key={log.id} className="text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors">
                    <td className="py-3 font-mono text-[10px] text-slate-400">{log.time}</td>
                    <td className="py-3 font-semibold">{log.agent}</td>
                    <td className="py-3 text-slate-500 dark:text-slate-400">{log.event}</td>
                    <td className="py-3 font-mono text-[11px] text-slate-500">{log.target}</td>
                    <td className="py-3 text-right">
                      <span className={`inline-flex items-center gap-1 font-mono text-[10px] font-bold uppercase rounded ${
                        log.status.includes('PEP') ? 'text-rose-600 dark:text-rose-400' : 'text-emerald-600 dark:text-emerald-400'
                      }`}>
                        {log.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ==========================================================================
   4. DIGITAL TWIN VIEW
   ========================================================================== */
/* ==========================================================================
   4. DIGITAL TWIN VIEW
   ========================================================================== */

const ANATOMY_SYSTEMS = [
  {
    id: 'brain',
    name: 'Governance & Strategic Directives',
    corporateTerm: 'Board of Directors',
    icon: Brain,
    analogy: 'Manages board-level corporate resolutions, strategic corporate guidance, corporate policies, and designated signing authorities.',
    color: 'text-sky-600',
    borderColor: 'border-sky-200 hover:border-sky-500',
    bg: 'bg-sky-50/40',
    activeBg: 'bg-sky-50 border-sky-500 ring-4 ring-sky-50',
    badge: 'bg-sky-100 text-sky-800 text-[10px] font-semibold'
  },
  {
    id: 'heart',
    name: 'Equity Ownership & Capital Solvency',
    corporateTerm: 'UBO & Shareholders',
    icon: Heart,
    analogy: 'Manages equity share distribution, capital injection reserves, beneficial ownership logs, and primary source of funds verification.',
    color: 'text-rose-600',
    borderColor: 'border-rose-200 hover:border-rose-500',
    bg: 'bg-rose-50/40',
    activeBg: 'bg-rose-50 border-rose-500 ring-4 ring-rose-50',
    badge: 'bg-rose-100 text-rose-800 text-[10px] font-semibold'
  },
  {
    id: 'circulatory',
    name: 'Counterparty Network & Group Linkages',
    corporateTerm: 'Related Parties & Subsidiaries',
    icon: Activity,
    analogy: 'Traces parent/subsidiary relations, connected-party transaction routes, corporate guarantees, and cross-border group holdings.',
    color: 'text-amber-600',
    borderColor: 'border-amber-200 hover:border-amber-500',
    bg: 'bg-amber-50/40',
    activeBg: 'bg-amber-50 border-amber-500 ring-4 ring-amber-50',
    badge: 'bg-amber-100 text-amber-800 text-[10px] font-semibold'
  },
  {
    id: 'skeleton',
    name: 'Constitutive Legal Foundation',
    corporateTerm: 'Constitutive Filings & Documents',
    icon: Layers,
    analogy: 'Establishes static corporate registry facts, Certificate of Incorporation data, ACRA BizProfiles, and primary company charter records.',
    color: 'text-indigo-600',
    borderColor: 'border-indigo-200 hover:border-indigo-500',
    bg: 'bg-indigo-50/40',
    activeBg: 'bg-indigo-50 border-indigo-500 ring-4 ring-indigo-50',
    badge: 'bg-indigo-100 text-indigo-800 text-[10px] font-semibold'
  },
  {
    id: 'immune',
    name: 'Regulatory Screenings & Risk Shields',
    corporateTerm: 'KYC & Screening Filters',
    icon: Shield,
    analogy: 'Provides OFAC/UN sanctions verification, PEP screenings, adverse media queries, and continuous transaction screening filters.',
    color: 'text-emerald-600',
    borderColor: 'border-emerald-200 hover:border-emerald-500',
    bg: 'bg-emerald-50/40',
    activeBg: 'bg-emerald-50 border-emerald-500 ring-4 ring-emerald-50',
    badge: 'bg-emerald-100 text-emerald-800 text-[10px] font-semibold'
  },
  {
    id: 'metabolism',
    name: 'Financial Performance & Balance Sheet Vitality',
    corporateTerm: 'Financial Assets & Leverage',
    icon: TrendingUp,
    analogy: 'Translates corporate operating revenues, asset reserves, leverage quotients, and liquid cash levels into standard commercial credit ratings.',
    color: 'text-[#0474C4]',
    borderColor: 'border-[#A8C4EC] hover:border-[#0474C4]',
    bg: 'bg-[#F0F4FA]/60',
    activeBg: 'bg-[#F0F4FA] border-[#0474C4] ring-4 ring-blue-50',
    badge: 'bg-blue-100 text-[#0474C4] text-[10px] font-semibold'
  }
];

export function DigitalTwinView({ activeClient }: { activeClient: ClientProfile }) {
  const [selectedSubsystem, setSelectedSubsystem] = useState<string>('brain');
  const [rightPanelTab, setRightPanelTab] = useState<'diagnostics' | 'copilot'>('diagnostics');
  const [messages, setMessages] = useState([
    {
      id: 'msg-1',
      sender: 'twin',
      text: 'Good morning. I am your Digital Twin engine. I have fully indexed the corporate register files, shareholders, directors, and related party networks for this client.',
      time: '09:00'
    },
    {
      id: 'msg-2',
      sender: 'twin',
      text: `For ${activeClient.companyName}, I have constructed a comprehensive corporate profile map mapping the regulatory, financial, and structural attributes to a live Digital Twin. Hover or click sections of the Corporate Structure to inspect.`,
      time: '09:01'
    }
  ]);
  const [inputVal, setInputVal] = useState('');

  // Auto scroll/alert when subsystem changes
  useEffect(() => {
    // Switch right panel to diagnostics on click to show details
    setRightPanelTab('diagnostics');
  }, [selectedSubsystem]);

  const handleSendMessage = (e?: React.FormEvent, customText?: string) => {
    if (e) e.preventDefault();
    const queryText = customText || inputVal;
    if (!queryText.trim()) return;

    const userMsg = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: queryText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    if (!customText) setInputVal('');

    // Simulate response based on current selected subsystem
    setTimeout(() => {
      let replyText = `Analyzing "${queryText}" across the Digital Twin index...`;

      if (queryText.toLowerCase().includes('resolution') || queryText.toLowerCase().includes('director') || selectedSubsystem === 'brain') {
        const dNames = (activeClient.directors || []).map(d => d.name).join(', ') || 'registered directors';
        replyText = `[Governance & Strategic Directives Log] Board Resolution analysis completed.\n\nDirectors on file: ${dNames}.\n\nValidation checklist:\n- Board resolution quorum is VALID (3 signatures).\n- Strategic governance is clear.\n- Authorized signing authority confirmed for Dr. Evelyn Chen.\n\nDrafting corporate verification letter now... Ready for export.`;
      } else if (queryText.toLowerCase().includes('ubo') || queryText.toLowerCase().includes('pep') || selectedSubsystem === 'heart') {
        const pStatus = activeClient.shareholders.some(s => s.pepStatus);
        replyText = `[Equity Ownership & Capital Solvency Log] Ultimate Beneficial Owner (UBO) audit complete.\n\nStructure resolves to ${activeClient.shareholders.length} direct shareholders:\n${activeClient.shareholders.map(s => ` - ${s.name} (${s.equity}%)`).join('\n')}\n\nCompliance flag status: ${pStatus ? '🚨 WARNING: PEP status detected for Maximilian Sterling. Enhanced Due Diligence (EDD) must be completed.' : '✓ All shareholders vetted and cleared.'}`;
      } else if (queryText.toLowerCase().includes('related') || queryText.toLowerCase().includes('subsidiary') || selectedSubsystem === 'circulatory') {
        replyText = `[Counterparty Network & Group Linkages Log] Inter-corporate network resolved.\n\nActive links mapped to the following entities:\n- AeroVentures Capital Ltd (Parent Investor)\n- Aether Aero-Tech UK Ltd (Subsidiary - 100% owned)\n- Temasek Holdings (Anchor Sovereign Investor)\n\nCross-border risk index is classified as Low. Inbound trade flows comply with banking channels.`;
      } else if (queryText.toLowerCase().includes('document') || queryText.toLowerCase().includes('ocr') || selectedSubsystem === 'skeleton') {
        replyText = `[Constitutive Legal Foundation Log] Corporate structural elements verified.\n\nAll constitutive filings are active:\n- ACRA BizProfile (Live status, registered office: 79 Ayer Rajah)\n- Certificate of Incorporation (Matches local registry)\n- Board Resolution (Open corporate bank account)\n\nOCR Extraction Accuracy: 99.8%. Match status: PERFECT.`;
      } else if (queryText.toLowerCase().includes('screening') || queryText.toLowerCase().includes('sanction') || selectedSubsystem === 'immune') {
        replyText = `[Regulatory Screenings & Risk Shields Log] Real-time name screening audit.\n\nResults:\n- OFAC Specially Designated Nationals List: 0 Hits\n- EU Sanctions List: 0 Hits\n- UN Consolidated List: 0 Hits\n- Interpol Red Notices: Clear\n\nNo regulatory compliance threats found for ${activeClient.companyName}. Shield integrity is 100%.`;
      } else if (queryText.toLowerCase().includes('financial') || queryText.toLowerCase().includes('credit') || selectedSubsystem === 'metabolism') {
        replyText = `[Financial Performance & Balance Sheet Vitality Log] Corporate financial health index computed.\n\nFinancial parameters of ${activeClient.companyName}:\n- Revenue: ${activeClient.financials.revenue}\n- Assets: ${activeClient.financials.assets}\n- Debt-to-Equity Ratio: ${activeClient.financials.debtRatio}\n- Current Credit Rating: ${activeClient.financials.rating}\n\nRecommendation: The cash flow conversion of this entity supports a credit line up to $1,500,000 SGD under standard covenants.`;
      }

      setMessages(prev => [
        ...prev,
        {
          id: `msg-twin-${Date.now()}`,
          sender: 'twin',
          text: replyText,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }, 1000);
  };

  // Safe data retrieval
  const directors = activeClient.directors || [
    { name: 'Dr. Evelyn Chen', role: 'Managing Director & CEO', appointmentDate: '2024-10-12', nationality: 'Singapore' },
    { name: 'Marcus Sterling Vance', role: 'Non-Executive Director (AeroVentures)', appointmentDate: '2024-11-01', nationality: 'United States' },
    { name: 'Lau Jun Jie', role: 'Independent Director (ACRA Legal Rep)', appointmentDate: '2025-01-15', nationality: 'Singapore' }
  ];

  const relatedParties = activeClient.relatedParties || [
    { name: 'AeroVentures Capital Ltd', relationType: 'Parent Entity (Investment)', status: 'Active', riskLevel: 'Low' },
    { name: 'Aether Aero-Tech UK Ltd', relationType: 'Subsidiary (100% Owned)', status: 'Active', riskLevel: 'Low' },
    { name: 'Temasek Holdings (Pvt)', relationType: 'Anchor Sovereign Investor', status: 'Active', riskLevel: 'Low' }
  ];

  const alerts = activeClient.alerts || [];

  const systemDetails = ANATOMY_SYSTEMS.find(s => s.id === selectedSubsystem) || ANATOMY_SYSTEMS[0];

  return (
    <div className="bg-white border border-slate-200/80 rounded-2xl shadow-sm overflow-hidden flex flex-col lg:flex-row h-[780px] text-left">
      
      {/* LEFT COLUMN: INTERACTIVE CORPORATE PROFILE MAP (60%) */}
      <div className="flex-1 p-6 flex flex-col justify-between border-r border-slate-200/60 bg-slate-50/30 overflow-y-auto">
        <div>
          {/* Header */}
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                <Activity className="w-4 h-4 text-indigo-500" />
                Corporate Structure Digital Twin
              </h3>
              <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                Architectural mapping of corporate profiles: internal (board, equity) and external (network links, regulatory screening, financials).
              </p>
            </div>
            <div className="flex items-center gap-1.5 text-[10px] text-emerald-600 bg-emerald-50 px-2 py-0.5 border border-emerald-100 rounded-full font-mono font-medium animate-pulse">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block"></span>
              <span>STRUCTURAL TWIN ACTIVE</span>
            </div>
          </div>

          {/* Central schematic layout representing corporate architecture */}
          <div className="relative border border-slate-100 bg-white/70 rounded-2xl p-6 mb-4 min-h-[360px] flex items-center justify-center">
            
            {/* SVG Connecting lines showing relation pathways between corporate nodes */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <linearGradient id="glowGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#4f46e5" stopOpacity="0.15" />
                  <stop offset="50%" stopColor="#ec4899" stopOpacity="0.15" />
                  <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.15" />
                </linearGradient>
              </defs>
              
              {/* Dynamic illuminated paths to active selected systems */}
              <circle cx="50%" cy="50%" r="50" className="fill-none stroke-slate-100" strokeWidth="2" strokeDasharray="5,5" />
              <circle cx="50%" cy="50%" r="100" className="fill-none stroke-slate-100/50" strokeWidth="1" strokeDasharray="3,3" />
              
              {/* Central Nucleus Radiating Flows */}
              <line x1="50%" y1="50%" x2="25%" y2="20%" className={`stroke-2 transition-all duration-300 ${selectedSubsystem === 'brain' ? 'stroke-sky-500/80 animate-pulse' : 'stroke-slate-200/40'}`} />
              <line x1="50%" y1="50%" x2="75%" y2="20%" className={`stroke-2 transition-all duration-300 ${selectedSubsystem === 'heart' ? 'stroke-rose-500/80 animate-pulse' : 'stroke-slate-200/40'}`} />
              
              <line x1="50%" y1="50%" x2="25%" y2="50%" className={`stroke-2 transition-all duration-300 ${selectedSubsystem === 'skeleton' ? 'stroke-indigo-500/80 animate-pulse' : 'stroke-slate-200/40'}`} strokeDasharray="4,4" />
              <line x1="50%" y1="50%" x2="75%" y2="50%" className={`stroke-2 transition-all duration-300 ${selectedSubsystem === 'circulatory' ? 'stroke-amber-500/80 animate-pulse' : 'stroke-slate-200/40'}`} strokeDasharray="4,4" />
              
              <line x1="50%" y1="50%" x2="25%" y2="80%" className={`stroke-2 transition-all duration-300 ${selectedSubsystem === 'immune' ? 'stroke-emerald-500/80 animate-pulse' : 'stroke-slate-200/40'}`} />
              <line x1="50%" y1="50%" x2="75%" y2="80%" className={`stroke-2 transition-all duration-300 ${selectedSubsystem === 'metabolism' ? 'stroke-blue-500/80 animate-pulse' : 'stroke-slate-200/40'}`} />
            </svg>

            {/* Layout Grid Overlay */}
            <div className="grid grid-cols-2 gap-x-20 gap-y-10 w-full relative z-10 max-w-xl mx-auto">
              
              {/* 1. BRAIN */}
              <button 
                onClick={() => setSelectedSubsystem('brain')}
                className={`p-3.5 border text-left rounded-xl transition duration-200 cursor-pointer flex gap-3 ${
                  selectedSubsystem === 'brain' 
                    ? ANATOMY_SYSTEMS[0].activeBg 
                    : 'bg-white border-slate-150 hover:bg-slate-50'
                }`}
              >
                <div className="p-2 bg-sky-100/60 rounded-lg shrink-0">
                  <Brain className="w-4.5 h-4.5 text-sky-600" />
                </div>
                <div className="min-w-0">
                  <span className="block text-[10px] font-semibold text-sky-700 uppercase tracking-wider">GOVERNANCE ENGINE</span>
                  <span className="block font-bold text-slate-800 text-xs truncate">Board of Directors</span>
                  <span className="block text-[9px] text-slate-500 mt-0.5 truncate">{directors.length} Board Members</span>
                </div>
              </button>

              {/* 2. HEART */}
              <button 
                onClick={() => setSelectedSubsystem('heart')}
                className={`p-3.5 border text-left rounded-xl transition duration-200 cursor-pointer flex gap-3 ${
                  selectedSubsystem === 'heart' 
                    ? ANATOMY_SYSTEMS[1].activeBg 
                    : 'bg-white border-slate-150 hover:bg-slate-50'
                }`}
              >
                <div className="p-2 bg-rose-100/60 rounded-lg shrink-0">
                  <Heart className="w-4.5 h-4.5 text-rose-600" />
                </div>
                <div className="min-w-0">
                  <span className="block text-[10px] font-semibold text-rose-700 uppercase tracking-wider">CAPITAL SOLVENCY</span>
                  <span className="block font-bold text-slate-800 text-xs truncate">UBO & Capital Equity</span>
                  <span className="block text-[9px] text-slate-500 mt-0.5 truncate">
                    {activeClient.shareholders.some(s => s.pepStatus) ? '🚨 PEP Standing Flagged' : '✓ Standard Capital'}
                  </span>
                </div>
              </button>

              {/* CENTER CIRCLE REPRESENTING THE "CORPORATE TWIN" */}
              <div className="col-span-2 flex justify-center -my-3">
                <div className="w-24 h-24 rounded-full bg-slate-50 border border-slate-200/80 flex flex-col items-center justify-center text-center p-2 relative shadow-inner">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 absolute top-1.5 animate-ping"></span>
                  <span className="text-[7px] font-mono text-slate-400 font-bold uppercase tracking-widest leading-none">ENTITY MODEL</span>
                  <span className="text-[11px] font-extrabold text-slate-800 leading-tight mt-1 truncate max-w-[84px]">{activeClient.companyName.split(' ')[0]}</span>
                  <span className="text-[7px] font-bold text-indigo-600 font-mono mt-0.5 bg-indigo-50 border border-indigo-100/50 px-1 py-0.2 rounded">TWIN ENGINE</span>
                </div>
              </div>

              {/* 3. SKELETON */}
              <button 
                onClick={() => setSelectedSubsystem('skeleton')}
                className={`p-3.5 border text-left rounded-xl transition duration-200 cursor-pointer flex gap-3 ${
                  selectedSubsystem === 'skeleton' 
                    ? ANATOMY_SYSTEMS[3].activeBg 
                    : 'bg-white border-slate-150 hover:bg-slate-50'
                }`}
              >
                <div className="p-2 bg-indigo-100/60 rounded-lg shrink-0">
                  <Layers className="w-4.5 h-4.5 text-indigo-600" />
                </div>
                <div className="min-w-0">
                  <span className="block text-[10px] font-semibold text-indigo-700 uppercase tracking-wider">CONSTITUTIVE STANDING</span>
                  <span className="block font-bold text-slate-800 text-xs truncate">Legal Registry Base</span>
                  <span className="block text-[9px] text-slate-500 mt-0.5 truncate">{activeClient.documents.length} Filings Verified</span>
                </div>
              </button>

              {/* 4. CIRCULATORY */}
              <button 
                onClick={() => setSelectedSubsystem('circulatory')}
                className={`p-3.5 border text-left rounded-xl transition duration-200 cursor-pointer flex gap-3 ${
                  selectedSubsystem === 'circulatory' 
                    ? ANATOMY_SYSTEMS[2].activeBg 
                    : 'bg-white border-slate-150 hover:bg-slate-50'
                }`}
              >
                <div className="p-2 bg-amber-100/60 rounded-lg shrink-0">
                  <Activity className="w-4.5 h-4.5 text-amber-600" />
                </div>
                <div className="min-w-0">
                  <span className="block text-[10px] font-semibold text-amber-700 uppercase tracking-wider">GROUP RELATIONSHIPS</span>
                  <span className="block font-bold text-slate-800 text-xs truncate">Subsidiaries & Links</span>
                  <span className="block text-[9px] text-slate-500 mt-0.5 truncate">{relatedParties.length} Network Nodes</span>
                </div>
              </button>

              {/* 5. IMMUNE SYSTEM */}
              <button 
                onClick={() => setSelectedSubsystem('immune')}
                className={`p-3.5 border text-left rounded-xl transition duration-200 cursor-pointer flex gap-3 ${
                  selectedSubsystem === 'immune' 
                    ? ANATOMY_SYSTEMS[4].activeBg 
                    : 'bg-white border-slate-150 hover:bg-slate-50'
                }`}
              >
                <div className="p-2 bg-emerald-100/60 rounded-lg shrink-0">
                  <Shield className="w-4.5 h-4.5 text-emerald-600" />
                </div>
                <div className="min-w-0">
                  <span className="block text-[10px] font-semibold text-emerald-700 uppercase tracking-wider">REGULATORY SCREENINGS</span>
                  <span className="block font-bold text-slate-800 text-xs truncate">AML & KYC Verification</span>
                  <span className="block text-[9px] text-emerald-500 mt-0.5 truncate">OFAC • UN • Adverse Media</span>
                </div>
              </button>

              {/* 6. METABOLISM */}
              <button 
                onClick={() => setSelectedSubsystem('metabolism')}
                className={`p-3.5 border text-left rounded-xl transition duration-200 cursor-pointer flex gap-3 ${
                  selectedSubsystem === 'metabolism' 
                    ? ANATOMY_SYSTEMS[5].activeBg 
                    : 'bg-white border-slate-150 hover:bg-slate-50'
                }`}
              >
                <div className="p-2 bg-blue-100/60 rounded-lg shrink-0">
                  <TrendingUp className="w-4.5 h-4.5 text-[#0474C4]" />
                </div>
                <div className="min-w-0">
                  <span className="block text-[10px] font-semibold text-[#0474C4] uppercase tracking-wider">FINANCIAL SOLVENCY</span>
                  <span className="block font-bold text-slate-800 text-xs truncate">Cash & Credit Rating</span>
                  <span className="block text-[9px] text-slate-500 mt-0.5 truncate">Rating: {activeClient.financials.rating} • AAA Range</span>
                </div>
              </button>

            </div>
          </div>
        </div>

        {/* Selected System Explanation Widget */}
        <div className="mt-4 p-4 border border-slate-150 bg-white rounded-xl shadow-inner-sm">
          <div className="flex gap-3 items-start">
            <div className={`p-2 rounded-lg ${systemDetails.bg} shrink-0`}>
              {React.createElement(systemDetails.icon, { className: `w-5 h-5 ${systemDetails.color}` })}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-800">{systemDetails.name}</span>
                <span className={`px-2 py-0.2 rounded-full text-[9px] font-mono border ${systemDetails.badge}`}>
                  {systemDetails.corporateTerm}
                </span>
              </div>
              <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
                <strong className="text-slate-800">Corporate Function:</strong> {systemDetails.analogy}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* RIGHT COLUMN: DETAIL INSPECTOR & COPILOT TWIN (40%) */}
      <div className="w-full lg:w-[420px] flex flex-col bg-white border-l border-slate-200/80">
        
        {/* Toggle Inspector Tab */}
        <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between shrink-0">
          <div className="flex gap-1.5 p-0.5 bg-slate-200/70 rounded-lg">
            <button 
              onClick={() => setRightPanelTab('diagnostics')}
              className={`px-3 py-1 text-xs font-bold rounded-md transition-all cursor-pointer ${
                rightPanelTab === 'diagnostics' 
                  ? 'bg-white text-indigo-600 shadow-sm' 
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Diagnostic Inspector
            </button>
            <button 
              onClick={() => setRightPanelTab('copilot')}
              className={`px-3 py-1 text-xs font-bold rounded-md transition-all cursor-pointer ${
                rightPanelTab === 'copilot' 
                  ? 'bg-white text-indigo-600 shadow-sm' 
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Copilot Chat
            </button>
          </div>
          <span className="text-[10px] font-mono text-slate-400 font-bold tracking-widest uppercase">
            {selectedSubsystem.toUpperCase()} NODE
          </span>
        </div>

        {/* Dynamic Panel Area */}
        <div className="flex-1 overflow-y-auto p-5">
          
          {rightPanelTab === 'diagnostics' ? (
            <div className="space-y-4">
              
              {/* HEADER BASED ON SUBSYSTEM */}
              <div className="border-b border-slate-100 pb-3">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-indigo-500" />
                  {systemDetails.name.split(' (')[0]} Vital Details
                </h4>
                <p className="text-[10px] text-slate-500 mt-0.5 leading-normal">
                  Corporate parameters registered on the {systemDetails.corporateTerm} layer.
                </p>
              </div>

              {/* 1. BRAIN DETAILS */}
              {selectedSubsystem === 'brain' && (
                <div className="space-y-3">
                  <div className="bg-slate-50/60 p-3 rounded-xl border border-slate-100 space-y-2">
                    <span className="text-[10px] font-mono font-bold text-slate-500 block uppercase">Board Quorum Status</span>
                    <div className="flex items-center gap-1.5 text-[11px] text-slate-800">
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                      <span className="font-semibold">Quorum Met (3 Signed Board Directors)</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <span className="text-[10px] font-mono font-bold text-slate-500 block uppercase">Board Directors List</span>
                    {directors.map((d, index) => (
                      <div key={index} className="p-3 border border-slate-150 rounded-xl bg-white space-y-1 hover:border-slate-300/80 transition">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-slate-800">{d.name}</span>
                          <span className="text-[10px] text-slate-500 bg-slate-100 px-1.5 py-0.2 rounded font-medium">{d.nationality}</span>
                        </div>
                        <div className="flex items-center justify-between text-[10px] text-slate-600">
                          <span>{d.role}</span>
                          <span className="font-mono text-slate-400">Appointed: {d.appointmentDate}</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="bg-emerald-50/30 border border-emerald-100 p-3 rounded-xl space-y-1.5">
                    <span className="text-[10px] font-bold text-emerald-800 uppercase block font-mono">Cognitive Integrity Check</span>
                    <p className="text-[11px] text-emerald-700 leading-normal">
                      Strategy alignment holds perfect ratings. Authorizations match signature registers in ACRA Certificate filings. No management conflicts.
                    </p>
                  </div>
                </div>
              )}

              {/* 2. HEART DETAILS */}
              {selectedSubsystem === 'heart' && (
                <div className="space-y-4">
                  <div className="bg-slate-50/60 p-3 rounded-xl border border-slate-100 space-y-2">
                    <span className="text-[10px] font-mono font-bold text-slate-500 block uppercase">Total Capital Solvency</span>
                    <div className="flex items-center justify-between text-xs font-bold text-slate-800">
                      <span>Equity Resolved</span>
                      <span className="text-emerald-600">100% Core Registered Shares</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <span className="text-[10px] font-mono font-bold text-slate-500 block uppercase">Ultimate Beneficial Owners (UBO)</span>
                    {activeClient.shareholders.map((s, index) => (
                      <div key={index} className="p-3 border border-slate-150 rounded-xl bg-white space-y-1.5 hover:border-slate-300/80 transition">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-slate-800">{s.name}</span>
                          <span className="text-xs font-bold text-slate-700 font-mono">{s.equity}% Ownership</span>
                        </div>
                        <div className="flex items-center justify-between text-[10px]">
                          <span className="text-slate-500">Classification: Direct Shareholder</span>
                          {s.pepStatus ? (
                            <span className="text-rose-600 bg-rose-50 px-2 py-0.5 border border-rose-100 rounded-full font-bold font-mono">
                              🚨 PEP REGISTERED
                            </span>
                          ) : (
                            <span className="text-emerald-600 bg-emerald-50 px-2 py-0.5 border border-emerald-100 rounded-full font-mono font-medium">
                              ✓ AML CLEANED
                            </span>
                          )}
                        </div>
                        {/* Custom equity visualizer */}
                        <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden mt-1">
                          <div 
                            className={`h-full ${s.pepStatus ? 'bg-rose-500' : 'bg-rose-500'}`}
                            style={{ width: `${s.equity}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="bg-rose-50/30 border border-rose-100 p-3 rounded-xl space-y-1.5">
                    <span className="text-[10px] font-bold text-rose-800 uppercase block font-mono">AML Capital Flow Analysis</span>
                    <p className="text-[11px] text-rose-700 leading-normal">
                      {activeClient.shareholders.some(s => s.pepStatus) 
                        ? 'High PEP exposure detected. Ultimate Beneficial Owner registers require Enhanced Due Diligence (EDD) forms prior to legal validation.' 
                        : 'Capital source vettings complete. Asset backing is verified clean without venture shell layering risk.'}
                    </p>
                  </div>
                </div>
              )}

              {/* 3. CIRCULATORY DETAILS */}
              {selectedSubsystem === 'circulatory' && (
                <div className="space-y-3">
                  <span className="text-[10px] font-mono font-bold text-slate-500 block uppercase">Associated Corporate Linkages</span>
                  {relatedParties.map((rp, index) => (
                    <div key={index} className="p-3 border border-slate-150 rounded-xl bg-white space-y-1 hover:border-slate-300/80 transition">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-800">{rp.name}</span>
                        <span className="text-[9px] text-indigo-600 bg-indigo-50 border border-indigo-100/50 px-2 py-0.2 rounded font-mono font-semibold">
                          {rp.status}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[10px] text-slate-600">
                        <span>{rp.relationType}</span>
                        <span className={`font-mono font-bold ${
                          rp.riskLevel === 'High' ? 'text-red-500' : rp.riskLevel === 'Medium' ? 'text-amber-500' : 'text-emerald-500'
                        }`}>
                          {rp.riskLevel} Risk Link
                        </span>
                      </div>
                    </div>
                  ))}

                  <div className="bg-slate-50/60 p-3.5 border border-slate-150 rounded-xl space-y-2 mt-2">
                    <span className="text-[10px] font-mono font-bold text-slate-500 block uppercase">Group Transaction Flow</span>
                    <div className="flex items-center gap-1.5 text-[11px] text-slate-700 font-medium">
                      <span>Sovereign Parent</span>
                      <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                      <span className="text-indigo-600">{activeClient.companyName.split(' ')[0]}</span>
                      <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                      <span>EU Subsidiaries</span>
                    </div>
                  </div>
                </div>
              )}

              {/* 4. SKELETON DETAILS */}
              {selectedSubsystem === 'skeleton' && (
                <div className="space-y-3">
                  <span className="text-[10px] font-mono font-bold text-slate-500 block uppercase">Legal Documents Framework</span>
                  {activeClient.documents.map((doc, index) => (
                    <div key={index} className="p-3 border border-slate-150 rounded-xl bg-white space-y-2 hover:border-slate-300/80 transition">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex gap-2 items-start">
                          <FileText className="w-4 h-4 text-indigo-500 shrink-0 mt-0.5" />
                          <div className="min-w-0">
                            <span className="block text-xs font-bold text-slate-800 truncate">{doc.name}</span>
                            <span className="block text-[10px] text-slate-500">{doc.type}</span>
                          </div>
                        </div>
                        <span className="text-[9px] text-emerald-600 bg-emerald-50 border border-emerald-100/50 px-1.5 py-0.2 rounded font-bold font-mono">
                          {doc.status.toUpperCase()}
                        </span>
                      </div>
                      
                      {doc.ocrData && (
                        <div className="p-2 bg-slate-50 rounded-lg text-[9px] text-slate-600 font-mono space-y-1 border border-slate-100">
                          <span className="text-[8px] font-bold text-indigo-600 block uppercase font-mono mb-1">OCR CONSTITUTIVE EXTRACTIONS:</span>
                          {Object.entries(doc.ocrData).map(([k, v]) => (
                            <div key={k} className="flex justify-between gap-4">
                              <span className="text-slate-400 truncate max-w-[140px]">{k}:</span>
                              <span className="text-slate-700 truncate font-bold text-right">{v}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* 5. IMMUNE SYSTEM DETAILS */}
              {selectedSubsystem === 'immune' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="bg-slate-50/60 p-2.5 border border-slate-100 rounded-xl text-center space-y-1">
                      <span className="text-[9px] font-mono font-semibold text-slate-400 block uppercase">OFAC SANCTION MATRIX</span>
                      <span className="text-xs font-bold text-emerald-600">✓ 0 MATCHES</span>
                    </div>
                    <div className="bg-slate-50/60 p-2.5 border border-slate-100 rounded-xl text-center space-y-1">
                      <span className="text-[9px] font-mono font-semibold text-slate-400 block uppercase">ADVERSE MEDIA SCAN</span>
                      <span className="text-xs font-bold text-emerald-600">✓ CLEAR INDEX</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <span className="text-[10px] font-mono font-bold text-slate-500 block uppercase">Active Sanctions & Compliance Alerts</span>
                    {alerts.length === 0 ? (
                      <div className="p-4 border border-slate-150 bg-emerald-50/20 text-center rounded-xl space-y-1">
                        <CheckCircle className="w-6 h-6 text-emerald-500 mx-auto" />
                        <h5 className="text-xs font-bold text-emerald-800">No Regulatory Violations Detected</h5>
                        <p className="text-[10px] text-emerald-600">Corporate screening indicates no active regulatory enforcement or match warnings.</p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {alerts.map((al, index) => (
                          <div key={index} className="p-3 border border-slate-150 rounded-xl bg-white space-y-1.5 hover:border-slate-300/80 transition">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-slate-800 flex items-center gap-1">
                                <AlertTriangle className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                                {al.title}
                              </span>
                              <span className={`text-[8px] font-bold px-1.5 py-0.2 rounded uppercase font-mono ${
                                al.severity === 'high' ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
                              }`}>
                                {al.severity} Risk
                              </span>
                            </div>
                            <p className="text-[10px] text-slate-600 leading-normal">{al.description}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* 6. METABOLISM DETAILS */}
              {selectedSubsystem === 'metabolism' && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <span className="text-[10px] font-mono font-bold text-slate-500 block uppercase">Corporate Key Financial Metrics</span>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 border border-slate-150 bg-white rounded-xl hover:border-slate-300/80 transition">
                        <span className="text-[9px] font-mono text-slate-400 block uppercase">REVENUE FLOWS</span>
                        <span className="text-sm font-bold text-slate-800">{activeClient.financials.revenue}</span>
                      </div>
                      <div className="p-3 border border-slate-150 bg-white rounded-xl hover:border-slate-300/80 transition">
                        <span className="text-[9px] font-mono text-slate-400 block uppercase">TOTAL ASSETS</span>
                        <span className="text-sm font-bold text-slate-800">{activeClient.financials.assets}</span>
                      </div>
                      <div className="p-3 border border-slate-150 bg-white rounded-xl hover:border-slate-300/80 transition">
                        <span className="text-[9px] font-mono text-slate-400 block uppercase">DEBT / EQUITY RATIO</span>
                        <span className="text-sm font-bold text-slate-800">{activeClient.financials.debtRatio}</span>
                      </div>
                      <div className="p-3 border border-slate-150 bg-white rounded-xl hover:border-slate-300/80 transition">
                        <span className="text-[9px] font-mono text-slate-400 block uppercase">CREDIT RATING</span>
                        <span className="text-sm font-bold text-slate-800 text-indigo-600 font-extrabold">{activeClient.financials.rating}</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-blue-50/30 border border-blue-100 p-3 rounded-xl space-y-1.5">
                    <span className="text-[10px] font-bold text-blue-900 uppercase block font-mono">Credit Conversion Capacity</span>
                    <p className="text-[11px] text-blue-800 leading-normal">
                      The current cash and debt profile supports credit expansion covenants. Assets provide solid coverage for the requested banking limits.
                    </p>
                  </div>
                </div>
              )}

            </div>
          ) : (
            
            /* TAB 2: COPILOT TWIN CHAT */
            <div className="flex flex-col h-full space-y-4">
              
              {/* Chat messages */}
              <div className="flex-1 space-y-3 min-h-[360px] max-h-[380px] overflow-y-auto pr-1">
                {messages.map(msg => (
                  <div 
                    key={msg.id} 
                    className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`max-w-[85%] rounded-xl p-3 text-xs leading-relaxed shadow-sm ${
                      msg.sender === 'user'
                        ? 'bg-indigo-600 text-white rounded-br-none'
                        : 'bg-slate-50 border border-slate-150 text-slate-800 rounded-bl-none'
                    }`}>
                      <div className="flex items-center justify-between gap-4 mb-1 text-[9px] font-mono text-slate-400">
                        <span className="font-bold">{msg.sender === 'user' ? 'YOU (RM)' : 'DIGITAL TWIN AI'}</span>
                        <span>{msg.time}</span>
                      </div>
                      <p className="whitespace-pre-line text-xs font-sans font-medium">{msg.text}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Subsystem Context-Aware Prompt Suggestions */}
              <div className="space-y-1.5 pt-2 border-t border-slate-100">
                <span className="text-[9px] font-mono text-slate-400 uppercase font-bold tracking-wider block">
                  CONTEXT-AWARE QUERIES ({systemDetails.name.split(' (')[0]}):
                </span>
                
                {selectedSubsystem === 'brain' && (
                  <div className="flex flex-wrap gap-1.5">
                    <button 
                      onClick={() => handleSendMessage(undefined, "Verify board resolution quorum signatures")}
                      className="text-[10px] text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-150 px-2 py-1 rounded-md transition cursor-pointer"
                    >
                      Verify Board Quorum
                    </button>
                    <button 
                      onClick={() => handleSendMessage(undefined, "Draft director verification correspondence")}
                      className="text-[10px] text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-150 px-2 py-1 rounded-md transition cursor-pointer"
                    >
                      Draft Director Verification Email
                    </button>
                  </div>
                )}

                {selectedSubsystem === 'heart' && (
                  <div className="flex flex-wrap gap-1.5">
                    <button 
                      onClick={() => handleSendMessage(undefined, "Audit beneficial owner registers for PEP exposure")}
                      className="text-[10px] text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-150 px-2 py-1 rounded-md transition cursor-pointer"
                    >
                      Audit PEP Exposure
                    </button>
                    <button 
                      onClick={() => handleSendMessage(undefined, "Draft UBO disclosure request letter")}
                      className="text-[10px] text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-150 px-2 py-1 rounded-md transition cursor-pointer"
                    >
                      Draft UBO Disclosure Req
                    </button>
                  </div>
                )}

                {selectedSubsystem === 'circulatory' && (
                  <div className="flex flex-wrap gap-1.5">
                    <button 
                      onClick={() => handleSendMessage(undefined, "Map corporate subsidiary liability structure")}
                      className="text-[10px] text-amber-700 bg-amber-50 hover:bg-amber-100 border border-amber-150 px-2 py-1 rounded-md transition cursor-pointer"
                    >
                      Map Subsidiary Liability
                    </button>
                    <button 
                      onClick={() => handleSendMessage(undefined, "Assess cross-border fund flows and risks")}
                      className="text-[10px] text-amber-700 bg-amber-50 hover:bg-amber-100 border border-amber-150 px-2 py-1 rounded-md transition cursor-pointer"
                    >
                      Audit Cross-Border Flows
                    </button>
                  </div>
                )}

                {selectedSubsystem === 'skeleton' && (
                  <div className="flex flex-wrap gap-1.5">
                    <button 
                      onClick={() => handleSendMessage(undefined, "Extract ACRA biz profile registry parameters via OCR")}
                      className="text-[10px] text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-150 px-2 py-1 rounded-md transition cursor-pointer"
                    >
                      Inspect OCR Extractions
                    </button>
                    <button 
                      onClick={() => handleSendMessage(undefined, "Verify legal incorporation standing")}
                      className="text-[10px] text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-150 px-2 py-1 rounded-md transition cursor-pointer"
                    >
                      Verify Legal Standing
                    </button>
                  </div>
                )}

                {selectedSubsystem === 'immune' && (
                  <div className="flex flex-wrap gap-1.5">
                    <button 
                      onClick={() => handleSendMessage(undefined, "Run name screening across global sanctions registers")}
                      className="text-[10px] text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-150 px-2 py-1 rounded-md transition cursor-pointer"
                    >
                      Run Sanctions Check
                    </button>
                    <button 
                      onClick={() => handleSendMessage(undefined, "Draft enhanced due diligence mitigation paper")}
                      className="text-[10px] text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-150 px-2 py-1 rounded-md transition cursor-pointer"
                    >
                      Draft EDD Mitigation Brief
                    </button>
                  </div>
                )}

                {selectedSubsystem === 'metabolism' && (
                  <div className="flex flex-wrap gap-1.5">
                    <button 
                      onClick={() => handleSendMessage(undefined, "Assess debt ratio leverage and loan covenant bounds")}
                      className="text-[10px] text-blue-800 bg-blue-50 hover:bg-blue-100 border border-blue-150 px-2 py-1 rounded-md transition cursor-pointer"
                    >
                      Check Leverage Bounds
                    </button>
                    <button 
                      onClick={() => handleSendMessage(undefined, "Draft credit rating expandability covenant summary")}
                      className="text-[10px] text-blue-800 bg-blue-50 hover:bg-blue-100 border border-blue-150 px-2 py-1 rounded-md transition cursor-pointer"
                    >
                      Draft Credit Recommendations
                    </button>
                  </div>
                )}
              </div>

            </div>
          )}

        </div>

        {/* Input Form at the bottom */}
        {rightPanelTab === 'copilot' && (
          <form onSubmit={handleSendMessage} className="p-4 border-t border-slate-150 bg-slate-50 flex gap-2 shrink-0">
            <input
              type="text"
              value={inputVal}
              onChange={e => setInputVal(e.target.value)}
              placeholder={`Ask about ${systemDetails.corporateTerm.toLowerCase()}...`}
              className="flex-1 border border-slate-200 bg-white rounded-lg px-4 py-2 text-xs focus:ring-1 focus:ring-indigo-500 outline-none text-slate-800 placeholder-slate-400"
            />
            <button 
              type="submit" 
              className="p-2 px-4 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-lg transition flex items-center gap-1 cursor-pointer shadow-sm"
            >
              <span>Ask</span> <Send className="w-3 h-3" />
            </button>
          </form>
        )}

      </div>

    </div>
  );
}

/* ==========================================================================
   5. NOTIFICATIONS VIEW
   ========================================================================== */
interface NotificationsViewProps {
  notifications?: SystemNotification[];
  onActionNotification?: (notifId: string, action: 'approve' | 'reject') => void;
  onSelectClient?: (clientId: string) => void;
}

export function NotificationsView({
  notifications = [],
  onActionNotification,
  onSelectClient
}: NotificationsViewProps) {
  const [selectedNotif, setSelectedNotif] = useState<SystemNotification | null>(null);

  const defaultAlerts: SystemNotification[] = [
    { id: 'not-1', type: 'critical', title: 'PEP Alert', msg: 'AML PEP Alert: Shareholder Maximilian Sterling detected in sanctions adverse registers.', time: '10 mins ago', node: 'aml', clientId: 'client_1', clientName: 'Nexus Tech Solutions' },
    { id: 'not-2', type: 'info', title: 'Biometrics Verified', msg: 'Biometric FaceID Passed: Representative Dr. Evelyn Chen facial matches completed successfully.', time: '1 hour ago', node: 'biometrics', clientId: 'client_1', clientName: 'Nexus Tech Solutions' },
    { id: 'not-3', type: 'warning', title: 'Document Verification Submitted', msg: 'Customer Vortex Global Trade submitted verified OCR attributes for Certificate of Incorporation.', time: '3 hours ago', node: 'doc_verification', clientId: 'client_2', clientName: 'Vortex Global Trade', actionRequired: true, documentDetails: { docId: 'doc_1', docName: 'Certificate_of_Incorporation_Signed.pdf', docType: 'coi', ocrData: { 'Legal Entity Name': 'Vortex Global Trade Pte Ltd', 'Registration Number': 'SG-948271', 'Date of Incorporation': '14-Feb-2021', 'Authorized Signatory': 'David Vance', 'Country': 'Singapore' } } },
    { id: 'not-4', type: 'success', title: 'ACRA Registry Synced', msg: 'ACRA Registry Matched: Onboarding metadata synced with local Singapore registry.', time: '1 day ago', node: 'registry', clientId: 'client_1', clientName: 'Nexus Tech Solutions' }
  ];

  const allList = notifications.length > 0 ? notifications : defaultAlerts;
  const pendingCount = allList.filter(n => n.actionRequired && !n.actioned).length;

  return (
    <div className="space-y-4 text-left">
      <div className="border-b border-slate-200 dark:border-slate-800 pb-4 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">RM Notifications & Action Center</h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Real-time customer submissions, OCR document verifications, and compliance alerts.</p>
        </div>
        <span className="text-[10px] font-mono text-indigo-500 font-bold bg-indigo-50 dark:bg-indigo-950/20 px-2.5 py-1 rounded-full border border-indigo-200 dark:border-indigo-800">
          {pendingCount} RM ACTION REQUIRED
        </span>
      </div>

      <div className="space-y-3">
        {allList.map(al => {
          const isPendingAction = al.actionRequired && !al.actioned;
          const isActioned = al.actioned;

          return (
            <div 
              key={al.id} 
              className={`border rounded-xl p-4 shadow-sm space-y-3 transition ${
                isPendingAction
                  ? 'border-amber-400 dark:border-amber-600 bg-amber-50/20 dark:bg-amber-950/10'
                  : isActioned
                  ? 'border-emerald-300 dark:border-emerald-800 bg-emerald-50/10'
                  : al.type === 'critical' ? 'border-rose-200 dark:border-rose-950/30 bg-rose-50/10' :
                    al.type === 'warning' ? 'border-amber-200 dark:border-amber-950/30 bg-amber-50/10' :
                    al.type === 'success' ? 'border-emerald-200 dark:border-emerald-950/30 bg-emerald-50/10' :
                    'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
              }`}
            >
              <div className="flex items-start gap-3.5">
                <div className={`p-2 rounded-lg shrink-0 ${
                  isPendingAction ? 'bg-amber-500 text-white animate-pulse' :
                  isActioned ? 'bg-emerald-500 text-white' :
                  al.type === 'critical' ? 'bg-rose-100 text-rose-800 dark:bg-rose-950/40 dark:text-rose-400' :
                  al.type === 'warning' ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-400' :
                  al.type === 'success' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400' :
                  'bg-blue-100 text-blue-800 dark:bg-blue-950/40 dark:text-blue-400'
                }`}>
                  {isActioned ? <CheckCircle className="w-4 h-4" /> :
                   al.type === 'critical' ? <AlertTriangle className="w-4 h-4" /> :
                   al.type === 'success' ? <CheckCircle className="w-4 h-4" /> :
                   al.type === 'warning' ? <AlertTriangle className="w-4 h-4" /> :
                   <Bell className="w-4 h-4" />}
                </div>

                <div className="flex-1 space-y-1">
                  <div className="flex justify-between items-start gap-4">
                    <div>
                      <span className="text-xs font-bold text-slate-900 dark:text-white block">
                        {al.title || al.msg}
                      </span>
                      <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                        Client: <strong className="text-slate-900 dark:text-white">{al.clientName}</strong> • {al.msg}
                      </p>
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono shrink-0">{al.time}</span>
                  </div>

                  <div className="flex items-center gap-2 pt-1">
                    <span className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 text-[9px] font-mono rounded text-slate-500 uppercase">
                      NODE: {al.node?.toUpperCase()}
                    </span>

                    {isPendingAction && (
                      <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-amber-500 text-white uppercase shadow-xs">
                        ● RM ACTION REQUIRED
                      </span>
                    )}

                    {isActioned && (
                      <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 uppercase">
                        ✓ APPROVED & WORKFLOW ADVANCED
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Action Details Expansion */}
              {al.documentDetails && (
                <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-lg border border-slate-200 dark:border-slate-700 space-y-2.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                      <FileCheck className="w-4 h-4 text-emerald-500" /> Submitted File: {al.documentDetails.docName}
                    </span>
                    <button
                      onClick={() => setSelectedNotif(selectedNotif?.id === al.id ? null : al)}
                      className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
                    >
                      {selectedNotif?.id === al.id ? 'Hide Attributes ▲' : 'View Extracted Attributes ▼'}
                    </button>
                  </div>

                  {(selectedNotif?.id === al.id || isPendingAction) && (
                    <div className="space-y-2 pt-1 border-t border-slate-200 dark:border-slate-700">
                      <p className="text-[10px] font-mono text-slate-500 uppercase font-bold">OCR Key-Value Attributes Verified by Customer:</p>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px]">
                        {Object.entries(al.documentDetails.ocrData || {}).map(([k, v]) => (
                          <div key={k} className="p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-md">
                            <span className="text-[9px] font-mono text-slate-400 block uppercase truncate">{k}</span>
                            <span className="font-semibold text-slate-800 dark:text-slate-200 block truncate">{String(v)}</span>
                          </div>
                        ))}
                      </div>

                      {isPendingAction && (
                        <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg space-y-2 mt-2">
                          <p className="text-xs font-bold text-amber-800 dark:text-amber-300 flex items-center gap-1.5">
                            <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
                            System Prompt: Action on this notification to proceed to the next onboarding step?
                          </p>
                          <div className="flex items-center gap-2 pt-1">
                            <button
                              onClick={() => {
                                onActionNotification?.(al.id, 'approve');
                                if (onSelectClient && al.clientId) onSelectClient(al.clientId);
                              }}
                              className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg shadow-sm transition flex items-center gap-1.5 cursor-pointer"
                            >
                              <CheckCircle className="w-3.5 h-3.5" /> Approve & Proceed to Next Step
                            </button>
                            <button
                              onClick={() => onActionNotification?.(al.id, 'reject')}
                              className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 font-semibold text-xs rounded-lg transition cursor-pointer"
                            >
                              Request Clarification
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ==========================================================================
   6. REVIEW QUEUE VIEW
   ========================================================================== */
export function ReviewQueueView({ 
  clients, 
  onSelectClient, 
  onNavigateToWorkspace 
}: { 
  clients: ClientProfile[], 
  onSelectClient: (id: string) => void, 
  onNavigateToWorkspace: () => void 
}) {
  const [searchTerm, setSearchTerm] = useState('');
  const [riskFilter, setRiskFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [jurisdictionFilter, setJurisdictionFilter] = useState('all');

  // Derive risk tier helper
  const getRiskTier = (c: ClientProfile): { tier: string; color: string; badge: string } => {
    const rating = c.financials?.rating || '';
    const hasFlags = c.workflowNodes?.some(n => n.status === 'flagged');
    const name = c.companyName?.toLowerCase() || '';

    if (name.includes('aethelgard') || rating.includes('C') || rating.includes('High Risk')) {
      return {
        tier: 'Tier 4 Very High EDD',
        color: 'bg-rose-50 text-rose-700 border-rose-200',
        badge: 'High Risk (EDD)'
      };
    }
    if (name.includes('meridian') || rating.includes('BBB') || hasFlags) {
      return {
        tier: 'Tier 3 High',
        color: 'bg-amber-50 text-amber-700 border-amber-200',
        badge: 'Medium-High'
      };
    }
    if (name.includes('apex') || rating.includes('A')) {
      return {
        tier: 'Tier 2 Medium',
        color: 'bg-blue-50 text-blue-700 border-blue-200',
        badge: 'Medium Risk'
      };
    }
    return {
      tier: 'Tier 1 Low',
      color: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      badge: 'Low Risk'
    };
  };

  const filteredClients = useMemo(() => {
    return clients.filter(c => {
      const q = searchTerm.toLowerCase().trim();
      const risk = getRiskTier(c);
      const matchesSearch = !q ||
        c.companyName?.toLowerCase().includes(q) ||
        c.registrationNumber?.toLowerCase().includes(q) ||
        c.jurisdiction?.toLowerCase().includes(q) ||
        c.industry?.toLowerCase().includes(q) ||
        c.authorizedRepresentative?.name?.toLowerCase().includes(q);

      const matchesRisk = riskFilter === 'all' || risk.tier === riskFilter;

      const hasFlags = c.workflowNodes?.some(n => n.status === 'flagged');
      const isApproved = c.overallStatus === 'approved';
      let matchesStatus = true;
      if (statusFilter === 'flagged') matchesStatus = hasFlags;
      else if (statusFilter === 'approved') matchesStatus = isApproved;
      else if (statusFilter === 'in_progress') matchesStatus = !isApproved && !hasFlags;

      const matchesJurisdiction = jurisdictionFilter === 'all' || c.jurisdiction?.toLowerCase().includes(jurisdictionFilter.toLowerCase());

      return matchesSearch && matchesRisk && matchesStatus && matchesJurisdiction;
    });
  }, [clients, searchTerm, riskFilter, statusFilter, jurisdictionFilter]);

  const flaggedCount = clients.filter(c => c.workflowNodes?.some(n => n.status === 'flagged' || n.status === 'awaiting_approval')).length;
  const approvedCount = clients.filter(c => c.overallStatus === 'approved').length;

  return (
    <div className="space-y-6 text-left">
      {/* HEADER BAR (MATCHING RM WORKLIST LOOK & FEEL) */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200 font-mono flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
              Compliance &amp; Risk Gateway
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-50 text-purple-700 border border-purple-200 font-mono flex items-center gap-1">
              <Scale className="w-3.5 h-3.5 text-purple-600" />
              Underwriting &amp; Sanctions Gatekeeper
            </span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Compliance Review &amp; Underwriting Queue
          </h1>
          <p className="text-sm text-slate-500 mt-1 max-w-3xl leading-relaxed">
            Review high-risk client profiles, investigate sanctions/PEP alerts, audit multi-tier corporate shareholding graphs, and grant regulatory sign-off for onboarding activation.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onNavigateToWorkspace}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition shadow-xs cursor-pointer"
          >
            <Compass className="w-4 h-4" />
            Open Compliance Workspace
          </button>
        </div>
      </div>

      {/* 5 TOP METRIC KPI CARDS (MATCHING RM WORKLIST) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Underwriting Queue */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4.5 shadow-xs flex flex-col justify-between hover:border-slate-300 transition">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Underwriting Queue
          </span>
          <div className="mt-2.5">
            <div className="text-2xl font-black text-slate-900 tracking-tight font-sans">
              {clients.length} cases
            </div>
            <p className="text-xs font-medium text-slate-500 mt-0.5">
              {flaggedCount} requiring EDD sign-off
            </p>
          </div>
        </div>

        {/* Avg Review Velocity */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4.5 shadow-xs flex flex-col justify-between hover:border-slate-300 transition">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Avg Compliance Velocity
          </span>
          <div className="mt-2.5">
            <div className="text-2xl font-black text-slate-900 tracking-tight font-sans">
              18.5 hrs
            </div>
            <p className="text-xs font-semibold text-emerald-600 mt-0.5 flex items-center gap-1">
              <span>-5.5h vs 24h regulatory SLA</span>
            </p>
          </div>
        </div>

        {/* Sanctions & PEP Clearance */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4.5 shadow-xs flex flex-col justify-between hover:border-slate-300 transition">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Sanctions Clearance
          </span>
          <div className="mt-2.5">
            <div className="text-2xl font-black text-emerald-600 tracking-tight font-sans">
              99.8% clean
            </div>
            <p className="text-xs font-medium text-slate-500 mt-0.5">
              0 unresolved UN/OFAC blocks
            </p>
          </div>
        </div>

        {/* Compliance Gate Readiness */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4.5 shadow-xs flex flex-col justify-between hover:border-slate-300 transition">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Approved Sign-Offs
          </span>
          <div className="mt-2.5">
            <div className="text-2xl font-black text-slate-900 tracking-tight font-sans">
              {approvedCount + 4} entities
            </div>
            <p className="text-xs font-semibold text-emerald-600 mt-0.5 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Full audit trail documented</span>
            </p>
          </div>
        </div>

        {/* Action Attention */}
        <div className="bg-white border border-amber-200/80 bg-amber-50/20 rounded-2xl p-4.5 shadow-xs flex flex-col justify-between hover:border-amber-300 transition">
          <span className="text-xs font-semibold text-amber-700 uppercase tracking-wider flex items-center gap-1">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600" /> Action Attention
          </span>
          <div className="mt-2.5">
            <div className="text-2xl font-black text-amber-900 tracking-tight font-sans">
              1 urgent
            </div>
            <p className="text-xs font-medium text-amber-700 mt-0.5">
              Aethelgard Energy (Tier 4 EDD)
            </p>
          </div>
        </div>
      </div>

      {/* FILTER & SEARCH CONTROLS (MATCHING RM WORKLIST) */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="relative flex-1 min-w-[280px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by company name, registration no, jurisdiction, or representative..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 shrink-0 font-medium">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <span>Filters:</span>
          </div>

          <select
            value={riskFilter}
            onChange={(e) => setRiskFilter(e.target.value)}
            className="bg-slate-50 text-slate-700 text-xs px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer font-medium"
          >
            <option value="all">All Risk Tiers</option>
            <option value="Tier 4 Very High EDD">Tier 4 (Very High EDD)</option>
            <option value="Tier 3 High">Tier 3 (High Risk)</option>
            <option value="Tier 2 Medium">Tier 2 (Medium Risk)</option>
            <option value="Tier 1 Low">Tier 1 (Low Risk)</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-50 text-slate-700 text-xs px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer font-medium"
          >
            <option value="all">All Statuses</option>
            <option value="flagged">Action Required (Flagged)</option>
            <option value="in_progress">In Underwriting</option>
            <option value="approved">Approved</option>
          </select>

          <select
            value={jurisdictionFilter}
            onChange={(e) => setJurisdictionFilter(e.target.value)}
            className="bg-slate-50 text-slate-700 text-xs px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer font-medium"
          >
            <option value="all">All Jurisdictions</option>
            <option value="Singapore">Singapore</option>
            <option value="United Kingdom">United Kingdom</option>
            <option value="Switzerland">Switzerland</option>
            <option value="United States">United States</option>
          </select>

          {(searchTerm || riskFilter !== 'all' || statusFilter !== 'all' || jurisdictionFilter !== 'all') && (
            <button
              onClick={() => {
                setSearchTerm('');
                setRiskFilter('all');
                setStatusFilter('all');
                setJurisdictionFilter('all');
              }}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700 px-2 py-1 cursor-pointer shrink-0"
            >
              Reset
            </button>
          )}
        </div>
      </div>

      {/* CASE CARDS LIST (MATCHING RM WORKLIST CARD DESIGN) */}
      <div className="grid grid-cols-1 gap-4">
        {filteredClients.map((c, idx) => {
          const risk = getRiskTier(c);
          const hasFlags = c.workflowNodes?.some(n => n.status === 'flagged');
          const totalNodes = c.workflowNodes?.length || 6;
          const completedNodes = c.workflowNodes?.filter(n => n.status === 'completed').length || 0;
          const progressPercent = Math.round((completedNodes / totalNodes) * 100);

          return (
            <div
              key={`${c.id}_${idx}`}
              className="bg-white border border-slate-200 rounded-2xl p-5 hover:border-slate-300 transition shadow-xs text-left"
            >
              {/* Header Row */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3.5">
                <div className="flex items-center gap-3">
                  <span className="w-6 h-6 rounded-full bg-slate-900 text-white text-xs font-mono font-bold flex items-center justify-center shrink-0">
                    #{idx + 1}
                  </span>

                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-extrabold text-slate-900 text-base">{c.companyName}</h3>
                      <span className="text-xs font-mono px-2 py-0.5 bg-slate-100 text-slate-600 rounded-md font-bold">
                        {c.industry}
                      </span>
                      <span className="text-xs font-mono px-2 py-0.5 bg-slate-100 text-slate-600 rounded-md font-medium">
                        Reg: #{c.registrationNumber}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-1">
                      Jurisdiction: <strong className="text-slate-700">{c.jurisdiction}</strong> • Rep: <strong className="text-slate-700">{c.authorizedRepresentative?.name}</strong> ({c.authorizedRepresentative?.role})
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-start sm:self-auto shrink-0">
                  <span className={`px-2.5 py-1 rounded-md text-[11px] font-mono font-bold border ${risk.color}`}>
                    {risk.tier}
                  </span>
                  {hasFlags ? (
                    <span className="px-2.5 py-1 rounded-md text-[11px] font-mono font-bold bg-rose-50 text-rose-700 border border-rose-200 animate-pulse flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3 text-rose-600" />
                      FLAGGED ALERT
                    </span>
                  ) : c.overallStatus === 'approved' ? (
                    <span className="px-2.5 py-1 rounded-md text-[11px] font-mono font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      Approved
                    </span>
                  ) : (
                    <span className="px-2.5 py-1 rounded-md text-[11px] font-mono font-bold bg-blue-50 text-blue-700 border border-blue-200">
                      In Underwriting
                    </span>
                  )}
                </div>
              </div>

              {/* Compliance Flag / EDD Trigger Box */}
              {hasFlags && (
                <div className="mt-3.5 p-3.5 bg-amber-50/70 border border-amber-200 rounded-xl flex items-start gap-3">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div className="text-xs text-amber-950 leading-relaxed font-sans">
                    <strong className="font-bold text-amber-900 uppercase font-mono text-[10px] block mb-0.5">
                      COMPLIANCE ACTION ATTENTION TRIGGER
                    </strong>
                    {c.companyName.includes('Aethelgard') ? (
                      <span>Complex multi-tiered offshore holding structure (Geneva &amp; Cayman Islands). 28.5% beneficial ownership threshold requires senior underwriter sign-off and notarized trust deed verification.</span>
                    ) : c.companyName.includes('Meridian') ? (
                      <span>Senior Advisory Board Member identified as former government official (PEP Tier 2). Dual-authorization AML check required under Policy Section 4.2.</span>
                    ) : (
                      <span>Enhanced Due Diligence (EDD) required: Review beneficial ownership concentration and tax classification documents.</span>
                    )}
                  </div>
                </div>
              )}

              {/* Progress and Details Bar */}
              <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
                <div>
                  <div className="flex items-center justify-between text-xs mb-1.5 font-medium">
                    <span className="text-slate-500 font-mono">Stage Progress</span>
                    <span className="font-bold text-slate-700">{completedNodes} of {totalNodes} completed ({progressPercent}%)</span>
                  </div>
                  <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-600 rounded-full transition-all duration-300"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                </div>

                <div className="text-xs space-y-1">
                  <span className="text-slate-500 font-mono uppercase text-[10px] font-bold block">Financial Rating &amp; Assets</span>
                  <div className="font-medium text-slate-800">
                    Rating: <strong className="text-blue-700 font-mono">{c.financials?.rating || 'AAA / Tier 1'}</strong> • Assets: <strong>{c.financials?.assets || '$140M'}</strong>
                  </div>
                </div>

                <div className="text-xs space-y-1">
                  <span className="text-slate-500 font-mono uppercase text-[10px] font-bold block">Watchlist Screening Standing</span>
                  <div className="font-medium text-slate-800 flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    <span>UN/OFAC/EU Watchlists: <strong className="text-emerald-700 font-mono">CLEARED</strong></span>
                  </div>
                </div>
              </div>

              {/* Footer Actions */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                <div className="text-xs font-mono text-slate-500 flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-bold">
                    Vault Docs: {c.documents?.length || 0}
                  </span>
                  <span>•</span>
                  <span>Shareholders: {c.shareholders?.length || 0}</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      onSelectClient(c.id);
                      onNavigateToWorkspace();
                    }}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <Compass className="w-3.5 h-3.5" />
                    Investigate in Workspace
                  </button>
                </div>
              </div>
            </div>
          );
        })}

        {filteredClients.length === 0 && (
          <div className="p-12 text-center bg-white border border-slate-200 rounded-2xl">
            <ShieldCheck className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-bold text-slate-700">No cases match your filter</p>
            <p className="text-xs text-slate-400 mt-1">Try clearing your search keyword or resetting the filters.</p>
          </div>
        )}
      </div>
    </div>
  );
}

/* ==========================================================================
   6b. OPERATIONS REVIEW QUEUE VIEW & DOC VERIFICATION HUB VIEW
   ========================================================================== */
export function OperationsQueueView({ 
  clients, 
  onSelectClient, 
  onNavigateToWorkspace 
}: { 
  clients: ClientProfile[], 
  onSelectClient: (id: string) => void, 
  onNavigateToWorkspace: () => void 
}) {
  const [filter, setFilter] = useState<'all' | 'flagged' | 'pending'>('all');

  const filteredClients = useMemo(() => {
    if (filter === 'flagged') {
      return clients.filter(c => c.workflowNodes.some(n => n.status === 'flagged' || n.status === 'awaiting_approval'));
    }
    if (filter === 'pending') {
      return clients.filter(c => c.workflowNodes.some(n => n.status === 'pending' || n.status === 'running'));
    }
    return clients;
  }, [clients, filter]);

  return (
    <div className="space-y-6 text-left">
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <ListTodo className="w-5 h-5 text-[#002D62] dark:text-[#00A3E0]" />
            <span>Operations Review Queue</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Operations Officer Command Center: Monitor task execution exceptions, document verification reviews, registry extractions, and sign-off requests.
          </p>
        </div>

        <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 self-start">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              filter === 'all'
                ? 'bg-[#002D62] text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            All Onboardings ({clients.length})
          </button>
          <button
            onClick={() => setFilter('flagged')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
              filter === 'flagged'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            Exceptions ({clients.filter(c => c.workflowNodes.some(n => n.status === 'flagged')).length})
          </button>
          <button
            onClick={() => setFilter('pending')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              filter === 'pending'
                ? 'bg-[#00A3E0] text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            In Progress ({clients.filter(c => c.workflowNodes.some(n => n.status === 'running' || n.status === 'pending')).length})
          </button>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50 dark:bg-slate-900/40">
          <span className="text-xs font-bold text-slate-700 dark:text-slate-300 font-mono">OPERATIONS REVIEW ITEMS</span>
          <span className="text-[11px] font-mono text-[#008752] font-bold bg-emerald-50 dark:bg-emerald-950/20 px-2.5 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-800">
            OPERATIONS REVIEWER ACTIVE
          </span>
        </div>

        <div className="divide-y divide-slate-100 dark:divide-slate-800/60">
          {filteredClients.map((c, idx) => {
            const flaggedNodes = c.workflowNodes.filter(n => n.status === 'flagged' || n.status === 'awaiting_approval');
            const completedCount = c.workflowNodes.filter(n => n.status === 'completed').length;

            return (
              <div 
                key={`${c.id}_ops_${idx}`} 
                onClick={() => {
                  onSelectClient(c.id);
                  onNavigateToWorkspace();
                }}
                className="p-5 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors cursor-pointer"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-slate-900 dark:text-white text-base">{c.companyName}</h4>
                    <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-[10px] font-mono text-slate-500 dark:text-slate-400 rounded">
                      {c.jurisdiction}
                    </span>
                    {flaggedNodes.length > 0 && (
                      <span className="px-2 py-0.5 bg-amber-100 dark:bg-amber-950/40 text-amber-800 dark:text-amber-400 font-mono text-[10px] font-bold rounded flex items-center gap-1 animate-pulse">
                        <AlertTriangle className="w-3 h-3" />
                        {flaggedNodes.length} Exception Alert(s)
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Reg No: #{c.registrationNumber} • {c.industry} • Documents: {c.documents.length} Uploaded
                  </p>
                  <div className="flex items-center gap-2 pt-1">
                    <span className="text-[10px] font-mono text-slate-400 uppercase">Workflow Stages:</span>
                    <div className="flex items-center gap-1">
                      {c.workflowNodes.map(n => (
                        <span 
                          key={n.id} 
                          className={`w-2.5 h-2.5 rounded-full ${
                            n.status === 'completed' ? 'bg-[#008752]' :
                            n.status === 'flagged' ? 'bg-amber-500' :
                            n.status === 'running' ? 'bg-[#00A3E0] animate-pulse' :
                            'bg-slate-200 dark:bg-slate-700'
                          }`}
                          title={`${n.name}: ${n.status}`}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 shrink-0">
                  <div className="text-right font-mono">
                    <span className="text-[10px] text-slate-400 uppercase block">Progress</span>
                    <strong className="text-xs text-[#002D62] dark:text-[#00A3E0]">
                      {completedCount}/{c.workflowNodes.length} Done
                    </strong>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectClient(c.id);
                      onNavigateToWorkspace();
                    }}
                    className="px-4 py-2 bg-[#008752] hover:bg-[#006e42] text-white font-bold text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-sm"
                  >
                    <span>Review Operations Journey</span> <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export function DocVerificationHubView({ 
  activeClient,
  onApproveDocument,
  onRejectDocument
}: { 
  activeClient: ClientProfile;
  onApproveDocument?: (docId: string) => void;
  onRejectDocument?: (docId: string, reason?: string) => void;
}) {
  const documents = activeClient?.documents || [];
  const [selectedDocId, setSelectedDocId] = useState<string>(documents[0]?.id || '');
  const [viewMode, setViewMode] = useState<'list' | 'preview'>('list');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'verified' | 'pending' | 'externally_sourced'>('all');
  const [fullscreenDoc, setFullscreenDoc] = useState<UploadedDocument | null>(null);
  const [zoomLevel, setZoomLevel] = useState(100);
  const [rotation, setRotation] = useState(0);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [showRejectPrompt, setShowRejectPrompt] = useState(false);
  const [rejectReason, setRejectReason] = useState('');

  // Keep selectedDoc in sync if documents change or on first load
  const activeDoc = useMemo(() => {
    return documents.find(d => d.id === selectedDocId) || documents[0] || null;
  }, [documents, selectedDocId]);

  const verifiedCount = documents.filter(d => d.status === 'verified').length;
  const pendingCount = documents.filter(d => d.status === 'pending' || d.status === 'pending_review').length;
  const externalCount = documents.filter(d => d.source === 'externally_sourced').length;
  const totalAttributesCount = documents.reduce((sum, d) => sum + (d.ocrData ? Object.keys(d.ocrData).length : 0), 0);

  const filteredDocuments = useMemo(() => {
    return documents.filter((doc) => {
      if (statusFilter === 'verified' && doc.status !== 'verified') return false;
      if (statusFilter === 'pending' && doc.status !== 'pending' && doc.status !== 'pending_review') return false;
      if (statusFilter === 'externally_sourced' && doc.source !== 'externally_sourced') return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = doc.name.toLowerCase().includes(q);
        const matchesType = doc.type.toLowerCase().includes(q);
        const matchesSource = (doc.sourceDetails || '').toLowerCase().includes(q);
        const matchesOcr = doc.ocrData 
          ? Object.entries(doc.ocrData).some(([k, v]) => k.toLowerCase().includes(q) || String(v).toLowerCase().includes(q))
          : false;
        return matchesName || matchesType || matchesSource || matchesOcr;
      }
      return true;
    });
  }, [documents, statusFilter, searchQuery]);

  const handleCopy = (key: string, val: string) => {
    navigator.clipboard.writeText(val);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 1800);
  };

  const handleZoomIn = () => setZoomLevel(prev => Math.min(prev + 20, 200));
  const handleZoomOut = () => setZoomLevel(prev => Math.max(prev - 20, 60));
  const handleRotate = () => setRotation(prev => (prev + 90) % 360);

  const handleSelectAndInspectDoc = (doc: UploadedDocument) => {
    setSelectedDocId(doc.id);
    setViewMode('preview');
    setShowRejectPrompt(false);
  };

  const currentIndex = documents.findIndex(d => d.id === activeDoc?.id);
  const hasPrev = currentIndex > 0;
  const hasNext = currentIndex >= 0 && currentIndex < documents.length - 1;

  if (documents.length === 0) {
    return (
      <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center text-slate-500 shadow-xs">
        <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
        <h3 className="text-base font-bold text-slate-800">No Documents Ingested</h3>
        <p className="text-xs text-slate-500 mt-1">There are no client verification documents currently available in this vault.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 text-left">
      {/* 1. HEADER BAR */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5 flex-wrap">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200 font-mono">
                Operations Verification
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-100 text-slate-700 border border-slate-200 font-mono">
                LayoutLMv3 OCR Pipeline
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 font-mono flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                99.4% Parsing Confidence
              </span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <FileText className="w-6 h-6 text-blue-600" />
              <span>Document Review Hub</span>
            </h2>
            <p className="text-sm text-slate-500 mt-1 max-w-3xl leading-relaxed">
              Review document extraction logs, LayoutLMv3 key-value pairs, signature checks, and legal document authenticity for {activeClient?.companyName || 'Active Client'}.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <span className="px-3.5 py-2 bg-slate-50 border border-slate-200 text-slate-700 rounded-xl text-xs font-mono font-bold">
              Total Vault Files: {documents.length}
            </span>
          </div>
        </div>

        {/* Quick Stats Banner */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 border-t border-slate-100">
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Vault Files</span>
              <span className="text-base font-bold text-slate-900 mt-0.5 block">{documents.length}</span>
            </div>
            <FileText className="w-4 h-4 text-slate-400" />
          </div>
          <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-100 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider block">Verified Records</span>
              <span className="text-base font-bold text-emerald-800 mt-0.5 block">{verifiedCount}</span>
            </div>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="p-3 bg-amber-50/60 rounded-xl border border-amber-100 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-bold text-amber-700 uppercase tracking-wider block">Pending / In-Review</span>
              <span className="text-base font-bold text-amber-800 mt-0.5 block">{pendingCount}</span>
            </div>
            <AlertTriangle className="w-4 h-4 text-amber-600" />
          </div>
          <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-100 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-bold text-blue-700 uppercase tracking-wider block">OCR Attributes</span>
              <span className="text-base font-bold text-blue-800 mt-0.5 block">{totalAttributesCount} Fields</span>
            </div>
            <Layers className="w-4 h-4 text-blue-600" />
          </div>
        </div>

        {/* View Mode Switcher Tab Bar */}
        <div className="pt-3 border-t border-slate-100 flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl border border-slate-200">
            <button
              onClick={() => setViewMode('list')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
                viewMode === 'list'
                  ? 'bg-white text-blue-600 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>List of Documents ({documents.length})</span>
            </button>
            <button
              onClick={() => {
                if (activeDoc) {
                  setViewMode('preview');
                }
              }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
                viewMode === 'preview'
                  ? 'bg-white text-blue-600 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Document Preview & Attributes {activeDoc ? `(${activeDoc.name})` : ''}</span>
            </button>
          </div>

          {viewMode === 'list' && (
            <div className="flex items-center gap-2 flex-wrap">
              {/* Search input */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search documents or attributes..."
                  className="pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 outline-none focus:border-blue-400 w-56 transition"
                />
              </div>

              {/* Status Filter buttons */}
              <div className="flex items-center gap-1 bg-slate-50 p-1 rounded-xl border border-slate-200 text-xs">
                <button
                  onClick={() => setStatusFilter('all')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer ${
                    statusFilter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  All ({documents.length})
                </button>
                <button
                  onClick={() => setStatusFilter('verified')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer ${
                    statusFilter === 'verified' ? 'bg-white text-emerald-700 shadow-xs' : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Verified ({verifiedCount})
                </button>
                <button
                  onClick={() => setStatusFilter('pending')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer ${
                    statusFilter === 'pending' ? 'bg-white text-amber-700 shadow-xs' : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Pending ({pendingCount})
                </button>
                <button
                  onClick={() => setStatusFilter('externally_sourced')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer ${
                    statusFilter === 'externally_sourced' ? 'bg-white text-blue-700 shadow-xs' : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Externally Sourced ({externalCount})
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* =========================================================================
          VIEW MODE A: LIST OF DOCUMENTS
          ========================================================================= */}
      {viewMode === 'list' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <FileText className="w-5 h-5 text-blue-600" />
                <span>Client Vault Documents</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Click any document in the list to open its visual preview and inspect all extracted OCR attributes.
              </p>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              Showing {filteredDocuments.length} of {documents.length} files
            </span>
          </div>

          {filteredDocuments.length === 0 ? (
            <div className="py-12 text-center text-slate-400">
              <FileText className="w-10 h-10 mx-auto mb-2 text-slate-300" />
              <p className="text-sm font-semibold text-slate-700">No documents found matching your filter.</p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setStatusFilter('all');
                }}
                className="mt-2 text-xs font-bold text-blue-600 hover:underline cursor-pointer"
              >
                Reset search & filters
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredDocuments.map((doc) => {
                const attrCount = doc.ocrData ? Object.keys(doc.ocrData).length : 0;
                const isCurrentActive = doc.id === activeDoc?.id;

                return (
                  <div
                    key={doc.id}
                    onClick={() => handleSelectAndInspectDoc(doc)}
                    className={`group p-4 rounded-xl border transition-all cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                      isCurrentActive
                        ? 'border-blue-300 bg-blue-50/30 shadow-xs'
                        : 'border-slate-200 hover:border-blue-300 hover:bg-slate-50/60'
                    }`}
                  >
                    {/* Left: Document Info */}
                    <div className="flex items-start sm:items-center gap-3.5 flex-1 min-w-0">
                      <div className="p-3 bg-blue-50 text-blue-600 rounded-xl border border-blue-200 shrink-0 group-hover:scale-105 transition-transform">
                        <FileText className="w-6 h-6" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors truncate">
                            {doc.name}
                          </h4>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                            doc.status === 'verified'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : doc.status === 'rejected'
                              ? 'bg-rose-50 text-rose-700 border border-rose-200'
                              : 'bg-amber-50 text-amber-700 border border-amber-200'
                          }`}>
                            {doc.status}
                          </span>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                            doc.source === 'externally_sourced'
                              ? 'bg-purple-50 text-purple-700 border border-purple-200'
                              : 'bg-blue-50 text-blue-700 border border-blue-200'
                          }`}>
                            {doc.source === 'externally_sourced' ? '🌐 External Sourced' : '👤 Customer Upload'}
                          </span>
                        </div>

                        <div className="flex items-center gap-2 text-xs text-slate-500 font-mono mt-1 flex-wrap">
                          <span className="font-sans font-medium text-slate-700">{doc.type}</span>
                          <span>•</span>
                          <span>{doc.size}</span>
                          <span>•</span>
                          <span>Uploaded: {doc.uploadedAt}</span>
                          <span>•</span>
                          <span className="text-slate-400">ID: {doc.id}</span>
                        </div>

                        {/* Extracted Attributes Preview Mini Chips */}
                        {doc.ocrData && attrCount > 0 && (
                          <div className="mt-2 flex items-center gap-1.5 flex-wrap">
                            <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded border border-slate-200 flex items-center gap-1">
                              <Layers className="w-3 h-3 text-blue-600" /> {attrCount} OCR Fields:
                            </span>
                            {Object.entries(doc.ocrData).slice(0, 3).map(([k, v]) => (
                              <span key={k} className="text-[10px] font-mono bg-white border border-slate-200 text-slate-600 px-2 py-0.5 rounded truncate max-w-[200px]">
                                <strong className="text-slate-800">{k}:</strong> {String(v)}
                              </span>
                            ))}
                            {attrCount > 3 && (
                              <span className="text-[10px] font-mono text-slate-400 font-semibold">
                                +{attrCount - 3} more
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Right: Actions */}
                    <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSelectAndInspectDoc(doc);
                        }}
                        className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Inspect Preview & OCR</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setFullscreenDoc(doc);
                        }}
                        className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 rounded-xl border border-slate-200 transition cursor-pointer"
                        title="Open in Fullscreen Modal"
                      >
                        <Maximize2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* =========================================================================
          VIEW MODE B: DOCUMENT PREVIEW AND EXTRACTED ATTRIBUTES
          ========================================================================= */}
      {viewMode === 'preview' && activeDoc && (
        <div className="space-y-6">
          {/* Navigation Bar: Back to List & Document Switcher */}
          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setViewMode('list')}
                className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl border border-slate-200 transition flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back to Document List</span>
              </button>

              <div className="h-5 w-px bg-slate-200 hidden sm:block" />

              <div className="flex items-center gap-1 overflow-x-auto py-0.5">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider font-mono mr-1 hidden sm:inline">
                  Switch Doc:
                </span>
                {documents.map((d) => (
                  <button
                    key={d.id}
                    onClick={() => {
                      setSelectedDocId(d.id);
                      setShowRejectPrompt(false);
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold font-mono transition cursor-pointer truncate max-w-[130px] border ${
                      d.id === activeDoc.id
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
                    }`}
                    title={d.name}
                  >
                    {d.name.replace('.pdf', '')}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => {
                  if (hasPrev) {
                    setSelectedDocId(documents[currentIndex - 1].id);
                    setShowRejectPrompt(false);
                  }
                }}
                disabled={!hasPrev}
                className="px-2.5 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-bold rounded-lg border border-slate-200 transition cursor-pointer disabled:opacity-40"
              >
                ‹ Prev
              </button>
              <span className="text-xs font-mono text-slate-500 font-bold">
                {currentIndex + 1} / {documents.length}
              </span>
              <button
                onClick={() => {
                  if (hasNext) {
                    setSelectedDocId(documents[currentIndex + 1].id);
                    setShowRejectPrompt(false);
                  }
                }}
                disabled={!hasNext}
                className="px-2.5 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-bold rounded-lg border border-slate-200 transition cursor-pointer disabled:opacity-40"
              >
                Next ›
              </button>
            </div>
          </div>

          {/* Active Document Overview Card */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-blue-50 text-blue-600 border border-blue-200 shrink-0">
                  <FileText className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-base font-bold text-slate-900">{activeDoc.name}</h3>
                    <span className={`px-2.5 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                      activeDoc.status === 'verified' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                      activeDoc.status === 'rejected' ? 'bg-rose-50 text-rose-700 border border-rose-200' :
                      'bg-amber-50 text-amber-700 border border-amber-200'
                    }`}>
                      {activeDoc.status}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-slate-100 text-slate-600 border border-slate-200">
                      Doc ID: {activeDoc.id}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 font-mono mt-0.5">
                    {activeDoc.type} • {activeDoc.size}
                  </p>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-2 shrink-0 flex-wrap">
                <button
                  onClick={() => onApproveDocument?.(activeDoc.id)}
                  className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Approve Document</span>
                </button>
                <button
                  onClick={() => setShowRejectPrompt(!showRejectPrompt)}
                  className="px-3.5 py-2 bg-white hover:bg-rose-50 text-rose-700 font-bold text-xs rounded-xl border border-rose-200 transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <AlertTriangle className="w-4 h-4 text-rose-500" />
                  <span>Reject / Re-upload</span>
                </button>
                <button
                  onClick={() => setFullscreenDoc(activeDoc)}
                  className="px-3 py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-xl border border-slate-200 transition flex items-center gap-1.5 cursor-pointer"
                  title="Open Fullscreen Viewer"
                >
                  <Maximize2 className="w-3.5 h-3.5 text-slate-500" />
                  <span className="hidden sm:inline">Fullscreen</span>
                </button>
              </div>
            </div>

            {/* Detailed Overview Metadata Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-slate-100 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Document Type</span>
                <span className="font-bold text-slate-800 truncate block mt-0.5">{activeDoc.type}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Uploaded Timestamp</span>
                <span className="font-mono text-slate-700 block mt-0.5">{activeDoc.uploadedAt}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Ingestion Source</span>
                <div className="mt-0.5">
                  <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                    activeDoc.source === 'externally_sourced' 
                      ? 'bg-purple-50 text-purple-700 border border-purple-200' 
                      : 'bg-blue-50 text-blue-700 border border-blue-200'
                  }`}>
                    {activeDoc.source === 'externally_sourced' ? '🌐 Externally Sourced' : '👤 Customer Provided'}
                  </span>
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Vault Integrity</span>
                <span className="inline-flex items-center gap-1 text-[11px] font-mono text-emerald-700 font-semibold mt-0.5">
                  <Lock className="w-3 h-3 text-emerald-600" /> SHA-256 Verified
                </span>
              </div>
            </div>

            {/* Rejection Prompt Bar */}
            {showRejectPrompt && (
              <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2 flex-1">
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                  <input
                    type="text"
                    value={rejectReason}
                    onChange={(e) => setRejectReason(e.target.value)}
                    placeholder="Specify rejection reason (e.g., Unclear signature, expired date, missing witness)..."
                    className="w-full p-2 bg-white border border-rose-300 rounded-lg text-slate-900 text-xs outline-none focus:ring-2 focus:ring-rose-400"
                  />
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => setShowRejectPrompt(false)}
                    className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-lg text-xs font-semibold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      onRejectDocument?.(activeDoc.id, rejectReason);
                      setShowRejectPrompt(false);
                    }}
                    className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-lg text-xs cursor-pointer shadow-xs"
                  >
                    Confirm Reject
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* SIDE-BY-SIDE VIEW: PREVIEW ON THE LEFT, EXTRACTED ATTRIBUTES ON THE RIGHT */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* LEFT: DOCUMENT PREVIEW CANVAS (NO DOTS!) */}
            <div className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden flex flex-col">
              {/* Preview Toolbar */}
              <div className="px-5 py-3.5 bg-white border-b border-slate-200 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <Eye className="w-4 h-4 text-blue-600" />
                  <span className="text-xs font-bold text-slate-800">Document Preview</span>
                  <span className="text-[10px] font-mono text-slate-400">({activeDoc.type})</span>
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex items-center bg-slate-100 rounded-xl p-0.5 border border-slate-200">
                    <button
                      onClick={handleZoomOut}
                      disabled={zoomLevel <= 60}
                      className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-white rounded-lg transition cursor-pointer disabled:opacity-40"
                      title="Zoom Out"
                    >
                      <ZoomOut className="w-3.5 h-3.5" />
                    </button>
                    <span className="text-[10px] font-mono font-bold px-2 text-slate-700">{zoomLevel}%</span>
                    <button
                      onClick={handleZoomIn}
                      disabled={zoomLevel >= 200}
                      className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-white rounded-lg transition cursor-pointer disabled:opacity-40"
                      title="Zoom In"
                    >
                      <ZoomIn className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <button
                    onClick={handleRotate}
                    className="p-2 text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl border border-slate-200 transition cursor-pointer"
                    title="Rotate 90°"
                  >
                    <RotateCw className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => setFullscreenDoc(activeDoc)}
                    className="p-2 text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl border border-slate-200 transition cursor-pointer"
                    title="Fullscreen Viewer"
                  >
                    <Maximize2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Document Canvas Area: Clean solid slate-100/70 background WITHOUT DOTS */}
              <div className="p-6 sm:p-8 bg-slate-100/70 flex justify-center items-start min-h-[640px] max-h-[820px] overflow-auto">
                <DocumentPreviewCanvas document={activeDoc} zoomLevel={zoomLevel} rotation={rotation} />
              </div>

              {/* Preview Footer note */}
              <div className="px-5 py-2.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500 font-mono">
                <span className="flex items-center gap-1.5">
                  <Lock className="w-3 h-3 text-amber-500" /> Bank-Grade Read-Only Canvas
                </span>
                <span>Digital Watermarked & Tamper-Evident</span>
              </div>
            </div>

            {/* RIGHT: EXTRACTED ATTRIBUTES */}
            <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden flex flex-col">
              {/* Attributes Header */}
              <div className="px-5 py-3.5 bg-white border-b border-slate-200 flex items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <Layers className="w-4 h-4 text-blue-600" />
                    <span>Extracted Attributes</span>
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    LayoutLMv3 OCR Pipeline • High-Confidence Field Mapping
                  </p>
                </div>
                <span className="px-2.5 py-1 rounded-full text-[10px] font-mono font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  99.4% Match
                </span>
              </div>

              {/* Attributes List */}
              <div className="p-5 space-y-3 max-h-[720px] overflow-y-auto">
                {activeDoc.ocrData && Object.keys(activeDoc.ocrData).length > 0 ? (
                  <div className="space-y-3">
                    {Object.entries(activeDoc.ocrData).map(([key, val]) => (
                      <div 
                        key={key} 
                        className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5 hover:border-blue-300 transition-colors group"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-[11px] font-bold text-slate-600 font-mono uppercase tracking-wider">{key}</span>
                          <button
                            onClick={() => handleCopy(key, String(val))}
                            className="text-[10px] text-slate-400 hover:text-blue-600 font-medium flex items-center gap-1 cursor-pointer transition"
                            title="Copy value"
                          >
                            {copiedKey === key ? (
                              <span className="text-emerald-600 font-bold flex items-center gap-1">
                                <CheckCheck className="w-3 h-3" /> Copied
                              </span>
                            ) : (
                              <span className="flex items-center gap-1 opacity-60 group-hover:opacity-100">
                                <Copy className="w-3 h-3" /> Copy
                              </span>
                            )}
                          </button>
                        </div>
                        <div className="text-xs font-semibold text-slate-900 bg-white p-2.5 rounded-lg border border-slate-200 font-mono break-words">
                          {String(val)}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="py-16 text-center text-slate-400 bg-slate-50 rounded-2xl border border-dashed border-slate-200 p-6">
                    <Layers className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                    <p className="text-xs font-medium">No key-value OCR attributes found for this document.</p>
                  </div>
                )}

                {/* Automated Verification Checklist */}
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
                  <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block font-mono">
                    Automated Verification Gates
                  </span>
                  <div className="space-y-1.5 text-[11px]">
                    <div className="flex items-center justify-between text-slate-600">
                      <span className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Official Signature Authenticity
                      </span>
                      <span className="font-mono text-emerald-700 font-bold">VERIFIED</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-600">
                      <span className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> LayoutLMv3 Structural Alignment
                      </span>
                      <span className="font-mono text-emerald-700 font-bold">100% MATCH</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-600">
                      <span className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> ACRA / Corporate Registry Parity
                      </span>
                      <span className="font-mono text-emerald-700 font-bold">PARITY CONFIRMED</span>
                    </div>
                  </div>
                </div>

                {/* Read-Only Vault Governance Notice */}
                <div className="p-3 bg-blue-50/80 border border-blue-200/80 rounded-xl space-y-1 text-blue-900">
                  <div className="flex items-center gap-1.5 font-bold text-blue-800 text-xs">
                    <ShieldCheck className="w-4 h-4 text-blue-600" />
                    <span>Bank-Grade Read-Only Vault</span>
                  </div>
                  <p className="text-[11px] text-blue-700 leading-relaxed">
                    Direct downloads are disabled across all operations consoles to maintain institutional document custody standards.
                  </p>
                </div>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* REACT DOCUMENT VIEWER MODAL (FULLSCREEN ACCESS) */}
      <DocumentViewerModal
        document={fullscreenDoc}
        isOpen={Boolean(fullscreenDoc)}
        onClose={() => setFullscreenDoc(null)}
        readOnly={false}
        userRole="compliance"
        onApprove={(docId) => {
          onApproveDocument?.(docId);
          setFullscreenDoc(null);
        }}
        onReject={(docId, reason) => {
          onRejectDocument?.(docId, reason);
          setFullscreenDoc(null);
        }}
      />
    </div>
  );
}

/* ==========================================================================
   7. SCREENING RESULTS VIEW
   ========================================================================== */
export function ScreeningResultsView({ activeClient }: { activeClient: ClientProfile }) {
  const [sanctionsQuery, setSanctionsQuery] = useState(activeClient?.companyName || 'Aether Aero-Tech Pte Ltd');
  const [sanctionsResult, setSanctionsResult] = useState<any>(null);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    if (activeClient?.companyName) {
      setSanctionsQuery(activeClient.companyName);
    }
  }, [activeClient?.id, activeClient?.companyName]);

  const handleRunSanctionsScreen = async (queryToScreen?: string) => {
    const target = queryToScreen || sanctionsQuery;
    if (!target.trim()) return;
    setSearching(true);
    try {
      const res = await fetch('/api/sanctions/screen', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: target })
      });
      const data = await res.json();
      setSanctionsResult(data);
    } catch (e) {
      console.error(e);
    } finally {
      setSearching(false);
    }
  };

  const pepCount = activeClient?.shareholders?.filter(s => s.pepStatus).length || 0;

  return (
    <div className="space-y-6 text-left">
      {/* HEADER BAR (MATCHING RM WORKLIST) */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200 font-mono flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
              PEP &amp; Sanctions Screening Engine
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200 font-mono flex items-center gap-1">
              <Globe className="w-3.5 h-3.5 text-rose-600" />
              Live UN &amp; OFAC Public Feeds Active
            </span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            PEP &amp; Public Sanctions Screening Board
          </h1>
          <p className="text-sm text-slate-500 mt-1 max-w-3xl leading-relaxed">
            Automated fuzzy screening against live UN Security Council, US OFAC SDN, and EU Consolidated Financial Sanctions datasets with zero false-hit latency.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => handleRunSanctionsScreen()}
            disabled={searching}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition shadow-xs cursor-pointer disabled:opacity-50"
          >
            {searching ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
            Screen Active Entity
          </button>
        </div>
      </div>

      {/* 5 TOP METRIC KPI CARDS (MATCHING RM WORKLIST) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Screening Coverage */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4.5 shadow-xs flex flex-col justify-between hover:border-slate-300 transition">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Sanctions Datasets
          </span>
          <div className="mt-2.5">
            <div className="text-2xl font-black text-slate-900 tracking-tight font-sans">
              4 Feeds
            </div>
            <p className="text-xs font-medium text-slate-500 mt-0.5">
              OFAC, UNSC, EU &amp; UK HMT
            </p>
          </div>
        </div>

        {/* Active Target */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4.5 shadow-xs flex flex-col justify-between hover:border-slate-300 transition">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Target Profile
          </span>
          <div className="mt-2.5">
            <div className="text-xl font-bold text-slate-900 tracking-tight truncate font-sans">
              {activeClient?.companyName || 'Corporate Target'}
            </div>
            <p className="text-xs font-medium text-slate-500 mt-0.5 truncate">
              {activeClient?.jurisdiction || 'Global'}
            </p>
          </div>
        </div>

        {/* UBOs Screened */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4.5 shadow-xs flex flex-col justify-between hover:border-slate-300 transition">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Beneficial Owners
          </span>
          <div className="mt-2.5">
            <div className="text-2xl font-black text-slate-900 tracking-tight font-sans">
              {activeClient?.shareholders?.length || 0} UBOs
            </div>
            <p className="text-xs font-medium text-slate-500 mt-0.5">
              {pepCount > 0 ? `${pepCount} PEP matches flagged` : 'All cleared'}
            </p>
          </div>
        </div>

        {/* Precision Threshold */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4.5 shadow-xs flex flex-col justify-between hover:border-slate-300 transition">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Fuzzy Precision
          </span>
          <div className="mt-2.5">
            <div className="text-2xl font-black text-emerald-600 tracking-tight font-sans">
              85% Threshold
            </div>
            <p className="text-xs font-semibold text-emerald-600 mt-0.5 flex items-center gap-1">
              <span>Levenshtein &amp; phonetic match</span>
            </p>
          </div>
        </div>

        {/* Clearance Status */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4.5 shadow-xs flex flex-col justify-between hover:border-slate-300 transition">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            SDN Proximity
          </span>
          <div className="mt-2.5">
            <div className="text-2xl font-black text-emerald-600 tracking-tight font-sans">
              Clean
            </div>
            <p className="text-xs font-medium text-slate-500 mt-0.5">
              0 unresolved SDN blocks
            </p>
          </div>
        </div>
      </div>

      {/* SEARCH & QUERY COMPONENT */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 font-mono uppercase tracking-wider">
            <Search className="w-4 h-4 text-blue-600" />
            Live UN Security Council &amp; OFAC Sanctions Query
          </h3>
          <span className="text-xs font-mono text-emerald-700 font-bold bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full">
            REAL AUTOMATED FUZZY SEARCH
          </span>
        </div>

        <p className="text-xs text-slate-500 leading-relaxed">
          Screen any natural person or corporate entity against live international sanctions registers.
        </p>

        <div className="flex flex-col sm:flex-row items-stretch gap-2.5">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={sanctionsQuery}
              onChange={(e) => setSanctionsQuery(e.target.value)}
              placeholder="Enter entity name (e.g., Sberbank, VTB, Tornado Cash, Igor Sechin)..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white font-mono transition"
            />
          </div>
          <button
            onClick={() => handleRunSanctionsScreen()}
            disabled={searching}
            className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 shrink-0 cursor-pointer shadow-xs disabled:opacity-50"
          >
            {searching ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
            Screen Sanctions Feeds
          </button>
        </div>

        {/* Quick presets */}
        <div className="flex flex-wrap items-center gap-2 pt-1 text-xs text-slate-500">
          <span className="font-mono text-xs uppercase font-bold text-slate-400">Quick Test Presets:</span>
          {['Sberbank of Russia', 'VTB Bank', 'Tornado Cash', 'Al-Qaida', activeClient?.companyName || 'Apex Quantum'].map((preset, i) => (
            <button
              key={i}
              onClick={() => {
                setSanctionsQuery(preset);
                handleRunSanctionsScreen(preset);
              }}
              className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-mono text-xs transition cursor-pointer border border-slate-200"
            >
              {preset}
            </button>
          ))}
        </div>

        {/* Screening Results Card */}
        {sanctionsResult && (
          <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className="mt-4 p-5 bg-slate-50 border border-slate-200 rounded-xl space-y-3 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <span className="font-bold text-slate-900 font-mono text-sm">{sanctionsResult.query}</span>
                <p className="text-xs text-slate-500 font-mono mt-0.5">Source Feed: {sanctionsResult.source}</p>
              </div>
              <span className={`px-3 py-1 rounded-full font-mono text-xs font-bold border ${
                sanctionsResult.status === 'MATCH_FOUND' ? 'bg-rose-50 text-rose-700 border-rose-200 animate-pulse' : 'bg-emerald-50 text-emerald-700 border-emerald-200'
              }`}>
                {sanctionsResult.status} (Score: {sanctionsResult.highestRiskScore}%)
              </span>
            </div>

            {sanctionsResult.matches?.length > 0 ? (
              <div className="space-y-2.5">
                <span className="text-xs font-bold text-slate-500 uppercase font-mono">Matched Sanction List Entities ({sanctionsResult.totalMatches})</span>
                {sanctionsResult.matches.map((m: any, idx: number) => (
                  <div key={idx} className="p-4 bg-white border border-slate-200 rounded-xl space-y-1.5 shadow-2xs">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-slate-900 text-sm">{m.caption}</span>
                      <span className="font-mono text-xs font-bold text-rose-700 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded">
                        Match Score: {m.score}%
                      </span>
                    </div>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 font-mono">
                      <span>Type: {m.schema}</span>
                      <span>•</span>
                      <span>List: {m.datasets?.join(', ')}</span>
                      <span>•</span>
                      <span>Jurisdiction: {m.countries?.join(', ')}</span>
                    </div>
                    {m.sanctionDetails && (
                      <p className="text-xs text-slate-600 font-sans mt-1 bg-slate-50 p-2.5 rounded-lg border border-slate-200 leading-relaxed">
                        {m.sanctionDetails}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 text-center text-emerald-800 font-mono text-xs bg-emerald-50 border border-emerald-200 rounded-xl">
                ✓ No matches found on international UN, OFAC, or EU sanctions lists for "{sanctionsResult.query}".
              </div>
            )}
          </motion.div>
        )}
      </div>

      {/* BENEFICIAL OWNERS & FEEDS GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Beneficial Owner Watchlist Status */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 font-mono uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4 text-blue-600" />
              Client Beneficial Owner Watchlist Status
            </h3>
            <span className="text-xs font-mono text-slate-500 font-medium">
              {activeClient?.shareholders?.length || 0} UBOs
            </span>
          </div>

          <p className="text-xs text-slate-500 leading-relaxed">
            Every shareholder and ultimate beneficial owner in <strong className="text-slate-800">{activeClient?.companyName}</strong> is screened automatically.
          </p>

          <div className="space-y-2.5">
            {activeClient?.shareholders?.map((sh, idx) => (
              <div key={idx} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs hover:bg-slate-100/60 transition">
                <div>
                  <span className="font-bold text-slate-900 text-sm block">{sh.name}</span>
                  <p className="text-xs text-slate-500 font-mono mt-0.5">{sh.equity}% Ownership Equity</p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setSanctionsQuery(sh.name);
                      handleRunSanctionsScreen(sh.name);
                    }}
                    className="px-2.5 py-1.5 bg-white hover:bg-slate-100 text-slate-700 font-mono text-xs rounded-lg border border-slate-200 transition cursor-pointer font-medium"
                  >
                    Run Feed Search
                  </button>
                  {sh.pepStatus ? (
                    <span className="px-2.5 py-1 bg-rose-50 border border-rose-200 text-rose-700 font-mono text-xs font-bold rounded-lg animate-pulse">
                      PEP MATCH Hit
                    </span>
                  ) : (
                    <span className="px-2.5 py-1 bg-emerald-50 border border-emerald-200 text-emerald-700 font-mono text-xs font-bold rounded-lg flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      CLEARED
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Active Global Compliance Feeds */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 font-mono uppercase tracking-wider">
              <Lock className="w-4 h-4 text-emerald-600" />
              Active Global Compliance Feeds
            </h3>
            <span className="text-xs font-mono text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded">
              ALL SYNCED
            </span>
          </div>

          <p className="text-xs text-slate-500 leading-relaxed">
            Real-time regulatory sanction and watchlist data feeds connected to the screening engine.
          </p>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3 text-xs">
            <div className="flex justify-between items-center py-1">
              <div>
                <span className="text-slate-800 font-semibold block">OFAC Specially Designated Nationals (SDN)</span>
                <span className="text-[11px] text-slate-400 font-mono">US Dept of the Treasury • Daily Sync</span>
              </div>
              <span className="px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-mono font-bold rounded-md">SYNCED</span>
            </div>

            <div className="flex justify-between items-center py-1 border-t border-slate-200/60 pt-2">
              <div>
                <span className="text-slate-800 font-semibold block">UN Security Council Consolidated Sanctions</span>
                <span className="text-[11px] text-slate-400 font-mono">United Nations SC Resolutions • Real-Time</span>
              </div>
              <span className="px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-mono font-bold rounded-md">SYNCED</span>
            </div>

            <div className="flex justify-between items-center py-1 border-t border-slate-200/60 pt-2">
              <div>
                <span className="text-slate-800 font-semibold block">EU Financial Sanctions Files (FSF)</span>
                <span className="text-[11px] text-slate-400 font-mono">European Commission DG FISMA • Daily Sync</span>
              </div>
              <span className="px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-mono font-bold rounded-md">SYNCED</span>
            </div>

            <div className="flex justify-between items-center py-1 border-t border-slate-200/60 pt-2">
              <div>
                <span className="text-slate-800 font-semibold block">UK HMT Financial Sanctions Targets</span>
                <span className="text-[11px] text-slate-400 font-mono">Office of Financial Sanctions (OFSI) • Daily Sync</span>
              </div>
              <span className="px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-mono font-bold rounded-md">SYNCED</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ==========================================================================
   8. ESCALATIONS VIEW (MATCHING RM WORKLIST LOOK & FEEL)
   ========================================================================== */
export interface ComplianceEscalationCase {
  id: string;
  reference: string;
  entityName: string;
  category: string;
  severity: 'High (Tier 4 EDD)' | 'Medium (Tier 3)' | 'Low (Tier 2)';
  severityColor: string;
  status: 'In Formal Review' | 'Approved with Exception' | 'Pending Documents';
  statusColor: string;
  jurisdiction: string;
  daysInReview: number;
  assignedOfficer: string;
  reason: string;
  resolutionNotes?: string;
  actionTaken?: boolean;
}

const DEFAULT_ESCALATIONS: ComplianceEscalationCase[] = [
  {
    id: 'esc-1',
    reference: 'ESC-2025-019',
    entityName: 'Aethelgard Energy Partners SA',
    category: 'Multi-Tier Offshore Trust Discrepancy & 28.5% UBO Concentration',
    severity: 'High (Tier 4 EDD)',
    severityColor: 'bg-rose-50 text-rose-700 border-rose-200',
    status: 'In Formal Review',
    statusColor: 'bg-amber-50 text-amber-700 border-amber-200',
    jurisdiction: 'Switzerland / Geneva & Cayman Islands',
    daysInReview: 2,
    assignedOfficer: 'Elena Rostova, MLRO & Head of Compliance',
    reason: 'Settlor disclosure missing from Cayman subsidiary tier 3 entity; 28.5% beneficial ownership exceeds statutory 25% threshold. Requires notarized trust deed and MLRO dual-sign-off prior to account opening.'
  },
  {
    id: 'esc-2',
    reference: 'ESC-2025-014',
    entityName: 'Meridian Components International Ltd.',
    category: 'Senior Advisory Board Member Identified as Former State Official (PEP Tier 2)',
    severity: 'Medium (Tier 3)',
    severityColor: 'bg-amber-50 text-amber-700 border-amber-200',
    status: 'Approved with Exception',
    statusColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    jurisdiction: 'United Kingdom / England & Wales',
    daysInReview: 1,
    assignedOfficer: 'David Vance, Senior Compliance Specialist',
    reason: 'Senior advisory member stepped down from government committee 4 years ago. Source of wealth successfully cross-referenced with audited public accounts; policy waiver granted under Compliance Protocol 4.2.'
  }
];

export function EscalationsView() {
  const [escalations, setEscalations] = useState<ComplianceEscalationCase[]>(DEFAULT_ESCALATIONS);
  const [searchTerm, setSearchTerm] = useState('');
  const [severityFilter, setSeverityFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleApproveException = (caseId: string) => {
    setEscalations(prev => prev.map(c => {
      if (c.id === caseId) {
        return {
          ...c,
          status: 'Approved with Exception',
          statusColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
          actionTaken: true,
          resolutionNotes: 'Conditional exception approved by Compliance Committee Quorum. Annual EDD review scheduled.'
        };
      }
      return c;
    }));
    showToast('Policy exception approved and logged in regulatory audit trail.');
  };

  const handleRequestDocs = (caseId: string) => {
    setEscalations(prev => prev.map(c => {
      if (c.id === caseId) {
        return {
          ...c,
          status: 'Pending Documents',
          statusColor: 'bg-purple-50 text-purple-700 border-purple-200',
          actionTaken: true,
          resolutionNotes: 'Request dispatched to Relationship Manager for certified apostilled deed of trust.'
        };
      }
      return c;
    }));
    showToast('Formal document request sent to Relationship Manager.');
  };

  const filtered = useMemo(() => {
    return escalations.filter(c => {
      const q = searchTerm.toLowerCase().trim();
      const matchesSearch = !q ||
        c.entityName.toLowerCase().includes(q) ||
        c.reference.toLowerCase().includes(q) ||
        c.category.toLowerCase().includes(q) ||
        c.jurisdiction.toLowerCase().includes(q);

      const matchesSeverity = severityFilter === 'all' || c.severity.includes(severityFilter);
      const matchesStatus = statusFilter === 'all' || c.status === statusFilter;

      return matchesSearch && matchesSeverity && matchesStatus;
    });
  }, [escalations, searchTerm, severityFilter, statusFilter]);

  const activeEscalationsCount = escalations.filter(e => e.status === 'In Formal Review').length;

  return (
    <div className="space-y-6 text-left">
      {/* Toast Notification */}
      {toastMessage && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
          className="fixed top-20 right-8 z-50 px-4 py-3 bg-slate-900 text-white text-xs font-semibold rounded-xl shadow-lg flex items-center gap-2"
        >
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </motion.div>
      )}

      {/* HEADER BAR (MATCHING RM WORKLIST) */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200 font-mono flex items-center gap-1.5">
              <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
              Regulatory Escalations &amp; Committee Submissions
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 font-mono flex items-center gap-1">
              <Users className="w-3.5 h-3.5 text-emerald-600" />
              MLRO &amp; Committee Quorum Active
            </span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Active Regulatory Escalations &amp; Committee Submissions
          </h1>
          <p className="text-sm text-slate-500 mt-1 max-w-3xl leading-relaxed">
            Review complex legal disputes, multi-tier offshore trust disclosures, PEP board appointments, and high-risk sanctions proximity cases requiring formal Compliance Committee sign-off.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <span className="px-3.5 py-2 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold font-mono">
            Quorum: 3 of 3 Active
          </span>
        </div>
      </div>

      {/* 5 TOP METRIC KPI CARDS (MATCHING RM WORKLIST) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Active Escalations */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4.5 shadow-xs flex flex-col justify-between hover:border-slate-300 transition">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Active Escalations
          </span>
          <div className="mt-2.5">
            <div className="text-2xl font-black text-slate-900 tracking-tight font-sans">
              {activeEscalationsCount} cases
            </div>
            <p className="text-xs font-medium text-slate-500 mt-0.5">
              In formal committee review
            </p>
          </div>
        </div>

        {/* Resolution Time */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4.5 shadow-xs flex flex-col justify-between hover:border-slate-300 transition">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Mean Resolution Time
          </span>
          <div className="mt-2.5">
            <div className="text-2xl font-black text-slate-900 tracking-tight font-sans">
              1.8 days
            </div>
            <p className="text-xs font-semibold text-emerald-600 mt-0.5 flex items-center gap-1">
              <span>-1.2d vs 3.0d regulatory SLA</span>
            </p>
          </div>
        </div>

        {/* Senior Waivers */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4.5 shadow-xs flex flex-col justify-between hover:border-slate-300 transition">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Approved Waivers
          </span>
          <div className="mt-2.5">
            <div className="text-2xl font-black text-emerald-600 tracking-tight font-sans">
              5 logged
            </div>
            <p className="text-xs font-medium text-slate-500 mt-0.5">
              With senior underwriter sign-off
            </p>
          </div>
        </div>

        {/* Quorum Readiness */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4.5 shadow-xs flex flex-col justify-between hover:border-slate-300 transition">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Committee Quorum
          </span>
          <div className="mt-2.5">
            <div className="text-2xl font-black text-slate-900 tracking-tight font-sans">
              3 of 3 Active
            </div>
            <p className="text-xs font-medium text-slate-500 mt-0.5">
              MLRO, Legal &amp; Risk Head
            </p>
          </div>
        </div>

        {/* Action Attention */}
        <div className="bg-white border border-amber-200/80 bg-amber-50/20 rounded-2xl p-4.5 shadow-xs flex flex-col justify-between hover:border-amber-300 transition">
          <span className="text-xs font-semibold text-amber-700 uppercase tracking-wider flex items-center gap-1">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600" /> Action Attention
          </span>
          <div className="mt-2.5">
            <div className="text-2xl font-black text-amber-900 tracking-tight font-sans">
              1 pending
            </div>
            <p className="text-xs font-medium text-amber-700 mt-0.5">
              Aethelgard (Trust Deed)
            </p>
          </div>
        </div>
      </div>

      {/* FILTER & SEARCH CONTROLS */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="relative flex-1 min-w-[280px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by case ID, client name, category, or reviewer..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 shrink-0 font-medium">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <span>Filters:</span>
          </div>

          <select
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
            className="bg-slate-50 text-slate-700 text-xs px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer font-medium"
          >
            <option value="all">All Severities</option>
            <option value="High">High Severity (Tier 4)</option>
            <option value="Medium">Medium Severity (Tier 3)</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-50 text-slate-700 text-xs px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer font-medium"
          >
            <option value="all">All Statuses</option>
            <option value="In Formal Review">In Formal Review</option>
            <option value="Approved with Exception">Approved with Exception</option>
            <option value="Pending Documents">Pending Documents</option>
          </select>

          {(searchTerm || severityFilter !== 'all' || statusFilter !== 'all') && (
            <button
              onClick={() => {
                setSearchTerm('');
                setSeverityFilter('all');
                setStatusFilter('all');
              }}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700 px-2 py-1 cursor-pointer shrink-0"
            >
              Reset
            </button>
          )}
        </div>
      </div>

      {/* ESCALATION CASE CARDS */}
      <div className="grid grid-cols-1 gap-4">
        {filtered.map((item, idx) => (
          <div
            key={item.id}
            className="bg-white border border-slate-200 rounded-2xl p-5 hover:border-slate-300 transition shadow-xs text-left"
          >
            {/* Header Row */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3.5">
              <div className="flex items-center gap-3">
                <span className="w-6 h-6 rounded-full bg-slate-900 text-white text-xs font-mono font-bold flex items-center justify-center shrink-0">
                  #{idx + 1}
                </span>

                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono text-xs font-bold text-blue-600">{item.reference}</span>
                    <span className="text-slate-300">•</span>
                    <h3 className="font-extrabold text-slate-900 text-base">{item.entityName}</h3>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Jurisdiction: <strong className="text-slate-700">{item.jurisdiction}</strong> • Review Days: <strong className="text-slate-700">{item.daysInReview}d</strong>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 self-start sm:self-auto shrink-0">
                <span className={`px-2.5 py-1 rounded-md text-[11px] font-mono font-bold border ${item.severityColor}`}>
                  {item.severity}
                </span>
                <span className={`px-2.5 py-1 rounded-md text-[11px] font-mono font-bold border ${item.statusColor}`}>
                  {item.status}
                </span>
              </div>
            </div>

            {/* Category & Reason Box */}
            <div className="mt-4 p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <div className="flex items-center gap-2">
                <Scale className="w-4 h-4 text-purple-600 shrink-0" />
                <strong className="text-xs font-bold text-slate-900">{item.category}</strong>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed font-sans">
                {item.reason}
              </p>
              {item.resolutionNotes && (
                <div className="mt-2 pt-2 border-t border-slate-200 text-xs font-sans text-emerald-800 bg-emerald-50/70 p-2.5 rounded-lg border border-emerald-200">
                  <strong className="font-bold block text-[10px] font-mono uppercase text-emerald-900 mb-0.5">
                    COMMITTEE DISPOSITION
                  </strong>
                  {item.resolutionNotes}
                </div>
              )}
            </div>

            {/* Footer Row with Actions */}
            <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
              <div className="text-xs text-slate-500 font-mono">
                Assigned: <strong className="text-slate-700">{item.assignedOfficer}</strong>
              </div>

              <div className="flex items-center gap-2">
                {item.status === 'In Formal Review' && (
                  <>
                    <button
                      onClick={() => handleRequestDocs(item.id)}
                      className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer border border-slate-200"
                    >
                      Request Certified Deeds
                    </button>
                    <button
                      onClick={() => handleApproveException(item.id)}
                      className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Approve Conditional Waiver
                    </button>
                  </>
                )}
                {item.status !== 'In Formal Review' && (
                  <span className="text-xs font-bold font-mono text-emerald-700 flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Action Completed
                  </span>
                )}
              </div>
            </div>
          </div>
        ))}

        {filtered.length === 0 && (
          <div className="p-12 text-center bg-white border border-slate-200 rounded-2xl">
            <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
            <p className="text-sm font-bold text-slate-700">No regulatory escalations match your filter</p>
            <p className="text-xs text-slate-400 mt-1">Escalation protocol is in safe standing.</p>
          </div>
        )}
      </div>
    </div>
  );
}

/* ==========================================================================
   9. JOURNEYS VIEW
   ========================================================================== */
export interface JourneyStage {
  id: string;
  name: string;
  description?: string;
  linkedPipelineId: string;
  transitionRule?: 'auto' | 'approval_gate' | 'risk_check';
  executionMode?: 'sequential' | 'parallel';
  attachedAgentIds?: string[];
  pipelines?: string[];
  trigger?: string;
  output?: string;
  parallelNotes?: string;
}

export type JourneyPhase = JourneyStage;

export interface JourneyStep {
  id: string;
  name: string;
  agentId: string;
  executionType: 'sequential' | 'parallel';
  failureHandling: 'escalate' | 'retry' | 'ignore';
  parameterOverrides?: string;
}

export interface Journey {
  id: string;
  name: string;
  description: string;
  expectedSLA: string;
  primaryAnchorId?: string;
  status: 'Active' | 'Draft' | 'Deprecated';
  linkedPipelineId?: string;
  intakeDocuments?: string[];
  riskEscalationThreshold?: number;
  contractingMethod?: string;
  targetEntity?: string;
  parallelBranchRules?: string;
  stages?: JourneyStage[];
  phases?: JourneyStage[];
  hybridStages?: HybridStage[];
  steps: JourneyStep[];
}

export const DEFAULT_JOURNEYS: Journey[] = [
  {
    id: 'corporate_onboarding_journey',
    name: '🏢 Corporate Entity Onboarding Journey',
    description: 'Full-scope institutional client onboarding lifecycle for corporate entities. Covers 10 end-to-end automated stages plus perpetual post-onboarding KYC monitoring with parallel pipeline execution branches.',
    expectedSLA: '24 Hours',
    targetEntity: 'Global MNC, regional corporate, holding company, listed entity, single-jurisdiction operating company.',
    primaryAnchorId: 'lead_intelligence_agent',
    linkedPipelineId: 'p01_lead_intelligence',
    status: 'Active',
    intakeDocuments: ['Certificate of Incorporation', 'Board Resolution', 'Director Passports', 'UBO Declaration', 'vLEI Credential', 'Financial Statements'],
    riskEscalationThreshold: 60,
    contractingMethod: 'DocuSign e-Signature & Board Resolution',
    parallelBranchRules: 'Stages 2 and 3 can run in parallel. Stage 6 (Screening) runs in parallel with late-stage document collection but must complete before Stage 7. Within Stage 9, CASA runs first (no dependencies); FX/MM and Trade Finance can run in parallel after CASA; Derivatives runs after ISDA confirmation (may delay this branch). Digital Assets runs after CASA (settlement wallet dependency).',
    stages: [
      {
        id: 'stage_1',
        name: 'STAGE 1: PROSPECT QUALIFICATION',
        description: 'RM creates new lead. Lead intelligence and entity resolution pipelines enrich entity profile and prepare briefing.',
        linkedPipelineId: 'p01_lead_intelligence',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['lead_intelligence_agent', 'entity_resolution_agent'],
        pipelines: ['P-01 (Lead Intelligence)', 'P-02 (Entity Resolution)'],
        trigger: 'RM creates new lead',
        output: 'Pre-populated entity profile in Digital Twin, RM pre-meeting briefing'
      },
      {
        id: 'stage_2',
        name: 'STAGE 2: ENTITY RESEARCH',
        description: 'Autonomous research queries corporate registries and regulatory databases to map ownership chain and identify directors.',
        linkedPipelineId: 'p03_autonomous_research',
        transitionRule: 'auto',
        executionMode: 'parallel',
        attachedAgentIds: ['research_agent', 'registry_connector_agent', 'regulatory_database_agent', 'ownership_agent', 'ubo_agent', 'vie_structure_agent'],
        pipelines: ['P-03 (Autonomous Research)', 'P-04 (Ownership Structure Mapping)'],
        trigger: 'Auto on completion of Stage 1',
        output: 'Verified entity data from registries, ownership chain mapped, directors identified',
        parallelNotes: 'Stages 2 and 3 can run in parallel.'
      },
      {
        id: 'stage_3',
        name: 'STAGE 3: INDIVIDUAL VERIFICATION',
        description: 'Verifies individual directors and UBOs via identity registries and cryptographically validates vLEI credentials when presented.',
        linkedPipelineId: 'p05_director_individual_verification',
        transitionRule: 'auto',
        executionMode: 'parallel',
        attachedAgentIds: ['director_verification_agent', 'identity_verification_agent', 'vlei_agent'],
        pipelines: ['P-05 (Director Verification)', 'P-06 (vLEI Verification)'],
        trigger: 'Auto on completion of Stage 2 (or in parallel)',
        output: 'Directors and UBOs verified at confidence score per individual',
        parallelNotes: 'Stages 2 and 3 can run in parallel.'
      },
      {
        id: 'stage_4',
        name: 'STAGE 4: DYNAMIC KYC',
        description: 'Dynamic KYC engine computes minimum-necessary question set based on entity type, jurisdiction, and product combination.',
        linkedPipelineId: 'p08_dynamic_kyc_engine',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['kyc_engine_agent', 'regulatory_rules_agent'],
        pipelines: ['P-08 (Dynamic KYC Engine)'],
        trigger: 'Auto on completion of Stage 3',
        output: 'Minimum-necessary question set, Information State map (Verified / Needs Attestation / Needs From You)'
      },
      {
        id: 'stage_5',
        name: 'STAGE 5: DOCUMENT COLLECTION AND OUTREACH',
        description: 'Client outreach dispatched via digital portal. OCR document intelligence processes and validates uploaded packets.',
        linkedPipelineId: 'p09_client_outreach',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['client_outreach_agent', 'document_intelligence_agent', 'ocr_agent', 'cross_validation_agent'],
        pipelines: ['P-09 (Client Outreach)', 'P-07 (Document Intelligence)'],
        trigger: 'Auto — outreach initiated, documents processed as uploaded',
        output: 'Digital Twin enriched to completion threshold'
      },
      {
        id: 'stage_6',
        name: 'STAGE 6: SCREENING',
        description: 'Real-time global sanctions, PEP lists, and adverse media screening. Mandatory execution before risk scoring.',
        linkedPipelineId: 'p10_sanctions_pep_screening',
        transitionRule: 'risk_check',
        executionMode: 'parallel',
        attachedAgentIds: ['sanctions_screening_agent', 'pep_screening_agent', 'adverse_media_agent'],
        pipelines: ['P-10 (Sanctions and PEP)', 'P-11 (Adverse Media)'],
        trigger: 'DOCUMENT_COLLECTION_COMPLETE event [Mandatory — runs before risk assessment]',
        output: 'Screening results in Digital Twin, EDD flags raised if triggered',
        parallelNotes: 'Stage 6 runs in parallel with late-stage document collection but must complete before Stage 7.'
      },
      {
        id: 'stage_7',
        name: 'STAGE 7: RISK ASSESSMENT',
        description: 'Multi-factor risk matrix calculates overall risk score, assigns risk band, and triggers Enhanced Due Diligence if required.',
        linkedPipelineId: 'p12_risk_assessment',
        transitionRule: 'risk_check',
        executionMode: 'sequential',
        attachedAgentIds: ['risk_assessment_agent', 'edd_trigger_agent'],
        pipelines: ['P-12 (Risk Assessment)', 'P-13 (EDD — conditional if triggered)'],
        trigger: 'SCREENING_COMPLETE event',
        output: 'Risk score, risk band, explainability narrative'
      },
      {
        id: 'stage_8',
        name: 'STAGE 8: APPROVAL',
        description: 'Approval Gateway routes onboarding decision to auto-approval, compliance review, senior management, or committee.',
        linkedPipelineId: 'p20_approval_gateway',
        transitionRule: 'approval_gate',
        executionMode: 'sequential',
        attachedAgentIds: ['approval_gateway_agent'],
        pipelines: ['P-20 (Approval Gateway)'],
        trigger: 'RISK_ASSESSMENT_COMPLETE event',
        output: 'AUTO_APPROVED / COMPLIANCE_REVIEW / SENIOR_REVIEW / COMMITTEE_REVIEW routing'
      },
      {
        id: 'stage_9',
        name: 'STAGE 9: PRODUCT PROVISIONING',
        description: 'Parallel product account setup (CASA, FX/MM, Derivatives, Trade Finance, Digital Assets) adhering to dependency order.',
        linkedPipelineId: 'p21_casa_provisioning',
        transitionRule: 'auto',
        executionMode: 'parallel',
        attachedAgentIds: ['signatory_intelligence_agent', 'casa_provisioning_agent', 'fx_mm_provisioning_agent', 'trade_finance_provisioning_agent', 'derivatives_provisioning_agent', 'digital_asset_provisioning_agent'],
        pipelines: ['P-19 (Signatory Intelligence)', 'P-21 (CASA)', 'P-22 (FX/MM)', 'P-23 (Derivatives — if applicable)', 'P-24 (Trade Finance — if applicable)', 'P-25 (Digital Assets — if applicable)'],
        trigger: 'CLIENT_APPROVED event [Pipelines run in parallel where no dependency]',
        output: 'All requested products provisioned',
        parallelNotes: 'CASA runs first (no dependencies); FX/MM and Trade Finance run in parallel after CASA; Derivatives runs after ISDA confirmation (may delay this branch); Digital Assets runs after CASA (settlement wallet dependency).'
      },
      {
        id: 'stage_10',
        name: 'STAGE 10: READY TO TRADE',
        description: 'Ready-to-Trade validation verifies all product accounts are operational, triggers notifications, and unlocks client trading.',
        linkedPipelineId: 'p26_rtt_validation',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['rtt_validation_agent'],
        pipelines: ['P-26 (RTT Validation)'],
        trigger: 'Each PRODUCT_PROVISIONED event',
        output: 'READY_TO_TRADE event, RM and client notified'
      },
      {
        id: 'stage_11',
        name: 'ONGOING: PERPETUAL KYC',
        description: 'Continuous post-onboarding monitoring for corporate registry changes, sanctions updates, and adverse news events.',
        linkedPipelineId: 'p27_perpetual_kyc',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['perpetual_kyc_agent'],
        pipelines: ['P-27 (Perpetual KYC)'],
        trigger: 'Continuous, post Ready-to-Trade',
        output: 'Real-time risk monitoring, automated trigger-based review alerts'
      }
    ],
    phases: [
      {
        id: 'stage_1',
        name: 'STAGE 1: PROSPECT QUALIFICATION',
        description: 'RM creates new lead. Lead intelligence and entity resolution pipelines enrich entity profile and prepare briefing.',
        linkedPipelineId: 'p01_lead_intelligence',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['lead_intelligence_agent', 'entity_resolution_agent'],
        pipelines: ['P-01 (Lead Intelligence)', 'P-02 (Entity Resolution)'],
        trigger: 'RM creates new lead',
        output: 'Pre-populated entity profile in Digital Twin, RM pre-meeting briefing'
      },
      {
        id: 'stage_2',
        name: 'STAGE 2: ENTITY RESEARCH',
        description: 'Autonomous research queries corporate registries and regulatory databases to map ownership chain and identify directors.',
        linkedPipelineId: 'p03_autonomous_research',
        transitionRule: 'auto',
        executionMode: 'parallel',
        attachedAgentIds: ['research_agent', 'registry_connector_agent', 'regulatory_database_agent', 'ownership_agent', 'ubo_agent', 'vie_structure_agent'],
        pipelines: ['P-03 (Autonomous Research)', 'P-04 (Ownership Structure Mapping)'],
        trigger: 'Auto on completion of Stage 1',
        output: 'Verified entity data from registries, ownership chain mapped, directors identified',
        parallelNotes: 'Stages 2 and 3 can run in parallel.'
      },
      {
        id: 'stage_3',
        name: 'STAGE 3: INDIVIDUAL VERIFICATION',
        description: 'Verifies individual directors and UBOs via identity registries and cryptographically validates vLEI credentials when presented.',
        linkedPipelineId: 'p05_director_individual_verification',
        transitionRule: 'auto',
        executionMode: 'parallel',
        attachedAgentIds: ['director_verification_agent', 'identity_verification_agent', 'vlei_agent'],
        pipelines: ['P-05 (Director Verification)', 'P-06 (vLEI Verification)'],
        trigger: 'Auto on completion of Stage 2 (or in parallel)',
        output: 'Directors and UBOs verified at confidence score per individual',
        parallelNotes: 'Stages 2 and 3 can run in parallel.'
      },
      {
        id: 'stage_4',
        name: 'STAGE 4: DYNAMIC KYC',
        description: 'Dynamic KYC engine computes minimum-necessary question set based on entity type, jurisdiction, and product combination.',
        linkedPipelineId: 'p08_dynamic_kyc_engine',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['kyc_engine_agent', 'regulatory_rules_agent'],
        pipelines: ['P-08 (Dynamic KYC Engine)'],
        trigger: 'Auto on completion of Stage 3',
        output: 'Minimum-necessary question set, Information State map (Verified / Needs Attestation / Needs From You)'
      },
      {
        id: 'stage_5',
        name: 'STAGE 5: DOCUMENT COLLECTION AND OUTREACH',
        description: 'Client outreach dispatched via digital portal. OCR document intelligence processes and validates uploaded packets.',
        linkedPipelineId: 'p09_client_outreach',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['client_outreach_agent', 'document_intelligence_agent', 'ocr_agent', 'cross_validation_agent'],
        pipelines: ['P-09 (Client Outreach)', 'P-07 (Document Intelligence)'],
        trigger: 'Auto — outreach initiated, documents processed as uploaded',
        output: 'Digital Twin enriched to completion threshold'
      },
      {
        id: 'stage_6',
        name: 'STAGE 6: SCREENING',
        description: 'Real-time global sanctions, PEP lists, and adverse media screening. Mandatory execution before risk scoring.',
        linkedPipelineId: 'p10_sanctions_pep_screening',
        transitionRule: 'risk_check',
        executionMode: 'parallel',
        attachedAgentIds: ['sanctions_screening_agent', 'pep_screening_agent', 'adverse_media_agent'],
        pipelines: ['P-10 (Sanctions and PEP)', 'P-11 (Adverse Media)'],
        trigger: 'DOCUMENT_COLLECTION_COMPLETE event [Mandatory — runs before risk assessment]',
        output: 'Screening results in Digital Twin, EDD flags raised if triggered',
        parallelNotes: 'Stage 6 runs in parallel with late-stage document collection but must complete before Stage 7.'
      },
      {
        id: 'stage_7',
        name: 'STAGE 7: RISK ASSESSMENT',
        description: 'Multi-factor risk matrix calculates overall risk score, assigns risk band, and triggers Enhanced Due Diligence if required.',
        linkedPipelineId: 'p12_risk_assessment',
        transitionRule: 'risk_check',
        executionMode: 'sequential',
        attachedAgentIds: ['risk_assessment_agent', 'edd_trigger_agent'],
        pipelines: ['P-12 (Risk Assessment)', 'P-13 (EDD — conditional if triggered)'],
        trigger: 'SCREENING_COMPLETE event',
        output: 'Risk score, risk band, explainability narrative'
      },
      {
        id: 'stage_8',
        name: 'STAGE 8: APPROVAL',
        description: 'Approval Gateway routes onboarding decision to auto-approval, compliance review, senior management, or committee.',
        linkedPipelineId: 'p20_approval_gateway',
        transitionRule: 'approval_gate',
        executionMode: 'sequential',
        attachedAgentIds: ['approval_gateway_agent'],
        pipelines: ['P-20 (Approval Gateway)'],
        trigger: 'RISK_ASSESSMENT_COMPLETE event',
        output: 'AUTO_APPROVED / COMPLIANCE_REVIEW / SENIOR_REVIEW / COMMITTEE_REVIEW routing'
      },
      {
        id: 'stage_9',
        name: 'STAGE 9: PRODUCT PROVISIONING',
        description: 'Parallel product account setup (CASA, FX/MM, Derivatives, Trade Finance, Digital Assets) adhering to dependency order.',
        linkedPipelineId: 'p21_casa_provisioning',
        transitionRule: 'auto',
        executionMode: 'parallel',
        attachedAgentIds: ['signatory_intelligence_agent', 'casa_provisioning_agent', 'fx_mm_provisioning_agent', 'trade_finance_provisioning_agent', 'derivatives_provisioning_agent', 'digital_asset_provisioning_agent'],
        pipelines: ['P-19 (Signatory Intelligence)', 'P-21 (CASA)', 'P-22 (FX/MM)', 'P-23 (Derivatives — if applicable)', 'P-24 (Trade Finance — if applicable)', 'P-25 (Digital Assets — if applicable)'],
        trigger: 'CLIENT_APPROVED event [Pipelines run in parallel where no dependency]',
        output: 'All requested products provisioned',
        parallelNotes: 'CASA runs first (no dependencies); FX/MM and Trade Finance run in parallel after CASA; Derivatives runs after ISDA confirmation (may delay this branch); Digital Assets runs after CASA (settlement wallet dependency).'
      },
      {
        id: 'stage_10',
        name: 'STAGE 10: READY TO TRADE',
        description: 'Ready-to-Trade validation verifies all product accounts are operational, triggers notifications, and unlocks client trading.',
        linkedPipelineId: 'p26_rtt_validation',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['rtt_validation_agent'],
        pipelines: ['P-26 (RTT Validation)'],
        trigger: 'Each PRODUCT_PROVISIONED event',
        output: 'READY_TO_TRADE event, RM and client notified'
      },
      {
        id: 'stage_11',
        name: 'ONGOING: PERPETUAL KYC',
        description: 'Continuous post-onboarding monitoring for corporate registry changes, sanctions updates, and adverse news events.',
        linkedPipelineId: 'p27_perpetual_kyc',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['perpetual_kyc_agent'],
        pipelines: ['P-27 (Perpetual KYC)'],
        trigger: 'Continuous, post Ready-to-Trade',
        output: 'Real-time risk monitoring, automated trigger-based review alerts'
      }
    ],
    steps: [
      { id: 's-1', name: 'STAGE 1: PROSPECT QUALIFICATION', agentId: 'lead_intelligence_agent', executionType: 'sequential', failureHandling: 'escalate' },
      { id: 's-2', name: 'STAGE 2: ENTITY RESEARCH', agentId: 'research_agent', executionType: 'parallel', failureHandling: 'escalate' },
      { id: 's-3', name: 'STAGE 3: INDIVIDUAL VERIFICATION', agentId: 'director_verification_agent', executionType: 'parallel', failureHandling: 'escalate' },
      { id: 's-4', name: 'STAGE 4: DYNAMIC KYC', agentId: 'kyc_engine_agent', executionType: 'sequential', failureHandling: 'escalate' },
      { id: 's-5', name: 'STAGE 5: DOCUMENT COLLECTION AND OUTREACH', agentId: 'client_outreach_agent', executionType: 'sequential', failureHandling: 'escalate' },
      { id: 's-6', name: 'STAGE 6: SCREENING', agentId: 'sanctions_screening_agent', executionType: 'parallel', failureHandling: 'escalate' },
      { id: 's-7', name: 'STAGE 7: RISK ASSESSMENT', agentId: 'risk_assessment_agent', executionType: 'sequential', failureHandling: 'escalate' },
      { id: 's-8', name: 'STAGE 8: APPROVAL', agentId: 'approval_gateway_agent', executionType: 'sequential', failureHandling: 'escalate' },
      { id: 's-9', name: 'STAGE 9: PRODUCT PROVISIONING', agentId: 'casa_provisioning_agent', executionType: 'parallel', failureHandling: 'escalate' },
      { id: 's-10', name: 'STAGE 10: READY TO TRADE', agentId: 'rtt_validation_agent', executionType: 'sequential', failureHandling: 'escalate' },
      { id: 's-11', name: 'ONGOING: PERPETUAL KYC', agentId: 'perpetual_kyc_agent', executionType: 'sequential', failureHandling: 'ignore' }
    ]
  },
  {
    id: 'corporate_onboarding_existing_client_journey',
    name: '🏢 Corporate Onboarding — Existing Client New Product',
    description: 'Accelerated onboarding pathway for existing approved corporate clients requesting additional financial products. Leverages pre-existing Digital Twin data without full KYC re-run.',
    expectedSLA: '4 Hours',
    targetEntity: 'Approved existing corporate client requesting additional product line (e.g. FX/MM, Derivatives, Trade Finance, Digital Custody).',
    primaryAnchorId: 'kyc_engine_agent',
    linkedPipelineId: 'p08_dynamic_kyc_engine',
    status: 'Active',
    intakeDocuments: ['Product Application Form', 'Updated Board Authorization (if applicable)', 'Delta Attestation'],
    riskEscalationThreshold: 70,
    contractingMethod: 'Digital Addendum & e-Signature',
    parallelBranchRules: 'Stages 1-4 execute sequentially for delta checks and risk overlay. Provisioning (Stage 6) triggers upon expedited approval.',
    stages: [
      {
        id: 'ex_stage_1',
        name: 'STAGE 1: PRODUCT REQUEST INTAKE',
        description: 'RM submits product request. Dynamic KYC pipeline evaluates delta requirements against existing Digital Twin.',
        linkedPipelineId: 'p08_dynamic_kyc_engine',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['kyc_engine_agent', 'regulatory_rules_agent'],
        pipelines: ['P-08 (Dynamic KYC — delta only)'],
        trigger: 'RM submits product request',
        output: 'Gap list — what is missing or expired for the new product specifically'
      },
      {
        id: 'ex_stage_2',
        name: 'STAGE 2: INCREMENTAL VERIFICATION',
        description: 'Targeted client outreach and document refresh for identified gaps only if gap list is non-empty.',
        linkedPipelineId: 'p09_client_outreach',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['client_outreach_agent', 'document_intelligence_agent', 'ocr_agent'],
        pipelines: ['P-07 (Document Intelligence — refresh only)', 'P-09 (Client Outreach — targeted)'],
        trigger: 'Gap list non-empty',
        output: 'Delta Digital Twin update'
      },
      {
        id: 'ex_stage_3',
        name: 'STAGE 3: PRODUCT-SPECIFIC SCREENING REFRESH',
        description: 'Refreshes global sanctions, PEP, and adverse media screening for product-specific parameters.',
        linkedPipelineId: 'p10_sanctions_pep_screening',
        transitionRule: 'risk_check',
        executionMode: 'parallel',
        attachedAgentIds: ['sanctions_screening_agent', 'adverse_media_agent'],
        pipelines: ['P-10 (Sanctions — refresh)', 'P-11 (Adverse Media — refresh)'],
        trigger: 'Auto',
        output: 'Screening current'
      },
      {
        id: 'ex_stage_4',
        name: 'STAGE 4: PRODUCT RISK OVERLAY',
        description: 'Applies product-specific risk matrix overlay to existing baseline client risk profile.',
        linkedPipelineId: 'p12_risk_assessment',
        transitionRule: 'risk_check',
        executionMode: 'sequential',
        attachedAgentIds: ['risk_assessment_agent'],
        pipelines: ['P-12 (Risk Assessment — product overlay only)'],
        trigger: 'Auto',
        output: 'Product-specific risk assessment'
      },
      {
        id: 'ex_stage_5',
        name: 'STAGE 5: APPROVAL (EXPEDITED)',
        description: 'Expedited approval routing with lower approval thresholds for existing approved clients.',
        linkedPipelineId: 'p20_approval_gateway',
        transitionRule: 'approval_gate',
        executionMode: 'sequential',
        attachedAgentIds: ['approval_gateway_agent'],
        pipelines: ['P-20 (Approval Gateway)'],
        trigger: 'Auto',
        output: 'Approval routing — typically lower threshold for existing approved clients'
      },
      {
        id: 'ex_stage_6',
        name: 'STAGE 6: PRODUCT PROVISIONING',
        description: 'Provisions requested product account(s) using stored signatory and entity credentials.',
        linkedPipelineId: 'p21_casa_provisioning',
        transitionRule: 'auto',
        executionMode: 'parallel',
        attachedAgentIds: ['casa_provisioning_agent', 'fx_mm_provisioning_agent', 'trade_finance_provisioning_agent', 'derivatives_provisioning_agent'],
        pipelines: ['Relevant provisioning pipeline per product'],
        trigger: 'APPROVED event',
        output: 'Product provisioned'
      },
      {
        id: 'ex_stage_7',
        name: 'STAGE 7: READY TO TRADE',
        description: 'Validates new product account operational status and notifies RM and client.',
        linkedPipelineId: 'p26_rtt_validation',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['rtt_validation_agent'],
        pipelines: ['P-26 (RTT Validation)'],
        trigger: 'PRODUCT_PROVISIONED',
        output: 'READY_TO_TRADE for new product'
      }
    ],
    phases: [
      {
        id: 'ex_stage_1',
        name: 'STAGE 1: PRODUCT REQUEST INTAKE',
        description: 'RM submits product request. Dynamic KYC pipeline evaluates delta requirements against existing Digital Twin.',
        linkedPipelineId: 'p08_dynamic_kyc_engine',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['kyc_engine_agent', 'regulatory_rules_agent'],
        pipelines: ['P-08 (Dynamic KYC — delta only)'],
        trigger: 'RM submits product request',
        output: 'Gap list — what is missing or expired for the new product specifically'
      },
      {
        id: 'ex_stage_2',
        name: 'STAGE 2: INCREMENTAL VERIFICATION',
        description: 'Targeted client outreach and document refresh for identified gaps only if gap list is non-empty.',
        linkedPipelineId: 'p09_client_outreach',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['client_outreach_agent', 'document_intelligence_agent', 'ocr_agent'],
        pipelines: ['P-07 (Document Intelligence — refresh only)', 'P-09 (Client Outreach — targeted)'],
        trigger: 'Gap list non-empty',
        output: 'Delta Digital Twin update'
      },
      {
        id: 'ex_stage_3',
        name: 'STAGE 3: PRODUCT-SPECIFIC SCREENING REFRESH',
        description: 'Refreshes global sanctions, PEP, and adverse media screening for product-specific parameters.',
        linkedPipelineId: 'p10_sanctions_pep_screening',
        transitionRule: 'risk_check',
        executionMode: 'parallel',
        attachedAgentIds: ['sanctions_screening_agent', 'adverse_media_agent'],
        pipelines: ['P-10 (Sanctions — refresh)', 'P-11 (Adverse Media — refresh)'],
        trigger: 'Auto',
        output: 'Screening current'
      },
      {
        id: 'ex_stage_4',
        name: 'STAGE 4: PRODUCT RISK OVERLAY',
        description: 'Applies product-specific risk matrix overlay to existing baseline client risk profile.',
        linkedPipelineId: 'p12_risk_assessment',
        transitionRule: 'risk_check',
        executionMode: 'sequential',
        attachedAgentIds: ['risk_assessment_agent'],
        pipelines: ['P-12 (Risk Assessment — product overlay only)'],
        trigger: 'Auto',
        output: 'Product-specific risk assessment'
      },
      {
        id: 'ex_stage_5',
        name: 'STAGE 5: APPROVAL (EXPEDITED)',
        description: 'Expedited approval routing with lower approval thresholds for existing approved clients.',
        linkedPipelineId: 'p20_approval_gateway',
        transitionRule: 'approval_gate',
        executionMode: 'sequential',
        attachedAgentIds: ['approval_gateway_agent'],
        pipelines: ['P-20 (Approval Gateway)'],
        trigger: 'Auto',
        output: 'Approval routing — typically lower threshold for existing approved clients'
      },
      {
        id: 'ex_stage_6',
        name: 'STAGE 6: PRODUCT PROVISIONING',
        description: 'Provisions requested product account(s) using stored signatory and entity credentials.',
        linkedPipelineId: 'p21_casa_provisioning',
        transitionRule: 'auto',
        executionMode: 'parallel',
        attachedAgentIds: ['casa_provisioning_agent', 'fx_mm_provisioning_agent', 'trade_finance_provisioning_agent', 'derivatives_provisioning_agent'],
        pipelines: ['Relevant provisioning pipeline per product'],
        trigger: 'APPROVED event',
        output: 'Product provisioned'
      },
      {
        id: 'ex_stage_7',
        name: 'STAGE 7: READY TO TRADE',
        description: 'Validates new product account operational status and notifies RM and client.',
        linkedPipelineId: 'p26_rtt_validation',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['rtt_validation_agent'],
        pipelines: ['P-26 (RTT Validation)'],
        trigger: 'PRODUCT_PROVISIONED',
        output: 'READY_TO_TRADE for new product'
      }
    ],
    steps: [
      { id: 'ex-1', name: 'STAGE 1: PRODUCT REQUEST INTAKE', agentId: 'kyc_engine_agent', executionType: 'sequential', failureHandling: 'escalate' },
      { id: 'ex-2', name: 'STAGE 2: INCREMENTAL VERIFICATION', agentId: 'client_outreach_agent', executionType: 'sequential', failureHandling: 'escalate' },
      { id: 'ex-3', name: 'STAGE 3: PRODUCT-SPECIFIC SCREENING REFRESH', agentId: 'sanctions_screening_agent', executionType: 'parallel', failureHandling: 'escalate' },
      { id: 'ex-4', name: 'STAGE 4: PRODUCT RISK OVERLAY', agentId: 'risk_assessment_agent', executionType: 'sequential', failureHandling: 'escalate' },
      { id: 'ex-5', name: 'STAGE 5: APPROVAL (EXPEDITED)', agentId: 'approval_gateway_agent', executionType: 'sequential', failureHandling: 'escalate' },
      { id: 'ex-6', name: 'STAGE 6: PRODUCT PROVISIONING', agentId: 'casa_provisioning_agent', executionType: 'parallel', failureHandling: 'escalate' },
      { id: 'ex-7', name: 'STAGE 7: READY TO TRADE', agentId: 'rtt_validation_agent', executionType: 'sequential', failureHandling: 'escalate' }
    ]
  },
  {
    id: 'fund_onboarding_journey',
    name: '🏦 Journey 4: Fund Onboarding',
    description: 'Macro onboarding pathway for investment funds (hedge funds, PE/VC, family office funds, tokenized funds). Features dual-entity intake (fund entity + management company), prospectus/mandate extraction, investor base assessment, and mandate-specific product provisioning.',
    expectedSLA: '48 Hours',
    targetEntity: 'Hedge fund, PE fund, VC fund, family office fund, tokenized fund. Most complex journey — two entities (fund + manager), investor base assessment, fund document analysis.',
    primaryAnchorId: 'fund_document_intelligence_agent',
    linkedPipelineId: 'p15_fund_document_analysis',
    status: 'Active',
    intakeDocuments: [
      'Fund Offering Memorandum / Prospectus',
      'Trust Deed / Certificate of Incorporation',
      'Fund Manager License / Regulatory Filing',
      'FATCA / CRS Self-Certification',
      'UBO Register & Investor Eligibility Criteria'
    ],
    riskEscalationThreshold: 50,
    contractingMethod: 'Fund Mandate Agreement, ISDA, Custody Master Agreement',
    parallelBranchRules: 'Stage 1 runs dual intake for fund + management company. Stages 2 (Management Company KYC) and 3 (Fund Document Analysis) run in parallel. Stage 5 waits for Stages 3 & 4. Stage 10 provisions all mandate-eligible products in parallel once approved.',
    stages: [
      {
        id: 'fund_stage_1',
        name: 'STAGE 1: FUND STRUCTURE IDENTIFICATION',
        description: 'RM creates opportunity. Lead intelligence and entity resolution pipelines run for BOTH fund entity and management company separately, linking them via MANAGES relationship.',
        linkedPipelineId: 'p01_lead_intelligence',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['lead_intelligence_agent', 'entity_resolution_agent'],
        pipelines: ['P-01 (Lead Intelligence)', 'P-02 (Entity Resolution — fund & manager dual intake)'],
        trigger: 'RM creates opportunity',
        output: 'Two Digital Twin records created, linked via MANAGES relationship'
      },
      {
        id: 'fund_stage_2',
        name: 'STAGE 2: MANAGEMENT COMPANY KYC',
        description: 'Autonomous research and ownership mapping for the fund management company and key management individuals.',
        linkedPipelineId: 'p03_autonomous_research',
        transitionRule: 'auto',
        executionMode: 'parallel',
        attachedAgentIds: ['research_agent', 'registry_connector_agent', 'ownership_agent', 'director_verification_agent', 'vlei_agent'],
        pipelines: ['P-03 (Autonomous Research)', 'P-04 (Ownership Structure)', 'P-05 (Director Verification)', 'P-06 (vLEI Verification)'],
        trigger: 'Auto — parallel with Stage 3',
        output: 'Management company fully researched, key individuals verified',
        parallelNotes: 'Stages 2 and 3 execute in parallel.'
      },
      {
        id: 'fund_stage_3',
        name: 'STAGE 3: FUND DOCUMENT ANALYSIS',
        description: 'Fund document intelligence extracts investment mandate, eligible assets, leverage & derivative limits, and investor eligibility criteria from offering memorandum.',
        linkedPipelineId: 'p15_fund_document_analysis',
        transitionRule: 'auto',
        executionMode: 'parallel',
        attachedAgentIds: ['fund_document_intelligence_agent', 'mandate_extraction_agent'],
        pipelines: ['P-15 (Fund Document Analysis)'],
        trigger: 'Auto — parallel with Stage 2',
        output: 'Investment mandate extracted, eligible assets defined, leverage and derivative limits captured, investor eligibility criteria documented',
        parallelNotes: 'Stages 2 and 3 execute in parallel.'
      },
      {
        id: 'fund_stage_4',
        name: 'STAGE 4: REGULATORY STATUS VERIFICATION',
        description: 'Queries regulatory databases to verify fund manager licensing specifically (MAS CMS, SFC, FCA, VARA, SEC, etc.).',
        linkedPipelineId: 'p03_autonomous_research',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['regulatory_database_agent', 'regulatory_rules_agent'],
        pipelines: ['P-03 (Regulatory databases — fund manager licensing specifically)'],
        trigger: 'On completion of Stage 2',
        output: 'Fund manager licence verified (MAS CMS, SFC, FCA, VARA etc.)'
      },
      {
        id: 'fund_stage_5',
        name: 'STAGE 5: FUND ENTITY KYC AND CLASSIFICATION',
        description: 'Determines fund entity KYC requirements, processes FATCA/CRS classification, and maps investor base jurisdiction risk.',
        linkedPipelineId: 'p08_dynamic_kyc_engine',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['kyc_engine_agent', 'fatca_agent', 'ownership_agent'],
        pipelines: ['P-08 (Fund parameters)', 'P-16 (FATCA/CRS)', 'P-04 (Investor base jurisdiction mapping)'],
        trigger: 'On completion of Stages 3 and 4',
        output: 'KYC requirements for fund entity, FATCA/CRS classification, investor base risk profile'
      },
      {
        id: 'fund_stage_6',
        name: 'STAGE 6: DOCUMENT COLLECTION AND OUTREACH',
        description: 'Targeted RM-assisted outreach collects remaining fund documents and validates uploaded packets.',
        linkedPipelineId: 'p09_client_outreach',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['client_outreach_agent', 'document_intelligence_agent', 'ocr_agent'],
        pipelines: ['P-07 (Document Intelligence)', 'P-09 (Tier 2/3 — RM-assisted for funds)'],
        trigger: 'Auto',
        output: 'Remaining fund documents collected, Digital Twin complete'
      },
      {
        id: 'fund_stage_7',
        name: 'STAGE 7: SCREENING',
        description: 'Full global sanctions, PEP, and adverse media screening across both fund entity, management company, and all key individuals.',
        linkedPipelineId: 'p10_sanctions_pep_screening',
        transitionRule: 'risk_check',
        executionMode: 'parallel',
        attachedAgentIds: ['sanctions_screening_agent', 'pep_screening_agent', 'adverse_media_agent'],
        pipelines: ['P-10 (Sanctions and PEP)', 'P-11 (Adverse Media — both entities & key individuals)'],
        trigger: 'COLLECTION_COMPLETE',
        output: 'Full screening results — both fund and management company'
      },
      {
        id: 'fund_stage_8',
        name: 'STAGE 8: RISK ASSESSMENT',
        description: 'Multi-factor fund risk matrix evaluates strategy risk, investor jurisdiction risk, leverage risk, and triggers EDD.',
        linkedPipelineId: 'p12_risk_assessment',
        transitionRule: 'risk_check',
        executionMode: 'sequential',
        attachedAgentIds: ['risk_assessment_agent', 'edd_trigger_agent'],
        pipelines: ['P-12 (Fund-specific parameters — strategy, investor jurisdiction & leverage risk)', 'P-13 (EDD — conditional/triggered for funds)'],
        trigger: 'SCREENING_COMPLETE',
        output: 'Risk band — funds typically MEDIUM to HIGH'
      },
      {
        id: 'fund_stage_9',
        name: 'STAGE 9: SENIOR COMPLIANCE REVIEW',
        description: 'Senior compliance gateway routes fund onboarding decision for senior officer or committee approval.',
        linkedPipelineId: 'p20_approval_gateway',
        transitionRule: 'approval_gate',
        executionMode: 'sequential',
        attachedAgentIds: ['approval_gateway_agent'],
        pipelines: ['P-20 (SENIOR_REVIEW routing)'],
        trigger: 'RISK_ASSESSMENT_COMPLETE',
        output: 'Approval with conditions or rejection'
      },
      {
        id: 'fund_stage_10',
        name: 'STAGE 10: PRODUCT PROVISIONING',
        description: 'Parallel setup of mandate-eligible banking, treasury, custody, derivative (ISDA), and digital asset product accounts.',
        linkedPipelineId: 'p21_casa_provisioning',
        transitionRule: 'auto',
        executionMode: 'parallel',
        attachedAgentIds: [
          'signatory_intelligence_agent',
          'casa_provisioning_agent',
          'fx_mm_provisioning_agent',
          'derivatives_provisioning_agent',
          'digital_asset_provisioning_agent',
          'trade_finance_provisioning_agent'
        ],
        pipelines: [
          'P-19 (Signatory Intelligence — fund & mgmt co separately)',
          'P-21 (CASA — fund account + mgmt co account)',
          'P-22 (FX + MM — per mandate)',
          'P-23 (Derivatives — per mandate, requires ISDA)',
          'P-25 (Digital Assets — if in mandate)',
          'Custody Pipeline (traditional securities & fund admin banking)'
        ],
        trigger: 'APPROVED',
        output: 'All mandate-eligible products provisioned',
        parallelNotes: 'Standard products (CASA, FX Spot/Forwards, FX Swaps, MM, Custody) provision first. Mandate products (Derivatives, Prime Brokerage, Digital Assets, RWA, DeFi) provision per mandate eligibility.'
      },
      {
        id: 'fund_stage_11',
        name: 'STAGE 11: READY TO TRADE',
        description: 'Ready-to-Trade validation verifies operational status across all provisioned fund accounts and notifies RM and fund manager.',
        linkedPipelineId: 'p26_rtt_validation',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['rtt_validation_agent'],
        pipelines: ['P-26 (RTT Validation)'],
        trigger: 'PRODUCT_PROVISIONED',
        output: 'READY_TO_TRADE for fund'
      }
    ],
    phases: [
      {
        id: 'fund_stage_1',
        name: 'STAGE 1: FUND STRUCTURE IDENTIFICATION',
        description: 'RM creates opportunity. Lead intelligence and entity resolution pipelines run for BOTH fund entity and management company separately, linking them via MANAGES relationship.',
        linkedPipelineId: 'p01_lead_intelligence',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['lead_intelligence_agent', 'entity_resolution_agent'],
        pipelines: ['P-01 (Lead Intelligence)', 'P-02 (Entity Resolution — fund & manager dual intake)'],
        trigger: 'RM creates opportunity',
        output: 'Two Digital Twin records created, linked via MANAGES relationship'
      },
      {
        id: 'fund_stage_2',
        name: 'STAGE 2: MANAGEMENT COMPANY KYC',
        description: 'Autonomous research and ownership mapping for the fund management company and key management individuals.',
        linkedPipelineId: 'p03_autonomous_research',
        transitionRule: 'auto',
        executionMode: 'parallel',
        attachedAgentIds: ['research_agent', 'registry_connector_agent', 'ownership_agent', 'director_verification_agent', 'vlei_agent'],
        pipelines: ['P-03 (Autonomous Research)', 'P-04 (Ownership Structure)', 'P-05 (Director Verification)', 'P-06 (vLEI Verification)'],
        trigger: 'Auto — parallel with Stage 3',
        output: 'Management company fully researched, key individuals verified',
        parallelNotes: 'Stages 2 and 3 execute in parallel.'
      },
      {
        id: 'fund_stage_3',
        name: 'STAGE 3: FUND DOCUMENT ANALYSIS',
        description: 'Fund document intelligence extracts investment mandate, eligible assets, leverage & derivative limits, and investor eligibility criteria from offering memorandum.',
        linkedPipelineId: 'p15_fund_document_analysis',
        transitionRule: 'auto',
        executionMode: 'parallel',
        attachedAgentIds: ['fund_document_intelligence_agent', 'mandate_extraction_agent'],
        pipelines: ['P-15 (Fund Document Analysis)'],
        trigger: 'Auto — parallel with Stage 2',
        output: 'Investment mandate extracted, eligible assets defined, leverage and derivative limits captured, investor eligibility criteria documented',
        parallelNotes: 'Stages 2 and 3 execute in parallel.'
      },
      {
        id: 'fund_stage_4',
        name: 'STAGE 4: REGULATORY STATUS VERIFICATION',
        description: 'Queries regulatory databases to verify fund manager licensing specifically (MAS CMS, SFC, FCA, VARA, SEC, etc.).',
        linkedPipelineId: 'p03_autonomous_research',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['regulatory_database_agent', 'regulatory_rules_agent'],
        pipelines: ['P-03 (Regulatory databases — fund manager licensing specifically)'],
        trigger: 'On completion of Stage 2',
        output: 'Fund manager licence verified (MAS CMS, SFC, FCA, VARA etc.)'
      },
      {
        id: 'fund_stage_5',
        name: 'STAGE 5: FUND ENTITY KYC AND CLASSIFICATION',
        description: 'Determines fund entity KYC requirements, processes FATCA/CRS classification, and maps investor base jurisdiction risk.',
        linkedPipelineId: 'p08_dynamic_kyc_engine',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['kyc_engine_agent', 'fatca_agent', 'ownership_agent'],
        pipelines: ['P-08 (Fund parameters)', 'P-16 (FATCA/CRS)', 'P-04 (Investor base jurisdiction mapping)'],
        trigger: 'On completion of Stages 3 and 4',
        output: 'KYC requirements for fund entity, FATCA/CRS classification, investor base risk profile'
      },
      {
        id: 'fund_stage_6',
        name: 'STAGE 6: DOCUMENT COLLECTION AND OUTREACH',
        description: 'Targeted RM-assisted outreach collects remaining fund documents and validates uploaded packets.',
        linkedPipelineId: 'p09_client_outreach',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['client_outreach_agent', 'document_intelligence_agent', 'ocr_agent'],
        pipelines: ['P-07 (Document Intelligence)', 'P-09 (Tier 2/3 — RM-assisted for funds)'],
        trigger: 'Auto',
        output: 'Remaining fund documents collected, Digital Twin complete'
      },
      {
        id: 'fund_stage_7',
        name: 'STAGE 7: SCREENING',
        description: 'Full global sanctions, PEP, and adverse media screening across both fund entity, management company, and all key individuals.',
        linkedPipelineId: 'p10_sanctions_pep_screening',
        transitionRule: 'risk_check',
        executionMode: 'parallel',
        attachedAgentIds: ['sanctions_screening_agent', 'pep_screening_agent', 'adverse_media_agent'],
        pipelines: ['P-10 (Sanctions and PEP)', 'P-11 (Adverse Media — both entities & key individuals)'],
        trigger: 'COLLECTION_COMPLETE',
        output: 'Full screening results — both fund and management company'
      },
      {
        id: 'fund_stage_8',
        name: 'STAGE 8: RISK ASSESSMENT',
        description: 'Multi-factor fund risk matrix evaluates strategy risk, investor jurisdiction risk, leverage risk, and triggers EDD.',
        linkedPipelineId: 'p12_risk_assessment',
        transitionRule: 'risk_check',
        executionMode: 'sequential',
        attachedAgentIds: ['risk_assessment_agent', 'edd_trigger_agent'],
        pipelines: ['P-12 (Fund-specific parameters — strategy, investor jurisdiction & leverage risk)', 'P-13 (EDD — conditional/triggered for funds)'],
        trigger: 'SCREENING_COMPLETE',
        output: 'Risk band — funds typically MEDIUM to HIGH'
      },
      {
        id: 'fund_stage_9',
        name: 'STAGE 9: SENIOR COMPLIANCE REVIEW',
        description: 'Senior compliance gateway routes fund onboarding decision for senior officer or committee approval.',
        linkedPipelineId: 'p20_approval_gateway',
        transitionRule: 'approval_gate',
        executionMode: 'sequential',
        attachedAgentIds: ['approval_gateway_agent'],
        pipelines: ['P-20 (SENIOR_REVIEW routing)'],
        trigger: 'RISK_ASSESSMENT_COMPLETE',
        output: 'Approval with conditions or rejection'
      },
      {
        id: 'fund_stage_10',
        name: 'STAGE 10: PRODUCT PROVISIONING',
        description: 'Parallel setup of mandate-eligible banking, treasury, custody, derivative (ISDA), and digital asset product accounts.',
        linkedPipelineId: 'p21_casa_provisioning',
        transitionRule: 'auto',
        executionMode: 'parallel',
        attachedAgentIds: [
          'signatory_intelligence_agent',
          'casa_provisioning_agent',
          'fx_mm_provisioning_agent',
          'derivatives_provisioning_agent',
          'digital_asset_provisioning_agent',
          'trade_finance_provisioning_agent'
        ],
        pipelines: [
          'P-19 (Signatory Intelligence — fund & mgmt co separately)',
          'P-21 (CASA — fund account + mgmt co account)',
          'P-22 (FX + MM — per mandate)',
          'P-23 (Derivatives — per mandate, requires ISDA)',
          'P-25 (Digital Assets — if in mandate)',
          'Custody Pipeline (traditional securities & fund admin banking)'
        ],
        trigger: 'APPROVED',
        output: 'All mandate-eligible products provisioned',
        parallelNotes: 'Standard products (CASA, FX Spot/Forwards, FX Swaps, MM, Custody) provision first. Mandate products (Derivatives, Prime Brokerage, Digital Assets, RWA, DeFi) provision per mandate eligibility.'
      },
      {
        id: 'fund_stage_11',
        name: 'STAGE 11: READY TO TRADE',
        description: 'Ready-to-Trade validation verifies operational status across all provisioned fund accounts and notifies RM and fund manager.',
        linkedPipelineId: 'p26_rtt_validation',
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: ['rtt_validation_agent'],
        pipelines: ['P-26 (RTT Validation)'],
        trigger: 'PRODUCT_PROVISIONED',
        output: 'READY_TO_TRADE for fund'
      }
    ],
    steps: [
      { id: 'fund-1', name: 'STAGE 1: FUND STRUCTURE IDENTIFICATION', agentId: 'lead_intelligence_agent', executionType: 'sequential', failureHandling: 'escalate' },
      { id: 'fund-2', name: 'STAGE 2: MANAGEMENT COMPANY KYC', agentId: 'research_agent', executionType: 'parallel', failureHandling: 'escalate' },
      { id: 'fund-3', name: 'STAGE 3: FUND DOCUMENT ANALYSIS', agentId: 'fund_document_intelligence_agent', executionType: 'parallel', failureHandling: 'escalate' },
      { id: 'fund-4', name: 'STAGE 4: REGULATORY STATUS VERIFICATION', agentId: 'regulatory_database_agent', executionType: 'sequential', failureHandling: 'escalate' },
      { id: 'fund-5', name: 'STAGE 5: FUND ENTITY KYC AND CLASSIFICATION', agentId: 'kyc_engine_agent', executionType: 'sequential', failureHandling: 'escalate' },
      { id: 'fund-6', name: 'STAGE 6: DOCUMENT COLLECTION AND OUTREACH', agentId: 'client_outreach_agent', executionType: 'sequential', failureHandling: 'escalate' },
      { id: 'fund-7', name: 'STAGE 7: SCREENING', agentId: 'sanctions_screening_agent', executionType: 'parallel', failureHandling: 'escalate' },
      { id: 'fund-8', name: 'STAGE 8: RISK ASSESSMENT', agentId: 'risk_assessment_agent', executionType: 'sequential', failureHandling: 'escalate' },
      { id: 'fund-9', name: 'STAGE 9: SENIOR COMPLIANCE REVIEW', agentId: 'approval_gateway_agent', executionType: 'sequential', failureHandling: 'escalate' },
      { id: 'fund-10', name: 'STAGE 10: PRODUCT PROVISIONING', agentId: 'casa_provisioning_agent', executionType: 'parallel', failureHandling: 'escalate' },
      { id: 'fund-11', name: 'STAGE 11: READY TO TRADE', agentId: 'rtt_validation_agent', executionType: 'sequential', failureHandling: 'escalate' }
    ]
  }
];

export const DEFAULT_SYSTEM_AGENTS = INITIAL_AGENTS;

export const STAGE_TEMPLATES = [
  {
    id: 'intake',
    name: 'Entity Intake & Client Data Ingestion',
    category: 'Client Ingestion',
    description: 'Ingest company corporate profiles, registry identifiers (UEN/LEI), and kickoff automated intake validation.',
    recommendedPipeline: 'corporate_onboarding'
  },
  {
    id: 'kyb',
    name: 'KYB & Corporate Registry Pull',
    category: 'Entity Verification',
    description: 'Fetch and parse authentic government registers (ACRA, Companies House, Delaware Division of Corps).',
    recommendedPipeline: 'kyb_screening_pipeline'
  },
  {
    id: 'ubo',
    name: 'UBO Identification & Ownership Structure',
    category: 'Ownership Analysis',
    description: 'Traverse tiered shareholding layers to uncover 25%+ Ultimate Beneficial Owners (UBOs) and natural persons.',
    recommendedPipeline: 'ubo_resolution_pipeline'
  },
  {
    id: 'screening',
    name: 'Sanctions, PEP & Adverse Media Screening',
    category: 'AML Screening',
    description: 'Continuous real-time multi-jurisdiction watchlist checks against UN, OFAC, EU, MAS, and global media feeds.',
    recommendedPipeline: 'sanctions_pep_pipeline'
  },
  {
    id: 'risk_edd',
    name: 'Risk Rating & Enhanced Due Diligence (EDD)',
    category: 'Risk Analysis',
    description: 'Compute comprehensive multi-factor risk score matrix and trigger EDD workflows for high-risk flags.',
    recommendedPipeline: 'risk_rating_pipeline'
  },
  {
    id: 'provisioning',
    name: 'Product Provisioning & Account Activation',
    category: 'Activation',
    description: 'Dispatch Welcome Pack, issue multi-currency IBANs, and activate core banking cash/FX channels.',
    recommendedPipeline: 'provisioning_pipeline'
  },
  {
    id: 'note_stage',
    name: 'Operational Note & Compliance Memo',
    category: 'Documentation & Notes',
    description: 'Add an operational audit memo, compliance override notes, or checkpoint sign-off documentation to the journey.',
    recommendedPipeline: 'corporate_onboarding'
  },
  {
    id: 'custom',
    name: 'Custom Stage',
    category: 'Custom Architecture',
    description: 'Configure custom onboarding stage name, description, and attached Agent Studio pipelines.',
    recommendedPipeline: ''
  }
];

interface JourneysViewProps {
  agents?: OrchestrationAgent[];
  orchestrations?: AgentOrchestration[];
  onNavigateToStudio?: (pipelineId?: string) => void;
}

export function JourneysView({ agents = [], orchestrations = [], onNavigateToStudio }: JourneysViewProps) {
  // Load journeys from localstorage and merge with orchestrations
  const loadAndSyncJourneys = useCallback(() => {
    let baseJourneys: Journey[] = DEFAULT_JOURNEYS;
    const saved = localStorage.getItem('onboarding_journeys');
    if (saved) {
      try {
        const parsed: Journey[] = JSON.parse(saved);
        if (parsed && parsed.length > 0) {
          const hasJ1 = parsed.some(j => j.id === 'corporate_onboarding_journey');
          const hasJ2 = parsed.some(j => j.id === 'corporate_onboarding_existing_client_journey');
          const hasJ4 = parsed.some(j => j.id === 'fund_onboarding_journey');
          if (hasJ1 && hasJ2 && hasJ4) {
            baseJourneys = parsed;
          } else {
            baseJourneys = DEFAULT_JOURNEYS;
          }
        }
      } catch (e) {
        baseJourneys = DEFAULT_JOURNEYS;
      }
    }

    const firstOrchId = orchestrations[0]?.id || 'kyb_screening_pipeline';

    // Ensure each journey's linked pipeline exists in orchestrations
    const updated = baseJourneys.map(j => {
      const linked = (j as any).linkedPipelineId;
      const isValid = orchestrations.some(o => o.id === linked);
      return {
        ...j,
        linkedPipelineId: isValid ? linked : firstOrchId
      };
    });

    localStorage.setItem('onboarding_journeys', JSON.stringify(updated));
    return updated;
  }, [orchestrations]);

  const [journeys, setJourneys] = useState<Journey[]>(loadAndSyncJourneys);

  useEffect(() => {
    setJourneys(loadAndSyncJourneys());
  }, [orchestrations, loadAndSyncJourneys]);

  useEffect(() => {
    const handleUpdate = () => {
      setJourneys(loadAndSyncJourneys());
    };
    window.addEventListener('onboarding_journeys_updated', handleUpdate);
    window.addEventListener('storage', handleUpdate);
    return () => {
      window.removeEventListener('onboarding_journeys_updated', handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, [loadAndSyncJourneys]);

  useEffect(() => {
    localStorage.setItem('onboarding_journeys', JSON.stringify(journeys));
  }, [journeys]);

  // UI Modes: 'list' | 'builder'
  const [mode, setMode] = useState<'list' | 'builder'>('list');
  const [activeJourney, setActiveJourney] = useState<Journey | null>(null);

  // Form parameters for current journey being edited/created
  const [journeyName, setJourneyName] = useState('');
  const [journeyDesc, setJourneyDesc] = useState('');
  const [journeySLA, setJourneySLA] = useState('24 Hours');
  const [primaryAnchorId, setPrimaryAnchorId] = useState('kyc_agent');
  const [linkedPipelineId, setLinkedPipelineId] = useState('corporate_onboarding');
  const [journeyStatus, setJourneyStatus] = useState<'Active' | 'Draft' | 'Deprecated'>('Active');
  const [intakeDocs, setIntakeDocs] = useState<string[]>(['Certificate of Incorporation', 'Board Resolution', 'Director Passports']);
  const [riskThreshold, setRiskThreshold] = useState<number>(60);
  const [contractingMethod, setContractingMethod] = useState<string>('DocuSign e-Signature');

  // Journey Stages defined on canvas
  const [journeyStages, setJourneyStages] = useState<JourneyStage[]>([]);
  const [expandedStageId, setExpandedStageId] = useState<string | null>(null);

  // Add Stage Prompt Modal State
  const [showAddStagePrompt, setShowAddStagePrompt] = useState(false);
  const [selectedStageTemplateId, setSelectedStageTemplateId] = useState<string>('intake');
  const [customStageName, setCustomStageName] = useState<string>('');
  const [customStageDesc, setCustomStageDesc] = useState<string>('');
  const [addStageExecMode, setAddStageExecMode] = useState<'sequential' | 'parallel'>('sequential');
  const [addStagePipelineId, setAddStagePipelineId] = useState<string>('');

  // Resequencing Confirmation State (Prev / Next move prompt)
  const [stageMovePending, setStageMovePending] = useState<{ index: number; direction: 'up' | 'down'; stage: JourneyStage } | null>(null);

  // Name Required Modal & Toast
  const [showNameRequiredModal, setShowNameRequiredModal] = useState(false);
  const [pendingJourneyName, setPendingJourneyName] = useState('');
  const [nameError, setNameError] = useState<string | null>(null);
  const [saveToast, setSaveToast] = useState<string | null>(null);

  // Dry-run simulation state
  const [isSimulating, setIsSimulating] = useState(false);
  const [simulatedStage, setSimulatedStage] = useState<number>(-1);
  const [simulatedLogs, setSimulatedLogs] = useState<string[]>([]);

  // Modal state for detailed Stage Configuration & Node attachment
  const [editingStageIndex, setEditingStageIndex] = useState<number | null>(null);
  const [editingStage, setEditingStage] = useState<JourneyStage | null>(null);
  const [nodeSearchQuery, setNodeSearchQuery] = useState('');
  const [nodeTypeFilter, setNodeTypeFilter] = useState<'all' | 'super' | 'worker'>('all');

  // Delete Confirmation States
  const [journeyToDelete, setJourneyToDelete] = useState<Journey | null>(null);
  const [stageToDelete, setStageToDelete] = useState<JourneyStage | null>(null);

  // BPMN Viewer State (bpmn.io)
  const [bpmnModalJourney, setBpmnModalJourney] = useState<Journey | null>(null);
  const [builderTab, setBuilderTab] = useState<'graph' | 'bpmn'>('graph');

  // Available Agent Studio Nodes Pool (merging prop agents with DEFAULT_SYSTEM_AGENTS)
  const availableSystemAgents = useMemo(() => {
    const list = [...agents];
    for (const sysAg of DEFAULT_SYSTEM_AGENTS) {
      if (!list.some(a => a.id === sysAg.id)) {
        list.push(sysAg);
      }
    }
    return list;
  }, [agents]);

  // Maps & Agents
  const superAgents = availableSystemAgents.filter(a => a.agentClass === 'super');
  const allAgentsMap = useMemo(() => {
    return new Map(availableSystemAgents.map(a => [a.id, a]));
  }, [availableSystemAgents]);

  const getAgentName = (id: string) => {
    return allAgentsMap.get(id)?.name || id;
  };

  const openStageDetailModal = (index: number) => {
    const stage = journeyStages[index];
    if (!stage) return;
    const defaultPipeline = orchestrations.find(o => o.id === stage.linkedPipelineId);
    const defaultAgentIds = defaultPipeline ? defaultPipeline.agentIds : ['kyc_agent', 'kyb_agent'];

    setEditingStageIndex(index);
    setEditingStage({
      ...stage,
      executionMode: stage.executionMode || 'sequential',
      attachedAgentIds: stage.attachedAgentIds ? [...stage.attachedAgentIds] : [...defaultAgentIds],
      description: stage.description || ''
    });
    setNodeSearchQuery('');
    setNodeTypeFilter('all');
  };

  const handleSaveModalStage = () => {
    if (editingStageIndex === null || !editingStage) return;
    setJourneyStages(prev => {
      const updated = [...prev];
      updated[editingStageIndex] = editingStage;
      return updated;
    });
    setEditingStageIndex(null);
    setEditingStage(null);
  };

  const startCreateNewJourney = () => {
    setJourneyName('');
    setJourneyDesc('');
    setJourneySLA('24 Hours');
    setPrimaryAnchorId(superAgents[0]?.id || 'kyc_agent');
    setLinkedPipelineId(orchestrations[0]?.id || 'kyb_screening_pipeline');
    setJourneyStatus('Active');
    setIntakeDocs(['Certificate of Incorporation', 'Board Resolution', 'Director Passports']);
    setRiskThreshold(60);
    setContractingMethod('DocuSign e-Signature');
    
    // Blank canvas with 1 default stage preloaded
    const defaultPipeline = orchestrations[0]?.id || 'kyb_screening_pipeline';
    const chosenOrch = orchestrations.find(o => o.id === defaultPipeline);
    const initialStageId = `stage_${Date.now().toString().slice(-5)}_1`;
    setJourneyStages([
      {
        id: initialStageId,
        name: 'Stage 1: Customer Data & Document Intake',
        description: 'Customer portal document submission & OCR parsing.',
        linkedPipelineId: defaultPipeline,
        transitionRule: 'auto',
        executionMode: 'sequential',
        attachedAgentIds: chosenOrch ? [...chosenOrch.agentIds] : ['onboarding_agent', 'ocr_parsing_agent']
      }
    ]);
    setExpandedStageId(initialStageId);
    setActiveJourney(null);
    setMode('builder');
  };

  const startEditJourney = (journey: Journey) => {
    setJourneyName(journey.name);
    setJourneyDesc(journey.description);
    setJourneySLA(journey.expectedSLA);
    setPrimaryAnchorId(journey.primaryAnchorId || 'kyc_agent');
    setLinkedPipelineId((journey as any).linkedPipelineId || orchestrations[0]?.id || 'kyb_screening_pipeline');
    setJourneyStatus(journey.status);
    setIntakeDocs((journey as any).intakeDocuments || ['Certificate of Incorporation', 'Board Resolution']);
    setRiskThreshold((journey as any).riskEscalationThreshold || 60);
    setContractingMethod((journey as any).contractingMethod || 'DocuSign e-Signature');

    const existingStages = (journey as any).stages || (journey as any).phases;
    if (existingStages && existingStages.length > 0) {
      setJourneyStages(existingStages);
      setExpandedStageId(existingStages[0].id);
    } else {
      const fallbackStages: JourneyStage[] = [
        {
          id: 'p_1',
          name: 'Stage 1: Customer Data & Document Intake',
          description: 'Customer portal document uploads and OCR parsing.',
          linkedPipelineId: (journey as any).linkedPipelineId || orchestrations[0]?.id || 'kyb_screening_pipeline',
          transitionRule: 'auto',
          executionMode: 'sequential',
          attachedAgentIds: ['onboarding_agent', 'ocr_parsing_agent']
        },
        {
          id: 'p_2',
          name: 'Stage 2: Multi-Agent AI Verification Pipeline',
          description: 'Automated verification pipeline via Agent Studio.',
          linkedPipelineId: orchestrations[1]?.id || (journey as any).linkedPipelineId || 'corporate_onboarding',
          transitionRule: 'auto',
          executionMode: 'parallel',
          attachedAgentIds: ['kyc_agent', 'kyb_agent', 'sanctions_screening_agent']
        },
        {
          id: 'p_3',
          name: 'Stage 3: Compliance & Officer Review Gate',
          description: 'Risk threshold evaluation and manual officer gate.',
          linkedPipelineId: orchestrations[2]?.id || 'ubo_discovery_pipeline',
          transitionRule: 'approval_gate',
          executionMode: 'sequential',
          attachedAgentIds: ['ubo_discovery_agent', 'risk_scoring_agent']
        },
        {
          id: 'p_4',
          name: 'Stage 4: Legal Contracting & Core Provisioning',
          description: 'Legal e-signing and CASA vault account setup.',
          linkedPipelineId: orchestrations[0]?.id || 'kyb_screening_pipeline',
          transitionRule: 'auto',
          executionMode: 'sequential',
          attachedAgentIds: ['docusign_agent', 'account_provisioning_agent']
        }
      ];
      setJourneyStages(fallbackStages);
      setExpandedStageId(fallbackStages[0].id);
    }

    setActiveJourney(journey);
    setMode('builder');
  };

  const handleDeleteJourney = (journeyId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const target = journeys.find(j => j.id === journeyId);
    if (target) {
      setJourneyToDelete(target);
    }
  };

  const handleConfirmDeleteJourney = () => {
    if (!journeyToDelete) return;
    setJourneys(prev => {
      const next = prev.filter(j => j.id !== journeyToDelete.id);
      localStorage.setItem('onboarding_journeys', JSON.stringify(next));
      window.dispatchEvent(new Event('onboarding_journeys_updated'));
      return next;
    });
    setJourneyToDelete(null);
  };

  // Stage Renumbering Helper ensuring strict 1..N sequence without gaps or stale prefixes
  const renumberStages = (stages: JourneyStage[]): JourneyStage[] => {
    return stages.map((st, i) => {
      const stageNum = i + 1;
      let cleanName = st.name;
      cleanName = cleanName.replace(/^Stage\s*\d+[\s:\-–—]*/i, '').trim();
      if (!cleanName) cleanName = 'Onboarding Stage';
      return {
        ...st,
        name: `Stage ${stageNum}: ${cleanName}`
      };
    });
  };

  // Stage Manipulation Handlers
  const handleOpenAddStagePrompt = (pipelineId?: string) => {
    if (pipelineId) {
      setAddStagePipelineId(pipelineId);
    } else {
      setAddStagePipelineId(orchestrations[0]?.id || 'kyb_screening_pipeline');
    }
    setSelectedStageTemplateId('intake');
    setCustomStageName('');
    setCustomStageDesc('');
    setAddStageExecMode('sequential');
    setShowAddStagePrompt(true);
  };

  const handleConfirmAddStageFromPrompt = () => {
    const stageNum = journeyStages.length + 1;
    const tpl = STAGE_TEMPLATES.find(t => t.id === selectedStageTemplateId);
    const stageName = selectedStageTemplateId === 'custom' && customStageName.trim()
      ? customStageName.trim()
      : tpl ? tpl.name : 'New Onboarding Stage';
    const stageDesc = selectedStageTemplateId === 'custom' && customStageDesc.trim()
      ? customStageDesc.trim()
      : tpl ? tpl.description : 'Configure pipeline handoff parameters and transition rules.';

    const chosenPipelineId = addStagePipelineId || tpl?.recommendedPipeline || orchestrations[0]?.id || 'kyb_screening_pipeline';
    const chosenOrch = orchestrations.find(o => o.id === chosenPipelineId);

    const newStage: JourneyStage = {
      id: `stage_${Date.now().toString().slice(-6)}_${stageNum}`,
      name: `Stage ${stageNum}: ${stageName}`,
      description: stageDesc,
      linkedPipelineId: chosenPipelineId,
      transitionRule: 'approval_gate',
      executionMode: addStageExecMode,
      attachedAgentIds: chosenOrch ? [...chosenOrch.agentIds] : ['kyc_agent', 'kyb_agent']
    };

    setJourneyStages(prev => renumberStages([...prev, newStage]));
    setExpandedStageId(newStage.id);
    setShowAddStagePrompt(false);
    setCustomStageName('');
    setCustomStageDesc('');
    setSaveToast(`✅ Added Stage ${stageNum}: ${stageName}`);
    setTimeout(() => setSaveToast(null), 3000);
  };

  const handleDirectAttachPipelineAsStage = (pipelineId: string) => {
    const chosenOrch = orchestrations.find(o => o.id === pipelineId);
    const stageNum = journeyStages.length + 1;
    const pipelineName = chosenOrch?.name || 'Component Pipeline';

    const newStage: JourneyStage = {
      id: `stage_${Date.now().toString().slice(-6)}_${stageNum}`,
      name: `Stage ${stageNum}: ${pipelineName}`,
      description: `Automated processing via ${pipelineName} with ${chosenOrch?.agentIds.length || 0} wired agent nodes.`,
      linkedPipelineId: pipelineId,
      transitionRule: 'approval_gate',
      executionMode: 'sequential',
      attachedAgentIds: chosenOrch ? [...chosenOrch.agentIds] : ['kyc_agent', 'kyb_agent']
    };

    setJourneyStages(prev => renumberStages([...prev, newStage]));
    setExpandedStageId(newStage.id);
    setSaveToast(`✅ Attached "${pipelineName}" as Stage ${stageNum}`);
    setTimeout(() => setSaveToast(null), 3000);
  };

  const handleAddNoteStage = () => {
    const stageNum = journeyStages.length + 1;
    const chosenPipelineId = orchestrations[0]?.id || 'corporate_onboarding';
    const chosenOrch = orchestrations.find(o => o.id === chosenPipelineId);

    const newStage: JourneyStage = {
      id: `stage_${Date.now().toString().slice(-6)}_${stageNum}`,
      name: `Stage ${stageNum}: Operational Note & Compliance Memo`,
      description: `Operational audit memo and checkpoint notes recorded on ${new Date().toLocaleDateString()}. Action items and compliance sign-offs tracked here.`,
      linkedPipelineId: chosenPipelineId,
      transitionRule: 'approval_gate',
      executionMode: 'sequential',
      attachedAgentIds: chosenOrch ? [...chosenOrch.agentIds] : ['kyc_agent', 'kyb_agent']
    };

    setJourneyStages(prev => renumberStages([...prev, newStage]));
    setExpandedStageId(newStage.id);
    setSaveToast(`✅ Added Stage ${stageNum}: Operational Note & Compliance Memo`);
    setTimeout(() => setSaveToast(null), 3000);
  };

  const handleAppendStageNote = (stageId: string, noteText: string) => {
    if (!noteText.trim()) return;
    const stage = journeyStages.find(s => s.id === stageId);
    if (!stage) return;
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const noteEntry = `[${timestamp} RM Note]: ${noteText.trim()}`;
    const newDesc = stage.description ? `${stage.description} | ${noteEntry}` : noteEntry;
    handleUpdateStage(stageId, { description: newDesc });
    setSaveToast(`✅ Note added to stage`);
    setTimeout(() => setSaveToast(null), 2500);
  };

  const handleGenerateAINote = (stageId: string) => {
    const stage = journeyStages.find(s => s.id === stageId);
    if (!stage) return;
    const aiNote = `[AI Auto-Summary]: Verified all attached agent execution policies. Automated compliance checks passed with zero sanctions hits. Ready for Human-in-the-Loop officer gate sign-off.`;
    const newDesc = stage.description ? `${stage.description} | ${aiNote}` : aiNote;
    handleUpdateStage(stageId, { description: newDesc });
    setSaveToast(`✨ Generated AI Stage Summary Note`);
    setTimeout(() => setSaveToast(null), 3000);
  };

  const handleUpdateStage = (stageId: string, updates: Partial<JourneyStage>) => {
    setJourneyStages(prev => prev.map(s => s.id === stageId ? { ...s, ...updates } : s));
  };

  const isStageLocked = (stage?: JourneyStage | null) => {
    if (!stage) return false;
    return (stage as any).status === 'completed' || (stage as any).status === 'approved' || (stage as any).status === 'verified' || (stage as any).isLocked === true;
  };

  const handleRemoveStage = (stageId: string) => {
    const targetStage = journeyStages.find(s => s.id === stageId);
    if (targetStage && isStageLocked(targetStage)) {
      setSaveToast("🔒 Locked Stage: Finalized and verified stages cannot be deleted.");
      setTimeout(() => setSaveToast(null), 3500);
      return;
    }
    if (targetStage) {
      setStageToDelete(targetStage);
    }
  };

  const handleConfirmRemoveStage = () => {
    if (!stageToDelete) return;
    setJourneyStages(prev => {
      const remaining = prev.filter(s => s.id !== stageToDelete.id);
      return renumberStages(remaining);
    });
    if (expandedStageId === stageToDelete.id) {
      setExpandedStageId(null);
    }
    setStageToDelete(null);
  };

  const requestMoveStage = (index: number, direction: 'up' | 'down', e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= journeyStages.length) return;

    const sourceStage = journeyStages[index];
    const targetStage = journeyStages[targetIndex];

    if (isStageLocked(sourceStage) || isStageLocked(targetStage)) {
      setSaveToast("🔒 Stage Locked: Finalized and completed stages cannot be re-ordered.");
      setTimeout(() => setSaveToast(null), 3500);
      return;
    }

    setStageMovePending({ index, direction, stage: sourceStage });
  };

  const executeMoveStage = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= journeyStages.length) return;

    setJourneyStages(prev => {
      const next = [...prev];
      const temp = next[index];
      next[index] = next[targetIndex];
      next[targetIndex] = temp;
      return renumberStages(next);
    });
  };

  // Drag and drop state for Journey Graph stage nodes
  const [draggedStageId, setDraggedStageId] = useState<string | null>(null);
  const [dragOverStageId, setDragOverStageId] = useState<string | null>(null);
  const [dragOverTrack, setDragOverTrack] = useState<'sequential' | 'parallel' | null>(null);

  const handleDragStartStage = (e: React.DragEvent, stageId: string) => {
    e.stopPropagation();
    const stage = journeyStages.find(s => s.id === stageId);
    if (stage && isStageLocked(stage)) {
      e.preventDefault();
      setSaveToast("🔒 Stage Locked: Finalized & completed stages are locked against re-ordering.");
      setTimeout(() => setSaveToast(null), 3500);
      return;
    }
    try {
      e.dataTransfer.setData('text/plain', stageId);
      e.dataTransfer.setData('application/json', JSON.stringify({ stageId }));
    } catch (_) {}
    e.dataTransfer.effectAllowed = 'move';
    setDraggedStageId(stageId);
  };

  const handleDragOverStage = (e: React.DragEvent, targetStageId: string, trackMode?: 'sequential' | 'parallel') => {
    e.preventDefault();
    e.stopPropagation();
    try {
      e.dataTransfer.dropEffect = 'move';
    } catch (_) {}
    if (dragOverStageId !== targetStageId) {
      setDragOverStageId(targetStageId);
    }
    if (trackMode && dragOverTrack !== trackMode) {
      setDragOverTrack(trackMode);
    }
  };

  const handleDragEnterStage = (e: React.DragEvent, targetStageId: string, trackMode?: 'sequential' | 'parallel') => {
    e.preventDefault();
    e.stopPropagation();
    setDragOverStageId(targetStageId);
    if (trackMode) setDragOverTrack(trackMode);
  };

  const handleDropOnStageNode = (e: React.DragEvent, targetStageId: string, targetTrack?: 'sequential' | 'parallel') => {
    e.preventDefault();
    e.stopPropagation();
    let sourceId = draggedStageId;
    try {
      const textData = e.dataTransfer.getData('text/plain');
      if (textData) sourceId = textData;
      const jsonText = e.dataTransfer.getData('application/json');
      if (jsonText) {
        const parsed = JSON.parse(jsonText);
        if (parsed.stageId) sourceId = parsed.stageId;
      }
    } catch (_) {}

    if (!sourceId || sourceId === targetStageId) {
      setDraggedStageId(null);
      setDragOverStageId(null);
      setDragOverTrack(null);
      return;
    }

    const sourceStage = journeyStages.find(s => s.id === sourceId);
    const targetStage = journeyStages.find(s => s.id === targetStageId);

    if (isStageLocked(sourceStage) || isStageLocked(targetStage)) {
      setSaveToast("🔒 Reordering Blocked: Finalized and completed stages are automatically locked.");
      setTimeout(() => setSaveToast(null), 3500);
      setDraggedStageId(null);
      setDragOverStageId(null);
      setDragOverTrack(null);
      return;
    }

    setJourneyStages(prev => {
      const fromIndex = prev.findIndex(s => s.id === sourceId);
      const toIndex = prev.findIndex(s => s.id === targetStageId);
      if (fromIndex === -1 || toIndex === -1) return prev;

      const next = [...prev];
      const [movedStage] = next.splice(fromIndex, 1);
      
      const updatedStage = {
        ...movedStage,
        executionMode: targetTrack || movedStage.executionMode || 'sequential'
      };

      next.splice(toIndex, 0, updatedStage);
      return renumberStages(next);
    });

    setDraggedStageId(null);
    setDragOverStageId(null);
    setDragOverTrack(null);
  };

  const handleDropOnConnector = (e: React.DragEvent, targetIndex: number) => {
    e.preventDefault();
    e.stopPropagation();
    let sourceId = draggedStageId;
    try {
      const textData = e.dataTransfer.getData('text/plain');
      if (textData) sourceId = textData;
    } catch (_) {}

    if (!sourceId) {
      setDraggedStageId(null);
      setDragOverStageId(null);
      setDragOverTrack(null);
      return;
    }

    setJourneyStages(prev => {
      const fromIndex = prev.findIndex(s => s.id === sourceId);
      if (fromIndex === -1) return prev;

      const next = [...prev];
      const [movedStage] = next.splice(fromIndex, 1);

      let finalIdx = targetIndex;
      if (fromIndex < targetIndex) {
        finalIdx = targetIndex - 1;
      }
      
      next.splice(finalIdx, 0, movedStage);
      return renumberStages(next);
    });

    setDraggedStageId(null);
    setDragOverStageId(null);
    setDragOverTrack(null);
  };

  const handleDropOnTrackZone = (e: React.DragEvent, targetTrack: 'sequential' | 'parallel', position: 'start' | 'end') => {
    e.preventDefault();
    e.stopPropagation();
    let sourceId = draggedStageId;
    try {
      const textData = e.dataTransfer.getData('text/plain');
      if (textData) sourceId = textData;
    } catch (_) {}

    if (!sourceId) {
      setDraggedStageId(null);
      setDragOverStageId(null);
      setDragOverTrack(null);
      return;
    }

    setJourneyStages(prev => {
      const fromIndex = prev.findIndex(s => s.id === sourceId);
      if (fromIndex === -1) return prev;

      const next = [...prev];
      const [movedStage] = next.splice(fromIndex, 1);
      const updatedStage = {
        ...movedStage,
        executionMode: targetTrack
      };

      if (position === 'start') {
        next.unshift(updatedStage);
      } else {
        next.push(updatedStage);
      }

      return renumberStages(next);
    });

    setDraggedStageId(null);
    setDragOverStageId(null);
    setDragOverTrack(null);
  };

  const handleToggleStageTrack = (stageId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setJourneyStages(prev => prev.map(s => {
      if (s.id === stageId) {
        return {
          ...s,
          executionMode: s.executionMode === 'parallel' ? 'sequential' : 'parallel'
        };
      }
      return s;
    }));
  };

  const handleDragEndStage = (e: React.DragEvent) => {
    e.stopPropagation();
    setDraggedStageId(null);
    setDragOverStageId(null);
    setDragOverTrack(null);
  };

  // Check if journey name is empty or starts with "Untitled"
  const isJourneyNameInvalid = (name?: string) => {
    if (!name) return true;
    const trimmed = name.trim().toLowerCase();
    return trimmed === '' || trimmed === 'untitled' || trimmed.startsWith('untitled');
  };

  const executeSaveJourney = (customName?: string) => {
    const finalName = (customName || journeyName).trim();

    const compiledJourney: Journey = {
      id: activeJourney ? activeJourney.id : `journey_${Date.now()}`,
      name: finalName,
      description: journeyDesc || 'Custom client onboarding journey design created in Onboard.ai.',
      expectedSLA: journeySLA,
      primaryAnchorId,
      status: journeyStatus,
      linkedPipelineId: journeyStages[0]?.linkedPipelineId || linkedPipelineId || 'corporate_onboarding',
      intakeDocuments: intakeDocs,
      riskEscalationThreshold: riskThreshold,
      contractingMethod,
      stages: journeyStages,
      phases: journeyStages,
      steps: journeyStages.map((stage, idx) => ({
        id: `step_${idx + 1}`,
        name: stage.name,
        agentId: primaryAnchorId || 'kyc_agent',
        executionType: 'sequential',
        failureHandling: 'escalate'
      }))
    };

    setJourneys(prev => {
      const next = activeJourney
        ? prev.map(j => j.id === activeJourney.id ? compiledJourney : j)
        : [...prev, compiledJourney];
      localStorage.setItem('onboarding_journeys', JSON.stringify(next));
      window.dispatchEvent(new Event('onboarding_journeys_updated'));
      return next;
    });

    setSaveToast(`Journey Design "${finalName}" saved successfully with ${journeyStages.length} wired stages.`);
    setTimeout(() => setSaveToast(null), 3500);

    setMode('list');
    setActiveJourney(null);
    setIsSimulating(false);
  };

  const saveJourney = () => {
    if (isJourneyNameInvalid(journeyName)) {
      const initialVal = journeyName && !journeyName.toLowerCase().startsWith('untitled') ? journeyName : '';
      setPendingJourneyName(initialVal);
      setNameError(null);
      setShowNameRequiredModal(true);
      return;
    }

    executeSaveJourney();
  };

  const handleConfirmSaveName = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (isJourneyNameInvalid(pendingJourneyName)) {
      setNameError('Journey Design name cannot be empty or start with "Untitled". Please specify a descriptive name.');
      return;
    }

    setJourneyName(pendingJourneyName.trim());
    executeSaveJourney(pendingJourneyName);
    setShowNameRequiredModal(false);
  };

  // Simulation Engine loop across wired Journey Stages
  useEffect(() => {
    let timer: NodeJS.Timeout;
    const totalStages = journeyStages.length || 4;

    if (isSimulating && simulatedStage >= 0 && simulatedStage < totalStages) {
      const currentStage = journeyStages[simulatedStage] || {
        name: `Stage ${simulatedStage + 1}`,
        linkedPipelineId: 'corporate_onboarding'
      };
      const orch = orchestrations.find(o => o.id === currentStage.linkedPipelineId);
      const modeLabel = currentStage.executionMode === 'parallel' ? '🔀 PARALLEL FAN-OUT' : '⚡ SEQUENTIAL CHAIN';
      const attachedIds = currentStage.attachedAgentIds || orch?.agentIds || [];
      const agentNames = attachedIds.map(id => allAgentsMap.get(id)?.name || id).join(', ');

      setSimulatedLogs(prev => [
        ...prev,
        `[00:${String((simulatedStage + 1) * 2).padStart(2, '0')}.0] 🚀 Executing ${currentStage.name} (${modeLabel})...`,
        `  🤖 Invoking ${attachedIds.length} Wired Stage Nodes: [ ${agentNames || 'Default Nodes'} ]`,
        `  ⚡ Stage transition rule: ${currentStage.transitionRule ? currentStage.transitionRule.toUpperCase() : 'AUTO-ADVANCE'} -> Passed.`
      ]);

      timer = setTimeout(() => {
        if (simulatedStage + 1 < totalStages) {
          setSimulatedStage(prev => prev + 1);
        } else {
          setSimulatedLogs(prev => [
            ...prev,
            `[00:12.0] 🎉 Client Onboarding Journey Design execution completed successfully!`
          ]);
          setIsSimulating(false);
          setSimulatedStage(-1);
        }
      }, 2500);
    }

    return () => clearTimeout(timer);
  }, [isSimulating, simulatedStage, journeyStages, orchestrations]);

  const handleStartSimulation = () => {
    setIsSimulating(true);
    setSimulatedStage(0);
    setSimulatedLogs([
      `[00:00.0] 🤖 Initialising Lifecycle Dry-Run Simulation for: "${journeyName || 'Client Journey'}"`,
      `[00:00.2] 🌐 Handshaking with ${journeyStages.length} wired stages & linked Agent Studio topologies...`
    ]);
  };

  const handleStopSimulation = () => {
    setIsSimulating(false);
    setSimulatedStage(-1);
    setSimulatedLogs(prev => [...prev, '[00:00.0] ⏹️ Dry-run simulation stopped by administrator.']);
  };

  return (
    <div className="space-y-6 text-slate-800 dark:text-slate-100">
      {/* Toast Notification Banner */}
      {saveToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#262B40] text-white text-xs px-4 py-3 rounded-xl shadow-2xl border border-slate-700 flex items-center gap-2.5 animate-bounce">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="font-semibold">{saveToast}</span>
        </div>
      )}

      {/* Forced Name Modal */}
      {showNameRequiredModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-150 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-50 text-amber-600 border border-amber-200 rounded-xl">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <h3 className="font-extrabold text-sm text-[#262B40]">Name Your Journey Design</h3>
                  <p className="text-[11px] text-slate-500">Please enter a descriptive name before saving.</p>
                </div>
              </div>
              <button 
                onClick={() => setShowNameRequiredModal(false)}
                className="p-1 hover:bg-slate-100 rounded text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmSaveName} className="space-y-4">
              {nameError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg font-medium flex items-center gap-2 text-left">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
                  {nameError}
                </div>
              )}

              <div className="space-y-1.5 text-left">
                <label className="text-[10px] font-mono font-bold text-slate-500 uppercase block">
                  JOURNEY NAME <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  autoFocus
                  placeholder="e.g. Wealth & Institutional Funds Onboarding Path"
                  value={pendingJourneyName}
                  onChange={(e) => {
                    setPendingJourneyName(e.target.value);
                    setNameError(null);
                  }}
                  className="w-full bg-slate-50 border border-slate-200 px-3 py-2.5 rounded-lg text-xs font-bold text-[#262B40] focus:outline-none focus:border-[#0474C4] transition"
                />
                <p className="text-[10px] text-slate-400">
                  Cannot be empty or start with "Untitled".
                </p>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-150">
                <button
                  type="button"
                  onClick={() => setShowNameRequiredModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-lg transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#0474C4] hover:bg-[#06457F] text-white font-bold text-xs rounded-lg transition flex items-center gap-1.5 shadow-sm cursor-pointer"
                >
                  <Check className="w-4 h-4" /> Save Journey
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 1. LIST JOURNEYS MODE */}
      {mode === 'list' && (
        <div className="space-y-6">
          {/* Header */}
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-blue-50 border border-blue-200 text-[#0474C4] rounded-xl">
                <GitBranch className="w-6 h-6" />
              </div>
              <div className="text-left">
                <h2 className="font-bold text-base text-[#262B40] flex items-center gap-2">
                  Client Onboarding Journeys
                  <span className="text-[10px] bg-[#0474C4]/10 text-[#0474C4] border border-[#0474C4]/20 font-mono px-2 py-0.5 rounded-full uppercase font-bold">Journey Design</span>
                </h2>
                <p className="text-xs text-[#5379AE] mt-1 max-w-2xl leading-relaxed">
                  Compose client onboarding journey designs on a blank canvas, define stages, and attach component pipelines designed in <strong>Agent Studio</strong>.
                </p>
              </div>
            </div>

            <button
              onClick={startCreateNewJourney}
              className="px-4 py-2 bg-[#0474C4] hover:bg-[#06457F] text-white font-bold text-xs rounded-lg shadow-sm transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap self-start md:self-center"
            >
              <Plus className="w-4 h-4" /> Create New Journey Design
            </button>
          </div>

          {/* List Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {journeys.map(journey => {
              const stagesList = (journey as any).stages || (journey as any).phases;
              const stageCount = stagesList ? stagesList.length : 4;

              return (
                <div 
                  key={journey.id}
                  onClick={() => startEditJourney(journey)}
                  className="bg-white border border-slate-200 hover:border-[#0474C4] rounded-2xl p-6 shadow-sm space-y-5 transition duration-200 flex flex-col justify-between group cursor-pointer"
                >
                  <div className="space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="p-3 bg-[#F0F4FA] border border-[#A8C4EC]/60 text-[#0474C4] rounded-xl group-hover:bg-[#0474C4] group-hover:text-white transition duration-200">
                        <GitBranch className="w-5 h-5 group-hover:rotate-12 transition duration-200" />
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] font-mono font-bold border px-2.5 py-1 rounded uppercase ${
                          journey.status === 'Active' 
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
                            : 'bg-slate-100 text-slate-600 border-slate-200'
                        }`}>
                          {journey.status}
                        </span>
                      </div>
                    </div>

                    <div className="text-left space-y-2">
                      <h4 className="font-bold text-[#262B40] text-base group-hover:text-[#0474C4] transition">
                        {journey.name}
                      </h4>
                      <p className="text-xs text-[#5379AE] leading-relaxed">
                        {journey.description || 'No custom description defined.'}
                      </p>
                    </div>

                    {/* Stage Overview Banner */}
                    <div className="bg-[#F0F4FA]/60 p-4 rounded-xl border border-[#A8C4EC]/40 flex items-center justify-between">
                      <div className="text-left space-y-0.5">
                        <span className="text-[10px] font-mono font-bold text-[#5379AE] uppercase tracking-wider block">
                          JOURNEY ARCHITECTURE
                        </span>
                        <span className="text-xs font-bold text-[#262B40] block">
                          {stageCount} Standard Stages Configured
                        </span>
                        <span className="text-[10px] text-[#5379AE] block">
                          Covers Qualification, Research, Screening, Risk, Approvals, Provisioning & Perpetual KYC
                        </span>
                      </div>
                      <div className="px-3 py-1.5 bg-[#0474C4]/10 text-[#0474C4] border border-[#0474C4]/20 rounded-lg text-xs font-bold font-mono whitespace-nowrap">
                        {stageCount} Stages
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-slate-100 flex items-center justify-end text-xs">
                    <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setBpmnModalJourney(journey);
                        }}
                        className="px-3 py-1.5 bg-slate-100 hover:bg-blue-50 text-slate-700 hover:text-[#0474C4] border border-slate-200 hover:border-blue-300 font-bold rounded-lg transition flex items-center gap-1.5 cursor-pointer text-xs shadow-xs"
                        title="View & Simulate BPMN 2.0 Diagram (bpmn.io)"
                      >
                        <Layers className="w-3.5 h-3.5 text-[#0474C4]" /> BPMN 2.0
                      </button>

                      <button
                        onClick={() => startEditJourney(journey)}
                        className="px-3.5 py-1.5 bg-[#0474C4] hover:bg-[#06457F] text-white font-semibold rounded-lg transition flex items-center gap-1.5 cursor-pointer text-xs"
                      >
                        <Edit2 className="w-3.5 h-3.5" /> View & Edit Journey
                      </button>

                      <button
                        onClick={(e) => handleDeleteJourney(journey.id, e)}
                        className="p-1.5 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-lg transition cursor-pointer"
                        title="Delete Journey Design"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 2. JOURNEY CANVAS BUILDER */}
      {mode === 'builder' && (() => {
        const currentJourneyDraft: Journey = {
          id: activeJourney?.id || 'journey_custom_draft',
          name: journeyName || 'Draft Onboarding Journey',
          description: journeyDesc || 'Custom onboarding lifecycle design',
          expectedSLA: journeySLA,
          status: journeyStatus,
          targetEntity: activeJourney?.targetEntity || 'Institutional Client',
          stages: journeyStages,
          steps: journeyStages.map((s, idx) => ({
            id: `step-${idx + 1}`,
            name: s.name,
            agentId: s.attachedAgentIds?.[0] || 'lead_intelligence_agent',
            executionType: (s.executionMode || 'sequential') as any,
            failureHandling: 'escalate'
          }))
        };

        return (
        <div className="space-y-6">
          {/* Top Header Bar */}
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
            <div className="space-y-1 text-left">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => { setMode('list'); setIsSimulating(false); }}
                  className="text-xs text-[#5379AE] hover:text-[#262B40] transition flex items-center gap-1 cursor-pointer mr-2 font-bold"
                >
                  &larr; Back to Journeys
                </button>
                <h3 className="font-extrabold text-base text-[#262B40]">
                  {activeJourney ? `Journey Design Canvas: ${journeyName}` : 'Journey Design Canvas (Blank)'}
                </h3>
              </div>
              <p className="text-xs text-[#5379AE]">
                Define onboarding stages on the canvas, inspect the standard <strong>BPMN 2.0 Process Diagram</strong>, or attach component pipelines.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* View Switcher Tabs: Graph Canvas vs BPMN 2.0 */}
              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200">
                <button
                  type="button"
                  onClick={() => setBuilderTab('graph')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                    builderTab === 'graph'
                      ? 'bg-white text-[#0474C4] shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <GitBranch className="w-3.5 h-3.5" /> Graph Canvas
                </button>
                <button
                  type="button"
                  onClick={() => setBuilderTab('bpmn')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                    builderTab === 'bpmn'
                      ? 'bg-[#0474C4] text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5" /> BPMN 2.0 View (bpmn.io)
                </button>
              </div>

              {isSimulating ? (
                <button
                  onClick={handleStopSimulation}
                  className="px-3.5 py-2 bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                >
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" /> Stop Dry Run
                </button>
              ) : (
                <button
                  onClick={handleStartSimulation}
                  className="px-3.5 py-2 bg-slate-100 text-[#262B40] hover:bg-slate-200 border border-slate-200 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 text-[#0474C4]" /> Run Dry-Run Simulation
                </button>
              )}

              <button
                onClick={saveJourney}
                className="px-4 py-2 bg-[#0474C4] hover:bg-[#06457F] text-white font-bold text-xs rounded-lg transition flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                <Check className="w-4 h-4" /> Save Journey
              </button>
            </div>
          </div>

          {/* If BPMN View Tab is active, render full-featured BpmnJourneyViewer */}
          {builderTab === 'bpmn' ? (
            <div className="space-y-6">
              {/* Global Journey Attributes Block */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4 shadow-sm text-left">
                <h4 className="text-xs font-bold text-[#5379AE] font-mono uppercase tracking-wider">Journey Global Attributes</h4>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="md:col-span-2 space-y-1.5">
                    <label className="text-[10px] font-mono font-bold text-slate-500 uppercase block">
                      JOURNEY NAME <span className="text-rose-500">*</span>
                    </label>
                    <input 
                      type="text" 
                      placeholder="e.g. Wealth Management Onboarding Path"
                      value={journeyName}
                      onChange={(e) => setJourneyName(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 px-3 py-2 rounded-lg text-xs text-[#262B40] focus:outline-none focus:border-[#0474C4] transition font-bold"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono font-bold text-slate-500 uppercase block">JOURNEY STATUS</label>
                    <select
                      value={journeyStatus}
                      onChange={(e) => setJourneyStatus(e.target.value as any)}
                      className="w-full bg-slate-50 border border-slate-200 px-3 py-2 rounded-lg text-xs text-[#262B40] focus:outline-none focus:border-[#0474C4] transition font-medium"
                    >
                      <option value="Active">Active (Live routing)</option>
                      <option value="Draft">Draft (Offline composer)</option>
                      <option value="Deprecated">Deprecated</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono font-bold text-slate-500 uppercase block">DESCRIPTION</label>
                  <input 
                    type="text" 
                    placeholder="e.g. Triggers for corporate accounts registered across foreign jurisdictions..."
                    value={journeyDesc}
                    onChange={(e) => setJourneyDesc(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 px-3 py-2 rounded-lg text-xs text-[#262B40] focus:outline-none focus:border-[#0474C4] transition"
                  />
                </div>
              </div>

              {/* BPMN 2.0 Interactive Diagram Viewer */}
              <BpmnJourneyViewer
                journey={currentJourneyDraft}
                availableAgents={availableSystemAgents}
              />
            </div>
          ) : (

          /* Canvas & Sidebar Layout for Graph View */
          <div className="grid grid-cols-1 xl:grid-cols-4 gap-6 items-start">
            {/* LEFT / CENTER CANVAS */}
            <div className="xl:col-span-3 space-y-6">
              {/* Global Journey Attributes Block */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4 shadow-sm text-left">
                <h4 className="text-xs font-bold text-[#5379AE] font-mono uppercase tracking-wider">Journey Global Attributes</h4>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="md:col-span-2 space-y-1.5">
                    <label className="text-[10px] font-mono font-bold text-slate-500 uppercase block">
                      JOURNEY NAME <span className="text-rose-500">*</span>
                    </label>
                    <input 
                      type="text" 
                      placeholder="e.g. Wealth Management Onboarding Path"
                      value={journeyName}
                      onChange={(e) => setJourneyName(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 px-3 py-2 rounded-lg text-xs text-[#262B40] focus:outline-none focus:border-[#0474C4] transition font-bold"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono font-bold text-slate-500 uppercase block">JOURNEY STATUS</label>
                    <select
                      value={journeyStatus}
                      onChange={(e) => setJourneyStatus(e.target.value as any)}
                      className="w-full bg-slate-50 border border-slate-200 px-3 py-2 rounded-lg text-xs text-[#262B40] focus:outline-none focus:border-[#0474C4] transition font-medium"
                    >
                      <option value="Active">Active (Live routing)</option>
                      <option value="Draft">Draft (Offline composer)</option>
                      <option value="Deprecated">Deprecated</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono font-bold text-slate-500 uppercase block">DESCRIPTION</label>
                  <input 
                    type="text" 
                    placeholder="e.g. Triggers for corporate accounts registered across foreign jurisdictions..."
                    value={journeyDesc}
                    onChange={(e) => setJourneyDesc(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 px-3 py-2 rounded-lg text-xs text-[#262B40] focus:outline-none focus:border-[#0474C4] transition"
                  />
                </div>
              </div>

              {/* INTERACTIVE STAGE DEFINITION & WIRING CANVAS: JOURNEY GRAPH */}
              <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6 text-left relative overflow-hidden">
                {/* Canvas Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4 relative z-10">
                  <div>
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 bg-blue-50 border border-blue-200 text-[#0474C4] rounded-lg">
                        <GitBranch className="w-4 h-4" />
                      </div>
                      <h4 className="text-sm font-extrabold text-[#262B40] flex items-center gap-2">
                        Journey Graph
                        <span className="text-[10px] font-mono bg-blue-100 text-[#0474C4] border border-blue-200 px-2.5 py-0.5 rounded-full uppercase font-bold">
                          {journeyStages.length} Stage Nodes
                        </span>
                      </h4>
                    </div>
                    <p className="text-xs text-slate-500 mt-1">
                      Horizontal directed graph. Parallel stages branch below main track and converge at merge nodes. Click a node to expand.
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleOpenAddStagePrompt()}
                      className="px-3.5 py-1.5 bg-[#0474C4] hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition flex items-center gap-1.5 cursor-pointer shadow-sm"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add Stage Node
                    </button>
                  </div>
                </div>

                {/* Blank State if 0 stages */}
                {journeyStages.length === 0 ? (
                  <div className="bg-slate-50 border-2 border-dashed border-slate-300 rounded-2xl p-10 text-center space-y-4 relative z-10">
                    <div className="w-12 h-12 bg-blue-50 border border-blue-200 text-[#0474C4] rounded-2xl mx-auto flex items-center justify-center">
                      <Network className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-extrabold text-sm text-[#262B40]">Blank Graph Canvas</h4>
                      <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto leading-relaxed">
                        Your canvas is empty. Click <strong>+ Add Stage Node</strong> or select a <strong>Component Pipeline</strong> from the palette on the right.
                      </p>
                    </div>
                    <button
                      onClick={() => handleOpenAddStagePrompt()}
                      className="px-4 py-2 bg-[#0474C4] hover:bg-blue-700 text-white font-bold text-xs rounded-lg transition inline-flex items-center gap-1.5 cursor-pointer shadow-sm"
                    >
                      <Plus className="w-4 h-4" /> Add First Stage Node
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4 relative z-10">
                    {/* DRAG ACTIVE BANNER & TRACK DROP TARGET ZONES */}
                    {draggedStageId && (
                      <div className="bg-white border-2 border-blue-400 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-800 animate-fadeIn relative z-20 shadow-xl shadow-blue-500/10">
                        <div className="flex items-center gap-2">
                          <Move className="w-4 h-4 text-[#0474C4] animate-bounce shrink-0" />
                          <span className="font-extrabold text-[#262B40]">Reordering Stage Node:</span>
                          <span className="bg-blue-100 text-[#0474C4] font-mono px-2 py-0.5 rounded border border-blue-200 font-bold">
                            {journeyStages.find(s => s.id === draggedStageId)?.name || draggedStageId}
                          </span>
                          <span className="text-slate-500 text-[11px] hidden sm:inline">
                            — Drop onto highlighted connector zones below to resequence, or drop on track buttons.
                          </span>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <div 
                            onDragOver={(e) => { e.preventDefault(); setDragOverTrack('sequential'); }}
                            onDrop={(e) => handleDropOnTrackZone(e, 'sequential', 'end')}
                            className={`px-3 py-1.5 rounded-lg border text-xs font-extrabold transition flex items-center gap-1.5 cursor-pointer shadow-sm ${
                              dragOverTrack === 'sequential'
                                ? 'bg-emerald-500 text-white border-emerald-600 ring-4 ring-emerald-300 scale-105 shadow-lg shadow-emerald-500/30'
                                : 'bg-emerald-50 text-emerald-700 border-emerald-300 hover:bg-emerald-100'
                            }`}
                          >
                            <Zap className="w-3.5 h-3.5" /> Drop to Sequential Track
                          </div>
                          <div 
                            onDragOver={(e) => { e.preventDefault(); setDragOverTrack('parallel'); }}
                            onDrop={(e) => handleDropOnTrackZone(e, 'parallel', 'end')}
                            className={`px-3 py-1.5 rounded-lg border text-xs font-extrabold transition flex items-center gap-1.5 cursor-pointer shadow-sm ${
                              dragOverTrack === 'parallel'
                                ? 'bg-[#0474C4] text-white border-blue-700 ring-4 ring-blue-300 scale-105 shadow-lg shadow-blue-500/30'
                                : 'bg-blue-50 text-[#0474C4] border-blue-300 hover:bg-blue-100'
                            }`}
                          >
                            <GitBranch className="w-3.5 h-3.5" /> Drop to Parallel Track
                          </div>
                        </div>
                      </div>
                    )}

                    {/* HORIZONTAL DIRECTED GRAPH CANVAS (WHITE BACKGROUND) */}
                    <div className={`bg-white border rounded-2xl p-5 overflow-x-auto transition-all duration-200 ${
                      draggedStageId ? 'border-blue-400 ring-4 ring-blue-500/10 shadow-lg shadow-blue-500/5' : 'border-slate-200 shadow-sm'
                    }`}>
                      <div className="min-w-max flex items-center gap-0 py-4 px-2">
                        
                        {/* START / INTAKE NODE */}
                        <div className="flex flex-col items-center shrink-0 mr-1 text-center">
                          <div className="w-10 h-10 rounded-full bg-emerald-50 border-2 border-emerald-500 text-emerald-600 flex items-center justify-center font-bold text-xs shadow-md">
                            <CheckCircle className="w-4 h-4" />
                          </div>
                          <span className="text-[9px] font-mono font-bold text-emerald-700 uppercase mt-1.5 tracking-wider">
                            INTAKE
                          </span>
                        </div>

                        {/* RENDER EACH STAGE IN HORIZONTAL FLOW */}
                        {journeyStages.map((stage, idx) => {
                          const linkedOrch = orchestrations.find(o => o.id === stage.linkedPipelineId);
                          const isSimulatedActive = isSimulating && simulatedStage === idx;
                          const stageExecMode = stage.executionMode || 'sequential';
                          const isExpanded = expandedStageId === stage.id;
                          const attachedNodeIds = stage.attachedAgentIds || (linkedOrch ? linkedOrch.agentIds : ['kyc_agent', 'kyb_agent']);
                          const isParallel = stageExecMode === 'parallel';

                          const isDragged = draggedStageId === stage.id;
                          const isDragOver = dragOverStageId === stage.id && !isDragged;

                          return (
                            <React.Fragment key={stage.id || idx}>
                              {/* CONNECTOR LEADING TO THIS STAGE (WITHOUT ARROWHEADS) */}
                              <div 
                                onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); setDragOverStageId(`conn_${idx}`); }}
                                onDragEnter={(e) => { e.preventDefault(); e.stopPropagation(); setDragOverStageId(`conn_${idx}`); }}
                                onDrop={(e) => handleDropOnConnector(e, idx)}
                                className={`flex items-center shrink-0 px-2 relative transition-all duration-200 ${
                                  dragOverStageId === `conn_${idx}`
                                    ? 'bg-blue-50 border-2 border-dashed border-[#0474C4] rounded-xl px-4 py-2.5 scale-110 ring-4 ring-blue-400/30 shadow-xl shadow-blue-500/20 z-30'
                                    : draggedStageId
                                      ? 'bg-blue-50/50 border-2 border-dashed border-blue-300 rounded-xl px-2.5 py-1.5 hover:bg-blue-100 hover:border-blue-500 cursor-pointer shadow-sm'
                                      : ''
                                }`}
                                title={draggedStageId ? `Drop to place stage at position #${idx + 1}` : undefined}
                              >
                                <div className={`h-0.5 w-8 transition-colors ${
                                  isSimulatedActive ? 'bg-blue-500 animate-pulse' : dragOverStageId === `conn_${idx}` ? 'bg-[#0474C4] h-1' : 'bg-slate-300'
                                }`} />
                                
                                {dragOverStageId === `conn_${idx}` && (
                                  <span className="absolute -top-8 left-1/2 -translate-x-1/2 bg-[#0474C4] text-white font-mono text-[9px] font-extrabold px-2.5 py-0.5 rounded shadow-lg border border-blue-300 whitespace-nowrap z-30 animate-bounce">
                                    Insert Position #{idx + 1}
                                  </span>
                                )}
                              </div>

                              {/* STAGE GRAPH NODE RENDERING WITH DRAG-AND-DROP & REORDER CONTROLS */}
                              {isParallel ? (
                                /* PARALLEL FAN-OUT TOPOLOGY (FORK -> BRANCH TRACK -> MERGE) */
                                <div 
                                  draggable={true}
                                  onDragStart={(e) => handleDragStartStage(e, stage.id)}
                                  onDragEnd={handleDragEndStage}
                                  onDragOver={(e) => handleDragOverStage(e, stage.id, 'parallel')}
                                  onDragEnter={(e) => handleDragEnterStage(e, stage.id, 'parallel')}
                                  onDrop={(e) => handleDropOnStageNode(e, stage.id, dragOverTrack || 'parallel')}
                                  className={`flex flex-col shrink-0 border rounded-2xl relative transition-all duration-200 p-3 ${
                                    isExpanded
                                      ? 'border-2 border-[#0474C4] bg-sky-100 ring-4 ring-blue-400/30 shadow-xl shadow-blue-500/15'
                                      : isDragged
                                        ? 'opacity-40 border-2 border-dashed border-[#0474C4] bg-sky-100/50 scale-95'
                                        : isDragOver
                                          ? 'border-2 border-[#0474C4] ring-4 ring-blue-400/40 shadow-xl shadow-blue-500/20 scale-105 bg-sky-100'
                                          : 'border-[#A8C4EC] bg-sky-50/50 hover:border-[#0474C4] shadow-sm'
                                  }`}
                                >
                                  {/* QUICK REORDER & TRACK TOGGLE TOOLBAR */}
                                  <div className="flex items-center justify-between w-full gap-1 mb-2 border-b border-[#A8C4EC]/60 pb-1.5">
                                    <button
                                      type="button"
                                      disabled={idx === 0}
                                      onClick={(e) => requestMoveStage(idx, 'up', e)}
                                      className="px-2 py-0.5 rounded bg-white hover:bg-sky-100 text-[#262B40] border border-[#A8C4EC] disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed text-[10px] font-bold font-mono flex items-center shadow-2xs"
                                      title="Move Stage Earlier (Confirmation Prompt)"
                                    >
                                      Prev
                                    </button>

                                    <button
                                      type="button"
                                      onClick={(e) => handleToggleStageTrack(stage.id, e)}
                                      className="px-2 py-0.5 rounded text-[9px] font-mono font-extrabold bg-blue-100 text-[#0474C4] border border-blue-300 hover:bg-blue-200 transition cursor-pointer shadow-2xs"
                                      title="Click to switch to Sequential track"
                                    >
                                      🔀 Parallel
                                    </button>

                                    <button
                                      type="button"
                                      disabled={idx === journeyStages.length - 1}
                                      onClick={(e) => requestMoveStage(idx, 'down', e)}
                                      className="px-2 py-0.5 rounded bg-white hover:bg-sky-100 text-[#262B40] border border-[#A8C4EC] disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed text-[10px] font-bold font-mono flex items-center shadow-2xs"
                                      title="Move Stage Later (Confirmation Prompt)"
                                    >
                                      Next
                                    </button>
                                  </div>

                                  <div className="flex items-center gap-3">
                                    {/* DRAG HANDLE */}
                                    <div 
                                      className="p-1 text-[#5379AE] hover:text-[#0474C4] cursor-grab active:cursor-grabbing transition shrink-0"
                                      title="Drag stage node to reorder sequence or move tracks"
                                    >
                                      <GripVertical className="w-4 h-4" />
                                    </div>

                                    {/* FORK NODE */}
                                    <div className="flex flex-col items-center shrink-0 text-center">
                                      <div 
                                        className="w-9 h-9 rounded-full bg-blue-50 border-2 border-[#0474C4] text-[#0474C4] flex items-center justify-center font-bold shadow-sm cursor-help"
                                        title="Fork Node: Parallel Fan-Out Split"
                                      >
                                        <GitBranch className="w-4 h-4" />
                                      </div>
                                      <span className="text-[8px] font-mono font-extrabold text-[#0474C4] uppercase mt-1">
                                        FORK
                                      </span>
                                    </div>

                                    {/* BRANCH CONNECTOR SVG */}
                                    <svg className="w-10 h-16 shrink-0 text-[#0474C4] overflow-visible" viewBox="0 0 40 60">
                                      <path 
                                        d="M 0 30 C 20 30, 20 50, 40 50" 
                                        fill="none" 
                                        stroke="currentColor" 
                                        strokeWidth="2.5" 
                                        strokeDasharray={isSimulatedActive ? "4 2" : "none"}
                                        className={isSimulatedActive ? "animate-pulse" : ""}
                                      />
                                      <path 
                                        d="M 0 30 L 40 30" 
                                        fill="none" 
                                        stroke="currentColor" 
                                        strokeWidth="1.5" 
                                        strokeDasharray="2 2"
                                        opacity="0.4"
                                      />
                                    </svg>

                                    {/* PARALLEL TRACK STAGE CIRCULAR NODE (HIGHLIGHTED WHEN SELECTED) */}
                                    <div 
                                      onClick={() => setExpandedStageId(isExpanded ? null : stage.id)}
                                      className="flex flex-col items-center cursor-pointer group transition-transform duration-200 hover:scale-105 translate-y-3"
                                    >
                                      <div className={`w-14 h-14 rounded-full flex items-center justify-center transition-all duration-200 relative shadow-md ${
                                        isSimulatedActive
                                          ? 'bg-[#0474C4] text-white ring-4 ring-blue-300 border-2 border-blue-200 animate-pulse'
                                          : isExpanded
                                            ? 'bg-[#0474C4] text-white ring-4 ring-blue-400/40 border-2 border-white shadow-xl scale-110'
                                            : 'bg-white text-[#0474C4] border-2 border-[#0474C4] hover:bg-blue-50'
                                      }`}>
                                        <GitBranch className={`w-6 h-6 ${isExpanded ? 'text-white' : 'text-[#0474C4]'} group-hover:rotate-12 transition`} />
                                        <span className={`absolute -top-1 -right-1 font-mono text-[9px] font-bold px-1.5 py-0.5 rounded-full border shadow-xs ${
                                          isExpanded ? 'bg-[#06457F] text-white border-blue-300' : 'bg-[#0474C4] text-white border-blue-200'
                                        }`}>
                                          S{idx + 1}
                                        </span>
                                      </div>

                                      <div className="mt-2 text-center max-w-[130px]">
                                        <span className={`text-xs block truncate transition ${
                                          isExpanded ? 'font-black text-[#0474C4] underline underline-offset-2' : 'font-bold text-[#262B40] group-hover:text-[#0474C4]'
                                        }`}>
                                          {stage.name}
                                        </span>
                                        <div className="flex items-center justify-center gap-1 mt-0.5">
                                          <span className="text-[8px] font-mono font-bold bg-blue-100 text-[#0474C4] border border-blue-200 px-1.5 py-0.2 rounded uppercase">
                                            🔀 Parallel
                                          </span>
                                          <span className="text-[8px] font-mono text-slate-500 bg-slate-100 px-1 rounded border border-slate-200">
                                            {attachedNodeIds.length} Workers
                                          </span>
                                        </div>
                                      </div>
                                    </div>

                                    {/* MERGE CONNECTOR SVG */}
                                    <svg className="w-10 h-16 shrink-0 text-[#0474C4] overflow-visible" viewBox="0 0 40 60">
                                      <path 
                                        d="M 0 50 C 20 50, 20 30, 40 30" 
                                        fill="none" 
                                        stroke="currentColor" 
                                        strokeWidth="2.5" 
                                        strokeDasharray={isSimulatedActive ? "4 2" : "none"}
                                        className={isSimulatedActive ? "animate-pulse" : ""}
                                      />
                                      <path 
                                        d="M 0 30 L 40 30" 
                                        fill="none" 
                                        stroke="currentColor" 
                                        strokeWidth="1.5" 
                                        strokeDasharray="2 2"
                                        opacity="0.4"
                                      />
                                    </svg>

                                    {/* MERGE NODE */}
                                    <div className="flex flex-col items-center shrink-0 text-center">
                                      <div 
                                        className="w-9 h-9 rounded-full bg-blue-50 border-2 border-[#0474C4] text-[#0474C4] flex items-center justify-center font-bold shadow-sm cursor-help"
                                        title="Merge Node: Parallel Fan-In Sync"
                                      >
                                        <GitMerge className="w-4 h-4" />
                                      </div>
                                      <span className="text-[8px] font-mono font-extrabold text-[#0474C4] uppercase mt-1">
                                        MERGE
                                      </span>
                                    </div>
                                  </div>
                                </div>
                              ) : (
                                /* SEQUENTIAL MAINLINE STAGE CIRCULAR NODE (HIGHLIGHTED WHEN SELECTED) */
                                <div 
                                  draggable={true}
                                  onDragStart={(e) => handleDragStartStage(e, stage.id)}
                                  onDragEnd={handleDragEndStage}
                                  onDragOver={(e) => handleDragOverStage(e, stage.id, 'sequential')}
                                  onDragEnter={(e) => handleDragEnterStage(e, stage.id, 'sequential')}
                                  onDrop={(e) => handleDropOnStageNode(e, stage.id, dragOverTrack || 'sequential')}
                                  className={`flex flex-col items-center cursor-pointer group shrink-0 transition-all duration-200 p-2.5 rounded-2xl border ${
                                    isExpanded
                                      ? 'border-2 border-[#0474C4] bg-blue-50/70 ring-4 ring-blue-400/30 shadow-xl shadow-blue-500/15'
                                      : isDragged
                                        ? 'opacity-40 border-2 border-dashed border-blue-400 bg-blue-50/50 scale-95'
                                        : isDragOver
                                          ? 'border-2 border-blue-500 ring-4 ring-blue-400/40 shadow-xl shadow-blue-500/20 scale-105 bg-blue-50'
                                          : 'border-slate-200 bg-white hover:border-[#0474C4]/60 hover:shadow-md'
                                  }`}
                                >
                                  {/* QUICK REORDER & TRACK TOGGLE TOOLBAR */}
                                  <div className="flex items-center justify-between w-full gap-1 mb-2 border-b border-slate-100 pb-1.5">
                                    <button
                                      type="button"
                                      disabled={idx === 0}
                                      onClick={(e) => requestMoveStage(idx, 'up', e)}
                                      className="px-2 py-0.5 rounded bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed text-[10px] font-bold font-mono flex items-center shadow-2xs"
                                      title="Move Stage Earlier (Confirmation Prompt)"
                                    >
                                      Prev
                                    </button>

                                    <button
                                      type="button"
                                      onClick={(e) => handleToggleStageTrack(stage.id, e)}
                                      className="px-2 py-0.5 rounded text-[9px] font-mono font-extrabold bg-emerald-50 text-emerald-800 border border-emerald-300 hover:bg-emerald-100 transition cursor-pointer shadow-2xs"
                                      title="Click to switch to Parallel track"
                                    >
                                      ⚡ Sequential
                                    </button>

                                    <button
                                      type="button"
                                      disabled={idx === journeyStages.length - 1}
                                      onClick={(e) => requestMoveStage(idx, 'down', e)}
                                      className="px-2 py-0.5 rounded bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed text-[10px] font-bold font-mono flex items-center shadow-2xs"
                                      title="Move Stage Later (Confirmation Prompt)"
                                    >
                                      Next
                                    </button>
                                  </div>

                                  <div className="flex flex-col items-center w-full">
                                    {/* DRAG HANDLE */}
                                    <div 
                                      className="p-1 text-slate-400 hover:text-slate-700 cursor-grab active:cursor-grabbing transition mb-1 shrink-0"
                                      title="Drag stage node to reorder sequence or move tracks"
                                    >
                                      <GripVertical className="w-4 h-4" />
                                    </div>

                                    <div 
                                      onClick={() => setExpandedStageId(isExpanded ? null : stage.id)}
                                      className="flex flex-col items-center"
                                    >
                                      <div className={`w-14 h-14 rounded-full flex items-center justify-center transition-all duration-200 relative shadow-md ${
                                        isSimulatedActive
                                          ? 'bg-[#0474C4] text-white ring-4 ring-blue-300 border-2 border-blue-200 animate-pulse'
                                          : isExpanded
                                            ? 'bg-[#0474C4] text-white ring-4 ring-blue-400/40 border-2 border-white shadow-xl scale-110'
                                            : 'bg-white text-slate-800 border-2 border-slate-300 group-hover:border-[#0474C4] group-hover:bg-blue-50/60'
                                      }`}>
                                        <Zap className={`w-6 h-6 ${isExpanded ? 'text-white' : 'text-emerald-600'} group-hover:scale-110 transition`} />
                                        <span className={`absolute -top-1 -right-1 font-mono text-[9px] font-bold px-1.5 py-0.5 rounded-full border shadow-xs ${
                                          isExpanded ? 'bg-[#06457F] text-white border-blue-300' : 'bg-[#0474C4] text-white border-blue-200'
                                        }`}>
                                          S{idx + 1}
                                        </span>
                                      </div>

                                      <div className="mt-2 text-center max-w-[130px]">
                                        <span className={`text-xs block truncate transition ${
                                          isExpanded ? 'font-black text-[#0474C4] underline underline-offset-2' : 'font-bold text-[#262B40] group-hover:text-[#0474C4]'
                                        }`}>
                                          {stage.name}
                                        </span>
                                        <div className="flex items-center justify-center gap-1 mt-0.5">
                                          <span className="text-[8px] font-mono font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 px-1.5 py-0.2 rounded uppercase">
                                            ⚡ Sequential
                                          </span>
                                          <span className="text-[8px] font-mono text-slate-500 bg-slate-100 px-1 rounded border border-slate-200">
                                            {attachedNodeIds.length} Nodes
                                          </span>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              )}
                            </React.Fragment>
                          );
                        })}

                        {/* END / SLA COMPLETE MARKER CONNECTOR (WITHOUT ARROWHEAD) */}
                        <div 
                          onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); setDragOverStageId(`conn_end`); }}
                          onDragEnter={(e) => { e.preventDefault(); e.stopPropagation(); setDragOverStageId(`conn_end`); }}
                          onDrop={(e) => handleDropOnConnector(e, journeyStages.length)}
                          className={`flex items-center shrink-0 px-2 relative transition-all duration-200 ${
                            dragOverStageId === `conn_end`
                              ? 'bg-blue-50 border-2 border-dashed border-[#0474C4] rounded-xl px-4 py-2.5 scale-110 ring-4 ring-blue-400/30 shadow-xl shadow-blue-500/20 z-30'
                              : draggedStageId
                                ? 'bg-blue-50/50 border-2 border-dashed border-blue-300 rounded-xl px-2.5 py-1.5 hover:bg-blue-100 hover:border-blue-500 cursor-pointer shadow-sm'
                                : ''
                          }`}
                          title={draggedStageId ? 'Drop to place stage at the end of the sequence' : undefined}
                        >
                          <div className={`h-0.5 w-8 ${dragOverStageId === `conn_end` ? 'bg-[#0474C4] h-1' : 'bg-slate-300'}`} />
                          
                          {dragOverStageId === `conn_end` && (
                            <span className="absolute -top-8 left-1/2 -translate-x-1/2 bg-[#0474C4] text-white font-mono text-[9px] font-extrabold px-2.5 py-0.5 rounded shadow-lg border border-blue-300 whitespace-nowrap z-30 animate-bounce">
                              Insert at End
                            </span>
                          )}
                        </div>

                        <div className="flex flex-col items-center shrink-0 text-center">
                          <div className="w-10 h-10 rounded-full bg-blue-50 border-2 border-blue-500 text-[#0474C4] flex items-center justify-center font-bold text-xs shadow-md">
                            <Check className="w-5 h-5" />
                          </div>
                          <span className="text-[9px] font-mono font-bold text-[#0474C4] uppercase mt-1.5 tracking-wider">
                            COMPLETE
                          </span>
                        </div>

                      </div>
                    </div>

                    {/* EXPANDED STAGE CONFIGURATION INSPECTOR PANEL */}
                    <AnimatePresence mode="wait">
                      {expandedStageId && (() => {
                        const stageIdx = journeyStages.findIndex(s => s.id === expandedStageId);
                        const stage = journeyStages[stageIdx];
                        if (!stage) return null;

                        const linkedOrch = orchestrations.find(o => o.id === stage.linkedPipelineId);
                        const stageExecMode = stage.executionMode || 'sequential';
                        const attachedNodeIds = stage.attachedAgentIds || (linkedOrch ? linkedOrch.agentIds : ['kyc_agent', 'kyb_agent']);

                        return (
                          <motion.div
                            key={stage.id}
                            initial={{ opacity: 0, y: -8 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -8 }}
                            className="bg-white border-2 border-blue-500/30 rounded-2xl p-5 shadow-2xl space-y-5 relative text-left"
                          >
                            {/* Panel Header */}
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-150 pb-3">
                              <div className="flex items-center gap-2.5 flex-1">
                                <span className="text-[10px] font-mono font-bold bg-blue-50 text-[#0474C4] border border-blue-200 px-2.5 py-1 rounded uppercase shrink-0">
                                  STAGE {stageIdx + 1} CONFIGURATION
                                </span>

                                {/* Execution Mode Switcher Button */}
                                <button
                                  type="button"
                                  onClick={() => {
                                    const nextMode = stageExecMode === 'sequential' ? 'parallel' : 'sequential';
                                    handleUpdateStage(stage.id, { executionMode: nextMode });
                                  }}
                                  className={`text-[10px] font-mono font-bold px-3 py-1.5 rounded-lg border flex items-center gap-1.5 transition cursor-pointer shrink-0 shadow-xs ${
                                    stageExecMode === 'parallel'
                                      ? 'bg-blue-50 text-blue-800 border-blue-300 hover:bg-blue-100'
                                      : 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                                  }`}
                                  title="Click to toggle Sequential Chain vs Parallel Fan-Out mode on Journey Graph"
                                >
                                  {stageExecMode === 'parallel' ? (
                                    <>
                                      <GitBranch className="w-3.5 h-3.5 text-[#0474C4]" />
                                      🔀 Parallel Fan-Out (Fork/Merge)
                                    </>
                                  ) : (
                                    <>
                                      <Zap className="w-3.5 h-3.5 text-emerald-600" />
                                      ⚡ Sequential Chain
                                    </>
                                  )}
                                </button>

                                <input
                                  type="text"
                                  value={stage.name}
                                  onChange={(e) => handleUpdateStage(stage.id, { name: e.target.value })}
                                  placeholder={`Stage ${stageIdx + 1} Name`}
                                  className="w-full bg-slate-50 border border-slate-200 focus:border-[#0474C4] px-3 py-1.5 rounded-lg font-bold text-sm text-[#262B40] focus:outline-none transition"
                                />
                              </div>

                              <div className="flex items-center gap-1 shrink-0">
                                <button
                                  type="button"
                                  onClick={() => requestMoveStage(stageIdx, 'up')}
                                  disabled={stageIdx === 0}
                                  className="p-1.5 hover:bg-slate-100 rounded text-slate-500 disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed"
                                  title="Move Left in Sequence"
                                >
                                  <ArrowLeft className="w-4 h-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => requestMoveStage(stageIdx, 'down')}
                                  disabled={stageIdx === journeyStages.length - 1}
                                  className="p-1.5 hover:bg-slate-100 rounded text-slate-500 disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed"
                                  title="Move Right in Sequence"
                                >
                                  <ArrowRight className="w-4 h-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    handleRemoveStage(stage.id);
                                    setExpandedStageId(null);
                                  }}
                                  className="p-1.5 hover:bg-rose-50 rounded text-slate-400 hover:text-rose-600 transition cursor-pointer ml-1"
                                  title="Delete Stage Node"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setExpandedStageId(null)}
                                  className="p-1.5 hover:bg-slate-100 rounded text-slate-400 hover:text-slate-600 transition cursor-pointer ml-1"
                                  title="Close Inspector"
                                >
                                  <X className="w-4 h-4" />
                                </button>
                              </div>
                            </div>

                            {/* Configuration Form Controls */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div className="space-y-1.5">
                                <label className="text-[10px] font-mono font-bold text-slate-500 uppercase block flex items-center justify-between">
                                  <span>ASSOCIATED PROCESS FLOW</span>
                                  <span className="text-[9px] font-mono text-[#0474C4] font-semibold">Agent Studio Pipeline</span>
                                </label>
                                <div className="w-full bg-slate-50 border border-slate-200 px-3.5 py-2 rounded-lg flex items-center justify-between">
                                  <div className="flex items-center gap-2 min-w-0">
                                    <Bot className="w-4 h-4 text-[#0474C4] shrink-0" />
                                    <span className="text-xs font-extrabold text-[#262B40] truncate">
                                      {linkedOrch?.name || 'Standard KYB & Compliance Verification Flow'}
                                    </span>
                                  </div>
                                  <span className="text-[8px] font-mono font-bold bg-indigo-50 text-indigo-700 border border-indigo-200 px-2 py-0.5 rounded uppercase shrink-0 ml-2">
                                    {(linkedOrch?.strategy || 'HYBRID').toUpperCase()}
                                  </span>
                                </div>
                              </div>

                              <div className="space-y-1.5">
                                <label className="text-[10px] font-mono font-bold text-slate-500 uppercase block">
                                  TRANSITION EXECUTION RULE
                                </label>
                                <div className="w-full bg-amber-50/70 border border-amber-200 px-3.5 py-2 rounded-lg flex items-center justify-between">
                                  <div className="flex items-center gap-2 min-w-0">
                                    <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0" />
                                    <span className="text-xs font-bold text-amber-900 truncate">
                                      Human-in-the-Loop (HITL) Gate
                                    </span>
                                  </div>
                                  <span className="text-[8px] font-mono font-bold bg-amber-100 text-amber-800 border border-amber-300 px-2 py-0.5 rounded uppercase shrink-0 ml-2">
                                    Always Active
                                  </span>
                                </div>
                              </div>
                            </div>

                            {/* Wired Stage Nodes & Parallel Branches Breakdown */}
                            <div className="space-y-3">
                              <div className="bg-[#F0F4FA] p-3.5 rounded-xl border border-[#A8C4EC]/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                <div className="space-y-1.5 flex-1 min-w-0">
                                  <div className="flex items-center gap-2">
                                    <div className="p-1.5 bg-[#0474C4] text-white rounded-lg">
                                      <Bot className="w-4 h-4" />
                                    </div>
                                    <div>
                                      <span className="text-[10px] font-mono text-[#0474C4] font-bold uppercase tracking-wider block">
                                        WIRED WORKER NODES ({attachedNodeIds.length})
                                      </span>
                                      <span className="text-xs font-bold text-[#262B40] block truncate">
                                        {linkedOrch ? linkedOrch.name : 'Custom Pipeline'}
                                      </span>
                                    </div>
                                  </div>

                                  <div className="flex flex-wrap items-center gap-1.5 pt-1">
                                    {attachedNodeIds.map((agId, agIdx) => {
                                      const agObj = allAgentsMap.get(agId);
                                      const isSuper = agObj?.agentClass === 'super';
                                      return (
                                        <span 
                                          key={`${agId}_${agIdx}`} 
                                          className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border flex items-center gap-1 group/badge ${
                                            isSuper 
                                              ? 'bg-indigo-50 text-indigo-700 border-indigo-200' 
                                              : 'bg-white text-slate-700 border-slate-200'
                                          }`}
                                        >
                                          <Bot className="w-3 h-3 text-[#0474C4]" />
                                          <span>{agObj ? agObj.name : agId}</span>
                                          <button
                                            type="button"
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              const updated = attachedNodeIds.filter((_, idx) => idx !== agIdx);
                                              handleUpdateStage(stage.id, { attachedAgentIds: updated });
                                            }}
                                            className="text-slate-400 hover:text-rose-600 transition cursor-pointer ml-0.5 p-0.5 rounded hover:bg-slate-100"
                                            title="Detach node from stage"
                                          >
                                            <X className="w-2.5 h-2.5" />
                                          </button>
                                        </span>
                                      );
                                    })}
                                    
                                    {/* Inline Quick Attach Node Dropdown */}
                                    <div className="relative inline-block">
                                      <select
                                        value=""
                                        onChange={(e) => {
                                          const agIdToAttach = e.target.value;
                                          if (!agIdToAttach) return;
                                          if (!attachedNodeIds.includes(agIdToAttach)) {
                                            handleUpdateStage(stage.id, { attachedAgentIds: [...attachedNodeIds, agIdToAttach] });
                                          }
                                        }}
                                        className="text-[10px] font-mono font-bold bg-blue-50 text-[#0474C4] border border-blue-200 hover:bg-blue-100 px-2 py-0.5 rounded transition cursor-pointer focus:outline-none"
                                      >
                                        <option value="">+ Add Node...</option>
                                        {availableSystemAgents
                                          .filter(ag => !attachedNodeIds.includes(ag.id))
                                          .map(ag => (
                                            <option key={ag.id} value={ag.id}>
                                              {ag.name} ({ag.nodeType || ag.agentClass})
                                            </option>
                                          ))}
                                      </select>
                                    </div>
                                  </div>
                                </div>

                                <button
                                  type="button"
                                  onClick={() => openStageDetailModal(stageIdx)}
                                  className="px-3.5 py-2 bg-[#0474C4] hover:bg-[#06457F] text-white text-xs font-bold rounded-lg transition shadow-xs flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                                >
                                  <Settings className="w-3.5 h-3.5" />
                                  Configure Attached Nodes
                                </button>
                              </div>

                              {/* PARALLEL FAN-OUT BRANCH BREAKDOWN DISPLAY */}
                              {(stageExecMode === 'parallel' || (stage.pipelines && stage.pipelines.length > 1)) && (
                                <div className="bg-blue-50/70 border border-blue-200/80 p-3.5 rounded-xl space-y-2.5">
                                  <div className="flex items-center justify-between border-b border-blue-200/60 pb-1.5">
                                    <span className="text-[10px] font-mono font-extrabold text-[#0474C4] uppercase tracking-wider flex items-center gap-1.5">
                                      <GitBranch className="w-3.5 h-3.5 text-[#0474C4]" />
                                      Parallel Branch Architecture (Fork ➔ Concurrent Exec ➔ Fan-In Merge)
                                    </span>
                                    <span className="text-[9px] font-mono font-bold px-2 py-0.5 bg-blue-200 text-blue-900 rounded">
                                      {stage.pipelines?.length || 2} Parallel Tracks
                                    </span>
                                  </div>

                                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                                    {/* Branch A */}
                                    <div className="bg-white p-2.5 rounded-lg border border-blue-200 shadow-2xs space-y-1">
                                      <div className="flex items-center justify-between">
                                        <span className="text-[9px] font-mono font-extrabold text-[#0474C4] bg-blue-100 px-1.5 py-0.5 rounded">
                                          BRANCH A
                                        </span>
                                        <span className="text-[8px] font-mono text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200">
                                          ● Concurrent
                                        </span>
                                      </div>
                                      <h5 className="text-xs font-bold text-slate-800">
                                        {stage.pipelines?.[0] || 'P-10: Sanctions & PEP Screening Refresh'}
                                      </h5>
                                      <p className="text-[10px] font-mono text-slate-500 flex items-center gap-1">
                                        <Bot className="w-3 h-3 text-[#0474C4] shrink-0" />
                                        Worker Node: {attachedNodeIds[0] ? (allAgentsMap.get(attachedNodeIds[0])?.name || attachedNodeIds[0]) : 'sanctions_screening_agent'}
                                      </p>
                                    </div>

                                    {/* Branch B */}
                                    <div className="bg-white p-2.5 rounded-lg border border-blue-200 shadow-2xs space-y-1">
                                      <div className="flex items-center justify-between">
                                        <span className="text-[9px] font-mono font-extrabold text-[#0474C4] bg-blue-100 px-1.5 py-0.5 rounded">
                                          BRANCH B
                                        </span>
                                        <span className="text-[8px] font-mono text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200">
                                          ● Concurrent
                                        </span>
                                      </div>
                                      <h5 className="text-xs font-bold text-slate-800">
                                        {stage.pipelines?.[1] || 'P-11: Adverse Media & Watchlist Refresh'}
                                      </h5>
                                      <p className="text-[10px] font-mono text-slate-500 flex items-center gap-1">
                                        <Bot className="w-3 h-3 text-[#0474C4] shrink-0" />
                                        Worker Node: {attachedNodeIds[1] ? (allAgentsMap.get(attachedNodeIds[1])?.name || attachedNodeIds[1]) : 'adverse_media_agent'}
                                      </p>
                                    </div>
                                  </div>

                                  {/* Merge / Fan-In Gate Banner */}
                                  <div className="bg-white/80 border border-blue-200/80 p-2 rounded-lg flex items-center justify-between text-[10px] font-mono text-blue-900">
                                    <div className="flex items-center gap-1.5">
                                      <GitMerge className="w-3.5 h-3.5 text-[#0474C4] shrink-0" />
                                      <span><strong>Fan-In Join Gate:</strong> Branch A + Branch B outputs merge at Stage {stageIdx + 1} Risk Threshold Evaluation</span>
                                    </div>
                                    <span className="text-[9px] font-bold text-[#0474C4] bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                                      Advances to Stage {stageIdx + 2}
                                    </span>
                                  </div>
                                </div>
                              )}
                            </div>

                            {/* Stage Handoff Summary & Trigger/Output Specs */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                              <div className="space-y-1">
                                <label className="text-[10px] font-mono font-bold text-slate-500 uppercase block">
                                  TRIGGER CONDITION
                                </label>
                                <input
                                  type="text"
                                  value={stage.trigger || ''}
                                  onChange={(e) => handleUpdateStage(stage.id, { trigger: e.target.value })}
                                  placeholder="e.g. RM creates new lead / SCREENING_COMPLETE event"
                                  className="w-full bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg text-xs text-[#262B40] focus:outline-none focus:border-[#0474C4] transition"
                                />
                              </div>

                              <div className="space-y-1">
                                <label className="text-[10px] font-mono font-bold text-slate-500 uppercase block">
                                  EXPECTED OUTPUT / ARTIFACTS
                                </label>
                                <input
                                  type="text"
                                  value={stage.output || ''}
                                  onChange={(e) => handleUpdateStage(stage.id, { output: e.target.value })}
                                  placeholder="e.g. Verified entity data, Risk score narrative"
                                  className="w-full bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg text-xs text-[#262B40] focus:outline-none focus:border-[#0474C4] transition"
                                />
                              </div>

                              <div className="space-y-2 md:col-span-2 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                                <div className="flex flex-wrap items-center justify-between gap-2">
                                  <div className="flex items-center gap-1.5">
                                    <FileText className="w-3.5 h-3.5 text-[#0474C4]" />
                                    <label className="text-[10px] font-mono font-bold text-slate-700 uppercase block">
                                      STAGE HANDOFF SUMMARY & OPERATIONAL NOTES
                                    </label>
                                  </div>
                                  <div className="flex items-center gap-1.5">
                                    <button
                                      type="button"
                                      onClick={() => handleGenerateAINote(stage.id)}
                                      className="text-[10px] font-bold bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 px-2 py-1 rounded flex items-center gap-1 cursor-pointer transition shadow-2xs"
                                      title="Generate AI rationale and audit note"
                                    >
                                      <Sparkles className="w-3 h-3 text-indigo-600" /> AI Note
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const note = prompt("Enter operational audit note / RM comment to append:");
                                        if (note) handleAppendStageNote(stage.id, note);
                                      }}
                                      className="text-[10px] font-bold bg-blue-50 hover:bg-blue-100 text-[#0474C4] border border-blue-200 px-2 py-1 rounded flex items-center gap-1 cursor-pointer transition shadow-2xs"
                                      title="Append a timestamped operational note"
                                    >
                                      <Plus className="w-3 h-3" /> Add Note
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setSaveToast(`✅ Saved Stage ${stageIdx + 1} notes`);
                                        setTimeout(() => setSaveToast(null), 2500);
                                      }}
                                      className="text-[10px] font-bold bg-[#0474C4] hover:bg-[#06457F] text-white px-2.5 py-1 rounded flex items-center gap-1 cursor-pointer transition shadow-2xs"
                                    >
                                      <Check className="w-3 h-3" /> Save Notes
                                    </button>
                                  </div>
                                </div>
                                <textarea
                                  rows={2}
                                  value={stage.description || ''}
                                  onChange={(e) => handleUpdateStage(stage.id, { description: e.target.value })}
                                  placeholder="Describe what happens during this stage, record compliance sign-offs, RM notes, or handoff parameters..."
                                  className="w-full bg-white border border-slate-200 px-3 py-2 rounded-lg text-xs text-[#262B40] focus:outline-none focus:border-[#0474C4] transition resize-none leading-relaxed"
                                />
                                {/* Quick Note Chips */}
                                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                                  <span className="text-[9px] font-mono font-bold text-slate-400">Quick Insert:</span>
                                  {[
                                    '✅ KYC/KYB Check Passed',
                                    '⚠️ Manual EDD Gate Required',
                                    '📋 Director Sign-off Pending',
                                    '🛡️ Policy Exception Approved'
                                  ].map((chip, chipIdx) => (
                                    <button
                                      key={chipIdx}
                                      type="button"
                                      onClick={() => {
                                        const current = stage.description || '';
                                        const updated = current ? `${current} | ${chip}` : chip;
                                        handleUpdateStage(stage.id, { description: updated });
                                        setSaveToast(`✅ Inserted "${chip}"`);
                                        setTimeout(() => setSaveToast(null), 2000);
                                      }}
                                      className="text-[9px] font-mono bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 px-2 py-0.5 rounded transition cursor-pointer"
                                    >
                                      {chip}
                                    </button>
                                  ))}
                                </div>
                              </div>
                            </div>
                          </motion.div>
                        );
                      })()}
                    </AnimatePresence>
                  </div>
                )}

                {/* BOTTOM FLOATING DRY-RUN LOG CONSOLE */}
                {isSimulating && (
                  <div className="border border-slate-200 bg-white p-4 rounded-xl space-y-2 mt-6 shadow-sm">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-1.5">
                      <span className="text-[10px] font-mono font-bold text-[#0474C4] uppercase tracking-wider flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-[#0474C4] animate-pulse" /> Journey Lifecycle Traversal Console
                      </span>
                      <button 
                        onClick={handleStopSimulation}
                        className="text-[9px] font-mono text-slate-500 hover:text-[#262B40] uppercase font-bold cursor-pointer"
                      >
                        Abort
                      </button>
                    </div>
                    <div className="max-h-36 overflow-y-auto space-y-1 font-mono text-[10px] text-[#262B40] bg-slate-50 border border-slate-200 leading-relaxed p-3 rounded-lg">
                      {simulatedLogs.map((log, idx) => (
                        <div key={idx} className="flex items-start gap-1">
                          <span className="text-slate-400 shrink-0">[{idx+1}]</span>
                          <span className={`${log.includes('🎉') ? 'text-emerald-600 font-bold' : log.includes('🚀') ? 'text-[#0474C4] font-bold' : 'text-slate-700'}`}>{log}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* RIGHT SIDEBAR: AGENT STUDIO COMPONENT PIPELINES PALETTE */}
            <div className="space-y-6 text-left">
              <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4 shadow-sm">
                <div className="border-b border-slate-150 pb-3">
                  <span className="text-[9px] font-mono font-bold text-[#0474C4] uppercase tracking-wider block">
                    AGENT STUDIO PALETTE
                  </span>
                  <h4 className="font-extrabold text-sm text-[#262B40] mt-0.5">
                    Component Pipelines
                  </h4>
                  <p className="text-[11px] text-[#5379AE] mt-1">
                    Multi-agent topologies built in Agent Studio available for journey stage attachment.
                  </p>
                </div>

                <div className="space-y-3">
                  {orchestrations.map(orch => (
                    <div 
                      key={orch.id}
                      className="p-3.5 bg-slate-50 border border-slate-200 hover:border-[#0474C4]/50 rounded-xl space-y-2.5 transition duration-150"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-[#262B40] flex items-center gap-1.5">
                          <Bot className="w-3.5 h-3.5 text-[#0474C4]" />
                          {orch.name}
                        </span>
                        <span className="text-[8px] font-mono font-bold bg-blue-50 text-[#0474C4] border border-blue-200 px-2 py-0.5 rounded uppercase">
                          {(orch.strategy || 'HYBRID').toUpperCase()}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-1">
                        {orch.agentIds.map((agId, agIdx) => {
                          const ag = agents.find(a => a.id === agId);
                          return (
                            <span key={`${agId}_${agIdx}`} className="px-1.5 py-0.5 bg-white border border-slate-200 rounded text-[9px] font-mono text-slate-600">
                              {ag ? ag.name : agId}
                            </span>
                          );
                        })}
                      </div>

                      <div className="flex items-center gap-1.5 pt-1">
                        <button
                          type="button"
                          onClick={() => handleDirectAttachPipelineAsStage(orch.id)}
                          className="flex-1 py-1.5 bg-[#0474C4] hover:bg-[#06457F] text-white text-[10px] font-bold rounded-lg transition text-center flex items-center justify-center gap-1 cursor-pointer shadow-2xs"
                          title="Instantly attach this pipeline as a new stage node on the canvas"
                        >
                          <Plus className="w-3 h-3" /> Attach as Stage
                        </button>

                        <button
                          type="button"
                          onClick={() => handleOpenAddStagePrompt(orch.id)}
                          className="p-1.5 bg-white border border-slate-200 hover:border-slate-300 text-slate-600 hover:text-[#0474C4] rounded-lg transition cursor-pointer"
                          title="Configure stage template before attaching"
                        >
                          <SlidersHorizontal className="w-3.5 h-3.5" />
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            if (onNavigateToStudio) {
                              onNavigateToStudio(orch.id);
                            }
                          }}
                          className="p-1.5 bg-white border border-slate-200 hover:border-slate-300 text-slate-600 rounded-lg transition cursor-pointer"
                          title="Open Component Pipeline in Agent Studio"
                        >
                          <Settings className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
          )}
        </div>
        );
      })()}

      {/* DETAILED STAGE CONFIGURATION & WIRED AGENT NODES MODAL */}
      {editingStageIndex !== null && editingStage && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50 shrink-0">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0474C4] text-white rounded-xl shadow-xs">
                  <Sliders className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-[#262B40]">
                    Stage {editingStageIndex + 1} Details & Node Manager
                  </h3>
                  <p className="text-xs text-[#5379AE] mt-0.5">
                    Configure execution topology, transition rules, and attach/detach Agent Studio pipeline nodes.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setEditingStageIndex(null);
                  setEditingStage(null);
                }}
                className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 rounded-xl transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Scrollable Content */}
            <div className="p-6 overflow-y-auto space-y-6 text-left flex-1">
              {/* Stage General Settings Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div className="space-y-1.5 md:col-span-2">
                  <label className="text-[10px] font-mono font-bold text-slate-500 uppercase block">
                    STAGE TITLE
                  </label>
                  <input
                    type="text"
                    value={editingStage.name}
                    onChange={(e) => setEditingStage({ ...editingStage, name: e.target.value })}
                    className="w-full bg-white border border-slate-200 focus:border-[#0474C4] px-3 py-2 rounded-lg font-bold text-xs text-[#262B40] focus:outline-none transition"
                  />
                </div>

                {/* Stage Execution Topology Toggle */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono font-bold text-slate-500 uppercase block">
                    STAGE EXECUTION TOPOLOGY
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setEditingStage({ ...editingStage, executionMode: 'sequential' })}
                      className={`p-2.5 rounded-lg border text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer ${
                        editingStage.executionMode === 'sequential' || !editingStage.executionMode
                          ? 'bg-emerald-50 border-emerald-500 text-emerald-800 shadow-2xs'
                          : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      <Zap className="w-4 h-4 text-emerald-600" />
                      Sequential Chain
                    </button>

                    <button
                      type="button"
                      onClick={() => setEditingStage({ ...editingStage, executionMode: 'parallel' })}
                      className={`p-2.5 rounded-lg border text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer ${
                        editingStage.executionMode === 'parallel'
                          ? 'bg-blue-50 border-[#0474C4] text-blue-900 shadow-2xs'
                          : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      <GitBranch className="w-4 h-4 text-[#0474C4]" />
                      Parallel Fan-Out
                    </button>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono font-bold text-slate-500 uppercase block">
                    TRANSITION RULE
                  </label>
                  <div className="w-full bg-amber-50/70 border border-amber-200 px-3.5 py-2.5 rounded-lg flex items-center justify-between">
                    <div className="flex items-center gap-2 min-w-0">
                      <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0" />
                      <span className="text-xs font-bold text-amber-900 truncate">
                        Human-in-the-Loop (HITL) Gate
                      </span>
                    </div>
                    <span className="text-[8px] font-mono font-bold bg-amber-100 text-amber-800 border border-amber-300 px-2 py-0.5 rounded uppercase shrink-0 ml-2">
                      Always Active
                    </span>
                  </div>
                </div>

                <div className="space-y-1.5 md:col-span-2">
                  <label className="text-[10px] font-mono font-bold text-slate-500 uppercase block">
                    STAGE HANDOFF SUMMARY
                  </label>
                  <input
                    type="text"
                    value={editingStage.description || ''}
                    onChange={(e) => setEditingStage({ ...editingStage, description: e.target.value })}
                    className="w-full bg-white border border-slate-200 px-3 py-2 rounded-lg text-xs text-[#262B40] focus:outline-none focus:border-[#0474C4] transition"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono font-bold text-slate-500 uppercase block">
                    TRIGGER CONDITION
                  </label>
                  <input
                    type="text"
                    value={editingStage.trigger || ''}
                    onChange={(e) => setEditingStage({ ...editingStage, trigger: e.target.value })}
                    placeholder="e.g. RM creates new lead / SCREENING_COMPLETE event"
                    className="w-full bg-white border border-slate-200 px-3 py-2 rounded-lg text-xs text-[#262B40] focus:outline-none focus:border-[#0474C4] transition"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono font-bold text-slate-500 uppercase block">
                    EXPECTED OUTPUT / ARTIFACTS
                  </label>
                  <input
                    type="text"
                    value={editingStage.output || ''}
                    onChange={(e) => setEditingStage({ ...editingStage, output: e.target.value })}
                    placeholder="e.g. Verified entity data from registries"
                    className="w-full bg-white border border-slate-200 px-3 py-2 rounded-lg text-xs text-[#262B40] focus:outline-none focus:border-[#0474C4] transition"
                  />
                </div>

                <div className="space-y-1.5 md:col-span-2">
                  <label className="text-[10px] font-mono font-bold text-[#0474C4] uppercase block">
                    EXECUTED PIPELINES (COMMA SEPARATED)
                  </label>
                  <input
                    type="text"
                    value={editingStage.pipelines ? editingStage.pipelines.join(', ') : ''}
                    onChange={(e) => {
                      const list = e.target.value.split(',').map(s => s.trim()).filter(Boolean);
                      setEditingStage({ ...editingStage, pipelines: list });
                    }}
                    placeholder="e.g. P-01 (Lead Intelligence), P-02 (Entity Resolution)"
                    className="w-full bg-blue-50/40 border border-blue-200 px-3 py-2 rounded-lg text-xs font-mono text-blue-900 focus:outline-none focus:border-[#0474C4] transition"
                  />
                </div>
              </div>

              {/* Section 1: Wired Stage Nodes */}
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <h4 className="text-xs font-bold text-[#262B40] uppercase tracking-wider flex items-center gap-2">
                    <Bot className="w-4 h-4 text-[#0474C4]" />
                    Currently Wired Stage Nodes ({editingStage.attachedAgentIds?.length || 0})
                  </h4>

                  <span className="text-[10px] font-mono text-slate-500">
                    Execution Mode: <strong className="text-[#0474C4] uppercase">{editingStage.executionMode || 'sequential'}</strong>
                  </span>
                </div>

                {(!editingStage.attachedAgentIds || editingStage.attachedAgentIds.length === 0) ? (
                  <div className="p-4 bg-amber-50 border border-amber-200 text-amber-800 rounded-xl text-xs font-medium text-center">
                    No nodes currently attached to this stage. Select and attach nodes from the pool below.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {editingStage.attachedAgentIds.map((agId, agIdx) => {
                      const agentObj = allAgentsMap.get(agId);
                      const isSuper = agentObj?.agentClass === 'super';

                      return (
                        <div key={`${agId}_${agIdx}`} className="p-3 bg-white border border-slate-200 rounded-xl shadow-2xs flex items-center justify-between gap-3">
                          <div className="flex items-center gap-2.5 overflow-hidden">
                            <div className={`p-2 rounded-lg shrink-0 ${isSuper ? 'bg-sky-50 text-sky-700 border border-sky-200' : 'bg-blue-50 text-[#0474C4] border border-blue-200'}`}>
                              <Bot className="w-4 h-4" />
                            </div>
                            <div className="overflow-hidden">
                              <div className="flex items-center gap-1.5">
                                <span className="text-[9px] font-mono font-bold text-slate-400">Node #{agIdx + 1}</span>
                                <span className={`text-[8px] font-mono px-1.5 rounded uppercase font-bold ${isSuper ? 'bg-sky-100 text-sky-700' : 'bg-slate-100 text-slate-600'}`}>
                                  {agentObj?.nodeType || (isSuper ? 'Super Agent' : 'Worker')}
                                </span>
                              </div>
                              <h5 className="text-xs font-bold text-[#262B40] truncate">
                                {agentObj ? agentObj.name : agId}
                              </h5>
                              <p className="text-[10px] text-slate-500 truncate mt-0.5">
                                {agentObj?.capability || 'Agent Studio Pipeline Worker Node'}
                              </p>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={() => {
                              const updatedAgentIds = (editingStage.attachedAgentIds || []).filter(id => id !== agId);
                              setEditingStage({ ...editingStage, attachedAgentIds: updatedAgentIds });
                            }}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer shrink-0"
                            title="Detach Node from Stage"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Section 2: Available Agent Studio Nodes Selector */}
              <div className="space-y-3 pt-2">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-2">
                  <div>
                    <h4 className="text-xs font-bold text-[#262B40] uppercase tracking-wider flex items-center gap-1.5">
                      <Plus className="w-4 h-4 text-[#0474C4]" />
                      Available Agent Studio Nodes Pool
                    </h4>
                    <p className="text-[11px] text-[#5379AE] mt-0.5">
                      Select nodes from Agent Studio to attach to Stage {editingStageIndex + 1}.
                    </p>
                  </div>

                  {/* Filter Pills & Search */}
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                      <input
                        type="text"
                        placeholder="Search agent nodes..."
                        value={nodeSearchQuery}
                        onChange={(e) => setNodeSearchQuery(e.target.value)}
                        className="bg-slate-50 border border-slate-200 pl-8 pr-3 py-1.5 rounded-lg text-xs font-medium text-[#262B40] focus:outline-none focus:border-[#0474C4]"
                      />
                    </div>

                    <div className="flex items-center border border-slate-200 rounded-lg overflow-hidden bg-slate-50 p-0.5">
                      <button
                        type="button"
                        onClick={() => setNodeTypeFilter('all')}
                        className={`px-2 py-1 text-[10px] font-mono font-bold rounded ${nodeTypeFilter === 'all' ? 'bg-white text-[#0474C4] shadow-2xs' : 'text-slate-500 hover:text-slate-700'}`}
                      >
                        All
                      </button>
                      <button
                        type="button"
                        onClick={() => setNodeTypeFilter('super')}
                        className={`px-2 py-1 text-[10px] font-mono font-bold rounded ${nodeTypeFilter === 'super' ? 'bg-sky-50 text-sky-700 shadow-2xs' : 'text-slate-500 hover:text-slate-700'}`}
                      >
                        Super
                      </button>
                      <button
                        type="button"
                        onClick={() => setNodeTypeFilter('worker')}
                        className={`px-2 py-1 text-[10px] font-mono font-bold rounded ${nodeTypeFilter === 'worker' ? 'bg-white text-[#0474C4] shadow-2xs' : 'text-slate-500 hover:text-slate-700'}`}
                      >
                        Worker
                      </button>
                    </div>
                  </div>
                </div>

                {/* Nodes Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-60 overflow-y-auto p-1">
                  {availableSystemAgents
                    .filter(ag => {
                      const matchesSearch = ag.name.toLowerCase().includes(nodeSearchQuery.toLowerCase()) || 
                                            ag.capability.toLowerCase().includes(nodeSearchQuery.toLowerCase());
                      const matchesType = nodeTypeFilter === 'all' 
                        || (nodeTypeFilter === 'super' && ag.agentClass === 'super')
                        || (nodeTypeFilter === 'worker' && ag.agentClass !== 'super');
                      return matchesSearch && matchesType;
                    })
                    .map(ag => {
                      const isAlreadyAttached = (editingStage.attachedAgentIds || []).includes(ag.id);
                      const isSuper = ag.agentClass === 'super';

                      return (
                        <div 
                          key={ag.id} 
                          className={`p-3 rounded-xl border transition flex items-center justify-between gap-3 ${
                            isAlreadyAttached 
                              ? 'bg-slate-50 border-slate-200 opacity-60' 
                              : 'bg-white border-slate-200 hover:border-[#0474C4]/50 hover:shadow-2xs'
                          }`}
                        >
                          <div className="flex items-center gap-2.5 overflow-hidden">
                            <div className={`p-2 rounded-lg shrink-0 ${isSuper ? 'bg-sky-50 text-sky-700 border border-sky-200' : 'bg-blue-50 text-[#0474C4] border border-blue-200'}`}>
                              <Bot className="w-4 h-4" />
                            </div>
                            <div className="overflow-hidden">
                              <div className="flex items-center gap-1.5">
                                <span className={`text-[8px] font-mono px-1.5 rounded uppercase font-bold ${isSuper ? 'bg-sky-100 text-sky-700' : 'bg-slate-100 text-slate-600'}`}>
                                  {ag.nodeType || (isSuper ? 'Super Agent' : 'Worker')}
                                </span>
                                <span className="text-[9px] font-mono text-slate-400">{ag.model}</span>
                              </div>
                              <h5 className="text-xs font-bold text-[#262B40] truncate mt-0.5">
                                {ag.name}
                              </h5>
                              <p className="text-[10px] text-slate-500 truncate">
                                {ag.capability}
                              </p>
                            </div>
                          </div>

                          {isAlreadyAttached ? (
                            <span className="text-[10px] font-mono font-bold text-emerald-600 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-md shrink-0">
                              Attached
                            </span>
                          ) : (
                            <button
                              type="button"
                              onClick={() => {
                                const updatedAgentIds = [...(editingStage.attachedAgentIds || []), ag.id];
                                setEditingStage({ ...editingStage, attachedAgentIds: updatedAgentIds });
                              }}
                              className="px-3 py-1.5 bg-[#0474C4] hover:bg-[#06457F] text-white text-[11px] font-bold rounded-lg transition shrink-0 cursor-pointer flex items-center gap-1"
                            >
                              <Plus className="w-3.5 h-3.5" /> Attach
                            </button>
                          )}
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
              <span className="text-xs text-slate-500">
                Total Wired Nodes for Stage {editingStageIndex + 1}: <strong className="text-[#0474C4] font-bold">{editingStage.attachedAgentIds?.length || 0} Nodes</strong>
              </span>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setEditingStageIndex(null);
                    setEditingStage(null);
                  }}
                  className="px-4 py-2 border border-slate-200 hover:bg-slate-200/60 text-slate-700 font-bold text-xs rounded-lg transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveModalStage}
                  className="px-5 py-2 bg-[#0474C4] hover:bg-[#06457F] text-white font-bold text-xs rounded-lg transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Save className="w-4 h-4" /> Save Stage Configuration
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ADD STAGE & PIPELINE ATTACH TEMPLATE PROMPT MODAL */}
      {showAddStagePrompt && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden">
            {/* Header */}
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50 shrink-0">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0474C4] text-white rounded-xl shadow-xs">
                  <Plus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-[#262B40]">
                    Add Journey Stage & Attach Pipeline
                  </h3>
                  <p className="text-xs text-[#5379AE] mt-0.5">
                    Select a standardized onboarding stage template or configure a custom operational note/pipeline stage.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAddStagePrompt(false)}
                className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 rounded-xl transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Content */}
            <div className="p-6 overflow-y-auto space-y-5 text-left flex-1">
              {/* Template Selection */}
              <div>
                <label className="text-[10px] font-mono font-bold text-slate-500 uppercase block mb-2">
                  CHOOSE STAGE TEMPLATE / PATTERN
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-56 overflow-y-auto p-1">
                  {STAGE_TEMPLATES.map((tpl) => {
                    const isSelected = selectedStageTemplateId === tpl.id;
                    const isNote = tpl.id === 'note_stage';
                    return (
                      <div
                        key={tpl.id}
                        onClick={() => setSelectedStageTemplateId(tpl.id)}
                        className={`p-3 rounded-xl border transition cursor-pointer flex flex-col justify-between gap-1.5 ${
                          isSelected
                            ? 'bg-blue-50/80 border-[#0474C4] ring-2 ring-blue-500/20 shadow-xs'
                            : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/60'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded uppercase ${
                            isNote ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-600'
                          }`}>
                            {tpl.category}
                          </span>
                          {isSelected && <Check className="w-4 h-4 text-[#0474C4] shrink-0" />}
                        </div>
                        <div>
                          <h5 className="text-xs font-bold text-[#262B40]">{tpl.name}</h5>
                          <p className="text-[10px] text-slate-500 line-clamp-2 mt-0.5 leading-relaxed">
                            {tpl.description}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Custom Stage Details (If custom or note template selected) */}
              {(selectedStageTemplateId === 'custom' || selectedStageTemplateId === 'note_stage') && (
                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-3">
                  <div>
                    <label className="text-[10px] font-mono font-bold text-slate-500 uppercase block mb-1">
                      STAGE TITLE
                    </label>
                    <input
                      type="text"
                      value={customStageName}
                      onChange={(e) => setCustomStageName(e.target.value)}
                      placeholder={selectedStageTemplateId === 'note_stage' ? 'Operational Note & Compliance Memo' : 'e.g. Wealth Management Suitability Check'}
                      className="w-full bg-white border border-slate-200 px-3 py-2 rounded-lg text-xs font-bold text-[#262B40] focus:outline-none focus:border-[#0474C4]"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-mono font-bold text-slate-500 uppercase block mb-1">
                      OPERATIONAL NOTES / STAGE DESCRIPTION
                    </label>
                    <textarea
                      rows={2}
                      value={customStageDesc}
                      onChange={(e) => setCustomStageDesc(e.target.value)}
                      placeholder="Specify execution criteria, handoff requirements, or compliance notes..."
                      className="w-full bg-white border border-slate-200 px-3 py-2 rounded-lg text-xs text-[#262B40] focus:outline-none focus:border-[#0474C4] resize-none"
                    />
                  </div>
                </div>
              )}

              {/* Pipeline Link and Execution Mode */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-mono font-bold text-slate-500 uppercase block mb-1">
                    ATTACH COMPONENT PIPELINE
                  </label>
                  <select
                    value={addStagePipelineId}
                    onChange={(e) => setAddStagePipelineId(e.target.value)}
                    className="w-full bg-white border border-slate-200 px-3 py-2 rounded-lg text-xs font-bold text-[#262B40] focus:outline-none focus:border-[#0474C4] cursor-pointer"
                  >
                    {orchestrations.map((orch) => (
                      <option key={orch.id} value={orch.id}>
                        {orch.name} ({orch.agentIds.length} Nodes)
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-mono font-bold text-slate-500 uppercase block mb-1">
                    EXECUTION TOPOLOGY
                  </label>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      type="button"
                      onClick={() => setAddStageExecMode('sequential')}
                      className={`p-2 rounded-lg border text-xs font-bold flex items-center justify-center gap-1 transition cursor-pointer ${
                        addStageExecMode === 'sequential'
                          ? 'bg-emerald-50 border-emerald-500 text-emerald-800 shadow-2xs'
                          : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      <Zap className="w-3.5 h-3.5 text-emerald-600" /> Sequential
                    </button>
                    <button
                      type="button"
                      onClick={() => setAddStageExecMode('parallel')}
                      className={`p-2 rounded-lg border text-xs font-bold flex items-center justify-center gap-1 transition cursor-pointer ${
                        addStageExecMode === 'parallel'
                          ? 'bg-blue-50 border-[#0474C4] text-blue-900 shadow-2xs'
                          : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      <GitBranch className="w-3.5 h-3.5 text-[#0474C4]" /> Parallel
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
              <span className="text-xs text-slate-500">
                Will be attached as <strong className="text-[#0474C4] font-bold">Stage {journeyStages.length + 1}</strong>
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddStagePrompt(false)}
                  className="px-4 py-2 border border-slate-200 hover:bg-slate-200/60 text-slate-700 font-bold text-xs rounded-lg transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmAddStageFromPrompt}
                  className="px-5 py-2 bg-[#0474C4] hover:bg-[#06457F] text-white font-bold text-xs rounded-lg transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Plus className="w-4 h-4" /> Add Stage to Journey
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* STAGE RESEQUENCING CONFIRMATION MODAL */}
      {stageMovePending && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-md w-full p-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-blue-50 text-[#0474C4] rounded-xl">
                <SlidersHorizontal className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-[#262B40]">Reorder Journey Stage</h4>
                <p className="text-xs text-slate-500">Confirm sequence modification</p>
              </div>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Are you sure you want to move <strong>"{stageMovePending.stage.name}"</strong> {stageMovePending.direction === 'up' ? 'earlier (left)' : 'later (right)'} in the execution flow? All stages will be sequentially renumbered.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setStageMovePending(null)}
                className="px-3.5 py-1.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-lg transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  executeMoveStage(stageMovePending.index, stageMovePending.direction);
                  setStageMovePending(null);
                  setSaveToast(`✅ Stage re-sequenced successfully`);
                  setTimeout(() => setSaveToast(null), 2500);
                }}
                className="px-4 py-1.5 bg-[#0474C4] hover:bg-[#06457F] text-white text-xs font-bold rounded-lg transition cursor-pointer shadow-2xs"
              >
                Confirm Reorder
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Journey Confirmation Dialog */}
      <DeleteConfirmModal
        isOpen={!!journeyToDelete}
        onClose={() => setJourneyToDelete(null)}
        onConfirm={handleConfirmDeleteJourney}
        title="Delete Onboarding Journey"
        description={`Are you sure you want to permanently delete journey "${journeyToDelete?.name}"? This action cannot be undone.`}
        confirmLabel="Delete Journey"
      />

      {/* Delete Stage Confirmation Dialog */}
      <DeleteConfirmModal
        isOpen={!!stageToDelete}
        onClose={() => setStageToDelete(null)}
        onConfirm={handleConfirmRemoveStage}
        title="Delete Journey Stage"
        description={`Are you sure you want to remove "${stageToDelete?.name}" from this onboarding journey pipeline?`}
        confirmLabel="Delete Stage"
      />

      {/* BPMN 2.0 Full Modal Viewer (bpmn.io) */}
      {bpmnModalJourney && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
          <div className="w-full max-w-7xl h-[90vh] bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col">
            <BpmnJourneyViewer
              journey={bpmnModalJourney}
              availableAgents={availableSystemAgents}
              onClose={() => setBpmnModalJourney(null)}
              isModal={true}
            />
          </div>
        </div>
      )}
    </div>
  );
}

/* ==========================================================================
   10. POLICY ENGINE VIEW
   ========================================================================== */
export function PolicyEngineView() {
  const [policies, setPolicies] = useState([
    { id: 'pol-1', name: 'Offshore Shareholder Check', description: 'Trigger manual compliance override if UBO register contains entities incorporated in high-risk offshore shelters.', status: 'Active' },
    { id: 'pol-2', name: 'Minimum Underwrite Score', description: 'Enforce credit score ratings of BBB- or above for unsecured commercial credit lines over $500k USD.', status: 'Active' },
    { id: 'pol-3', name: 'PEP Liveness Requirement', description: 'Mandate webcam face liveness scans within 10 minutes of document submissions for PEP associated cases.', status: 'Active' }
  ]);

  // Zero-Cost Real Integration 1: Live Gemini 3.6 Policy Evaluator State
  const [selectedPolicy, setSelectedPolicy] = useState(policies[0]);
  const [testScenario, setTestScenario] = useState('A client from BVI submits a 15% corporate shareholder entity without ultimate natural person passport.');
  const [evalResult, setEvalResult] = useState<any>(null);
  const [evaluating, setEvaluating] = useState(false);

  const handleRunPolicyEval = async () => {
    setEvaluating(true);
    try {
      const res = await fetch('/api/admin/evaluate-policy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          policyName: selectedPolicy.name,
          ruleText: selectedPolicy.description,
          scenario: testScenario
        })
      });
      const data = await res.json();
      setEvalResult(data);
    } catch (e) {
      console.error(e);
    } finally {
      setEvaluating(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          Compliance Policy Engine & Gemini 3.6 AI Evaluator
          <span className="px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950/40 text-blue-700 dark:text-blue-400 text-[10px] font-mono font-bold">
            GEMINI 3.6 FLASH REASONING
          </span>
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Set regulatory policy parameters, compliance filters, and run real-time AI policy stress tests using Gemini 3.6 Flash.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Policy List */}
        <div className="space-y-3.5">
          <h3 className="text-xs font-bold text-slate-400 font-mono uppercase tracking-wider">Active Policy Rules</h3>
          {policies.map(pol => (
            <div 
              key={pol.id} 
              onClick={() => setSelectedPolicy(pol)}
              className={`bg-white dark:bg-slate-900 border rounded-xl p-4.5 shadow-sm transition cursor-pointer ${
                selectedPolicy.id === pol.id 
                  ? 'border-blue-500 ring-2 ring-blue-500/10 dark:bg-slate-850' 
                  : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
              }`}
            >
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h4 className="font-bold text-slate-900 dark:text-white text-sm">{pol.name}</h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5 leading-relaxed">{pol.description}</p>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                  <span className="text-[10px] font-mono text-slate-500 uppercase">{pol.status}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Gemini 3.6 Policy Stress Test Panel */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white font-mono uppercase tracking-wider flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-blue-500" />
              Gemini 3.6 Policy Stress Tester
            </h3>
            <span className="text-[10px] font-mono text-blue-600 dark:text-blue-400 font-bold bg-blue-50 dark:bg-blue-950/30 px-2.5 py-0.5 rounded">
              REAL AI REASONING
            </span>
          </div>

          <div className="space-y-2">
            <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300">Selected Policy Rule:</label>
            <div className="p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-xs font-semibold text-slate-800 dark:text-slate-200">
              {selectedPolicy.name}: <span className="font-normal text-slate-500">{selectedPolicy.description}</span>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300">Test Edge-Case Scenario:</label>
            <textarea
              value={testScenario}
              onChange={(e) => setTestScenario(e.target.value)}
              rows={3}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
            />
          </div>

          <button
            onClick={handleRunPolicyEval}
            disabled={evaluating}
            className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-sm"
          >
            {evaluating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            Run Gemini 3.6 Policy Reasoning Test
          </button>

          {evalResult && (
            <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className="p-4 bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 rounded-lg space-y-2.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-800 dark:text-slate-100">AI Verdict:</span>
                <span className={`px-2.5 py-0.5 rounded font-mono text-[10px] font-bold ${
                  evalResult.verdict === 'COMPLIANT' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-400' : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-400'
                }`}>
                  {evalResult.verdict} (Risk Score: {evalResult.riskScore}/100)
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-mono block font-bold">Regulatory Reference</span>
                <p className="text-slate-700 dark:text-slate-300 font-medium mt-0.5">{evalResult.regulatoryReference}</p>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-mono block font-bold">Recommended Action</span>
                <p className="text-slate-600 dark:text-slate-400 leading-relaxed mt-0.5">{evalResult.recommendedAction}</p>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ==========================================================================
   11. AGENT BLOCKS VIEW
   ========================================================================== */
export function AgentBlocksView() {
  const blocks = [
    { id: 'blk-1', name: 'Liveness Matcher', type: 'Biometrics Check', code: 'org.onboard.biometrics.liveness' },
    { id: 'blk-2', name: 'ACRA Registry Query', type: 'Registry Pull', code: 'org.onboard.registry.sg_acra' },
    { id: 'blk-3', name: 'OFAC Sanction Matcher', type: 'Watchlist Screen', code: 'org.onboard.compliance.ofac_screen' },
    { id: 'blk-4', name: 'Watermark OCR Vetting', type: 'OCR Analysis', code: 'org.onboard.ocr.watermark_check' }
  ];

  return (
    <div className="space-y-6">
      <div className="border-b border-slate-200 pb-5">
        <h2 className="text-xl font-bold text-slate-900">Journey Agent Blocks</h2>
        <p className="text-xs text-slate-500 mt-1">
          Assemble, review, and register custom code blocks and ML classifiers that can be dragged into journey graphs.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {blocks.map(blk => (
          <div 
            key={blk.id} 
            className="bg-slate-50 border border-slate-200 rounded-xl p-4 shadow-sm space-y-3"
          >
            <span className="text-[9px] font-mono text-blue-600 uppercase block font-semibold">{blk.type}</span>
            <h4 className="font-bold text-slate-900 text-xs">{blk.name}</h4>
            <div className="bg-white p-2 rounded border border-slate-100 text-[10px] font-mono text-slate-500 truncate">
              {blk.code}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
