import React, { useState, useEffect } from 'react';
import { Mail, Send, X, Sparkles, Shield } from 'lucide-react';
import { ClientProfile } from '../../types';

interface OutreachDraftModalProps {
  isOpen: boolean;
  client: ClientProfile | null;
  activePersona?: string;
  onClose: () => void;
  onSend: (emailData: {
    clientId: string;
    clientName: string;
    email: string;
    subject: string;
    body: string;
  }) => void;
}

export function OutreachDraftModal({ isOpen, client, activePersona, onClose, onSend }: OutreachDraftModalProps) {
  const isComplianceOfficer = activePersona === 'compliance_officer';

  const defaultRecipient = isComplianceOfficer
    ? 'relationship.manager@onboard.ai'
    : (client?.authorizedRepresentative?.email || 'representative@company.com');

  const defaultSubject = isComplianceOfficer
    ? `[Compliance Query] Onboarding Risk Review & Documentation Notice - ${client?.companyName || ''}`
    : `Action Required: Complete Secure Corporate Onboarding for ${client?.companyName || ''}`;

  const defaultBody = isComplianceOfficer
    ? `Hello Relationship Manager,\n\nI have completed the compliance & risk evaluation for "${client?.companyName || 'Corporate Client'}".\n\nPlease review the highlighted verification items, UBO register entries, and risk factors with the client before final signoff.\n\nBest regards,\nCompliance & Risk Officer\nOnboard.ai Risk & Compliance Division`
    : `Hello ${client?.authorizedRepresentative?.name || 'Representative'},\n\nOur Relationship Management team at Onboard.ai Bank has initiated your digital onboarding journey for "${client?.companyName || 'Corporate Client'}".\n\nTo securely complete the onboarding setup, please register/log in to our secure platform, verify your corporate identities using Singpass MyInfo or India Aadhaar/PAN Stack, and upload the required corporate files.\n\nBest regards,\nOnboard.ai Digital Onboarding Team`;

  const [recipient, setRecipient] = useState(defaultRecipient);
  const [subject, setSubject] = useState(defaultSubject);
  const [body, setBody] = useState(defaultBody);
  const [isSending, setIsSending] = useState(false);

  useEffect(() => {
    if (client) {
      setRecipient(isComplianceOfficer ? 'relationship.manager@onboard.ai' : (client.authorizedRepresentative?.email || 'representative@company.com'));
      setSubject(isComplianceOfficer ? `[Compliance Query] Onboarding Risk Review & Documentation Notice - ${client.companyName}` : `Action Required: Complete Secure Corporate Onboarding for ${client.companyName}`);
      setBody(isComplianceOfficer
        ? `Hello Relationship Manager,\n\nI have completed the compliance & risk evaluation for "${client.companyName}".\n\nPlease review the highlighted verification items, UBO register entries, and risk factors with the client before final signoff.\n\nBest regards,\nCompliance & Risk Officer\nOnboard.ai Risk & Compliance Division`
        : `Hello ${client.authorizedRepresentative?.name || 'Representative'},\n\nOur Relationship Management team at Onboard.ai Bank has initiated your digital onboarding journey for "${client.companyName}".\n\nTo securely complete the onboarding setup, please register/log in to our secure platform, verify your corporate identities using Singpass MyInfo or India Aadhaar/PAN Stack, and upload the required corporate files.\n\nBest regards,\nOnboard.ai Digital Onboarding Team`
      );
    }
  }, [client, isComplianceOfficer]);

  if (!isOpen || !client) return null;

  const handleApproveAndSend = () => {
    setIsSending(true);
    setTimeout(() => {
      onSend({
        clientId: client.id,
        clientName: client.companyName,
        email: recipient,
        subject: subject,
        body: body,
      });
      setIsSending(false);
      onClose();
    }, 300);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4 animate-fadeIn">
      <div className="bg-white border border-slate-200 rounded-2xl shadow-2xl max-w-2xl w-full overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-white border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-600 shadow-2xs shrink-0">
              <Mail className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900 tracking-tight">
                  {isComplianceOfficer ? 'Draft Compliance Query to RM' : 'Draft Outreach Email'}
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-blue-50 border border-blue-200 text-blue-700 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-amber-500" /> AI Draft
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                {isComplianceOfficer 
                  ? 'Review and verify the compliance query / risk escalation notice to the Relationship Manager.'
                  : 'Review and verify the automated client onboarding outreach before sending.'}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs bg-slate-50/50">
          <div className="p-3.5 bg-amber-50/80 border border-amber-200 rounded-xl flex items-start gap-2.5 text-amber-950">
            <Shield className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-xs text-amber-950">Verification Required</p>
              <p className="text-[11px] text-amber-900 leading-relaxed mt-0.5">
                {isComplianceOfficer 
                  ? 'Please review the email content and recipient address before approving. Once sent, this inquiry will be logged and dispatched to the assigned RM inbox.'
                  : 'Please verify recipient details and subject line before approval. Once approved, the outreach package will be dispatched to the client inbox.'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wide font-mono mb-1.5">
                Target Company
              </label>
              <input
                type="text"
                disabled
                value={client.companyName}
                className="w-full bg-slate-100 border border-slate-200 text-slate-700 rounded-xl p-2.5 font-bold cursor-not-allowed shadow-2xs"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wide font-mono mb-1.5">
                Recipient Email
              </label>
              <input
                type="email"
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                className="w-full bg-white border border-slate-200 text-slate-900 rounded-xl p-2.5 font-medium focus:ring-1 focus:ring-blue-600 focus:border-blue-600 focus:outline-none shadow-2xs"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wide font-mono mb-1.5">
              Email Subject Line
            </label>
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full bg-white border border-slate-200 text-slate-900 rounded-xl p-2.5 font-medium focus:ring-1 focus:ring-blue-600 focus:border-blue-600 focus:outline-none shadow-2xs"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wide font-mono mb-1.5">
              Outreach Body Content
            </label>
            <textarea
              rows={7}
              value={body}
              onChange={(e) => setBody(e.target.value)}
              className="w-full bg-white border border-slate-200 text-slate-900 rounded-xl p-3 font-mono text-xs leading-relaxed focus:ring-1 focus:ring-blue-600 focus:border-blue-600 focus:outline-none shadow-2xs"
            />
          </div>
        </div>

        {/* Footer actions */}
        <div className="px-6 py-4 bg-white border-t border-slate-200 flex items-center justify-between">
          <span className="text-[11px] text-slate-500 font-mono">
            Status: <strong className="text-amber-700">Awaiting Verification</strong>
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              disabled={isSending}
              className="px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-100 rounded-xl transition cursor-pointer"
            >
              Cancel / Discard
            </button>
            <button
              onClick={handleApproveAndSend}
              disabled={isSending || !recipient || !subject}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl shadow-xs transition flex items-center gap-2 cursor-pointer"
            >
              <Send className="w-4 h-4" />
              {isSending ? 'Dispatching...' : 'Approve & Send Email'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
