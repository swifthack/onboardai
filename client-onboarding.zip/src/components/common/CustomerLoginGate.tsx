import React, { useState, useMemo, useEffect } from 'react';
import { ClientProfile } from '../../types';
import { 
  Lock, 
  Mail, 
  Building2, 
  ArrowLeft, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight,
  ShieldCheck,
  Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CustomerLoginGateProps {
  clients: ClientProfile[];
  onLoginSuccess: (clientId: string) => void;
  onBackToPersonas: () => void;
  // If we came from an email link, we might pre-select a client ID
  initialClientId?: string | null;
}

export default function CustomerLoginGate({ 
  clients, 
  onLoginSuccess, 
  onBackToPersonas,
  initialClientId 
}: CustomerLoginGateProps) {
  
  // Choose initial client if provided, otherwise default to first client in list
  const [selectedClientId, setSelectedClientId] = useState<string>(() => {
    if (initialClientId && clients.some(c => c.id === initialClientId)) {
      return initialClientId;
    }
    return clients[0]?.id || '';
  });

  const [email, setEmail] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Active client object
  const activeClient = useMemo(() => {
    return clients.find(c => c.id === selectedClientId) || null;
  }, [clients, selectedClientId]);

  // Generate suggested domain based on corporate name
  const suggestedDomain = useMemo(() => {
    if (!activeClient) return 'company.com';
    
    // If the active client has a representative email, extract domain
    if (activeClient.authorizedRepresentative?.email) {
      const parts = activeClient.authorizedRepresentative.email.split('@');
      if (parts.length > 1) return parts[1];
    }
    
    // Otherwise clean the company name
    return activeClient.companyName
      .toLowerCase()
      .replace(/pte\s*ltd|ltd|inc|llc|corp|corporation/gi, '')
      .trim()
      .replace(/\s+/g, '-')
      .replace(/[^a-z0-9-]/g, '') + '.com';
  }, [activeClient]);

  // Suggested emails to display for simulation ease
  const simulatedEmails = useMemo(() => {
    if (!activeClient) return [];
    const repEmail = activeClient.authorizedRepresentative?.email;
    const baseDomain = suggestedDomain;
    
    const list: string[] = [];
    if (repEmail) list.push(repEmail);
    if (!repEmail || !repEmail.startsWith('admin@')) list.push(`admin@${baseDomain}`);
    if (!repEmail || !repEmail.startsWith('finance@')) list.push(`finance@${baseDomain}`);
    
    return list;
  }, [activeClient, suggestedDomain]);

  // Automatically set email when active client changes if email is currently empty or from another domain
  useEffect(() => {
    if (activeClient?.authorizedRepresentative?.email) {
      setEmail(activeClient.authorizedRepresentative.email);
    } else if (simulatedEmails.length > 0) {
      setEmail(simulatedEmails[0]);
    }
  }, [selectedClientId, activeClient, simulatedEmails]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!activeClient) {
      setError('Please select a corporate company.');
      return;
    }

    if (!email.trim()) {
      setError('Please select or enter your corporate email address.');
      return;
    }

    if (!email.includes('@') || email.length < 5) {
      setError('Please enter a valid corporate email address.');
      return;
    }

    // Direct transition to customer portal
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLoginSuccess(selectedClientId);
    }, 400);
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col justify-between p-6 md:p-12 relative overflow-hidden font-sans text-left">
      {/* Background decoration */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-50/40 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-slate-100/50 rounded-full blur-3xl pointer-events-none" />

      {/* Top logo & branding */}
      <header className="z-10 flex items-center justify-between w-full max-w-4xl mx-auto border-b border-slate-200 pb-5">
        <div className="flex items-center gap-2.5">
          <button 
            onClick={onBackToPersonas}
            className="p-1.5 hover:bg-slate-100 rounded-lg transition text-slate-500 hover:text-slate-800 flex items-center mr-1 cursor-pointer"
            title="Back to Persona Selection"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="h-7 w-7 rounded bg-blue-600 flex items-center justify-center font-bold text-white text-base tracking-tighter">
            O
          </div>
          <span className="font-bold text-lg tracking-tight text-slate-900">
            Onboard.ai <span className="text-slate-500 font-normal">Customer Gateway</span>
          </span>
        </div>
        <div className="flex items-center gap-2 text-xs font-mono text-slate-600 bg-slate-50 px-3 py-1 rounded-full border border-slate-200">
          <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block"></span>
          <span>DIRECT PORTAL AUTH</span>
        </div>
      </header>

      {/* Main card */}
      <main className="my-auto z-10 w-full max-w-lg mx-auto py-8">
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white border border-[#E2E8F0] rounded-2xl p-6 md:p-8 shadow-xl space-y-6"
        >
          {/* Header text */}
          <div className="space-y-1.5">
            <div className="h-10 w-10 bg-blue-50 border border-blue-100 rounded-xl flex items-center justify-center text-blue-600 mb-2">
              <Lock className="w-5 h-5" />
            </div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">Customer Portal Authentication</h1>
            <p className="text-slate-500 text-xs">
              Select your corporate profile and email to sign in directly to your corporate onboarding workspace.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* 1. Corporate Entity Selector */}
            <div className="space-y-1.5 text-left">
              <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block font-mono flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-slate-400" />
                Select Registered Corporate Company
              </label>
              <select
                value={selectedClientId}
                onChange={(e) => {
                  setSelectedClientId(e.target.value);
                  setError(null);
                }}
                className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-xs bg-slate-50 hover:bg-slate-100/50 transition font-medium focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:outline-none"
              >
                {clients.map((client, idx) => (
                  <option key={`${client.id}_${idx}`} value={client.id}>
                    {client.companyName} ({client.registrationNumber}) — {client.jurisdiction}
                  </option>
                ))}
              </select>
              <p className="text-[10px] text-slate-400 italic">
                Corporate profiles synced with Relationship Manager (RM) portfolio.
              </p>
            </div>

            {/* 2. Corporate Email */}
            <div className="space-y-1.5 text-left">
              <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block font-mono flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-slate-400" />
                Corporate Email Address
              </label>
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setError(null);
                  }}
                  placeholder={`e.g. representative@${suggestedDomain}`}
                  className="w-full pl-9 pr-3 py-2.5 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:outline-none bg-slate-50/50 hover:bg-slate-50 transition"
                  disabled={isLoading}
                />
                <span className="absolute left-3 top-3 text-slate-400">
                  @
                </span>
              </div>

              {/* Suggestions helper */}
              <div className="bg-blue-50/50 border border-blue-150 p-3 rounded-xl space-y-1.5 mt-2">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-mono font-bold text-blue-800 uppercase flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-blue-600" />
                    Authorized Accounts for {activeClient?.companyName}:
                  </span>
                </div>
                <div className="flex flex-wrap gap-1.5 pt-0.5">
                  {simulatedEmails.map(simEmail => {
                    const isSelected = email === simEmail;
                    return (
                      <button
                        key={simEmail}
                        type="button"
                        onClick={() => {
                          setEmail(simEmail);
                          setError(null);
                        }}
                        className={`text-[10px] font-mono px-2.5 py-1 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                          isSelected
                            ? 'bg-blue-600 text-white font-bold shadow-xs border border-blue-600'
                            : 'bg-white border border-blue-200 text-blue-700 hover:bg-blue-100/70'
                        }`}
                      >
                        {isSelected && <CheckCircle2 className="w-3 h-3 text-white" />}
                        <span>{simEmail}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Error messaging */}
            <AnimatePresence>
              {error && (
                <motion.div 
                  key="login-error-msg"
                  initial={{ opacity: 0, y: -5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -5 }}
                  className="p-3 bg-rose-50 border border-rose-100 rounded-xl flex items-center gap-2 text-xs text-rose-700"
                >
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                  <span>{error}</span>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Direct Sign-In Button */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 text-white font-bold text-xs tracking-wider uppercase rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-blue-600/20"
              >
                {isLoading ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                    Signing In to Customer Portal...
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>Sign In to Customer Portal</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>

          <div className="border-t border-slate-150 pt-4 flex justify-between items-center text-[10px] text-slate-500 font-mono">
            <span>DIRECT SECURE SESSION V4</span>
            <button 
              type="button" 
              onClick={onBackToPersonas}
              className="text-blue-600 hover:text-blue-800 font-bold hover:underline cursor-pointer"
            >
              Cancel & Exit
            </button>
          </div>
        </motion.div>
      </main>

      {/* Footer */}
      <footer className="z-10 w-full max-w-4xl mx-auto border-t border-[#E2E8F0] pt-5 flex flex-col md:flex-row justify-between items-center gap-4 text-xs font-mono text-[#64748B]">
        <span>© 2026 Onboard.ai Financial Technologies. All rights reserved.</span>
        <div className="flex items-center gap-5">
          <span>PORTAL SECURE LEVEL 4</span>
          <span>•</span>
          <span>AUTONOMOUS CORE OK</span>
        </div>
      </footer>
    </div>
  );
}

