import React, { useState } from 'react';
import { 
  FileText, X, ZoomIn, ZoomOut, RotateCw, ShieldCheck, 
  CheckCircle2, Clock, AlertTriangle, Building, User, Calendar, 
  Layers, Lock, Eye, Check, Copy, CheckCheck
} from 'lucide-react';
import { UploadedDocument } from '../../types';

interface DocumentViewerModalProps {
  document: UploadedDocument | null;
  isOpen: boolean;
  onClose: () => void;
  onApprove?: (docId: string) => void;
  onReject?: (docId: string, reason?: string) => void;
  onApproveDoc?: (docId: string) => void;
  onRejectDoc?: (docId: string, reason?: string) => void;
  readOnly?: boolean;
  userRole?: 'rm' | 'compliance' | 'customer';
}

// Exportable Document Preview Canvas for both modal and inline Review Hub view
export function DocumentPreviewCanvas({
  document,
  zoomLevel = 100,
  rotation = 0
}: {
  document: UploadedDocument;
  zoomLevel?: number;
  rotation?: number;
}) {
  const isIncorporation = document.name.toLowerCase().includes('incorporation') || document.type.toLowerCase().includes('incorporation');
  const isBoardRes = document.name.toLowerCase().includes('board') || document.type.toLowerCase().includes('board');
  const isUbo = document.name.toLowerCase().includes('controller') || document.name.toLowerCase().includes('ubo') || document.type.toLowerCase().includes('ubo');
  const isFinancials = document.name.toLowerCase().includes('financial') || document.type.toLowerCase().includes('financial');
  const isPassport = document.name.toLowerCase().includes('passport') || document.type.toLowerCase().includes('identification') || document.type.toLowerCase().includes('passport');

  return (
    <div 
      className="bg-white text-slate-900 shadow-xl rounded-lg p-8 sm:p-12 mx-auto transition-transform duration-200 border border-slate-300 min-h-[720px] max-w-[650px] relative select-none"
      style={{
        transform: `scale(${zoomLevel / 100}) rotate(${rotation}deg)`,
        transformOrigin: 'top center',
        fontFamily: 'serif'
      }}
    >
      {/* Institutional Watermark */}
      <div className="absolute inset-0 pointer-events-none flex items-center justify-center opacity-[0.04] overflow-hidden select-none">
        <span className="text-7xl font-black text-slate-900 transform -rotate-45 font-sans tracking-widest uppercase">
          CONFIDENTIAL • INSTITUTIONAL BANKING
        </span>
      </div>

      {/* Header Ribbon */}
      <div className="border-b-2 border-slate-900 pb-4 mb-6 flex items-start justify-between">
        <div className="space-y-1 text-left">
          <div className="text-[10px] uppercase tracking-widest font-sans font-extrabold text-slate-500">
            OFFICIAL GOVERNANCE & REGULATORY RECORD
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
            {document.name.replace('.pdf', '').replace(/_/g, ' ')}
          </h1>
          <p className="text-xs text-slate-600 font-sans">
            Type: <strong className="text-slate-900">{document.type}</strong> • Ingestion Date: {document.uploadedAt}
          </p>
        </div>
        <div className="text-right font-sans shrink-0">
          <div className="px-2.5 py-1 bg-slate-900 text-white text-[10px] font-bold rounded tracking-wider uppercase">
            CERTIFIED TRUE COPY
          </div>
          <span className="text-[9px] text-slate-400 font-mono block mt-1">Doc ID: {document.id}</span>
        </div>
      </div>

      {/* Dynamic Body Content according to Document Archetype */}
      {isIncorporation && (
        <div className="space-y-6 text-sm leading-relaxed text-left">
          <div className="text-center py-3 border-y border-slate-300">
            <span className="text-xs uppercase tracking-wider font-sans font-bold text-slate-700">
              ACCOUNTING AND CORPORATE REGULATORY AUTHORITY
            </span>
            <h2 className="text-lg font-bold mt-1 text-slate-900">CERTIFICATE OF INCORPORATION OF A PRIVATE COMPANY</h2>
          </div>

          <p className="text-justify indent-8">
            This is to certify that pursuant to Section 19(4) of the Companies Act, the company whose details are set forth below is duly incorporated and that the liability of the members is limited.
          </p>

          <div className="p-4 bg-slate-50 border border-slate-300 rounded font-sans space-y-2 text-xs">
            <div className="grid grid-cols-3 gap-2 border-b border-slate-200 pb-1.5">
              <span className="text-slate-500 font-medium">Company Name:</span>
              <span className="col-span-2 font-bold text-slate-900">{document.ocrData?.['Company Name'] || 'Apex Holdings Global Pte Ltd'}</span>
            </div>
            <div className="grid grid-cols-3 gap-2 border-b border-slate-200 pb-1.5">
              <span className="text-slate-500 font-medium">Company Registration / UEN:</span>
              <span className="col-span-2 font-bold font-mono text-slate-900">{document.ocrData?.['Registration Number (UEN)'] || '201934812K'}</span>
            </div>
            <div className="grid grid-cols-3 gap-2 border-b border-slate-200 pb-1.5">
              <span className="text-slate-500 font-medium">Date of Incorporation:</span>
              <span className="col-span-2 font-bold text-slate-900">{document.ocrData?.['Date of Incorporation'] || '14 October 2019'}</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <span className="text-slate-500 font-medium">Registered Address:</span>
              <span className="col-span-2 text-slate-800">{document.ocrData?.['Registered Address'] || '12 Marina Boulevard #28-01, MBFC Tower 3, Singapore 018982'}</span>
            </div>
          </div>

          <div className="pt-8 flex justify-between items-end font-sans">
            <div className="text-left">
              <div className="w-28 h-12 border-b border-slate-400 mb-1 flex items-center justify-center italic text-slate-400 text-xs">
                [Official Digital Seal]
              </div>
              <span className="text-[10px] text-slate-500 block">Registrar of Companies</span>
            </div>
            <div className="text-right">
              <span className="text-[10px] font-mono text-slate-400">Auth Code: ACRA-SG-92840182</span>
            </div>
          </div>
        </div>
      )}

      {isBoardRes && (
        <div className="space-y-5 text-sm leading-relaxed text-left">
          <div className="text-center py-2 border-y border-slate-300">
            <h2 className="text-base font-bold text-slate-900 uppercase">EXTRACT OF MINUTES & BOARD RESOLUTION</h2>
            <span className="text-xs font-sans text-slate-600">APPOINTMENT OF AUTHORISED BANKING SIGNATORIES</span>
          </div>

          <p className="text-justify">
            At a duly convened meeting of the Board of Directors, it was unanimously RESOLVED that the Company establish and maintain institutional banking facilities and that the following officers are authorised to execute transactions on behalf of the company:
          </p>

          <div className="space-y-3 font-sans text-xs">
            <div className="p-3 bg-slate-50 border border-slate-200 rounded">
              <span className="font-bold text-slate-900 block mb-1">Authorised Signatory Group A:</span>
              <p className="text-slate-700">{document.ocrData?.['Authorised Signatory 1'] || 'Elena Rostova (Managing Director)'}</p>
            </div>
            <div className="p-3 bg-slate-50 border border-slate-200 rounded">
              <span className="font-bold text-slate-900 block mb-1">Authorised Signatory Group B:</span>
              <p className="text-slate-700">{document.ocrData?.['Authorised Signatory 2'] || 'Michael Chen (Chief Financial Officer)'}</p>
            </div>
            <div className="p-3 bg-slate-50 border border-slate-200 rounded">
              <span className="font-bold text-slate-900 block mb-1">Signing Mandate / Operational Matrix:</span>
              <p className="text-slate-700">{document.ocrData?.['Banking Mandate'] || 'Dual signatures required for transactions exceeding SGD 500,000 equivalent.'}</p>
            </div>
          </div>

          <div className="pt-6 flex justify-between items-end font-sans">
            <div>
              <div className="w-32 h-10 border-b border-slate-400 mb-1 flex items-center justify-center italic text-slate-400 text-xs">
                Elena Rostova
              </div>
              <span className="text-[10px] text-slate-500 block font-bold">Elena Rostova, Managing Director</span>
            </div>
            <div>
              <div className="w-32 h-10 border-b border-slate-400 mb-1 flex items-center justify-center italic text-slate-400 text-xs">
                Michael Chen
              </div>
              <span className="text-[10px] text-slate-500 block font-bold">Michael Chen, CFO & Secretary</span>
            </div>
          </div>
        </div>
      )}

      {isUbo && (
        <div className="space-y-5 text-sm leading-relaxed text-left">
          <div className="text-center py-2 border-y border-slate-300">
            <h2 className="text-base font-bold text-slate-900 uppercase">REGISTER OF REGISTRABLE CONTROLLERS (RORC)</h2>
            <span className="text-xs font-sans text-slate-600">CONFIRMATION OF ULTIMATE BENEFICIAL OWNERSHIP</span>
          </div>

          <p className="text-xs text-justify font-sans text-slate-600">
            Pursuant to statutory regulatory mandates on anti-money laundering and corporate transparency, the following individual(s) hold significant interest (exceeding 25% voting power or ownership equity):
          </p>

          <table className="w-full text-left font-sans text-xs border border-slate-300">
            <thead className="bg-slate-100 border-b border-slate-300 text-slate-700">
              <tr>
                <th className="p-2 border-r border-slate-300">Controller Name</th>
                <th className="p-2 border-r border-slate-300">Equity / Voting %</th>
                <th className="p-2">Nature of Control</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              <tr>
                <td className="p-2 border-r border-slate-300 font-bold text-slate-900">
                  {document.ocrData?.['Primary Controller'] || 'Elena Rostova'}
                </td>
                <td className="p-2 border-r border-slate-300 font-mono font-bold text-emerald-800">
                  65.00%
                </td>
                <td className="p-2 text-slate-700">Direct Shareholding & Board Control</td>
              </tr>
              <tr>
                <td className="p-2 border-r border-slate-300 font-bold text-slate-900">
                  {document.ocrData?.['Secondary Controller'] || 'Apex Capital Investments Ltd'}
                </td>
                <td className="p-2 border-r border-slate-300 font-mono text-slate-800">
                  35.00%
                </td>
                <td className="p-2 text-slate-700">Institutional Holding Entity</td>
              </tr>
            </tbody>
          </table>

          <div className="p-3 bg-slate-50 border border-slate-200 rounded font-sans text-xs">
            <span className="font-bold text-slate-800 block">Filing Confirmation:</span>
            <p className="text-slate-600 text-[11px] mt-0.5">
              {document.ocrData?.['ACRA Filing Status'] || 'Lodged and verified in Electronic Register of Registrable Controllers (RORC)'}
            </p>
          </div>
        </div>
      )}

      {isFinancials && (
        <div className="space-y-4 text-sm text-left">
          <div className="text-center py-2 border-y border-slate-300 font-sans">
            <h2 className="text-base font-bold text-slate-900">INDEPENDENT AUDITOR'S REPORT</h2>
            <span className="text-xs text-slate-600">FINANCIAL STATEMENTS FOR YEAR ENDED 31 DECEMBER 2025</span>
          </div>

          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded font-sans text-xs">
            <span className="font-bold text-emerald-900 block">Auditor Opinion:</span>
            <p className="text-emerald-800 text-[11px] mt-0.5">
              {document.ocrData?.['Audit Opinion'] || 'In our opinion, the financial statements present fairly, in all material respects, the financial position of the Group.'}
            </p>
            <span className="text-[10px] text-emerald-700 font-mono mt-1 block">Firm: {document.ocrData?.['Audit Firm'] || 'PricewaterhouseCoopers LLP'}</span>
          </div>

          <div className="font-sans text-xs space-y-2">
            <h3 className="font-bold text-slate-900">Key Financial Highlights (USD)</h3>
            <div className="grid grid-cols-3 gap-2">
              <div className="p-2.5 bg-slate-50 border border-slate-200 rounded">
                <span className="text-[10px] text-slate-500 block">Total Revenue</span>
                <span className="font-bold font-mono text-slate-900 text-sm">{document.ocrData?.['Total Revenue (FY2025)'] || '$42,500,000'}</span>
              </div>
              <div className="p-2.5 bg-slate-50 border border-slate-200 rounded">
                <span className="text-[10px] text-slate-500 block">Net Profit Pre-Tax</span>
                <span className="font-bold font-mono text-emerald-700 text-sm">{document.ocrData?.['Net Profit Before Tax'] || '$8,420,000'}</span>
              </div>
              <div className="p-2.5 bg-slate-50 border border-slate-200 rounded">
                <span className="text-[10px] text-slate-500 block">Total Assets</span>
                <span className="font-bold font-mono text-slate-900 text-sm">{document.ocrData?.['Total Assets'] || '$78,900,000'}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {isPassport && (
        <div className="space-y-5 text-sm text-left">
          <div className="text-center py-2 border-y border-slate-300 font-sans">
            <h2 className="text-base font-bold text-slate-900">OFFICIAL PASSPORT & IDENTITY VERIFICATION</h2>
            <span className="text-xs text-slate-600">NOTARISED & CERTIFIED TRUE COPY</span>
          </div>

          <div className="p-4 bg-slate-50 border border-slate-300 rounded font-sans text-xs space-y-2">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <span className="text-slate-500 block text-[10px]">Full Name:</span>
                <span className="font-bold text-slate-900 text-sm">{document.ocrData?.['Full Name'] || 'Elena Rostova'}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">Passport No:</span>
                <span className="font-bold font-mono text-slate-900 text-sm">{document.ocrData?.['Passport Number'] || 'E74920148'}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">Nationality:</span>
                <span className="font-bold text-slate-800">{document.ocrData?.['Nationality'] || 'Singaporean'}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">Date of Birth / Expiry:</span>
                <span className="font-bold text-slate-800">{document.ocrData?.['Date of Birth'] || '12 March 1982'} (Exp: {document.ocrData?.['Expiry Date'] || '2034'})</span>
              </div>
            </div>
          </div>

          <div className="p-3 bg-blue-50 border border-blue-200 rounded font-sans text-xs text-blue-900">
            <span className="font-bold block">Notary Certification:</span>
            <p className="text-[11px] text-blue-800 mt-0.5">
              {document.ocrData?.['Certification'] || 'Certified as a genuine and authentic photographic identity document.'}
            </p>
          </div>
        </div>
      )}

      {/* Fallback for general uploaded documents */}
      {!isIncorporation && !isBoardRes && !isUbo && !isFinancials && !isPassport && (
        <div className="space-y-4 text-sm font-sans text-left">
          <div className="p-4 bg-slate-50 border border-slate-200 rounded space-y-2">
            <span className="font-bold text-slate-900 text-xs block uppercase">Document Metadata & Verification Record</span>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="text-slate-500 block text-[10px]">File Name:</span>
                <span className="font-mono font-bold text-slate-800">{document.name}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">File Size:</span>
                <span className="font-mono text-slate-800">{document.size}</span>
              </div>
            </div>
          </div>

          {document.ocrData && Object.keys(document.ocrData).length > 0 ? (
            <div className="space-y-2">
              <span className="text-xs font-bold text-slate-800">Extracted OCR Attributes:</span>
              <div className="divide-y divide-slate-200 border border-slate-200 rounded bg-white text-xs">
                {Object.entries(document.ocrData).map(([k, v]) => (
                  <div key={k} className="p-2.5 flex justify-between items-center">
                    <span className="font-bold text-slate-700">{k}:</span>
                    <span className="font-mono text-slate-900 text-right">{v}</span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="p-6 text-center text-slate-500 bg-slate-50 rounded border border-dashed border-slate-300">
              <FileText className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <p className="text-xs">Standard scanned PDF container. OCR parsing completed.</p>
            </div>
          )}
        </div>
      )}

      {/* Footer Security Seal */}
      <div className="mt-12 pt-4 border-t border-slate-200 flex items-center justify-between text-[10px] font-sans text-slate-400">
        <span>Onboard.ai Secure Document Vault</span>
        <span className="flex items-center gap-1 font-mono">
          <Lock className="w-3 h-3 text-slate-400" /> Tamper-Evident SHA-256 Hash Verified
        </span>
      </div>
    </div>
  );
}

export function DocumentViewerModal({
  document,
  isOpen,
  onClose,
  onApprove,
  onReject,
  onApproveDoc,
  onRejectDoc,
  readOnly = false,
  userRole = 'customer'
}: DocumentViewerModalProps) {
  const [zoomLevel, setZoomLevel] = useState(100);
  const [rotation, setRotation] = useState(0);
  const [showRejectInput, setShowRejectInput] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const handleApprove = () => {
    if (onApprove && document) onApprove(document.id);
    if (onApproveDoc && document) onApproveDoc(document.id);
  };

  const handleReject = (reason?: string) => {
    if (onReject && document) onReject(document.id, reason);
    if (onRejectDoc && document) onRejectDoc(document.id, reason);
  };

  const handleCopy = (key: string, val: string) => {
    navigator.clipboard.writeText(val);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 1800);
  };

  if (!isOpen || !document) return null;

  const handleZoomIn = () => setZoomLevel(prev => Math.min(prev + 20, 200));
  const handleZoomOut = () => setZoomLevel(prev => Math.max(prev - 20, 60));
  const handleRotate = () => setRotation(prev => (prev + 90) % 360);

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-hidden">
      {/* White Screen Modal Frame */}
      <div className="bg-white border border-slate-200 w-full max-w-7xl h-[94vh] rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-fade-in text-slate-900">
        
        {/* Top Control Bar */}
        <div className="px-5 py-3.5 bg-white border-b border-slate-200 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="p-2 rounded-xl bg-blue-50 text-blue-600 border border-blue-200 shrink-0">
              <FileText className="w-5 h-5" />
            </div>
            <div className="min-w-0 text-left">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base font-bold text-slate-900 truncate" title={document.name}>
                  {document.name}
                </h2>
                <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase shrink-0 ${
                  document.status === 'verified' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                  document.status === 'rejected' ? 'bg-rose-50 text-rose-700 border border-rose-200' :
                  'bg-amber-50 text-amber-700 border border-amber-200'
                }`}>
                  {document.status}
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-slate-100 text-slate-600 border border-slate-200">
                  Doc ID: {document.id}
                </span>
              </div>
              <p className="text-xs text-slate-500 font-mono truncate mt-0.5">
                {document.type} • {document.size} • Uploaded: {document.uploadedAt}
              </p>
            </div>
          </div>

          {/* Controls: Zoom, Rotate, Close */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="flex items-center bg-slate-100 rounded-xl p-0.5 border border-slate-200">
              <button
                onClick={handleZoomOut}
                disabled={zoomLevel <= 60}
                className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-white rounded-lg transition cursor-pointer disabled:opacity-40"
                title="Zoom Out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="text-[11px] font-mono font-bold px-2 text-slate-700">{zoomLevel}%</span>
              <button
                onClick={handleZoomIn}
                disabled={zoomLevel >= 200}
                className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-white rounded-lg transition cursor-pointer disabled:opacity-40"
                title="Zoom In"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
            </div>

            <button
              onClick={handleRotate}
              className="p-2 text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl border border-slate-200 transition cursor-pointer"
              title="Rotate 90°"
            >
              <RotateCw className="w-4 h-4" />
            </button>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl border border-slate-200 transition cursor-pointer ml-1"
              title="Close Viewer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* =========================================================================
            DOCUMENT OVERVIEW AT THE TOP OF THE PAGE
            ========================================================================= */}
        <div className="bg-slate-50/90 border-b border-slate-200 px-5 py-3 flex flex-col md:flex-row md:items-center justify-between gap-4 shrink-0 text-left">
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-xs">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Document Type</span>
              <span className="font-bold text-slate-900">{document.type}</span>
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Uploaded Timestamp</span>
              <span className="font-mono text-slate-700">{document.uploadedAt}</span>
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">File Size</span>
              <span className="font-mono text-slate-700">{document.size}</span>
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Source Ingestion</span>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                  document.source === 'externally_sourced' 
                    ? 'bg-sky-50 text-sky-700 border border-sky-200' 
                    : 'bg-blue-50 text-blue-700 border border-blue-200'
                }`}>
                  {document.source === 'externally_sourced' ? '🌐 Externally Sourced' : '👤 Customer Provided'}
                </span>
                {document.sourceDetails && (
                  <span className="text-[11px] text-slate-500 font-mono hidden sm:inline">
                    ({document.sourceDetails})
                  </span>
                )}
              </div>
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Vault Integrity</span>
              <span className="inline-flex items-center gap-1 text-[11px] font-mono text-emerald-700 font-semibold mt-0.5">
                <Lock className="w-3 h-3 text-emerald-600" /> Tamper-Evident SHA-256 Verified
              </span>
            </div>
          </div>

          {/* Operational Action Buttons in Document Overview Header */}
          {!readOnly && (userRole === 'rm' || userRole === 'compliance') && (
            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={handleApprove}
                className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Approve Document</span>
              </button>
              <button
                onClick={() => setShowRejectInput(true)}
                className="px-3 py-1.5 bg-white hover:bg-rose-50 text-rose-700 font-bold text-xs rounded-xl border border-rose-200 transition flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <AlertTriangle className="w-4 h-4 text-rose-500" />
                <span>Reject / Re-upload</span>
              </button>
            </div>
          )}
        </div>

        {/* Inline Rejection Reason Prompt (if triggered) */}
        {showRejectInput && (
          <div className="p-3.5 bg-rose-50 border-b border-rose-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-left">
            <div className="flex items-center gap-2 flex-1">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <input
                type="text"
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                placeholder="Specify rejection reason (e.g., Unclear signature, expired validity period, missing witness)..."
                className="w-full p-2 bg-white border border-rose-300 rounded-lg text-slate-900 text-xs outline-none focus:ring-2 focus:ring-rose-400"
              />
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => setShowRejectInput(false)}
                className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-lg text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  handleReject(rejectionReason);
                  setShowRejectInput(false);
                }}
                className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-lg text-xs cursor-pointer shadow-xs"
              >
                Confirm Reject
              </button>
            </div>
          </div>
        )}

        {/* =========================================================================
            SIDE-BY-SIDE SPLIT: PREVIEW ON LEFT, EXTRACTED ATTRIBUTES ON RIGHT
            ========================================================================= */}
        <div className="flex-1 overflow-hidden grid grid-cols-1 lg:grid-cols-12 bg-white">
          
          {/* LEFT: DOCUMENT PREVIEW */}
          <div className="lg:col-span-7 bg-slate-100/70 border-r border-slate-200 overflow-y-auto p-4 sm:p-8 flex justify-center items-start relative h-full">
            <DocumentPreviewCanvas document={document} zoomLevel={zoomLevel} rotation={rotation} />
          </div>

          {/* RIGHT: EXTRACTED ATTRIBUTES */}
          <div className="lg:col-span-5 bg-white overflow-y-auto p-5 flex flex-col justify-between h-full text-left space-y-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <Layers className="w-4 h-4 text-blue-600" />
                    <span>Extracted Attributes</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    LayoutLMv3 OCR Pipeline • High-Confidence Field Mapping
                  </p>
                </div>
                <span className="px-2.5 py-1 rounded-full text-[10px] font-mono font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  99.4% AI Match
                </span>
              </div>

              {/* Key-Value Attributes List */}
              {document.ocrData && Object.keys(document.ocrData).length > 0 ? (
                <div className="space-y-2.5">
                  {Object.entries(document.ocrData).map(([key, val]) => (
                    <div 
                      key={key} 
                      className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5 hover:border-blue-300 transition-colors group"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[11px] font-bold text-slate-600 font-mono uppercase tracking-wider">{key}</span>
                        <button
                          onClick={() => handleCopy(key, String(val))}
                          className="text-[10px] text-slate-400 hover:text-blue-600 font-medium flex items-center gap-1 cursor-pointer transition"
                          title="Copy value"
                        >
                          {copiedKey === key ? (
                            <span className="text-emerald-600 font-bold flex items-center gap-1">
                              <CheckCheck className="w-3 h-3" /> Copied
                            </span>
                          ) : (
                            <span className="flex items-center gap-1 opacity-60 group-hover:opacity-100">
                              <Copy className="w-3 h-3" /> Copy
                            </span>
                          )}
                        </button>
                      </div>
                      <div className="text-xs font-semibold text-slate-900 bg-white p-2.5 rounded-lg border border-slate-200 font-mono break-words">
                        {String(val)}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-16 text-center text-slate-400 bg-slate-50 rounded-2xl border border-dashed border-slate-200 p-6">
                  <Layers className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                  <p className="text-xs font-medium">No key-value OCR attributes found for this document.</p>
                </div>
              )}
            </div>

            {/* Bottom Compliance & Vault Assurance */}
            <div className="pt-4 border-t border-slate-100 space-y-2 text-xs">
              <div className="p-3 bg-blue-50/70 border border-blue-200/80 rounded-xl space-y-1 text-blue-900">
                <div className="flex items-center gap-1.5 font-bold text-blue-800 text-xs">
                  <ShieldCheck className="w-4 h-4 text-blue-600" />
                  <span>Bank-Grade Read-Only Vault</span>
                </div>
                <p className="text-[11px] text-blue-700 leading-relaxed">
                  Document rendered directly in secure sandbox memory. Direct file downloads are disabled to enforce institutional compliance governance.
                </p>
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
