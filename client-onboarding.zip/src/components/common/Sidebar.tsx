import React, { useState } from 'react';
import { 
  LogOut, 
  Building2, 
  Bell, 
  Plus, 
  Menu, 
  X, 
  CheckCircle2, 
  ShieldCheck, 
  Activity,
  ArrowRightLeft
} from 'lucide-react';
import { AppPersona, ClientProfile } from '../../types';
import { PERSONA_TABS } from '../../constants/personaTabs';

interface SidebarProps {
  activePersona: AppPersona;
  currentPersonaInfo?: { name: string; role: string };
  activeTab: string;
  setActiveTab: (tabId: string) => void;
  onSwitchPersona: () => void;
  activeClient?: ClientProfile | null;
  clients?: ClientProfile[];
  onSelectClient?: (clientId: string) => void;
  unreadNotifCount?: number;
  onInitiateJourney?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activePersona,
  currentPersonaInfo,
  activeTab,
  setActiveTab,
  onSwitchPersona,
  activeClient,
  clients = [],
  onSelectClient,
  unreadNotifCount = 0,
  onInitiateJourney,
}) => {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  // Ensure copilot panel is never rendered in left menu navigation for all personas,
  // and for customer persona remove the "notifications and alerts" text tab
  const activeTabsList = (PERSONA_TABS[activePersona] || []).filter(tab => 
    tab.id !== 'copilot' && 
    tab.id !== 'copilot_panel' && 
    !tab.label.toLowerCase().includes('copilot') &&
    !(activePersona === 'customer' && tab.id === 'notifications')
  );

  const personaBadges: Record<AppPersona, string> = {
    platform_admin: 'Admin Control Plane',
    rm: 'RM Cockpit Node',
    compliance_officer: 'Compliance Gateway',
    operations_officer: 'Operations Hub',
    customer: 'Customer Self-Service'
  };

  const getInitials = (name?: string) => {
    if (!name) return 'US';
    return name
      .split(' ')
      .map(part => part[0])
      .slice(0, 2)
      .join('')
      .toUpperCase();
  };

  const calculateReadiness = (client?: ClientProfile | null) => {
    if (!client || !client.workflowNodes) return 0;
    const completed = client.workflowNodes.filter(n => n.status === 'completed').length;
    return Math.round((completed / client.workflowNodes.length) * 100);
  };

  const readinessScore = calculateReadiness(activeClient);

  const sidebarContent = (
    <div className="flex flex-col h-full w-full bg-white text-slate-700">
      {/* Brand & Persona Header */}
      <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-white shrink-0 w-full">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-blue-600 rounded-xl text-white flex items-center justify-center font-black shadow-xs tracking-tighter w-8 h-8 text-sm">
            O
          </div>
          <div className="text-left">
            <div className="flex items-center gap-1.5">
              <h2 className="font-bold text-sm tracking-tight text-slate-900">Onboard.ai</h2>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" title="System Online" />
            </div>
            <span className="text-[10px] font-bold text-blue-600 tracking-wider block uppercase font-mono">
              {personaBadges[activePersona] || 'Workspace'}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Bell Symbol Icon Button for Customer */}
          {activePersona === 'customer' && (
            <button
              type="button"
              id="btn-sidebar-customer-bell"
              onClick={() => setActiveTab(activeTab === 'notifications' ? 'self_service_dashboard' : 'notifications')}
              className={`relative p-2 rounded-xl border transition cursor-pointer flex items-center justify-center shadow-xs ${
                activeTab === 'notifications'
                  ? 'bg-blue-600 text-white border-blue-600 ring-2 ring-blue-500/20'
                  : 'bg-slate-50 hover:bg-slate-100 text-slate-600 hover:text-slate-900 border-slate-200'
              }`}
              title={`Notifications (${unreadNotifCount} unread)`}
              aria-label="Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadNotifCount > 0 && (
                <span className="absolute -top-1 -right-1 px-1.5 py-0.2 bg-rose-600 text-[9px] font-black text-white rounded-full min-w-4 text-center leading-tight shadow-xs">
                  {unreadNotifCount}
                </span>
              )}
            </button>
          )}

          {/* Mobile Close Button */}
          <button
            type="button"
            onClick={() => setIsMobileOpen(false)}
            className="md:hidden p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* User Persona Profile Card (Hidden for RM, Operations, Compliance, and Customer as moved to top header) */}
      {activePersona !== 'rm' && activePersona !== 'operations_officer' && activePersona !== 'compliance_officer' && activePersona !== 'customer' && (
        <div className="p-3.5 mx-3 mt-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between gap-2.5 text-left shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center shrink-0 border border-blue-200">
              {getInitials(currentPersonaInfo?.name)}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-bold text-slate-900 truncate">
                {currentPersonaInfo?.name || 'Active User'}
              </p>
              <p className="text-[10px] font-medium text-slate-500 truncate">
                {currentPersonaInfo?.role || 'Institutional Access'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onSwitchPersona}
            title="Switch Persona / Log out"
            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer shrink-0"
          >
            <ArrowRightLeft className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Active Client / Journey Selector Card (Hidden for RM, Operations, Compliance, Customer, and Admin as moved to top header/workspace) */}
      {activeClient && activePersona !== 'platform_admin' && activePersona !== 'rm' && activePersona !== 'operations_officer' && activePersona !== 'compliance_officer' && activePersona !== 'customer' && (
        <div className="p-3.5 mx-3 mt-2.5 bg-slate-50/80 border border-slate-200 rounded-xl text-left shrink-0">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[9px] font-bold font-mono text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <Building2 className="w-3 h-3 text-blue-600" />
              {activePersona === 'customer' ? 'Corporate Account' : 'Active Journey'}
            </span>
            {activePersona === 'customer' ? (
              <span className="text-[9px] font-mono font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                {readinessScore}% READY
              </span>
            ) : (
              <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded border ${
                activeClient.overallStatus === 'approved'
                  ? 'text-emerald-700 bg-emerald-50 border-emerald-200'
                  : 'text-amber-700 bg-amber-50 border-amber-200'
              }`}>
                {activeClient.overallStatus === 'approved' ? 'APPROVED' : 'IN PROGRESS'}
              </span>
            )}
          </div>

          {/* Switcher Dropdown for Staff if multiple clients */}
          {activePersona !== 'customer' && clients.length > 1 && onSelectClient ? (
            <div className="relative mt-1">
              <select
                value={activeClient.id}
                onChange={(e) => onSelectClient(e.target.value)}
                className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1.5 text-xs font-bold text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 cursor-pointer truncate"
              >
                {clients.map(c => (
                  <option key={c.id} value={c.id}>
                    {c.companyName}
                  </option>
                ))}
              </select>
            </div>
          ) : (
            <p className="text-xs font-bold text-slate-900 truncate">
              {activeClient.companyName}
            </p>
          )}

          <div className="mt-1.5 flex items-center justify-between text-[10px] text-slate-500 font-mono">
            <span>UEN: {activeClient.registrationNumber || 'N/A'}</span>
            <span>{activeClient.jurisdiction}</span>
          </div>

          {/* Quick Initiate Journey button for non-RM staff */}
          {activePersona !== 'customer' && onInitiateJourney && (
            <button
              type="button"
              onClick={onInitiateJourney}
              className="mt-2.5 w-full flex items-center justify-center gap-1.5 py-1 px-2 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 text-[11px] font-bold border border-blue-200 transition cursor-pointer"
            >
              <Plus className="w-3 h-3" />
              <span>Initiate New Journey</span>
            </button>
          )}
        </div>
      )}

      {/* Dynamic Navigation Links based on active persona */}
      <nav className="flex-1 py-3 px-0 space-y-0.5 overflow-y-auto mt-1 w-full">
        <span className="text-[9px] font-bold font-mono text-slate-400 uppercase tracking-widest block px-4 mb-2">
          {activePersona === 'customer' ? 'PORTAL NAVIGATION' : 'WORKSPACE MODULES'}
        </span>

        {activeTabsList.map(tab => {
          const IconComponent = tab.icon;
          const isSelected = activeTab === tab.id;
          const isNotificationTab = tab.id === 'notifications';
          const badgeCount = isNotificationTab ? unreadNotifCount : 0;

          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => {
                setActiveTab(tab.id);
                setIsMobileOpen(false);
              }}
              className={`w-full flex items-center justify-start text-left gap-3 px-4 py-2.5 text-xs transition-all duration-150 cursor-pointer ${
                isSelected 
                  ? 'bg-blue-600 text-white shadow-xs font-bold' 
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50 font-semibold'
              }`}
            >
              <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 transition-colors ${
                isSelected 
                  ? 'bg-blue-700 text-white shadow-xs' 
                  : 'bg-slate-100 text-slate-500 border border-slate-200'
              }`}>
                <IconComponent className="w-3.5 h-3.5" />
              </div>
              
              <span className="text-left flex-1 leading-snug truncate">
                {tab.label}
              </span>

              {badgeCount > 0 && (
                <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold min-w-4 text-center leading-none ${
                  isSelected 
                    ? 'bg-white text-blue-700' 
                    : 'bg-rose-600 text-white'
                }`}>
                  {badgeCount}
                </span>
              )}
            </button>
          );
        })}

        {/* Session Switcher / Logout (Hidden for RM, Ops, Compliance, Customer as logout is in top header) */}
        {activePersona !== 'rm' && activePersona !== 'operations_officer' && activePersona !== 'compliance_officer' && activePersona !== 'customer' && (
          <div className="pt-3 mt-3 border-t border-slate-100 w-full">
            <span className="text-[9px] font-bold font-mono text-slate-400 uppercase tracking-widest block px-4 mb-1.5">
              SESSION CONTROL
            </span>
            <button
              type="button"
              onClick={onSwitchPersona}
              className="w-full flex items-center justify-start text-left gap-3 px-4 py-2.5 text-xs font-semibold text-slate-600 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer"
            >
              <div className="w-7 h-7 rounded-lg flex items-center justify-center bg-slate-100 border border-slate-200 shadow-xs shrink-0 text-slate-500">
                <LogOut className="w-3.5 h-3.5" />
              </div>
              <span className="text-left flex-1">Exit / Switch Persona</span>
            </button>
          </div>
        )}
      </nav>
    </div>
  );

  return (
    <>
      {/* Mobile Bar on small screens */}
      <div className="md:hidden bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between z-30 sticky top-0 w-full">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-blue-600 rounded-lg text-white font-bold text-xs">
            O
          </div>
          <div>
            <h2 className="font-bold text-xs text-slate-900">Onboard.ai</h2>
            <span className="text-[9px] font-bold text-blue-600 uppercase font-mono">
              {personaBadges[activePersona] || 'Node'}
            </span>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setIsMobileOpen(true)}
          className="p-2 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 cursor-pointer"
          aria-label="Open menu"
        >
          <Menu className="w-5 h-5" />
        </button>
      </div>

      {/* Mobile Drawer Overlay */}
      {isMobileOpen && (
        <div className="md:hidden fixed inset-0 z-50 flex">
          <div 
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs" 
            onClick={() => setIsMobileOpen(false)} 
          />
          <div className="relative w-72 max-w-[85vw] h-full shadow-2xl z-10 flex flex-col">
            {sidebarContent}
          </div>
        </div>
      )}

      {/* Desktop Left Sidebar (always visible on md+) */}
      <aside className="hidden md:flex flex-col w-64 lg:w-72 h-screen sticky top-0 shrink-0 border-r border-slate-200 shadow-xs z-20 overflow-hidden">
        {sidebarContent}
      </aside>
    </>
  );
};

export default Sidebar;
