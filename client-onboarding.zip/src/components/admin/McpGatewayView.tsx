import React, { useState } from 'react';
import { 
  Server, 
  Plus, 
  Search, 
  Globe, 
  Database, 
  Link2, 
  Activity, 
  CheckCircle2, 
  AlertTriangle, 
  Trash2, 
  Edit3, 
  Bot, 
  Layers, 
  Wrench, 
  Sliders, 
  Check, 
  ExternalLink,
  Zap,
  Lock,
  ArrowRight,
  ShieldCheck,
  RefreshCw
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { OrchestrationAgent } from '../../types';
import { DeleteConfirmModal } from '../common/DeleteConfirmModal';

export interface McpGatewayConfig {
  id: string;
  name: string;
  url: string;
  protocol: 'mcp-sse' | 'mcp-stdio' | 'mcp-websocket' | 'mcp-http';
  status: 'ONLINE' | 'DEGRADED' | 'OFFLINE';
  description: string;
  associatedAgentIds: string[];
  associatedApiIds: string[];
  latencyMs: number;
  uptime: string;
  toolsCount: number;
  environment: 'PRODUCTION' | 'STAGING' | 'SANDBOX';
  authType: 'BEARER_TOKEN' | 'MTLS' | 'API_KEY' | 'NONE';
  lastHeartbeat: string;
}

export interface CatalogApi {
  id: string;
  name: string;
  domain: string;
  process: string;
  endpoint: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  description: string;
  category: 'REGISTRY' | 'AML_COMPLIANCE' | 'BANKING_CORE' | 'DOCUMENT_AI' | 'CREDIT_RISK';
}

const DEFAULT_MCP_GATEWAYS: McpGatewayConfig[] = [
  {
    id: 'gw-acra-reg',
    name: 'Singapore ACRA & Corporate Registry Gateway',
    url: 'mcp://gateway.internal.bank.corp:8080/mcp/v1/acra',
    protocol: 'mcp-sse',
    status: 'ONLINE',
    description: 'Bridges institutional agents to Singapore ACRA Business Registry, BizFile+, and Companies House databases.',
    associatedAgentIds: ['lead_intelligence_agent', 'entity_resolution_agent', 'kyb_agent'],
    associatedApiIds: ['api-acra-01', 'api-acra-02', 'api-ch-01'],
    latencyMs: 84,
    uptime: '99.98%',
    toolsCount: 6,
    environment: 'PRODUCTION',
    authType: 'MTLS',
    lastHeartbeat: 'Just now'
  },
  {
    id: 'gw-fcc-screening',
    name: 'Financial Crime & Sanctions Screening Gateway',
    url: 'mcp://gateway.internal.bank.corp:8080/mcp/v1/sanctions',
    protocol: 'mcp-sse',
    status: 'ONLINE',
    description: 'High-throughput low-latency bridge to World-Check One, Dow Jones Watchlists, and MAS Anti-Money Laundering networks.',
    associatedAgentIds: ['sanctions_screener', 'adverse_news_agent', 'ubo_unwrapper_agent'],
    associatedApiIds: ['api-dowjones-01', 'api-worldcheck-01', 'api-mas-aml'],
    latencyMs: 110,
    uptime: '99.99%',
    toolsCount: 8,
    environment: 'PRODUCTION',
    authType: 'BEARER_TOKEN',
    lastHeartbeat: '3s ago'
  },
  {
    id: 'gw-doc-intel',
    name: 'Forensic Document Intelligence OCR Bridge',
    url: 'mcp://gateway.internal.bank.corp:8080/mcp/v1/document-intel',
    protocol: 'mcp-http',
    status: 'ONLINE',
    description: 'Extracts tabular and key-value fields from Certificates of Incorporation, Passports, and Board Resolutions with anti-spoofing.',
    associatedAgentIds: ['doc_verification_agent'],
    associatedApiIds: ['api-ocr-doc-01', 'api-tamper-scan'],
    latencyMs: 145,
    uptime: '99.95%',
    toolsCount: 4,
    environment: 'PRODUCTION',
    authType: 'API_KEY',
    lastHeartbeat: '12s ago'
  },
  {
    id: 'gw-core-ledger',
    name: 'Institutional Core Banking & Ledger Gateway',
    url: 'mcp://gateway.internal.bank.corp:8080/mcp/v1/core-banking',
    protocol: 'mcp-sse',
    status: 'ONLINE',
    description: 'Interface for provisioning multi-currency IBANs, limits, and customer KYC records directly in Avaloq/Mambu core.',
    associatedAgentIds: ['onboarding_coordinator'],
    associatedApiIds: ['api-core-account-open', 'api-credit-limit-set'],
    latencyMs: 62,
    uptime: '100.00%',
    toolsCount: 5,
    environment: 'PRODUCTION',
    authType: 'MTLS',
    lastHeartbeat: 'Just now'
  }
];

const DEFAULT_AVAILABLE_APIS: CatalogApi[] = [
  { id: 'api-acra-01', name: 'ACRA Corporate Profile Fetch', domain: 'Corporate Registry', process: 'KYB Entity Verification', endpoint: '/api/v2/sg/acra/entity', method: 'GET', description: 'Retrieves UEN filings, registration dates, and share capital.', category: 'REGISTRY' },
  { id: 'api-acra-02', name: 'ACRA Directors & Officers Search', domain: 'Corporate Registry', process: 'Officer Disambiguation', endpoint: '/api/v2/sg/acra/officers', method: 'GET', description: 'Returns active directors and authorized signatories.', category: 'REGISTRY' },
  { id: 'api-ch-01', name: 'Companies House UK Search', domain: 'Corporate Registry', process: 'International Registry Lookup', endpoint: '/api/v1/uk/companies-house/search', method: 'GET', description: 'Retrieves UK corporate filings and PSC registers.', category: 'REGISTRY' },
  { id: 'api-dowjones-01', name: 'Dow Jones PEP & Sanctions Search', domain: 'Financial Crime', process: 'PEP / Watchlist Screening', endpoint: '/api/v3/fcc/dowjones/screen', method: 'POST', description: 'Scans individual & corporate names against OFAC, EU, UN, and MAS.', category: 'AML_COMPLIANCE' },
  { id: 'api-worldcheck-01', name: 'LSEG World-Check One Query', domain: 'Financial Crime', process: 'Secondary Watchlist Audit', endpoint: '/api/v2/worldcheck/cases', method: 'POST', description: 'Secondary compliance check for PEPs and adverse media.', category: 'AML_COMPLIANCE' },
  { id: 'api-mas-aml', name: 'MAS Anti-Money Laundering Register', domain: 'Regulatory Reporting', process: 'MAS Notice 626 Audit', endpoint: '/api/v1/mas/aml-register', method: 'GET', description: 'Queries regulatory sanctions and investor alerts in Singapore.', category: 'AML_COMPLIANCE' },
  { id: 'api-ocr-doc-01', name: 'Multimodal Constitution & PDF OCR', domain: 'Document Intelligence', process: 'Document OCR Ingestion', endpoint: '/api/v2/ocr/corporate-constitution', method: 'POST', description: 'Extracts clauses, shareholding tables, and notary stamps.', category: 'DOCUMENT_AI' },
  { id: 'api-tamper-scan', name: 'Anti-Spoofing & Forensic Tamper Check', domain: 'Document Intelligence', process: 'Document Forensics', endpoint: '/api/v2/forensics/tamper-scan', method: 'POST', description: 'Scans noise artifacts and EXIF anomalies to prevent fraud.', category: 'DOCUMENT_AI' },
  { id: 'api-core-account-open', name: 'Avaloq / Mambu Account Provisioner', domain: 'Core Banking', process: 'Account Activation', endpoint: '/api/v1/core/accounts/provision', method: 'POST', description: 'Creates live corporate accounts upon KYC approval.', category: 'BANKING_CORE' },
  { id: 'api-credit-limit-set', name: 'Credit Limit & Facility Setter', domain: 'Risk & Underwriting', process: 'Credit Approval', endpoint: '/api/v1/core/facilities/limits', method: 'PUT', description: 'Updates approved overdraft and revolving credit lines.', category: 'CREDIT_RISK' }
];

interface McpGatewayViewProps {
  agents?: OrchestrationAgent[];
}

export default function McpGatewayView({ agents = [] }: McpGatewayViewProps) {
  const [gateways, setGateways] = useState<McpGatewayConfig[]>(() => {
    const saved = localStorage.getItem('mcp_gateways_v2');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return DEFAULT_MCP_GATEWAYS;
      }
    }
    return DEFAULT_MCP_GATEWAYS;
  });

  const [availableApis] = useState<CatalogApi[]>(() => {
    const saved = localStorage.getItem('catalog_apis_v2');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return DEFAULT_AVAILABLE_APIS;
      }
    }
    return DEFAULT_AVAILABLE_APIS;
  });

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGateway, setSelectedGateway] = useState<McpGatewayConfig | null>(DEFAULT_MCP_GATEWAYS[0]);
  const [isRegistering, setIsRegistering] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [gatewayToDelete, setGatewayToDelete] = useState<McpGatewayConfig | null>(null);

  // Registration Form State
  const [formData, setFormData] = useState({
    name: '',
    url: '',
    protocol: 'mcp-sse' as 'mcp-sse' | 'mcp-http' | 'mcp-websocket',
    description: '',
    environment: 'PRODUCTION' as 'PRODUCTION' | 'STAGING' | 'SANDBOX',
    authType: 'MTLS' as 'BEARER_TOKEN' | 'MTLS' | 'API_KEY' | 'NONE',
    selectedApis: [] as string[],
    selectedAgents: [] as string[]
  });

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  const handleSaveGateway = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.url) return;

    const newGateway: McpGatewayConfig = {
      id: `gw-${Date.now()}`,
      name: formData.name,
      url: formData.url,
      protocol: formData.protocol,
      status: 'ONLINE',
      description: formData.description || 'Enterprise MCP Gateway bridge',
      associatedAgentIds: formData.selectedAgents,
      associatedApiIds: formData.selectedApis,
      latencyMs: Math.floor(Math.random() * 80) + 40,
      uptime: '100.00%',
      toolsCount: formData.selectedApis.length,
      environment: formData.environment,
      authType: formData.authType,
      lastHeartbeat: 'Just now'
    };

    const updated = [newGateway, ...gateways];
    setGateways(updated);
    localStorage.setItem('mcp_gateways_v2', JSON.stringify(updated));
    setSelectedGateway(newGateway);
    setIsRegistering(false);
    showToast(`MCP Gateway "${newGateway.name}" registered successfully!`);
    setFormData({
      name: '',
      url: '',
      protocol: 'mcp-sse',
      description: '',
      environment: 'PRODUCTION',
      authType: 'MTLS',
      selectedApis: [],
      selectedAgents: []
    });
  };

  const handleDeleteGateway = (gwId: string) => {
    const target = gateways.find(g => g.id === gwId);
    if (target) {
      setGatewayToDelete(target);
    }
  };

  const handleConfirmDeleteGateway = () => {
    if (!gatewayToDelete) return;
    const updated = gateways.filter(g => g.id !== gatewayToDelete.id);
    setGateways(updated);
    localStorage.setItem('mcp_gateways_v2', JSON.stringify(updated));
    if (selectedGateway?.id === gatewayToDelete.id) {
      setSelectedGateway(updated[0] || null);
    }
    setGatewayToDelete(null);
    showToast('MCP Gateway deleted');
  };

  const handleToggleApiAssociation = (gwId: string, apiId: string) => {
    const updated = gateways.map(gw => {
      if (gw.id !== gwId) return gw;
      const exists = gw.associatedApiIds.includes(apiId);
      const newApis = exists 
        ? gw.associatedApiIds.filter(id => id !== apiId)
        : [...gw.associatedApiIds, apiId];
      return { ...gw, associatedApiIds: newApis, toolsCount: newApis.length };
    });
    setGateways(updated);
    localStorage.setItem('mcp_gateways_v2', JSON.stringify(updated));
    if (selectedGateway && selectedGateway.id === gwId) {
      setSelectedGateway(updated.find(g => g.id === gwId) || null);
    }
    showToast('API association updated');
  };

  const handleToggleAgentAssociation = (gwId: string, agentId: string) => {
    const updated = gateways.map(gw => {
      if (gw.id !== gwId) return gw;
      const exists = gw.associatedAgentIds.includes(agentId);
      const newAgents = exists 
        ? gw.associatedAgentIds.filter(id => id !== agentId)
        : [...gw.associatedAgentIds, agentId];
      return { ...gw, associatedAgentIds: newAgents };
    });
    setGateways(updated);
    localStorage.setItem('mcp_gateways_v2', JSON.stringify(updated));
    if (selectedGateway && selectedGateway.id === gwId) {
      setSelectedGateway(updated.find(g => g.id === gwId) || null);
    }
    showToast('Agent binding updated');
  };

  const filteredGateways = gateways.filter(gw => {
    return gw.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      gw.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      gw.url.toLowerCase().includes(searchTerm.toLowerCase());
  });

  return (
    <div className="space-y-6 text-slate-800">
      {/* Toast Alert */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-5 right-5 z-50 bg-[#008752] text-white px-4 py-2.5 rounded-xl shadow-xl font-bold text-xs flex items-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header Banner */}
      <div className="bg-white border border-[#A8C4EC]/60 rounded-2xl p-6 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[#00A3E0] text-white rounded-xl shadow-sm">
            <Server className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-[#0B2545] tracking-tight">MCP Gateway Manager</h1>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-100 text-cyan-800 font-bold border border-cyan-300">
                Model Context Protocol v2024-11
              </span>
            </div>
            <p className="text-xs text-slate-600 mt-0.5">
              Provision Model Context Protocol bridges, bind enterprise API catalog endpoints, and assign tools to onboarding agents.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsRegistering(true)}
            className="px-3.5 py-2 bg-[#0474C4] hover:bg-[#008752] text-white font-bold text-xs rounded-xl shadow-sm transition flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Register MCP Bridge</span>
          </button>
        </div>
      </div>

      {/* Register New Modal / Drawer */}
      <AnimatePresence>
        {isRegistering && (
          <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto space-y-4 text-left"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <Server className="w-5 h-5 text-[#0474C4]" />
                  <h3 className="text-base font-bold text-[#0B2545]">Register New MCP Gateway Bridge</h3>
                </div>
                <button
                  onClick={() => setIsRegistering(false)}
                  className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleSaveGateway} className="space-y-4 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Bridge Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. MAS Regulatory Reporting MCP Bridge"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-[#F4F6F8] border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:ring-1 focus:ring-[#0474C4]"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">MCP Endpoint URL</label>
                    <input
                      type="text"
                      required
                      placeholder="mcp://gateway.internal.bank.corp:8080/mcp/v1/..."
                      value={formData.url}
                      onChange={(e) => setFormData({ ...formData, url: e.target.value })}
                      className="w-full font-mono bg-[#F4F6F8] border border-slate-200 rounded-xl px-3 py-2 text-slate-800 text-[11px] focus:outline-none focus:ring-1 focus:ring-[#0474C4]"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Protocol Type</label>
                    <select
                      value={formData.protocol}
                      onChange={(e) => setFormData({ ...formData, protocol: e.target.value as any })}
                      className="w-full bg-[#F4F6F8] border border-slate-200 rounded-xl px-3 py-2 text-slate-700 focus:outline-none"
                    >
                      <option value="mcp-sse">MCP Server-Sent Events (SSE)</option>
                      <option value="mcp-http">MCP HTTP Post Gateway</option>
                      <option value="mcp-websocket">MCP Full-Duplex WebSocket</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Description & Purpose</label>
                  <textarea
                    rows={2}
                    placeholder="Describe which enterprise data sources this MCP gateway exposes as tools..."
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="w-full bg-[#F4F6F8] border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Auth Strategy</label>
                    <select
                      value={formData.authType}
                      onChange={(e) => setFormData({ ...formData, authType: e.target.value as any })}
                      className="w-full bg-[#F4F6F8] border border-slate-200 rounded-xl px-3 py-2 text-slate-700 focus:outline-none"
                    >
                      <option value="MTLS">Mutual TLS (mTLS X.509)</option>
                      <option value="BEARER_TOKEN">OAuth2 / Bearer JWT</option>
                      <option value="API_KEY">Enterprise API Key</option>
                      <option value="NONE">None (Internal VPC)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Target Environment</label>
                    <select
                      value={formData.environment}
                      onChange={(e) => setFormData({ ...formData, environment: e.target.value as any })}
                      className="w-full bg-[#F4F6F8] border border-slate-200 rounded-xl px-3 py-2 text-slate-700 focus:outline-none"
                    >
                      <option value="PRODUCTION">Production</option>
                      <option value="STAGING">Staging</option>
                      <option value="SANDBOX">Sandbox</option>
                    </select>
                  </div>
                </div>

                {/* Associate APIs from Catalog */}
                <div className="space-y-1.5 pt-2">
                  <label className="block font-bold text-[#0B2545] text-xs">
                    Associate APIs from Catalog ({formData.selectedApis.length} selected)
                  </label>
                  <div className="max-h-36 overflow-y-auto border border-slate-200 rounded-xl p-2 bg-[#F4F6F8] space-y-1">
                    {availableApis.map(api => {
                      const isSelected = formData.selectedApis.includes(api.id);
                      return (
                        <div
                          key={api.id}
                          onClick={() => {
                            const newSelection = isSelected
                              ? formData.selectedApis.filter(id => id !== api.id)
                              : [...formData.selectedApis, api.id];
                            setFormData({ ...formData, selectedApis: newSelection });
                          }}
                          className={`p-2 rounded-lg cursor-pointer flex items-center justify-between transition text-xs ${
                            isSelected ? 'bg-cyan-100 text-cyan-900 font-bold border border-cyan-300' : 'bg-white text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          <div>
                            <span className="font-semibold">{api.name}</span>
                            <span className="text-[10px] font-mono text-slate-500 block">{api.domain} • {api.endpoint}</span>
                          </div>
                          {isSelected && <Check className="w-3.5 h-3.5 text-cyan-700" />}
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setIsRegistering(false)}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-[#0474C4] hover:bg-[#008752] text-white rounded-xl font-bold transition cursor-pointer shadow-sm"
                  >
                    Save & Deploy Bridge
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Main Two-Column View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Registered MCP Gateways List */}
        <div className="lg:col-span-5 bg-white border border-[#A8C4EC]/60 rounded-2xl p-4 shadow-sm space-y-3">
          
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <span className="text-xs font-bold text-[#0B2545] uppercase font-mono">
              Active MCP Bridges ({gateways.length})
            </span>
            <div className="relative w-40">
              <Search className="w-3 h-3 absolute left-2.5 top-2 text-slate-400" />
              <input
                type="text"
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-7 pr-2 py-1 bg-[#F4F6F8] border border-slate-200 rounded-lg text-xs focus:outline-none"
              />
            </div>
          </div>

          <div className="space-y-2 max-h-[700px] overflow-y-auto pr-1">
            {filteredGateways.map((gw) => {
              const isSelected = selectedGateway?.id === gw.id;
              return (
                <div
                  key={gw.id}
                  onClick={() => setSelectedGateway(gw)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer text-left space-y-2 ${
                    isSelected
                      ? 'bg-[#0B2545] text-white border-[#0B2545] shadow-md'
                      : 'bg-[#F4F6F8] hover:bg-slate-100 text-slate-800 border-slate-200/80'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className={`p-1.5 rounded-lg ${isSelected ? 'bg-cyan-500/20 text-cyan-300' : 'bg-cyan-100 text-[#0474C4]'}`}>
                        <Server className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="text-xs font-bold leading-tight">{gw.name}</h4>
                        <span className={`text-[10px] font-mono block ${isSelected ? 'text-slate-300' : 'text-slate-500'}`}>
                          {gw.protocol.toUpperCase()} • {gw.authType}
                        </span>
                      </div>
                    </div>

                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shrink-0">
                      {gw.status}
                    </span>
                  </div>

                  <p className={`text-[11px] line-clamp-2 ${isSelected ? 'text-slate-300' : 'text-slate-600'}`}>
                    {gw.description}
                  </p>

                  <div className={`pt-2 border-t flex items-center justify-between text-[10px] font-mono ${
                    isSelected ? 'border-white/10 text-slate-300' : 'border-slate-200 text-slate-500'
                  }`}>
                    <span>⚡ {gw.latencyMs}ms avg</span>
                    <span>🛠️ {gw.toolsCount} Tools Attached</span>
                    <span>🤖 {gw.associatedAgentIds.length} Agents</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Selected MCP Bridge Inspector & API/Agent Binding Matrix */}
        <div className="lg:col-span-7 space-y-4">
          {selectedGateway ? (
            <div className="space-y-4">
              
              {/* Detail Banner */}
              <div className="bg-white border border-[#A8C4EC]/60 rounded-2xl p-5 shadow-sm space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 className="text-base font-bold text-[#0B2545]">{selectedGateway.name}</h2>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold">
                        {selectedGateway.status}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 mt-1 font-mono">{selectedGateway.url}</p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleDeleteGateway(selectedGateway.id)}
                      className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                      title="Delete Gateway"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Gateway Specs */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
                  <div className="p-2.5 bg-[#F4F6F8] rounded-xl border border-slate-200 text-center">
                    <span className="text-[10px] text-slate-500 block">Protocol</span>
                    <span className="font-bold text-[#0B2545]">{selectedGateway.protocol}</span>
                  </div>
                  <div className="p-2.5 bg-[#F4F6F8] rounded-xl border border-slate-200 text-center">
                    <span className="text-[10px] text-slate-500 block">Auth Security</span>
                    <span className="font-bold text-[#0474C4]">{selectedGateway.authType}</span>
                  </div>
                  <div className="p-2.5 bg-[#F4F6F8] rounded-xl border border-slate-200 text-center">
                    <span className="text-[10px] text-slate-500 block">Latency</span>
                    <span className="font-bold text-emerald-700">{selectedGateway.latencyMs}ms</span>
                  </div>
                  <div className="p-2.5 bg-[#F4F6F8] rounded-xl border border-slate-200 text-center">
                    <span className="text-[10px] text-slate-500 block">Uptime</span>
                    <span className="font-bold text-emerald-700">{selectedGateway.uptime}</span>
                  </div>
                </div>
              </div>

              {/* 1. API Catalog Binding Section (Tools Accessible via this MCP Gateway) */}
              <div className="bg-white border border-[#A8C4EC]/60 rounded-2xl p-5 shadow-sm space-y-3">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <div className="flex items-center gap-2">
                    <Wrench className="w-4 h-4 text-[#0474C4]" />
                    <h3 className="text-xs font-bold uppercase font-mono text-[#0B2545]">
                      Bound API Catalog Tools ({selectedGateway.associatedApiIds.length} of {availableApis.length} Active)
                    </h3>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">Click to toggle tool access</span>
                </div>

                <div className="grid grid-cols-1 gap-2 max-h-56 overflow-y-auto pr-1">
                  {availableApis.map(api => {
                    const isBound = selectedGateway.associatedApiIds.includes(api.id);
                    return (
                      <div
                        key={api.id}
                        onClick={() => handleToggleApiAssociation(selectedGateway.id, api.id)}
                        className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                          isBound
                            ? 'bg-blue-50 border-blue-300 text-blue-950 shadow-xs'
                            : 'bg-[#F4F6F8] border-slate-200 text-slate-600 opacity-60 hover:opacity-100'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-extrabold ${
                            api.method === 'GET' ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'
                          }`}>
                            {api.method}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="text-xs font-bold">{api.name}</h4>
                              <span className="text-[10px] font-mono text-slate-500 bg-white px-1.5 py-0.2 rounded border border-slate-200">
                                {api.domain}
                              </span>
                            </div>
                            <span className="text-[10px] font-mono text-slate-500">{api.endpoint}</span>
                          </div>
                        </div>

                        <div className="shrink-0 flex items-center gap-2">
                          <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                            isBound ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-600'
                          }`}>
                            {isBound ? 'BOUND' : 'UNBOUND'}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* 2. Agent Association Section (MCP Gateways may or may not be associated with agents) */}
              <div className="bg-white border border-[#A8C4EC]/60 rounded-2xl p-5 shadow-sm space-y-3">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <div className="flex items-center gap-2">
                    <Bot className="w-4 h-4 text-[#008752]" />
                    <h3 className="text-xs font-bold uppercase font-mono text-[#0B2545]">
                      Associated Onboarding Agents ({selectedGateway.associatedAgentIds.length} Attached)
                    </h3>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">Gateways may operate standalone or agent-wired</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
                  {(agents.length > 0 ? agents : [
                    { id: 'lead_intelligence_agent', name: 'Lead Intelligence Agent' },
                    { id: 'entity_resolution_agent', name: 'Entity Resolution Agent' },
                    { id: 'kyb_agent', name: 'Corporate Registry KYB Agent' },
                    { id: 'sanctions_screener', name: 'Global Sanctions Screener' },
                    { id: 'ubo_unwrapper_agent', name: 'UBO Graph Analyzer' },
                    { id: 'doc_verification_agent', name: 'Forensic OCR Agent' }
                  ]).map((agent: any) => {
                    const isAttached = selectedGateway.associatedAgentIds.includes(agent.id);
                    return (
                      <div
                        key={agent.id}
                        onClick={() => handleToggleAgentAssociation(selectedGateway.id, agent.id)}
                        className={`p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between text-xs ${
                          isAttached
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-950 font-semibold shadow-xs'
                            : 'bg-[#F4F6F8] border-slate-200 text-slate-600 opacity-60 hover:opacity-100'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          <Bot className={`w-3.5 h-3.5 ${isAttached ? 'text-emerald-700' : 'text-slate-400'}`} />
                          <span className="truncate">{agent.name}</span>
                        </div>
                        {isAttached ? (
                          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-600 text-white font-bold shrink-0">
                            WIRED
                          </span>
                        ) : (
                          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-200 text-slate-600 font-bold shrink-0">
                            OFF
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>
          ) : (
            <div className="bg-white rounded-2xl p-12 border border-slate-200 text-center text-slate-400">
              <Server className="w-10 h-10 mx-auto mb-2 opacity-40" />
              <p className="text-sm font-bold text-slate-600">Select or register an MCP Gateway</p>
            </div>
          )}
        </div>

      </div>

      {/* Delete MCP Gateway Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={!!gatewayToDelete}
        onClose={() => setGatewayToDelete(null)}
        onConfirm={handleConfirmDeleteGateway}
        title="Delete MCP Gateway"
        description={`Are you sure you want to delete MCP Gateway "${gatewayToDelete?.name}" (${gatewayToDelete?.url})? This will detach its tools and routing bridge.`}
        confirmLabel="Delete Gateway"
      />
    </div>
  );
}
