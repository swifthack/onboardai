import React, { useState, useMemo } from 'react';
import { 
  ShieldCheck, 
  Search, 
  Filter, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Sliders, 
  Lock, 
  FileText, 
  Cpu, 
  Database, 
  Wrench, 
  Sparkles, 
  Eye, 
  Coins, 
  Scale, 
  Bot, 
  Activity, 
  TrendingDown, 
  RefreshCw, 
  Check, 
  HelpCircle,
  Layers,
  Zap,
  Info
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export interface GuardrailRule {
  id: string;
  name: string;
  code: string;
  description: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  enabled: boolean;
  actionOnBreach: 'BLOCK' | 'REDACT' | 'FLAG_AUDIT' | 'ROUTE_HUMAN' | 'THROTTLE';
  latencyImpactMs: number;
  parameters: { key: string; value: string; label: string }[];
}

export interface GuardrailDomain {
  id: string;
  name: string;
  icon: React.ComponentType<any>;
  color: string;
  description: string;
  category: 'Safety & Security' | 'Operations & Cost' | 'Compliance & Intelligence';
  rules: GuardrailRule[];
}

export const GUARDRAIL_DOMAINS: GuardrailDomain[] = [
  {
    id: 'input',
    name: 'Input Guardrails',
    icon: ShieldCheck,
    color: '#0474C4',
    category: 'Safety & Security',
    description: 'Validates, cleanses, sanitizes, and strips malicious payloads or unauthorized character encodings before prompt construction.',
    rules: [
      {
        id: 'in-01',
        name: 'PII / NRIC / SSN Redaction & Tokenization',
        code: 'INPUT_PII_MASK',
        description: 'Auto-detects and masks National Registration IDs, Tax IDs, IBANs, and credit cards with cryptographic tokens.',
        severity: 'CRITICAL',
        enabled: true,
        actionOnBreach: 'REDACT',
        latencyImpactMs: 8,
        parameters: [{ key: 'maskPattern', value: 'SHA256_FPE', label: 'Masking Format' }, { key: 'confidenceThreshold', value: '0.92', label: 'NER Confidence' }]
      },
      {
        id: 'in-02',
        name: 'SQL & NoSQL Injection Sanitizer',
        code: 'INPUT_SQLI_FILTER',
        description: 'Blocks SQL meta-characters, UNION SELECT, drop statements, and NoSQL operator injections in form and chat payloads.',
        severity: 'CRITICAL',
        enabled: true,
        actionOnBreach: 'BLOCK',
        latencyImpactMs: 4,
        parameters: [{ key: 'strictSyntaxCheck', value: 'true', label: 'Strict AST Parse' }]
      },
      {
        id: 'in-03',
        name: 'Malicious Unicode & Invisible Character Stripper',
        code: 'INPUT_UNICODE_STRIP',
        description: 'Detects zero-width joiners, homoglyph character spoofing, and bi-directional override control attacks.',
        severity: 'HIGH',
        enabled: true,
        actionOnBreach: 'REDACT',
        latencyImpactMs: 2,
        parameters: [{ key: 'stripZeroWidth', value: 'true', label: 'Zero-Width Clean' }]
      },
      {
        id: 'in-04',
        name: 'Language & Locale Whitelist Enforcement',
        code: 'INPUT_LOCALE_FILTER',
        description: 'Restricts user submission to authorized banking operating languages (EN, ZH, MS, TA, DE, FR).',
        severity: 'MEDIUM',
        enabled: true,
        actionOnBreach: 'BLOCK',
        latencyImpactMs: 6,
        parameters: [{ key: 'allowedLocales', value: 'en-US, en-SG, zh-CN, ms-MY', label: 'Allowed Locales' }]
      }
    ]
  },
  {
    id: 'prompt',
    name: 'Prompt Guardrails',
    icon: Sparkles,
    color: '#00A3E0',
    category: 'Safety & Security',
    description: 'Protects system instructions from adversarial jailbreaks, prompt leakage, and role-override exploits.',
    rules: [
      {
        id: 'pr-01',
        name: 'Adversarial Jailbreak & DAN Bypass Blocker',
        code: 'PROMPT_JAILBREAK_PREVENT',
        description: 'Semantic vector classifier that identifies adversarial personas, hypnotic roleplays, and "ignore previous rules" vectors.',
        severity: 'CRITICAL',
        enabled: true,
        actionOnBreach: 'BLOCK',
        latencyImpactMs: 14,
        parameters: [{ key: 'modelDetector', value: 'OpenAI Moderation / Claude Constitutional Guard', label: 'Detection Engine' }, { key: 'sensitivity', value: '0.96', label: 'Sensitivity Threshold' }]
      },
      {
        id: 'pr-02',
        name: 'System Prompt Confidentiality & Anti-Leakage',
        code: 'PROMPT_LEAK_DEFENSE',
        description: 'Prevents extraction attacks targeting the underlying internal corporate system prompt or private developer rules.',
        severity: 'CRITICAL',
        enabled: true,
        actionOnBreach: 'BLOCK',
        latencyImpactMs: 5,
        parameters: [{ key: 'detectMetaPromptQueries', value: 'true', label: 'Block "Repeat System Prompt"' }]
      },
      {
        id: 'pr-03',
        name: 'Context Frame Token Ceiling',
        code: 'PROMPT_MAX_TOKENS',
        description: 'Enforces hard ceiling on incoming prompt context window to avert context-stuffing DoS vulnerabilities.',
        severity: 'MEDIUM',
        enabled: true,
        actionOnBreach: 'BLOCK',
        latencyImpactMs: 1,
        parameters: [{ key: 'maxTokens', value: '16384', label: 'Max Context Tokens' }]
      }
    ]
  },
  {
    id: 'retrieval',
    name: 'Retrieval Guardrails',
    icon: Database,
    color: '#5379AE',
    category: 'Compliance & Intelligence',
    description: 'Audits RAG vector queries, validates semantic chunk relevance, and enforces strict tenant multi-jurisdiction boundaries.',
    rules: [
      {
        id: 'ret-01',
        name: 'Tenant & Legal Entity Isolation (Vector Multi-Tenancy)',
        code: 'RETRIEVAL_TENANT_ISOLATE',
        description: 'Injects mandatory metadata filters (tenant_id, legal_entity, jurisdiction) into all Pinecone / Qdrant queries.',
        severity: 'CRITICAL',
        enabled: true,
        actionOnBreach: 'BLOCK',
        latencyImpactMs: 3,
        parameters: [{ key: 'enforceStrictMetadata', value: 'true', label: 'Strict Filter Injection' }]
      },
      {
        id: 'ret-02',
        name: 'Cosine Similarity Relevance Threshold',
        code: 'RETRIEVAL_MIN_SIMILARITY',
        description: 'Discards vector chunks below cosine threshold to avoid passing unrelated or low-confidence documents to LLMs.',
        severity: 'HIGH',
        enabled: true,
        actionOnBreach: 'FLAG_AUDIT',
        latencyImpactMs: 4,
        parameters: [{ key: 'minCosineScore', value: '0.78', label: 'Min Cosine Score' }, { key: 'topKLimit', value: '8', label: 'Top K Chunks' }]
      },
      {
        id: 'ret-03',
        name: 'Document Classification & Access Control Matrix',
        code: 'RETRIEVAL_RBAC_CHECK',
        description: 'Validates that retrieved ACRA, UBO, or Tax documents do not exceed the querying agent’s security clearance level.',
        severity: 'CRITICAL',
        enabled: true,
        actionOnBreach: 'BLOCK',
        latencyImpactMs: 7,
        parameters: [{ key: 'clearanceCheck', value: 'CONFIDENTIAL_RESTRICTED', label: 'Max Clearance' }]
      }
    ]
  },
  {
    id: 'tools',
    name: 'Tools & Function Calling Guardrails',
    icon: Wrench,
    color: '#008752',
    category: 'Safety & Security',
    description: 'Enforces execution sandboxing, schema-conforming tool arguments, and human approvals on destructive write operations.',
    rules: [
      {
        id: 'tool-01',
        name: 'Destructive Action Human-in-the-Loop Intercept',
        code: 'TOOL_HUMAN_APPROVAL_MUTATE',
        description: 'Requires synchronous RM / Compliance Officer signing on write operations (e.g. approve_account, release_funds).',
        severity: 'CRITICAL',
        enabled: true,
        actionOnBreach: 'ROUTE_HUMAN',
        latencyImpactMs: 12,
        parameters: [{ key: 'interceptTools', value: 'approve_client_onboarding, update_credit_limit, dispatch_rm_override', label: 'Gated Operations' }]
      },
      {
        id: 'tool-02',
        name: 'Strict JSON Schema & Type Safety Validator',
        code: 'TOOL_PARAM_SCHEMA_CHECK',
        description: 'Validates tool calling parameters against OpenAPI / MCP schemas to eliminate hallucinated function arguments.',
        severity: 'HIGH',
        enabled: true,
        actionOnBreach: 'BLOCK',
        latencyImpactMs: 5,
        parameters: [{ key: 'strictValidation', value: 'true', label: 'Reject Unknown Keys' }]
      },
      {
        id: 'tool-03',
        name: 'MCP Sandbox Execution Isolation',
        code: 'TOOL_MCP_SANDBOX',
        description: 'Executes MCP tools inside gVisor containerized micro-vms with disabled host socket access.',
        severity: 'CRITICAL',
        enabled: true,
        actionOnBreach: 'BLOCK',
        latencyImpactMs: 18,
        parameters: [{ key: 'egressFirewall', value: 'WHITELIST_ONLY', label: 'Egress Policy' }]
      }
    ]
  },
  {
    id: 'output',
    name: 'Output Guardrails',
    icon: FileText,
    color: '#06457F',
    category: 'Safety & Security',
    description: 'Scans generated responses for hallucinations, toxic content, non-compliant financial advice, and PCI-DSS secrets.',
    rules: [
      {
        id: 'out-01',
        name: 'PCI-DSS & Cardholder Data Exfiltration Filter',
        code: 'OUTPUT_PCI_SCAN',
        description: 'Scans agent outputs using Luhn algorithm regex and Named Entity Recognition to redact payment card numbers and CVVs.',
        severity: 'CRITICAL',
        enabled: true,
        actionOnBreach: 'REDACT',
        latencyImpactMs: 6,
        parameters: [{ key: 'luhnCheck', value: 'true', label: 'Luhn Verification' }]
      },
      {
        id: 'out-02',
        name: 'Hallucination & Grounding Verification Loop',
        code: 'OUTPUT_GROUNDING_CHECK',
        description: 'Checks factual statements against retrieved context documents using NLI (Natural Language Inference).',
        severity: 'HIGH',
        enabled: true,
        actionOnBreach: 'FLAG_AUDIT',
        latencyImpactMs: 35,
        parameters: [{ key: 'nliConfidenceMin', value: '0.88', label: 'NLI Entailment Floor' }]
      },
      {
        id: 'out-03',
        name: 'Unauthorized Financial Guarantee / Advice Detection',
        code: 'OUTPUT_ADVICE_RESTRICTION',
        description: 'Ensures agents do not generate guarantees of credit approval, return on investment promises, or legal counsel.',
        severity: 'HIGH',
        enabled: true,
        actionOnBreach: 'BLOCK',
        latencyImpactMs: 11,
        parameters: [{ key: 'complianceDictionary', value: 'MAS_FA_ACT_V3', label: 'Guidance Standard' }]
      }
    ]
  },
  {
    id: 'runtime',
    name: 'Runtime & Concurrency Guardrails',
    icon: Cpu,
    color: '#262B40',
    category: 'Operations & Cost',
    description: 'Controls execution lifecycles, circuit breakers, parallel task concurrency, and fallback routing.',
    rules: [
      {
        id: 'run-01',
        name: 'Circuit Breaker & Fallback Agent Router',
        code: 'RUNTIME_CIRCUIT_BREAKER',
        description: 'Automatically routes requests to fallback agents or degraded local heuristic models on consecutive API timeouts.',
        severity: 'HIGH',
        enabled: true,
        actionOnBreach: 'THROTTLE',
        latencyImpactMs: 2,
        parameters: [{ key: 'failureThreshold', value: '3 errors / 30s', label: 'Trip Condition' }, { key: 'fallbackAgentId', value: 'rm_copilot_agent', label: 'Failover Target' }]
      },
      {
        id: 'run-02',
        name: 'Per-Tenant Execution Concurrency Limit',
        code: 'RUNTIME_MAX_CONCURRENCY',
        description: 'Caps simultaneous agent orchestration executions to maintain deterministic latency QoS.',
        severity: 'MEDIUM',
        enabled: true,
        actionOnBreach: 'THROTTLE',
        latencyImpactMs: 1,
        parameters: [{ key: 'maxConcurrentJobs', value: '50', label: 'Max Parallel Runs' }]
      },
      {
        id: 'run-03',
        name: 'Hard SLA Execution Timeout (Watchdog Timer)',
        code: 'RUNTIME_WATCHDOG_TIMEOUT',
        description: 'Terminates runaway loops or hung tool integrations that exceed maximum execution threshold.',
        severity: 'HIGH',
        enabled: true,
        actionOnBreach: 'BLOCK',
        latencyImpactMs: 1,
        parameters: [{ key: 'hardTimeoutMs', value: '15000', label: 'Max Allowed SLA' }]
      }
    ]
  },
  {
    id: 'memory',
    name: 'Memory & State Guardrails',
    icon: Layers,
    color: '#3E4766',
    category: 'Safety & Security',
    description: 'Governs conversational memory buffers, short-term vs episodic memory lifespans, and cross-session GDPR erasure.',
    rules: [
      {
        id: 'mem-01',
        name: 'GDPR / PDPA Right-to-be-Forgotten Purge Gate',
        code: 'MEM_GDPR_PURGE',
        description: 'Enforces cryptographically verifiable deletion of client session memories upon customer request or account closure.',
        severity: 'CRITICAL',
        enabled: true,
        actionOnBreach: 'BLOCK',
        latencyImpactMs: 5,
        parameters: [{ key: 'retentionDays', value: '30', label: 'Auto Expire Window' }]
      },
      {
        id: 'mem-02',
        name: 'Cross-Client Memory Contamination Firewall',
        code: 'MEM_CROSS_CLIENT_ISOLATION',
        description: 'Hard-blocks any vector read/write that references another client ID in shared memory caches.',
        severity: 'CRITICAL',
        enabled: true,
        actionOnBreach: 'BLOCK',
        latencyImpactMs: 2,
        parameters: [{ key: 'strictKeyPrefixing', value: 'true', label: 'Key Namespace Validation' }]
      },
      {
        id: 'mem-03',
        name: 'Episodic Memory Compression & Summarization',
        code: 'MEM_COMPRESSION_GATE',
        description: 'Summarizes long onboarding interaction histories into structured key-value state to eliminate semantic drift.',
        severity: 'LOW',
        enabled: true,
        actionOnBreach: 'FLAG_AUDIT',
        latencyImpactMs: 8,
        parameters: [{ key: 'maxTurnWindow', value: '20', label: 'Max Raw Turns' }]
      }
    ]
  },
  {
    id: 'tokenomics',
    name: 'Tokenomics & Rate Guardrails',
    icon: Coins,
    color: '#E06A3B',
    category: 'Operations & Cost',
    description: 'Manages token budgets, TPM (Tokens Per Minute), RPM caps, and proactive cost allocation accounting.',
    rules: [
      {
        id: 'tok-01',
        name: 'Daily Cost Ceiling & Budget Throttle',
        code: 'TOKEN_DAILY_BUDGET_CAP',
        description: 'Freezes non-critical background analytical tasks when daily tenant consumption surpasses hard cap.',
        severity: 'HIGH',
        enabled: true,
        actionOnBreach: 'THROTTLE',
        latencyImpactMs: 1,
        parameters: [{ key: 'dailyLimitUsd', value: '500.00', label: 'Daily Ceiling (USD)' }]
      },
      {
        id: 'tok-02',
        name: 'Max Tokens Per Task Envelope',
        code: 'TOKEN_PER_CALL_LIMIT',
        description: 'Enforces strict max completion and prompt token consumption boundaries per single agent invocation.',
        severity: 'MEDIUM',
        enabled: true,
        actionOnBreach: 'BLOCK',
        latencyImpactMs: 1,
        parameters: [{ key: 'maxTokensPerCall', value: '8192', label: 'Token Limit' }]
      },
      {
        id: 'tok-03',
        name: 'Adaptive Rate Limiting (Token Bucket)',
        code: 'TOKEN_RPM_BURST_CONTROL',
        description: 'Smooths out bursty multi-agent pipelines to avoid upstream 429 rate limit exceptions.',
        severity: 'MEDIUM',
        enabled: true,
        actionOnBreach: 'THROTTLE',
        latencyImpactMs: 2,
        parameters: [{ key: 'maxRpm', value: '600', label: 'Requests Per Minute' }]
      }
    ]
  },
  {
    id: 'security',
    name: 'Enterprise Security & IAM Guardrails',
    icon: Lock,
    color: '#EB001B',
    category: 'Safety & Security',
    description: 'Enforces mutual TLS, zero-trust token verification, role-based access control, and cryptographic audit signatures.',
    rules: [
      {
        id: 'sec-01',
        name: 'A2A Mutual TLS & Cryptographic Signature Verification',
        code: 'SEC_A2A_MTLS_VERIFY',
        description: 'Requires all inter-agent RPC calls to carry valid X.509 client certificates and SHA-256 JWT signatures.',
        severity: 'CRITICAL',
        enabled: true,
        actionOnBreach: 'BLOCK',
        latencyImpactMs: 4,
        parameters: [{ key: 'certValidation', value: 'STRICT_CA', label: 'Trust Store Mode' }]
      },
      {
        id: 'sec-02',
        name: 'Dynamic Least-Privilege IAM Scope Minting',
        code: 'SEC_DYNAMIC_TOKEN_SCOPING',
        description: 'Mints short-lived (60-second) scoped tokens for agents limited strictly to their designated task execution.',
        severity: 'CRITICAL',
        enabled: true,
        actionOnBreach: 'BLOCK',
        latencyImpactMs: 3,
        parameters: [{ key: 'tokenTtlSeconds', value: '60', label: 'Token TTL' }]
      }
    ]
  },
  {
    id: 'regulatory',
    name: 'Regulatory & AML/KYC Compliance Guardrails',
    icon: Scale,
    color: '#06457F',
    category: 'Compliance & Intelligence',
    description: 'Guarantees compliance with MAS Notice 626, HKMA, FATF 40 Recommendations, OFAC, and Wolfsberg principles.',
    rules: [
      {
        id: 'reg-01',
        name: 'MAS Notice 626 AML Compliance Verification',
        code: 'REG_MAS_626_AUDIT',
        description: 'Mandates deterministic beneficial ownership identification down to the 25% threshold for all institutional clients.',
        severity: 'CRITICAL',
        enabled: true,
        actionOnBreach: 'BLOCK',
        latencyImpactMs: 8,
        parameters: [{ key: 'uboThreshold', value: '25%', label: 'UBO Ownership Floor' }]
      },
      {
        id: 'reg-02',
        name: 'PEP & Sanctions False-Negative Zero Tolerance Gate',
        code: 'REG_SANCTIONS_ZERO_MISS',
        description: 'Forces secondary validation algorithm whenever fuzzy name match exceeds 70% threshold against OFAC/MAS lists.',
        severity: 'CRITICAL',
        enabled: true,
        actionOnBreach: 'ROUTE_HUMAN',
        latencyImpactMs: 15,
        parameters: [{ key: 'fuzzyThreshold', value: '0.70', label: 'Screening Fuzzy Level' }]
      },
      {
        id: 'reg-03',
        name: 'Transparent Audit Trail & Reason Code Generation',
        code: 'REG_DECISION_EXPLAINABILITY',
        description: 'Requires every automated underwriting or compliance flag to produce immutable explainability reason codes.',
        severity: 'HIGH',
        enabled: true,
        actionOnBreach: 'FLAG_AUDIT',
        latencyImpactMs: 6,
        parameters: [{ key: 'storeInLedger', value: 'true', label: 'Write to Audit Ledger' }]
      }
    ]
  },
  {
    id: 'agentic_ai',
    name: 'Agentic AI & Autonomy Guardrails',
    icon: Bot,
    color: '#00A3E0',
    category: 'Compliance & Intelligence',
    description: 'Prevents autonomous multi-agent recursion cascades, circular dependency deadlock, and unconstrained action loops.',
    rules: [
      {
        id: 'agt-01',
        name: 'Recursion Depth & Max Step Hop Limiter',
        code: 'AGENTIC_MAX_HOP_DEPTH',
        description: 'Caps autonomous sub-agent delegation depth to 5 tiers to prevent infinite cyclic delegation loops.',
        severity: 'CRITICAL',
        enabled: true,
        actionOnBreach: 'BLOCK',
        latencyImpactMs: 2,
        parameters: [{ key: 'maxDelegationDepth', value: '5', label: 'Max Step Depth' }]
      },
      {
        id: 'agt-02',
        name: 'Consensus & Multi-Agent Verification Quorum',
        code: 'AGENTIC_CONSENSUS_QUORUM',
        description: 'Requires at least 2 independent specialized agents (e.g. KYC + AML) to agree on high-risk risk assessments.',
        severity: 'HIGH',
        enabled: true,
        actionOnBreach: 'ROUTE_HUMAN',
        latencyImpactMs: 25,
        parameters: [{ key: 'requiredQuorum', value: '2 of 2 Agents', label: 'Quorum Ratio' }]
      },
      {
        id: 'agt-03',
        name: 'Autonomous Task State Serialization Gate',
        code: 'AGENTIC_STATE_CHECKPOINT',
        description: 'Forces checkpointing of execution states to Redis before invoking downstream external microservices.',
        severity: 'MEDIUM',
        enabled: true,
        actionOnBreach: 'FLAG_AUDIT',
        latencyImpactMs: 4,
        parameters: [{ key: 'checkpointStore', value: 'REDIS_STATE_STORE', label: 'State Backend' }]
      }
    ]
  },
  {
    id: 'observability',
    name: 'Observability & Telemetry Guardrails',
    icon: Activity,
    color: '#008752',
    category: 'Operations & Cost',
    description: 'Ensures OpenTelemetry trace propagation, real-time latency anomaly alerts, and SLA degradation alarms.',
    rules: [
      {
        id: 'obs-01',
        name: 'W3C Distributed Trace Context Propagation',
        code: 'OBS_OTEL_TRACE_INJECT',
        description: 'Guarantees that every request across MCP Gateways, Agents, and LLM calls carries valid W3C traceparent headers.',
        severity: 'HIGH',
        enabled: true,
        actionOnBreach: 'FLAG_AUDIT',
        latencyImpactMs: 1,
        parameters: [{ key: 'traceSampleRate', value: '1.0 (100%)', label: 'Trace Sampling' }]
      },
      {
        id: 'obs-02',
        name: 'Real-Time Latency Anomaly Alarm',
        code: 'OBS_LATENCY_SPIKE_ALERT',
        description: 'Dispatches real-time PagerDuty alerts if p99 latency across any onboarding node exceeds 4,000ms over 60s.',
        severity: 'HIGH',
        enabled: true,
        actionOnBreach: 'FLAG_AUDIT',
        latencyImpactMs: 1,
        parameters: [{ key: 'p99LatencyThreshold', value: '4000ms', label: 'p99 Threshold' }]
      },
      {
        id: 'obs-03',
        name: 'Synthetic Health Probe & Heartbeat Guard',
        code: 'OBS_SYNTHETIC_HEARTBEAT',
        description: 'Runs end-to-end synthetic KYC mock handshakes every 30 seconds to guarantee pipeline availability.',
        severity: 'MEDIUM',
        enabled: true,
        actionOnBreach: 'FLAG_AUDIT',
        latencyImpactMs: 1,
        parameters: [{ key: 'probeIntervalSeconds', value: '30', label: 'Interval (s)' }]
      }
    ]
  },
  {
    id: 'cost_optimisation',
    name: 'Cost Optimisation & Smart Routing Guardrails',
    icon: TrendingDown,
    color: '#0474C4',
    category: 'Operations & Cost',
    description: 'Dynamically routes simple deterministic tasks to lightweight Flash models, caches frequent queries, and prunes unused prompt tokens.',
    rules: [
      {
        id: 'cost-01',
        name: 'Dynamic Model Cascading (Haiku/Mini vs. Sonnet/GPT-4o Routing)',
        code: 'COST_MODEL_CASCADING',
        description: 'Evaluates task complexity and automatically downgrades simple classification from Claude 3.5 Sonnet / GPT-4o to Claude 3.5 Haiku / GPT-4o-mini (saving 80% cost).',
        severity: 'HIGH',
        enabled: true,
        actionOnBreach: 'FLAG_AUDIT',
        latencyImpactMs: 3,
        parameters: [{ key: 'complexityClassifier', value: 'FastText_Triage_v2', label: 'Routing Triage' }, { key: 'estMonthlySavings', value: '$4,200', label: 'Estimated Savings' }]
      },
      {
        id: 'cost-02',
        name: 'Semantic Response Caching Gate',
        code: 'COST_SEMANTIC_CACHE',
        description: 'Returns cached ACRA filings or sanctions checks when queries match recent lookups within 12-hour TTL.',
        severity: 'HIGH',
        enabled: true,
        actionOnBreach: 'FLAG_AUDIT',
        latencyImpactMs: 2,
        parameters: [{ key: 'cacheTtlHours', value: '12', label: 'Cache TTL' }, { key: 'vectorThreshold', value: '0.98', label: 'Exact Match Floor' }]
      },
      {
        id: 'cost-03',
        name: 'Redundant Document & Image Downsampling Filter',
        code: 'COST_PAYLOAD_OPTIMIZER',
        description: 'Downsamples high-res passport/utility bill uploads to optimal 300 DPI OCR resolution before sending to multimodal APIs.',
        severity: 'MEDIUM',
        enabled: true,
        actionOnBreach: 'FLAG_AUDIT',
        latencyImpactMs: 8,
        parameters: [{ key: 'targetDpi', value: '300 DPI', label: 'Target Resolution' }]
      }
    ]
  }
];

export const DOMAIN_ICON_MAP: Record<string, React.ComponentType<any>> = {
  input: ShieldCheck,
  prompt: Sparkles,
  retrieval: Database,
  tools: Wrench,
  output: FileText,
  runtime: Cpu,
  memory: Layers,
  tokenomics: Coins,
  security: Lock,
  regulatory: Scale,
  agentic_ai: Bot,
  observability: Activity,
  cost_optimisation: TrendingDown,
};

export const getDomainIcon = (domainId: string): React.ComponentType<any> => {
  return DOMAIN_ICON_MAP[domainId] || ShieldCheck;
};

export default function GuardrailsView() {
  const [domains, setDomains] = useState<GuardrailDomain[]>(() => {
    const saved = localStorage.getItem('guardrail_domains_v1');
    if (saved) {
      try {
        const parsed: GuardrailDomain[] = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map(d => ({
            ...d,
            icon: getDomainIcon(d.id)
          }));
        }
      } catch (e) {
        return GUARDRAIL_DOMAINS;
      }
    }
    return GUARDRAIL_DOMAINS;
  });

  const [selectedDomainId, setSelectedDomainId] = useState<string>('input');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSeverity, setSelectedSeverity] = useState<string>('ALL');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const activeDomain = useMemo(() => {
    return domains.find(d => d.id === selectedDomainId) || domains[0];
  }, [domains, selectedDomainId]);

  // Counts & Stats
  const stats = useMemo(() => {
    let totalRules = 0;
    let enabledRules = 0;
    let criticalRules = 0;
    domains.forEach(d => {
      d.rules.forEach(r => {
        totalRules++;
        if (r.enabled) enabledRules++;
        if (r.severity === 'CRITICAL') criticalRules++;
      });
    });
    return {
      totalDomains: domains.length,
      totalRules,
      enabledRules,
      criticalRules,
      complianceScore: Math.round((enabledRules / totalRules) * 100)
    };
  }, [domains]);

  const toggleRule = (domainId: string, ruleId: string) => {
    setDomains(prev => {
      const updated = prev.map(d => {
        if (d.id !== domainId) return d;
        return {
          ...d,
          rules: d.rules.map(r => {
            if (r.id !== ruleId) return r;
            const newEnabled = !r.enabled;
            return { ...r, enabled: newEnabled };
          })
        };
      });
      localStorage.setItem('guardrail_domains_v1', JSON.stringify(updated));
      return updated;
    });
    showToast(`Rule updated successfully`);
  };

  const updateRuleAction = (domainId: string, ruleId: string, action: any) => {
    setDomains(prev => {
      const updated = prev.map(d => {
        if (d.id !== domainId) return d;
        return {
          ...d,
          rules: d.rules.map(r => r.id === ruleId ? { ...r, actionOnBreach: action } : r)
        };
      });
      localStorage.setItem('guardrail_domains_v1', JSON.stringify(updated));
      return updated;
    });
    showToast(`Enforcement action changed to ${action}`);
  };

  const showToast = (msg: string) => {
    setSuccessToast(msg);
    setTimeout(() => setSuccessToast(null), 2500);
  };

  const handleToggleAllInDomain = (domainId: string, enable: boolean) => {
    setDomains(prev => {
      const updated = prev.map(d => {
        if (d.id !== domainId) return d;
        return {
          ...d,
          rules: d.rules.map(r => ({ ...r, enabled: enable }))
        };
      });
      localStorage.setItem('guardrail_domains_v1', JSON.stringify(updated));
      return updated;
    });
    showToast(`All rules in ${activeDomain.name} ${enable ? 'enabled' : 'disabled'}`);
  };

  const filteredRules = useMemo(() => {
    return activeDomain.rules.filter(r => {
      const matchesSearch = searchTerm === '' || 
        r.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesSeverity = selectedSeverity === 'ALL' || r.severity === selectedSeverity;
      return matchesSearch && matchesSeverity;
    });
  }, [activeDomain, searchTerm, selectedSeverity]);

  return (
    <div className="space-y-6 text-slate-800">
      {/* Toast */}
      <AnimatePresence>
        {successToast && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-5 right-5 z-50 bg-[#008752] text-white px-4 py-2.5 rounded-xl shadow-xl font-bold text-xs flex items-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{successToast}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header Banner */}
      <div className="bg-white border border-[#A8C4EC]/60 rounded-2xl p-6 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2.5 bg-[#0474C4] text-white rounded-xl shadow-sm">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-[#0B2545] tracking-tight">Enterprise Agent Guardrails Framework</h1>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold border border-emerald-300">
                  13 DOMAINS ACTIVE
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-0.5">
                Comprehensive security, deterministic compliance, safety, tokenomics, and agentic autonomy boundaries.
              </p>
            </div>
          </div>
        </div>

        {/* Global Summary Metric Cards */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="bg-[#F4F6F8] px-3.5 py-2 rounded-xl border border-slate-200 text-center">
            <span className="text-[10px] uppercase font-mono text-slate-500 block font-bold">Total Domains</span>
            <span className="text-base font-extrabold text-[#0B2545]">{stats.totalDomains}</span>
          </div>
          <div className="bg-[#F4F6F8] px-3.5 py-2 rounded-xl border border-slate-200 text-center">
            <span className="text-[10px] uppercase font-mono text-slate-500 block font-bold">Active Rules</span>
            <span className="text-base font-extrabold text-[#008752]">{stats.enabledRules} / {stats.totalRules}</span>
          </div>
          <div className="bg-[#F4F6F8] px-3.5 py-2 rounded-xl border border-slate-200 text-center">
            <span className="text-[10px] uppercase font-mono text-slate-500 block font-bold">Critical Gates</span>
            <span className="text-base font-extrabold text-[#EB001B]">{stats.criticalRules}</span>
          </div>
          <div className="bg-emerald-50 px-3.5 py-2 rounded-xl border border-emerald-200 text-center">
            <span className="text-[10px] uppercase font-mono text-emerald-700 block font-bold">Posture Score</span>
            <span className="text-base font-extrabold text-[#008752]">{stats.complianceScore}%</span>
          </div>
        </div>
      </div>

      {/* Main Two-Column Guardrails Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: 13 Guardrail Domains Navigation List */}
        <div className="lg:col-span-4 bg-white border border-[#A8C4EC]/60 rounded-2xl p-4 shadow-sm space-y-3">
          <div className="px-2 pb-2 border-b border-slate-100 flex items-center justify-between">
            <span className="text-xs font-bold text-[#0B2545] uppercase tracking-wider font-mono">
              13 Policy Domains
            </span>
            <span className="text-[10px] font-mono text-slate-500">
              Select to inspect
            </span>
          </div>

          <div className="space-y-1.5 max-h-[720px] overflow-y-auto pr-1">
            {domains.map((domain, index) => {
              const Icon = getDomainIcon(domain.id);
              const isSelected = domain.id === selectedDomainId;
              const activeCount = domain.rules.filter(r => r.enabled).length;
              const totalCount = domain.rules.length;

              return (
                <button
                  key={domain.id}
                  onClick={() => setSelectedDomainId(domain.id)}
                  className={`w-full text-left p-3 rounded-xl transition-all flex items-center justify-between cursor-pointer border ${
                    isSelected
                      ? 'bg-[#0B2545] text-white border-[#0B2545] shadow-md'
                      : 'bg-[#F4F6F8] hover:bg-slate-100 text-slate-700 border-slate-200/80'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div 
                      className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                        isSelected ? 'bg-white/20 text-white' : 'bg-white text-[#0474C4] border border-slate-200 shadow-xs'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="truncate">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-mono font-bold opacity-70">#{index + 1}</span>
                        <h4 className="text-xs font-bold truncate">{domain.name}</h4>
                      </div>
                      <p className={`text-[10px] truncate ${isSelected ? 'text-slate-300' : 'text-slate-500'}`}>
                        {domain.category}
                      </p>
                    </div>
                  </div>

                  <div className="text-right shrink-0 pl-2">
                    <span 
                      className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold ${
                        isSelected 
                          ? 'bg-emerald-500/30 text-emerald-300 border border-emerald-400/40' 
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {activeCount}/{totalCount}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: Selected Domain Detail & Interactive Rule Configuration */}
        <div className="lg:col-span-8 space-y-4">
          
          {/* Domain Banner Card */}
          <div className="bg-white border border-[#A8C4EC]/60 rounded-2xl p-5 shadow-sm space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-[#0474C4] text-white shadow-sm">
                  {React.createElement(getDomainIcon(activeDomain.id), { className: 'w-5 h-5' })}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base font-bold text-[#0B2545]">{activeDomain.name}</h2>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-100 text-[#0474C4] font-bold">
                      {activeDomain.category}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                    {activeDomain.description}
                  </p>
                </div>
              </div>

              {/* Quick Batch Actions */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => handleToggleAllInDomain(activeDomain.id, true)}
                  className="px-2.5 py-1.5 bg-[#008752] hover:bg-[#006e42] text-white rounded-lg text-xs font-bold transition cursor-pointer shadow-xs"
                >
                  Enable All
                </button>
                <button
                  onClick={() => handleToggleAllInDomain(activeDomain.id, false)}
                  className="px-2.5 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-xs font-bold transition cursor-pointer"
                >
                  Disable All
                </button>
              </div>
            </div>

            {/* Filter and Search within Domain */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-1">
              <div className="relative w-full sm:w-64">
                <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search rules in this domain..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 bg-[#F4F6F8] border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-[#0474C4]"
                />
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <span className="text-[11px] font-semibold text-slate-500">Severity:</span>
                <select
                  value={selectedSeverity}
                  onChange={(e) => setSelectedSeverity(e.target.value)}
                  className="bg-[#F4F6F8] border border-slate-200 text-xs rounded-xl px-2.5 py-1.5 text-slate-700 focus:outline-none"
                >
                  <option value="ALL">All Severities</option>
                  <option value="CRITICAL">Critical</option>
                  <option value="HIGH">High</option>
                  <option value="MEDIUM">Medium</option>
                  <option value="LOW">Low</option>
                </select>
              </div>
            </div>
          </div>

          {/* Rules List for Selected Domain */}
          <div className="space-y-3.5">
            {filteredRules.length === 0 ? (
              <div className="bg-white rounded-2xl p-8 border border-slate-200 text-center text-slate-400">
                <ShieldCheck className="w-8 h-8 mx-auto mb-2 opacity-40 text-slate-500" />
                <p className="text-xs font-bold text-slate-600">No matching guardrail rules found</p>
                <p className="text-[11px] mt-1 text-slate-400">Try adjusting your search query or severity filter.</p>
              </div>
            ) : (
              filteredRules.map((rule) => {
                const isCritical = rule.severity === 'CRITICAL';
                const isHigh = rule.severity === 'HIGH';

                return (
                  <div
                    key={rule.id}
                    className={`bg-white rounded-2xl border p-5 transition-all shadow-sm ${
                      rule.enabled 
                        ? 'border-slate-200 hover:border-[#0474C4]' 
                        : 'border-slate-200/60 opacity-60 bg-slate-50'
                    }`}
                  >
                    <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                      
                      {/* Left info */}
                      <div className="space-y-2 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-bold border border-slate-200">
                            {rule.code}
                          </span>
                          
                          <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-extrabold ${
                            isCritical 
                              ? 'bg-rose-100 text-rose-800 border border-rose-300' 
                              : isHigh 
                                ? 'bg-amber-100 text-amber-800 border border-amber-300' 
                                : 'bg-blue-100 text-blue-800 border border-blue-300'
                          }`}>
                            {rule.severity}
                          </span>

                          <span className="text-[10px] font-mono text-slate-400 flex items-center gap-1">
                            <Activity className="w-3 h-3 text-cyan-600" /> +{rule.latencyImpactMs}ms latency
                          </span>
                        </div>

                        <h3 className="text-sm font-bold text-[#0B2545]">{rule.name}</h3>
                        <p className="text-xs text-slate-600 leading-relaxed">{rule.description}</p>

                        {/* Parameter Chips */}
                        {rule.parameters && rule.parameters.length > 0 && (
                          <div className="pt-2 flex items-center gap-2 flex-wrap">
                            <span className="text-[10px] font-mono text-slate-400 uppercase font-semibold">Config:</span>
                            {rule.parameters.map((param, pIdx) => (
                              <div key={pIdx} className="text-[10px] font-mono bg-[#F4F6F8] border border-slate-200 px-2 py-1 rounded-lg text-slate-700 flex items-center gap-1">
                                <span className="text-slate-500">{param.label}:</span>
                                <span className="font-bold text-[#0474C4]">{param.value}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Right controls */}
                      <div className="flex flex-col sm:flex-row md:flex-col items-end gap-3 shrink-0 pt-1 md:pt-0 border-t md:border-t-0 border-slate-100">
                        {/* Toggle Button */}
                        <button
                          onClick={() => toggleRule(activeDomain.id, rule.id)}
                          className={`w-full sm:w-auto px-3.5 py-1.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer ${
                            rule.enabled
                              ? 'bg-[#008752] text-white hover:bg-[#006e42] shadow-sm'
                              : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                          }`}
                        >
                          {rule.enabled ? (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>Enforced</span>
                            </>
                          ) : (
                            <>
                              <XCircle className="w-3.5 h-3.5" />
                              <span>Disabled</span>
                            </>
                          )}
                        </button>

                        {/* Action on Breach Dropdown */}
                        <div className="w-full sm:w-auto text-right">
                          <label className="block text-[10px] font-mono text-slate-400 mb-1">Action on Breach:</label>
                          <select
                            value={rule.actionOnBreach}
                            disabled={!rule.enabled}
                            onChange={(e) => updateRuleAction(activeDomain.id, rule.id, e.target.value)}
                            className="bg-[#F4F6F8] border border-slate-200 text-xs font-semibold rounded-lg px-2.5 py-1 text-slate-700 focus:outline-none cursor-pointer disabled:opacity-50"
                          >
                            <option value="BLOCK">🛑 Block Request</option>
                            <option value="REDACT">✂️ Redact & Tokenize</option>
                            <option value="ROUTE_HUMAN">👤 Route to Human (RM)</option>
                            <option value="FLAG_AUDIT">⚠️ Flag & Write Audit</option>
                            <option value="THROTTLE">⏳ Throttle Rate</option>
                          </select>
                        </div>

                      </div>

                    </div>
                  </div>
                );
              })
            )}
          </div>

        </div>

      </div>

    </div>
  );
}
