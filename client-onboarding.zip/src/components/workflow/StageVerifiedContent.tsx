import React from 'react';
import { 
  Building2, 
  ShieldCheck, 
  FileCheck2, 
  Users, 
  CreditCard, 
  Award, 
  Lock, 
  FileText, 
  Eye, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Network,
  ExternalLink,
  Search,
  KeyRound,
  Compass,
  ArrowRight,
  TrendingUp,
  Landmark,
  Mail
} from 'lucide-react';
import { ClientProfile, WorkflowNode, UploadedDocument } from '../../types';

interface StageVerifiedContentProps {
  client: ClientProfile;
  selectedNode: WorkflowNode;
  stageIndex: number;
  totalStages: number;
  stageName: string;
  stageDescription?: string;
  onViewDocument: (doc: UploadedDocument) => void;
  onShowGraph?: () => void;
  onTriggerOutreach?: () => void;
}

export const StageVerifiedContent: React.FC<StageVerifiedContentProps> = ({
  client,
  selectedNode,
  stageIndex,
  totalStages,
  stageName,
  stageDescription,
  onViewDocument,
  onShowGraph,
  onTriggerOutreach
}) => {
  const isSg = client.jurisdiction.toLowerCase().includes('singapore') || client.jurisdiction.includes('SG');
  const isUk = client.jurisdiction.toLowerCase().includes('uk') || client.jurisdiction.toLowerCase().includes('united kingdom');
  const isMeridian = client.id === 'client_meridian' || client.companyName?.toLowerCase().includes('meridian');
  const leiNumber = isMeridian ? '5493001KJTIIGC8Y1R12' : ((client as any).lei || '5493001KJTIIGC8Y1R12');

  const isCompleted = selectedNode.status === 'completed';
  const isRunning = selectedNode.status === 'running';
  const isFlagged = selectedNode.status === 'flagged';

  // Determine stage category based on stageIndex or node id
  const stageNum = stageIndex + 1;
  const nodeId = selectedNode.id || `stage_${stageNum}`;

  // Helper to render status badge
  const renderStatusBadge = () => {
    if (isCompleted) {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-semibold font-mono">
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
          Verified &amp; Certified
        </span>
      );
    }
    if (isRunning) {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200 text-xs font-semibold font-mono">
          <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse" />
          In Progress • Active Evaluation
        </span>
      );
    }
    if (isFlagged) {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-50 text-amber-700 border border-amber-200 text-xs font-semibold font-mono">
          <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
          Action Required • Officer Review
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-100 text-slate-600 border border-slate-200 text-xs font-semibold font-mono">
        <Clock className="w-3.5 h-3.5 text-slate-400" />
        Pending Execution
      </span>
    );
  };

  // Content specific to Stage 1: Prospect Qualification & Intake
  const renderStage1Content = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Legal Entity Name</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1">{client.companyName}</strong>
          <span className="text-[10px] font-mono text-emerald-600 font-medium mt-1 inline-flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" /> Exact Registry Match
          </span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Registration Number</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1 font-mono">{client.registrationNumber}</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">Source: {isSg ? 'ACRA BizProfile' : isUk ? 'UK Companies House' : 'Official Registry'}</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">LEI (Legal Entity Identifier)</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1 font-mono">{leiNumber}</strong>
          <span className="text-[10px] font-mono text-emerald-600 font-medium mt-1 inline-flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" /> GLEIF Ledger Active
          </span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Incorporation Jurisdiction</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1">{client.jurisdiction}</strong>
          <span className="text-[10px] font-mono text-emerald-600 font-medium mt-1 block">FATF Compliant • Tier-1</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Operating Industry Class</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1 truncate">{client.industry}</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">NACE / SSIC Code Verified</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">License Standing</span>
          <strong className="text-sm text-emerald-700 font-semibold block mt-1">Active &amp; Good Standing</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">Filing Recency: Current</span>
        </div>
      </div>

      <div className="p-3.5 rounded-xl bg-blue-50/40 border border-blue-100 flex items-start justify-between gap-4">
        <div className="space-y-1">
          <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
            <Building2 className="w-4 h-4 text-blue-600" />
            Verified Statutory Registry Briefing
          </span>
          <p className="text-xs text-slate-600 leading-relaxed">
            Statutory registry synchronization verified active incorporation record. Automated Lead Intelligence pipeline pre-populated corporate entity Digital Twin with zero manual data entry required.
          </p>
        </div>
        <span className="text-[10px] font-mono font-bold text-blue-700 bg-white px-2 py-1 rounded border border-blue-200 shrink-0">
          P-01 &bull; P-02 CONNECTED
        </span>
      </div>
    </div>
  );

  // Content specific to Stage 2: Entity Research & Ownership Mapping
  const renderStage2Content = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">UBO Identification Threshold</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1">25% Statutory Direct/Indirect</strong>
          <span className="text-[10px] font-mono text-emerald-600 font-medium mt-1 block">Deterministic Cap Table 100% Mapped</span>
        </div>
        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Corporate Shell Layers</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1">Transparent Domestic Structure</strong>
          <span className="text-[10px] font-mono text-emerald-600 font-medium mt-1 block">0 Offshore Layering Flags</span>
        </div>
        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Capital Origin / Source of Wealth</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1">Vetted Institutional Capital</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">Equity Origin Audited</span>
        </div>
      </div>

      <div className="border border-slate-200 rounded-xl p-4 bg-white shadow-2xs">
        <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider font-mono mb-3 flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <Users className="w-4 h-4 text-blue-600" />
            Verified Ultimate Beneficial Owners (UBOs) &amp; Shareholders
          </span>
          <span className="text-[10px] font-mono text-slate-400 font-normal">REGISTER EXTRACT</span>
        </h4>
        <div className="space-y-2">
          {client.shareholders.map((sh, idx) => (
            <div key={idx} className="flex items-center justify-between p-2.5 bg-slate-50/80 border border-slate-100 rounded-lg">
              <div className="min-w-0 mr-3">
                <p className="text-xs font-semibold text-slate-900 truncate">{sh.name}</p>
                <p className="text-[10px] text-slate-500 font-mono">
                  Tier {sh.tier || 1} &bull; Direct Shareholding &bull; {sh.nationality || client.jurisdiction}
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {sh.pepStatus ? (
                  <span className="px-2 py-0.5 bg-amber-100 text-amber-800 font-mono text-[9px] font-bold rounded-md uppercase">
                    PEP Scrutiny
                  </span>
                ) : (
                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-mono text-[9px] font-bold rounded-md">
                    Non-PEP
                  </span>
                )}
                <span className="text-xs font-bold font-mono text-slate-900 bg-white border border-slate-200 px-2 py-0.5 rounded">
                  {sh.equity}% Equity
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  // Content specific to Stage 3: Individual Verification & Biometrics
  const renderStage3Content = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Authorized Signatory</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1 truncate">{client.authorizedRepresentative.name}</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">{client.authorizedRepresentative.role}</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">ID Document Verification</span>
          <strong className="text-sm text-emerald-700 font-semibold block mt-1">Official Passport Validated</strong>
          <span className="text-[10px] font-mono text-emerald-600 font-medium mt-1 block">Bio-Data Page Verified</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Biometric Match Score</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1 font-mono">
            {client.authorizedRepresentative.biometricMatchScore || 98.6}%
          </strong>
          <span className="text-[10px] font-mono text-emerald-600 font-medium mt-1 block">128-Point Spatial Match</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Liveness Detection</span>
          <strong className="text-sm text-emerald-700 font-semibold block mt-1">PASSED (Passive Liveness)</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">Anti-Deepfake Confirmed</span>
        </div>
      </div>

      <div className="border border-slate-200 rounded-xl p-4 bg-white shadow-2xs">
        <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider font-mono mb-3 flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <KeyRound className="w-4 h-4 text-blue-600" />
            Registered Directors &amp; Executive Officers
          </span>
          <span className="text-[10px] font-mono text-emerald-600 font-medium">vLEI CREDENTIAL VALID</span>
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {(client.directors && client.directors.length > 0 ? client.directors : [
            { name: client.authorizedRepresentative.name, role: client.authorizedRepresentative.role, appointmentDate: '2021-04-15', nationality: client.jurisdiction }
          ]).map((dir, idx) => (
            <div key={idx} className="p-2.5 bg-slate-50/80 border border-slate-100 rounded-lg flex items-center justify-between">
              <div>
                <p className="text-xs font-semibold text-slate-900">{dir.name}</p>
                <p className="text-[10px] text-slate-500">{dir.role} &bull; Appointed {dir.appointmentDate}</p>
              </div>
              <span className="text-[9px] font-mono font-bold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded border border-emerald-200">
                Verified
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  // Content specific to Stage 4: Dynamic KYC & Tax Classification
  const renderStage4Content = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Dynamic KYC Question Set</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1">100% Answered (8 of 8)</strong>
          <span className="text-[10px] font-mono text-emerald-600 font-medium mt-1 block">Minimum-Necessary Scope</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">FATCA / CRS Classification</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1">Active NFFE Compliant</strong>
          <span className="text-[10px] font-mono text-emerald-600 font-medium mt-1 block">W-8BEN-E / W-9 Validated</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Tax Residence Attestation</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1">{client.jurisdiction}</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">Tax Identifier Verified</span>
        </div>
      </div>

      <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
        <h4 className="text-xs font-bold text-slate-800 font-mono uppercase mb-2">Verified Regulatory Attestations</h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-700 font-medium">
          <div className="flex items-center gap-2 p-2 bg-white rounded border border-slate-200">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span>Non-Sanctioned Operating Territory Affirmation</span>
          </div>
          <div className="flex items-center gap-2 p-2 bg-white rounded border border-slate-200">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span>Authorized Corporate Representative Resolution</span>
          </div>
          <div className="flex items-center gap-2 p-2 bg-white rounded border border-slate-200">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span>Solvency &amp; Ongoing Business Continuity Warranty</span>
          </div>
          <div className="flex items-center gap-2 p-2 bg-white rounded border border-slate-200">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span>Anti-Bribery &amp; Foreign Corrupt Practices Clause</span>
          </div>
        </div>
      </div>
    </div>
  );

  // Content specific to Stage 5: Document Collection & OCR
  const renderStage5Content = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Documents Parsed in Vault</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1">{client.documents?.length || 0} Files</strong>
          <span className="text-[10px] font-mono text-emerald-600 font-medium mt-1 block">100% OCR Multi-Modal Processed</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">OCR Extraction Accuracy</span>
          <strong className="text-sm text-emerald-700 font-semibold block mt-1">99.4% LayoutLMv3</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">Zero Field Discrepancies</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Tamper Detection Checksum</span>
          <strong className="text-sm text-emerald-700 font-semibold block mt-1">SHA-256 Verified</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">Unaltered Digital Artifacts</span>
        </div>
      </div>

      <div className="border border-slate-200 rounded-xl p-4 bg-white shadow-2xs">
        <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider font-mono mb-3 flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <FileText className="w-4 h-4 text-blue-600" />
            Verified Statutory Document Dossier ({client.documents?.length || 0})
          </span>
          <span className="text-[10px] font-mono text-slate-400">CLICK TO INSPECT FILE</span>
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {client.documents && client.documents.length > 0 ? (
            client.documents.map((doc) => (
              <div 
                key={doc.id}
                onClick={() => onViewDocument(doc)}
                className="p-3 rounded-lg border border-slate-200 bg-slate-50/60 hover:bg-blue-50/40 hover:border-blue-300 transition cursor-pointer flex items-center justify-between gap-3 group"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <FileText className="w-4 h-4 text-blue-600 shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-slate-900 truncate group-hover:text-blue-700">{doc.name}</p>
                    <span className="text-[10px] font-mono text-slate-400">{doc.type} &bull; {doc.size}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase bg-emerald-100 text-emerald-800">
                    {doc.status}
                  </span>
                  <Eye className="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-600" />
                </div>
              </div>
            ))
          ) : (
            <p className="col-span-2 text-xs text-slate-400 italic py-2">No documents attached.</p>
          )}
        </div>
      </div>
    </div>
  );

  // Content specific to Stage 6: Screening (Sanctions & PEP)
  const renderStage6Content = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">OFAC SDN List</span>
          <strong className="text-sm text-emerald-700 font-semibold block mt-1">0 Matches (CLEARED)</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">Live Daily Delta Sync</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">UN Security Council</span>
          <strong className="text-sm text-emerald-700 font-semibold block mt-1">0 Matches (CLEARED)</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">Global Consolidated List</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">EU &amp; UK HMT Sanctions</span>
          <strong className="text-sm text-emerald-700 font-semibold block mt-1">0 Matches (CLEARED)</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">Asset Freeze Watchlist</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Adverse Media Sentiment</span>
          <strong className="text-sm text-emerald-700 font-semibold block mt-1">Clean (0 Negative Mentions)</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">Global News Feeds Audited</span>
        </div>
      </div>

      <div className="p-3.5 rounded-xl bg-blue-50/30 border border-blue-100 flex items-start justify-between gap-4">
        <div className="space-y-1">
          <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
            <Search className="w-4 h-4 text-blue-600" />
            Phonetic Double-Metaphone &amp; Fuzzy Matching Engine
          </span>
          <p className="text-xs text-slate-600 leading-relaxed">
            Automated screening executed across entity name, registered directors, and all disclosed beneficial owners at an 85% Levenshtein phonetic threshold. Zero actionable sanctions nexus identified.
          </p>
        </div>
        <span className="text-[10px] font-mono font-bold text-emerald-700 bg-white px-2.5 py-1 rounded border border-emerald-200 shrink-0">
          SCREENING CLEAR
        </span>
      </div>
    </div>
  );

  // Content specific to Stage 7: Risk Assessment
  const renderStage7Content = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Composite Risk Tier</span>
          <strong className="text-sm text-emerald-700 font-semibold block mt-1">LOW RISK (18 / 100)</strong>
          <span className="text-[10px] font-mono text-emerald-600 font-medium mt-1 block">Green Band Qualified</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Jurisdictional Risk</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1">Low (Score: 12)</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">{client.jurisdiction}</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Internal Credit Rating</span>
          <strong className="text-sm text-blue-700 font-semibold block mt-1 font-mono">{client.financials.rating}</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">Prime Underwriting Tier</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Underwriting Workflow</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1">Standard SLA (24h)</strong>
          <span className="text-[10px] font-mono text-emerald-600 font-medium mt-1 block">No EDD Escalation</span>
        </div>
      </div>

      <div className="border border-slate-200 rounded-xl p-4 bg-white shadow-2xs">
        <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider font-mono mb-3 flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <TrendingUp className="w-4 h-4 text-blue-600" />
            Balance Sheet &amp; Financial Disclosures
          </span>
          <span className="text-[10px] font-mono text-slate-400">AUDITED FINANCIAL STATEMENT</span>
        </h4>
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
            <span className="text-[9px] font-mono text-slate-400 uppercase block">ANNUAL REVENUE</span>
            <strong className="text-xs font-semibold text-slate-900 block mt-0.5">{client.financials.revenue}</strong>
          </div>
          <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
            <span className="text-[9px] font-mono text-slate-400 uppercase block">TOTAL ASSETS</span>
            <strong className="text-xs font-semibold text-slate-900 block mt-0.5">{client.financials.assets}</strong>
          </div>
          <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
            <span className="text-[9px] font-mono text-slate-400 uppercase block">DEBT LEVERAGE</span>
            <strong className="text-xs font-semibold text-slate-900 block mt-0.5">{client.financials.debtRatio}</strong>
          </div>
        </div>
      </div>
    </div>
  );

  // Content specific to Stage 8: Approval Gateway
  const renderStage8Content = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Approval Routing</span>
          <strong className="text-sm text-emerald-700 font-semibold block mt-1">AUTO_APPROVED Qualified</strong>
          <span className="text-[10px] font-mono text-emerald-600 font-medium mt-1 block">Risk Matrix Passed Threshold</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Four-Eyes Audit Sign-Off</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1">RM &amp; Compliance Verified</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">Dual Supervision Complete</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Immutable Ledger Hash</span>
          <strong className="text-sm text-blue-700 font-semibold block mt-1 font-mono">0x8a92...e410</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">Compliance Journal Stamp</span>
        </div>
      </div>

      <div className="p-3.5 rounded-xl bg-emerald-50/40 border border-emerald-200 flex items-center gap-3">
        <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
        <div className="text-xs text-slate-700">
          <strong className="text-slate-900 font-bold block">Supervisory Decision Clearance</strong>
          Institutional onboarding decision cleared under regulatory mandate. Master Corporate Terms prepared for automated core banking account setup.
        </div>
      </div>
    </div>
  );

  // Content specific to Stage 9: Product Provisioning
  const renderStage9Content = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Multi-Currency Operating CASA</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1 font-mono">GB29 NWBK 6016 1331</strong>
          <span className="text-[10px] font-mono text-emerald-600 font-medium mt-1 block">USD / EUR / GBP / SGD Ready</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Global FX/MM Settlement Path</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1 font-mono">SWIFT: NWBKGB2L</strong>
          <span className="text-[10px] font-mono text-emerald-600 font-medium mt-1 block">Real-Time Gross Settlement</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Trade Finance Facility</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1">Revolving Letter of Credit</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">Approved Limit Active</span>
        </div>
      </div>

      <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
        <span className="text-xs font-bold text-slate-800 font-mono uppercase block mb-1">Core Banking Ledger Integration</span>
        <p className="text-xs text-slate-600">
          Virtual accounts, automated cash concentration sweeps, and multi-currency settlement conduits have been provisioned and synchronized with the core transaction ledger.
        </p>
      </div>
    </div>
  );

  // Content specific to Stage 10: Ready to Trade & Activation
  const renderStage10Content = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Client Trading Mandate</span>
          <strong className="text-sm text-emerald-700 font-semibold block mt-1">UNLOCKED &amp; ACTIVE</strong>
          <span className="text-[10px] font-mono text-emerald-600 font-medium mt-1 block">Global Execution Authorized</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Standard Settlement Instructions</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1">SSI Exchanged via SWIFT RMA</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">Counterparty Cleared</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Welcome Packet Dispatched</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1">Portal Credentials Issued</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">API Keys Generated</span>
        </div>
      </div>

      <div className="p-3.5 rounded-xl bg-emerald-50/40 border border-emerald-200 flex items-center gap-3">
        <Award className="w-5 h-5 text-emerald-600 shrink-0" />
        <div className="text-xs text-slate-700">
          <strong className="text-slate-900 font-bold block">Mandate Activation Complete</strong>
          {client.companyName} is officially onboarded and ready to transact across corporate treasury, foreign exchange, and liquidity management facilities.
        </div>
      </div>
    </div>
  );

  // Content specific to Stage 11: Perpetual KYC & Ongoing Monitoring
  const renderStage11Content = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Registry Delta Webhooks</span>
          <strong className="text-sm text-emerald-700 font-semibold block mt-1">Continuous 24/7 Monitoring</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">Registry Filings Tracked</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Automated Sanctions Re-Scan</span>
          <strong className="text-sm text-emerald-700 font-semibold block mt-1">Daily Automated Run</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">Watchlist Delta Surveillance</span>
        </div>

        <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Next Scheduled Periodic Audit</span>
          <strong className="text-sm text-slate-900 font-semibold block mt-1">12-Month Standard Cycle</strong>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">Target: 2027-03-31</span>
        </div>
      </div>

      <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-4">
        <div className="text-xs text-slate-600">
          <strong className="text-slate-900 font-bold block">Autonomous Governance Active</strong>
          Zero scheduled manual refresh required unless material corporate structure, UBO, or regulatory watchlist alterations occur.
        </div>
        <span className="text-[10px] font-mono font-bold text-blue-700 bg-white px-2.5 py-1 rounded border border-blue-200 shrink-0">
          PERPETUAL SURVEILLANCE
        </span>
      </div>
    </div>
  );

  // Router for rendering the appropriate stage content
  const renderSelectedStageDetails = () => {
    switch (stageNum) {
      case 1:
        return renderStage1Content();
      case 2:
        return renderStage2Content();
      case 3:
        return renderStage3Content();
      case 4:
        return renderStage4Content();
      case 5:
        return renderStage5Content();
      case 6:
        return renderStage6Content();
      case 7:
        return renderStage7Content();
      case 8:
        return renderStage8Content();
      case 9:
        return renderStage9Content();
      case 10:
        return renderStage10Content();
      case 11:
        return renderStage11Content();
      default:
        // Generic fallback for any other custom stage
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Stage Target</span>
                <strong className="text-sm text-slate-900 font-semibold block mt-1">{stageName}</strong>
              </div>
              <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Entity</span>
                <strong className="text-sm text-slate-900 font-semibold block mt-1">{client.companyName}</strong>
              </div>
            </div>
            {stageDescription && (
              <p className="text-xs text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-200">{stageDescription}</p>
            )}
          </div>
        );
    }
  };

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-5">
      {/* Top Header: Title, Status, and Show Visual Dependency Graph Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div className="space-y-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[11px] font-mono font-bold text-blue-600 uppercase tracking-wider bg-blue-50 px-2 py-0.5 rounded border border-blue-100">
              Stage {stageNum} of {totalStages}
            </span>
            <h2 className="text-base font-bold text-slate-900 tracking-tight">
              {stageName}
            </h2>
          </div>
          <p className="text-xs text-slate-500">
            {stageDescription || 'Certified compliance attributes, statutory records, and verification evidence.'}
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {renderStatusBadge()}
          
          {onTriggerOutreach && (
            <button
              type="button"
              onClick={onTriggerOutreach}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-2xs transition cursor-pointer"
              title="Trigger client outreach email with onboarding credentials"
            >
              <Mail className="w-3.5 h-3.5" />
              <span>Trigger Outreach</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Verified Content Area for this Stage */}
      <div>
        {renderSelectedStageDetails()}
      </div>

      {/* Recent Stage Findings & Log Highlights */}
      {selectedNode.results?.findings && selectedNode.results.findings.length > 0 && (
        <div className="border-t border-slate-100 pt-4">
          <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider font-mono mb-2 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            Stage Verification Evidence &amp; Findings
          </h4>
          <ul className="space-y-1.5">
            {selectedNode.results.findings.map((finding, idx) => (
              <li key={idx} className="text-xs text-slate-600 flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0 mt-1.5" />
                <span>{finding}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default StageVerifiedContent;
