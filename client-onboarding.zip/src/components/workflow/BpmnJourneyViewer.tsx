import React, { useEffect, useRef, useState, useMemo } from 'react';
import {
  Maximize2,
  Minimize2,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Download,
  Copy,
  Check,
  Play,
  Pause,
  Layers,
  Code2,
  FileText,
  Sparkles,
  Bot,
  ShieldCheck,
  Building2,
  GitBranch,
  ArrowRight,
  Info,
  CheckCircle2,
  Cpu,
  RefreshCw,
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
// @ts-ignore - Import bpmn-js production build
import BpmnNavigatedViewer from 'bpmn-js/dist/bpmn-navigated-viewer.production.min.js';
import 'bpmn-js/dist/assets/diagram-js.css';
import 'bpmn-js/dist/assets/bpmn-js.css';
import 'bpmn-js/dist/assets/bpmn-font/css/bpmn-embedded.css';

import { Journey, JourneyStage } from '../common/PersonaSubviews';
import { OrchestrationAgent } from '../../types';
import { generateJourneyBpmnXml } from '../../utils/bpmnXmlGenerator';

interface BpmnJourneyViewerProps {
  journey: Journey;
  availableAgents?: OrchestrationAgent[];
  onClose?: () => void;
  isModal?: boolean;
}

export function BpmnJourneyViewer({
  journey,
  availableAgents = [],
  onClose,
  isModal = false
}: BpmnJourneyViewerProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const viewerRef = useRef<any>(null);
  const importCountRef = useRef(0);

  // View Mode: 'canvas' | 'xml' | 'mapping'
  const [viewMode, setViewMode] = useState<'canvas' | 'xml' | 'mapping'>('canvas');
  const [selectedElement, setSelectedElement] = useState<any>(null);
  const [copied, setCopied] = useState(false);
  const [isSimulating, setIsSimulating] = useState(false);
  const [activeSimulationNodeIndex, setActiveSimulationNodeIndex] = useState(-1);
  const [simulationLogs, setSimulationLogs] = useState<string[]>([]);
  const [viewerError, setViewerError] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(isModal);

  // Generate BPMN 2.0 XML
  const bpmnXml = useMemo(() => {
    return generateJourneyBpmnXml(journey, availableAgents);
  }, [journey, availableAgents]);

  // Extract list of all stage node IDs for simulation sequence
  const stageNodeIds = useMemo(() => {
    const ids: string[] = [`StartEvent_${(journey.id || 'default').replace(/[^a-zA-Z0-9_]/g, '_')}`];
    (journey.stages || []).forEach((stage, stageIdx) => {
      const rawStageId = stage.id || `stage_${stageIdx + 1}`;
      const safeStageId = rawStageId.replace(/[^a-zA-Z0-9_]/g, '_');
      if (stage.executionMode === 'parallel' && (stage.attachedAgentIds?.length || 0) > 1) {
        ids.push(`Gateway_Split_${safeStageId}`);
        const branchCount = Math.min(stage.attachedAgentIds?.length || 1, 3);
        for (let i = 0; i < branchCount; i++) {
          ids.push(`Task_${safeStageId}_branch_${i + 1}`);
        }
        ids.push(`Gateway_Join_${safeStageId}`);
      } else {
        ids.push(`Activity_${safeStageId}`);
        if (stage.transitionRule === 'risk_check' || stage.transitionRule === 'approval_gate') {
          ids.push(`Gateway_Decision_${safeStageId}`);
        }
      }
    });
    ids.push(`EndEvent_${(journey.id || 'default').replace(/[^a-zA-Z0-9_]/g, '_')}`);
    return ids;
  }, [journey]);

  // Initialize and Render BPMN Diagram via bpmn-js
  useEffect(() => {
    if (viewMode !== 'canvas' || !containerRef.current) {
      if (viewerRef.current) {
        try {
          viewerRef.current.destroy();
        } catch (e) {}
        viewerRef.current = null;
      }
      return;
    }

    let isCancelled = false;
    const currentImportId = ++importCountRef.current;

    // Reuse or create viewer instance for the current container
    let viewer = viewerRef.current;
    if (!viewer) {
      try {
        if (containerRef.current) {
          containerRef.current.innerHTML = '';
        }
        viewer = new BpmnNavigatedViewer({
          container: containerRef.current,
          height: '100%',
          width: '100%'
        });

        const eventBus = viewer.get('eventBus');
        eventBus.on('element.click', (event: any) => {
          const element = event.element;
          if (element && element.businessObject) {
            const bo = element.businessObject;
            setSelectedElement({
              id: element.id,
              type: element.type,
              name: bo.name || element.id,
              documentation: bo.documentation?.[0]?.text || '',
              lane: bo.$parent?.name || '',
              businessObject: bo
            });
          }
        });

        viewerRef.current = viewer;
      } catch (e: any) {
        if (!isCancelled) {
          console.error('[BPMN.io] Viewer Instantiation Error:', e);
          setViewerError(e.message || 'Failed to initialize bpmn.io viewer');
        }
        return;
      }
    }

    // Import XML into the viewer
    viewer.importXML(bpmnXml)
      .then((result: any) => {
        if (isCancelled || currentImportId !== importCountRef.current || !viewerRef.current) {
          return;
        }
        if (result?.warnings?.length) {
          console.warn('[BPMN.io] Import warnings:', result.warnings);
        }
        try {
          const canvas = viewer.get('canvas');
          canvas.zoom('fit-viewport');
        } catch (e) {}
        setViewerError(null);
      })
      .catch((err: any) => {
        if (isCancelled || currentImportId !== importCountRef.current || !viewerRef.current) {
          return;
        }
        // Suppress benign teardown or superseded import exceptions
        if (err?.message && (err.message.includes('root-0') || err.message.includes('destroyed') || err.message.includes('undefined'))) {
          return;
        }
        console.error('[BPMN.io] XML Import Error:', err);
        setViewerError(`BPMN Render Error: ${err.message || 'Failed to parse BPMN XML'}`);
      });

    return () => {
      isCancelled = true;
    };
  }, [bpmnXml, viewMode]);

  // Clean up viewer on component unmount
  useEffect(() => {
    return () => {
      if (viewerRef.current) {
        try {
          viewerRef.current.destroy();
        } catch (e) {}
        viewerRef.current = null;
      }
    };
  }, []);

  // Controls for Zoom
  const handleZoomIn = () => {
    if (!viewerRef.current) return;
    const canvas = viewerRef.current.get('canvas');
    canvas.zoom(canvas.zoom() * 1.25);
  };

  const handleZoomOut = () => {
    if (!viewerRef.current) return;
    const canvas = viewerRef.current.get('canvas');
    canvas.zoom(canvas.zoom() * 0.8);
  };

  const handleFitViewport = () => {
    if (!viewerRef.current) return;
    const canvas = viewerRef.current.get('canvas');
    canvas.zoom('fit-viewport');
  };

  const handleResetZoom = () => {
    if (!viewerRef.current) return;
    const canvas = viewerRef.current.get('canvas');
    canvas.zoom(1.0);
  };

  // Copy BPMN XML
  const handleCopyXml = () => {
    navigator.clipboard.writeText(bpmnXml);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Download BPMN 2.0 XML
  const handleDownloadXml = () => {
    const blob = new Blob([bpmnXml], { type: 'application/xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${(journey.id || 'journey')}_bpmn_2_0.bpmn`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Download SVG
  const handleDownloadSvg = async () => {
    if (!viewerRef.current) return;
    try {
      const { svg } = await viewerRef.current.saveSVG();
      const blob = new Blob([svg], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${(journey.id || 'journey')}_bpmn_diagram.svg`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to export BPMN SVG:', err);
    }
  };

  // Interactive Simulation
  const handleToggleSimulation = () => {
    if (isSimulating) {
      setIsSimulating(false);
      if (viewerRef.current) {
        const canvas = viewerRef.current.get('canvas');
        stageNodeIds.forEach(id => {
          try {
            canvas.removeMarker(id, 'bpmn-sim-active');
            canvas.removeMarker(id, 'bpmn-sim-done');
          } catch (e) {}
        });
      }
      return;
    }

    setIsSimulating(true);
    setActiveSimulationNodeIndex(0);
    setSimulationLogs([
      `[00:00.0] 🚀 BPMN 2.0 Process Engine Initiated for: "${journey.name}"`,
      `[00:00.2] 📍 StartEvent token dispatched via Front-Office RM Lane`
    ]);
  };

  // Simulation step timer
  useEffect(() => {
    if (!isSimulating || activeSimulationNodeIndex < 0) return;

    if (activeSimulationNodeIndex >= stageNodeIds.length) {
      setIsSimulating(false);
      setSimulationLogs(prev => [
        ...prev,
        `[00:08.5] 🏁 Process Reached EndEvent: Client successfully onboarded into Core Banking!`
      ]);
      return;
    }

    const currentNodeId = stageNodeIds[activeSimulationNodeIndex];
    if (viewerRef.current) {
      const canvas = viewerRef.current.get('canvas');
      try {
        // mark previous as done
        if (activeSimulationNodeIndex > 0) {
          const prevNodeId = stageNodeIds[activeSimulationNodeIndex - 1];
          canvas.removeMarker(prevNodeId, 'bpmn-sim-active');
          canvas.addMarker(prevNodeId, 'bpmn-sim-done');
        }
        // mark current as active
        canvas.addMarker(currentNodeId, 'bpmn-sim-active');
        canvas.scrollToElement(currentNodeId);
      } catch (e) {}
    }

    const timer = setTimeout(() => {
      setSimulationLogs(prev => [
        ...prev,
        `[00:0${activeSimulationNodeIndex + 1}.0] ⚡ Traversed BPMN Node [${currentNodeId}]`
      ]);
      setActiveSimulationNodeIndex(prev => prev + 1);
    }, 1200);

    return () => clearTimeout(timer);
  }, [isSimulating, activeSimulationNodeIndex, stageNodeIds]);

  // Find linked stage details if an element is selected
  const selectedStageData = useMemo(() => {
    if (!selectedElement) return null;
    const elementId = selectedElement.id;
    return (journey.stages || []).find(s => 
      elementId.includes(s.id) ||
      elementId === `Activity_${s.id}` ||
      elementId === `Gateway_Split_${s.id}` ||
      elementId === `Gateway_Decision_${s.id}`
    );
  }, [selectedElement, journey]);

  return (
    <div className={`flex flex-col bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xl text-left ${
      isFullscreen ? 'fixed inset-4 z-50 rounded-2xl ring-1 ring-slate-900/10' : 'w-full h-[780px]'
    }`}>
      {/* Top Header & Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 bg-slate-900 text-white border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-[#0474C4] rounded-xl text-white shadow-sm flex items-center justify-center">
            <GitBranch className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-sm text-white tracking-wide flex items-center gap-2">
                BPMN 2.0 Process Diagram
                <span className="text-[10px] font-mono bg-blue-500/20 text-blue-300 border border-blue-400/30 px-2 py-0.5 rounded-full font-bold">
                  bpmn.io Engine
                </span>
              </h3>
            </div>
            <p className="text-xs text-slate-400 font-mono mt-0.5 truncate max-w-md">
              {journey.name} &bull; {journey.stages?.length || 0} Stages Mapped
            </p>
          </div>
        </div>

        {/* View Mode Tabs */}
        <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-xl border border-slate-700">
          <button
            type="button"
            onClick={() => setViewMode('canvas')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              viewMode === 'canvas'
                ? 'bg-[#0474C4] text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
          >
            <Layers className="w-3.5 h-3.5" /> BPMN Canvas
          </button>
          <button
            type="button"
            onClick={() => setViewMode('xml')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              viewMode === 'xml'
                ? 'bg-[#0474C4] text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" /> BPMN 2.0 XML
          </button>
          <button
            type="button"
            onClick={() => setViewMode('mapping')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              viewMode === 'mapping'
                ? 'bg-[#0474C4] text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
          >
            <FileText className="w-3.5 h-3.5" /> Stage Mapping Matrix
          </button>
        </div>

        {/* Actions & Utilities */}
        <div className="flex items-center gap-2">
          {viewMode === 'canvas' && (
            <>
              <button
                type="button"
                onClick={handleToggleSimulation}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm ${
                  isSimulating
                    ? 'bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold animate-pulse'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                }`}
                title="Simulate BPMN process execution token traversal"
              >
                {isSimulating ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                {isSimulating ? 'Simulating...' : 'Simulate Traversal'}
              </button>

              <button
                type="button"
                onClick={handleDownloadSvg}
                className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 text-xs font-bold rounded-lg transition flex items-center gap-1 cursor-pointer"
                title="Export as vector SVG image"
              >
                <Download className="w-3.5 h-3.5" /> Export SVG
              </button>
            </>
          )}

          <button
            type="button"
            onClick={handleDownloadXml}
            className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 text-xs font-bold rounded-lg transition flex items-center gap-1 cursor-pointer"
            title="Download BPMN 2.0 XML file (.bpmn)"
          >
            <Download className="w-3.5 h-3.5" /> Export .BPMN
          </button>

          <button
            type="button"
            onClick={() => setIsFullscreen(prev => !prev)}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 rounded-lg transition cursor-pointer"
            title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 bg-slate-800 hover:bg-red-900/60 text-slate-300 hover:text-red-200 border border-slate-700 rounded-lg text-xs font-bold transition cursor-pointer"
            >
              Close
            </button>
          )}
        </div>
      </div>

      {/* Swimlane Color Legend Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-2 bg-slate-50 border-b border-slate-200 text-xs">
        <div className="flex flex-wrap items-center gap-4 text-[11px] font-mono">
          <span className="font-extrabold text-slate-700 uppercase tracking-wider">Swimlane Routing:</span>
          <span className="flex items-center gap-1.5 text-blue-700 bg-blue-100/60 px-2 py-0.5 rounded border border-blue-200">
            <span className="w-2 h-2 rounded-full bg-blue-600" /> Lane 1: RM &amp; Front-Office Outreach
          </span>
          <span className="flex items-center gap-1.5 text-indigo-700 bg-indigo-100/60 px-2 py-0.5 rounded border border-indigo-200">
            <span className="w-2 h-2 rounded-full bg-indigo-600" /> Lane 2: AI Autonomous Agent Swarm
          </span>
          <span className="flex items-center gap-1.5 text-purple-700 bg-purple-100/60 px-2 py-0.5 rounded border border-purple-200">
            <span className="w-2 h-2 rounded-full bg-purple-600" /> Lane 3: Senior Compliance &amp; Risk Policy Gates
          </span>
          <span className="flex items-center gap-1.5 text-emerald-700 bg-emerald-100/60 px-2 py-0.5 rounded border border-emerald-200">
            <span className="w-2 h-2 rounded-full bg-emerald-600" /> Lane 4: Product Provisioning &amp; Core Banking
          </span>
        </div>

        <div className="flex items-center gap-2 text-[11px] text-slate-500">
          <Info className="w-3.5 h-3.5 text-blue-500" />
          <span>Click any task or gateway in the canvas to inspect mapped properties</span>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 relative flex overflow-hidden bg-slate-100/70">
        
        {/* VIEW 1: BPMN 2.0 Visual Canvas */}
        {viewMode === 'canvas' && (
          <div className="flex-1 relative flex overflow-hidden">
            {/* bpmn.io Container */}
            <div
              ref={containerRef}
              className="w-full h-full bg-white relative z-0 bpmn-canvas-styled"
              style={{ minHeight: '520px' }}
            />

            {/* Error Overlay */}
            {viewerError && (
              <div className="absolute inset-0 z-30 bg-white/90 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center">
                  <Info className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-extrabold text-sm text-slate-900">BPMN Viewer Notice</h4>
                  <p className="text-xs text-rose-600 font-mono mt-1 max-w-lg">{viewerError}</p>
                </div>
                <button
                  onClick={() => setViewMode('xml')}
                  className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-bold hover:bg-slate-800 transition cursor-pointer"
                >
                  View BPMN 2.0 XML Source
                </button>
              </div>
            )}

            {/* Canvas Floating Navigation Toolbar */}
            <div className="absolute bottom-5 left-5 z-20 flex items-center gap-1.5 bg-white/90 backdrop-blur-md p-1.5 rounded-xl border border-slate-300/80 shadow-lg">
              <button
                type="button"
                onClick={handleZoomIn}
                className="p-2 text-slate-700 hover:text-blue-600 hover:bg-slate-100 rounded-lg transition cursor-pointer"
                title="Zoom In"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={handleZoomOut}
                className="p-2 text-slate-700 hover:text-blue-600 hover:bg-slate-100 rounded-lg transition cursor-pointer"
                title="Zoom Out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <div className="w-px h-5 bg-slate-200" />
              <button
                type="button"
                onClick={handleFitViewport}
                className="px-2.5 py-1.5 text-xs font-bold text-slate-700 hover:text-blue-600 hover:bg-slate-100 rounded-lg transition cursor-pointer flex items-center gap-1"
                title="Fit to Viewport"
              >
                Fit
              </button>
              <button
                type="button"
                onClick={handleResetZoom}
                className="p-2 text-slate-700 hover:text-blue-600 hover:bg-slate-100 rounded-lg transition cursor-pointer"
                title="Reset 100%"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>

            {/* Simulation Log Console Overlay (when running) */}
            {isSimulating && (
              <div className="absolute bottom-5 right-5 z-20 w-80 max-h-56 bg-slate-950/90 backdrop-blur-md text-slate-200 border border-slate-800 rounded-xl p-3.5 shadow-2xl overflow-y-auto font-mono text-[11px] space-y-1.5 animate-fadeIn">
                <div className="flex items-center justify-between border-b border-slate-800 pb-1.5 mb-2">
                  <span className="font-extrabold text-blue-400 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-blue-400 animate-ping" />
                    Process Token Simulation
                  </span>
                  <span className="text-[10px] text-slate-400">
                    {activeSimulationNodeIndex + 1}/{stageNodeIds.length} Nodes
                  </span>
                </div>
                {simulationLogs.map((log, idx) => (
                  <div key={idx} className="text-slate-300 leading-tight">
                    {log}
                  </div>
                ))}
              </div>
            )}

            {/* Element Inspector Sidebar */}
            <AnimatePresence>
              {selectedElement && (
                <motion.div
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 50 }}
                  className="w-96 bg-white border-l border-slate-200 shadow-2xl p-5 overflow-y-auto relative z-20 flex flex-col justify-between"
                >
                  <div className="space-y-4">
                    <div className="flex items-start justify-between gap-2 border-b border-slate-100 pb-3">
                      <div>
                        <span className="text-[10px] font-mono bg-blue-100 text-[#0474C4] border border-blue-200 px-2 py-0.5 rounded-full font-bold uppercase">
                          {selectedElement.type.replace('bpmn:', '')}
                        </span>
                        <h4 className="font-extrabold text-sm text-slate-900 mt-1">
                          {selectedElement.name}
                        </h4>
                      </div>
                      <button
                        onClick={() => setSelectedElement(null)}
                        className="text-slate-400 hover:text-slate-600 p-1 rounded-lg text-xs"
                      >
                        &times;
                      </button>
                    </div>

                    <div className="space-y-2.5 text-xs text-slate-600">
                      <div>
                        <span className="font-bold text-slate-800">Element ID:</span>
                        <p className="font-mono text-[11px] text-slate-500 bg-slate-50 p-1.5 rounded border border-slate-200 mt-0.5 select-all">
                          {selectedElement.id}
                        </p>
                      </div>

                      {selectedElement.documentation && (
                        <div>
                          <span className="font-bold text-slate-800">Documentation:</span>
                          <p className="text-slate-600 bg-slate-50 p-2 rounded-lg border border-slate-200 mt-0.5 leading-relaxed">
                            {selectedElement.documentation}
                          </p>
                        </div>
                      )}

                      {/* Mapped Stage Specifics */}
                      {selectedStageData && (
                        <div className="pt-3 border-t border-slate-100 space-y-2.5">
                          <h5 className="font-extrabold text-xs text-slate-800 flex items-center gap-1.5">
                            <Sparkles className="w-3.5 h-3.5 text-[#0474C4]" />
                            Mapped Journey Stage Details
                          </h5>

                          <div className="grid grid-cols-2 gap-2 text-[11px]">
                            <div className="bg-slate-50 p-2 rounded border border-slate-200">
                              <span className="text-slate-500 block">Execution Mode</span>
                              <span className="font-bold font-mono text-slate-800 uppercase">
                                {selectedStageData.executionMode || 'Sequential'}
                              </span>
                            </div>
                            <div className="bg-slate-50 p-2 rounded border border-slate-200">
                              <span className="text-slate-500 block">Transition Rule</span>
                              <span className="font-bold font-mono text-slate-800 uppercase">
                                {selectedStageData.transitionRule || 'Auto'}
                              </span>
                            </div>
                          </div>

                          {selectedStageData.attachedAgentIds && selectedStageData.attachedAgentIds.length > 0 && (
                            <div>
                              <span className="text-slate-500 block mb-1">Attached AI Agents ({selectedStageData.attachedAgentIds.length}):</span>
                              <div className="space-y-1">
                                {selectedStageData.attachedAgentIds.map(agId => {
                                  const ag = availableAgents.find(a => a.id === agId);
                                  return (
                                    <div key={agId} className="flex items-center gap-2 p-1.5 bg-blue-50/50 rounded border border-blue-100 text-[11px]">
                                      <Bot className="w-3.5 h-3.5 text-[#0474C4] shrink-0" />
                                      <span className="font-bold text-slate-800 truncate">{ag?.name || agId}</span>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          )}

                          {selectedStageData.pipelines && selectedStageData.pipelines.length > 0 && (
                            <div>
                              <span className="text-slate-500 block mb-1">Sub-Pipelines:</span>
                              <div className="space-y-1">
                                {selectedStageData.pipelines.map((pipe, pIdx) => (
                                  <div key={pIdx} className="text-[10px] font-mono bg-slate-50 p-1.5 rounded border border-slate-200 text-slate-700">
                                    {pipe}
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="pt-4 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setSelectedElement(null)}
                      className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-lg transition"
                    >
                      Dismiss Inspector
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}

        {/* VIEW 2: BPMN 2.0 XML Code View */}
        {viewMode === 'xml' && (
          <div className="flex-1 flex flex-col bg-slate-950 text-slate-200 overflow-hidden relative">
            <div className="flex items-center justify-between px-5 py-2.5 bg-slate-900 border-b border-slate-800 text-xs">
              <div className="flex items-center gap-2 font-mono text-slate-400">
                <Code2 className="w-4 h-4 text-blue-400" />
                <span>BPMN 2.0 XML Document Definition (OMG &amp; Camunda Spec)</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleCopyXml}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-lg transition flex items-center gap-1.5 cursor-pointer text-xs font-bold border border-slate-700"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? 'Copied XML!' : 'Copy XML'}
                </button>
                <button
                  type="button"
                  onClick={handleDownloadXml}
                  className="px-3 py-1.5 bg-[#0474C4] hover:bg-blue-600 text-white rounded-lg transition flex items-center gap-1.5 cursor-pointer text-xs font-bold"
                >
                  <Download className="w-3.5 h-3.5" /> Download .BPMN
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-auto p-5 font-mono text-xs text-emerald-400 bg-slate-950 leading-relaxed selection:bg-blue-500 selection:text-white">
              <pre className="whitespace-pre">{bpmnXml}</pre>
            </div>
          </div>
        )}

        {/* VIEW 3: Stage-to-BPMN Mapping Breakdown Matrix */}
        {viewMode === 'mapping' && (
          <div className="flex-1 p-6 overflow-y-auto bg-slate-50 space-y-6">
            <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <h4 className="font-extrabold text-sm text-slate-900">
                    Journey Stage &rarr; BPMN 2.0 Construct Mapping Matrix
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    How each Onboarding Journey stage is structurally compiled into standard BPMN 2.0 elements, swimlanes, and gateway logic.
                  </p>
                </div>
                <span className="text-xs font-mono font-bold bg-blue-100 text-[#0474C4] px-3 py-1 rounded-full border border-blue-200">
                  {journey.stages?.length || 0} Stages Mapped
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-100/75 text-slate-700 font-extrabold border-y border-slate-200">
                      <th className="py-2.5 px-3">Stage # &amp; Name</th>
                      <th className="py-2.5 px-3">BPMN Element</th>
                      <th className="py-2.5 px-3">Swimlane</th>
                      <th className="py-2.5 px-3">Execution &amp; Gateway Pattern</th>
                      <th className="py-2.5 px-3">Attached Agents / Pipelines</th>
                      <th className="py-2.5 px-3">BPMN Technical ID</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {/* Start Event Row */}
                    <tr className="hover:bg-slate-50 transition">
                      <td className="py-3 px-3 font-extrabold text-blue-700">0. Lead Initiation</td>
                      <td className="py-3 px-3">
                        <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-mono font-bold text-[10px] border border-emerald-200">
                          bpmn:StartEvent
                        </span>
                      </td>
                      <td className="py-3 px-3 text-slate-600 font-medium">Lane 1: RM &amp; Outreach</td>
                      <td className="py-3 px-3 text-slate-500">Initiation Event Trigger</td>
                      <td className="py-3 px-3 text-slate-400 font-mono text-[11px]">CRM / Portal Form</td>
                      <td className="py-3 px-3 font-mono text-[11px] text-slate-400 select-all">
                        StartEvent_{(journey.id || 'default').replace(/[^a-zA-Z0-9_]/g, '_')}
                      </td>
                    </tr>

                    {(journey.stages || []).map((stage, idx) => {
                      const isParallel = stage.executionMode === 'parallel' && (stage.attachedAgentIds?.length || 0) > 1;
                      const hasDecision = stage.transitionRule === 'risk_check' || stage.transitionRule === 'approval_gate';

                      return (
                        <tr key={stage.id} className="hover:bg-slate-50 transition">
                          <td className="py-3 px-3 font-extrabold text-slate-900">
                            {idx + 1}. {stage.name}
                          </td>
                          <td className="py-3 px-3">
                            <span className="px-2 py-0.5 rounded bg-blue-100 text-blue-800 font-mono font-bold text-[10px] border border-blue-200">
                              {isParallel ? 'bpmn:ParallelGateway (Fork/Join)' : stage.transitionRule === 'approval_gate' ? 'bpmn:UserTask' : 'bpmn:ServiceTask'}
                            </span>
                            {hasDecision && (
                              <span className="ml-1.5 px-2 py-0.5 rounded bg-purple-100 text-purple-800 font-mono font-bold text-[10px] border border-purple-200">
                                + ExclusiveGateway
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-3 text-slate-700">
                            {stage.name.includes('OUTREACH') || stage.name.includes('LEAD')
                              ? 'Lane 1: RM & Outreach'
                              : stage.name.includes('SCREENING') || stage.name.includes('RISK') || stage.name.includes('REVIEW')
                              ? 'Lane 3: Compliance & Risk'
                              : stage.name.includes('PROVISIONING') || stage.name.includes('TRADE')
                              ? 'Lane 4: Product Provisioning'
                              : 'Lane 2: AI Autonomous Swarm'}
                          </td>
                          <td className="py-3 px-3 text-slate-600">
                            {isParallel ? (
                              <span className="text-amber-700 font-medium font-mono text-[11px]">
                                Parallel Split &rarr; {stage.attachedAgentIds?.length} Tasks &rarr; Join
                              </span>
                            ) : hasDecision ? (
                              <span className="text-purple-700 font-medium font-mono text-[11px]">
                                Sequential Task &rarr; XOR Decision Gate
                              </span>
                            ) : (
                              <span className="text-slate-600 font-mono text-[11px]">Direct Sequential Flow</span>
                            )}
                          </td>
                          <td className="py-3 px-3">
                            <div className="flex flex-wrap gap-1">
                              {(stage.attachedAgentIds || []).map(agId => (
                                <span key={agId} className="px-1.5 py-0.5 bg-slate-100 text-slate-700 rounded text-[10px] font-mono">
                                  {agId}
                                </span>
                              ))}
                            </div>
                          </td>
                          <td className="py-3 px-3 font-mono text-[11px] text-slate-400 select-all">
                            Activity_{stage.id}
                          </td>
                        </tr>
                      );
                    })}

                    {/* End Event Row */}
                    <tr className="hover:bg-slate-50 transition">
                      <td className="py-3 px-3 font-extrabold text-emerald-700">End. Ready to Trade</td>
                      <td className="py-3 px-3">
                        <span className="px-2 py-0.5 rounded bg-rose-100 text-rose-800 font-mono font-bold text-[10px] border border-rose-200">
                          bpmn:EndEvent
                        </span>
                      </td>
                      <td className="py-3 px-3 text-slate-600 font-medium">Lane 4: Provisioning &amp; Core</td>
                      <td className="py-3 px-3 text-slate-500">Lifecycle Terminal State</td>
                      <td className="py-3 px-3 text-slate-400 font-mono text-[11px]">Core Banking Active</td>
                      <td className="py-3 px-3 font-mono text-[11px] text-slate-400 select-all">
                        EndEvent_{(journey.id || 'default').replace(/[^a-zA-Z0-9_]/g, '_')}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

      </div>

      {/* Global CSS injected for BPMN node marker highlighting and styling */}
      <style>{`
        .bpmn-canvas-styled .djs-container {
          background-color: #ffffff !important;
        }
        .bpmn-sim-active .djs-visual > rect,
        .bpmn-sim-active .djs-visual > polygon,
        .bpmn-sim-active .djs-visual > circle {
          stroke: #0474c4 !important;
          stroke-width: 4px !important;
          fill: #e0f2fe !important;
          filter: drop-shadow(0 0 10px rgba(4, 116, 196, 0.6)) !important;
          animation: bpmn-pulse 1.2s infinite ease-in-out;
        }
        .bpmn-sim-done .djs-visual > rect,
        .bpmn-sim-done .djs-visual > polygon,
        .bpmn-sim-done .djs-visual > circle {
          stroke: #059669 !important;
          stroke-width: 2.5px !important;
          fill: #ecfdf5 !important;
        }
        @keyframes bpmn-pulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.03); }
        }
        .djs-element.selected .djs-outline {
          stroke: #0474c4 !important;
          stroke-width: 2px !important;
        }
      `}</style>
    </div>
  );
}
