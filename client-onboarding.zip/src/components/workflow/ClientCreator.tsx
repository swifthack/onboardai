import React, { useState } from 'react';
import { Bot, Sparkles, Loader2, AlertCircle, RefreshCw } from 'lucide-react';
import { ClientProfile } from '../../types';
import { apiService } from '../../services/apiService';

interface ClientCreatorProps {
  onClientCreated: (client: ClientProfile) => void;
  onClose: () => void;
}

const SAMPLE_PROMPTS = [
  "A fintech payment gateway in London with clean audit results, 3 venture founders, and high transaction revenues.",
  "An offshore logistics trust in Panama with standard shipping assets but complex multi-layer nested shell holding firms.",
  "An artificial intelligence healthcare group in Zurich with strong academic founders, low debt, and biometric validation pending.",
  "A gold mining conglomerate in South America with high environmental risks and one politically exposed executive."
];

export default function ClientCreator({ onClientCreated, onClose }: ClientCreatorProps) {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;

    setLoading(true);
    setError('');

    try {
      const { client: generatedData } = await apiService.generateClient({
        companyName: prompt,
        jurisdiction: 'Delaware, USA',
        industry: 'Fintech / Technology',
        authorizerName: 'John Doe',
        authorizerEmail: 'johndoe@example.com'
      });
      
      // Complete the structure so it fits ClientProfile types
      const completedClient: ClientProfile = {
        id: `client_gen_${Date.now()}`,
        companyName: generatedData.companyName || 'AI Generated Corp',
        registrationNumber: generatedData.registrationNumber || `REG-${Math.floor(Math.random() * 900000 + 100000)}`,
        jurisdiction: generatedData.jurisdiction || 'Delaware, USA',
        industry: generatedData.industry || 'General Technologies',
        authorizedRepresentative: {
          name: generatedData.authorizedRepresentative?.name || 'Jane Doe',
          role: generatedData.authorizedRepresentative?.role || 'Director',
          email: generatedData.authorizedRepresentative?.email || 'doe@company.com',
          biometricVerified: false,
          biometricMatchScore: 0,
          biometricSelfieUrl: ''
        },
        shareholders: generatedData.shareholders || [
          { name: 'Founder One', equity: 100.0, pepStatus: false }
        ],
        financials: generatedData.financials || {
          revenue: '$5.0M USD',
          assets: '$2.0M USD',
          debtRatio: '0.25',
          rating: 'A'
        },
        documents: (generatedData.documents || []).map((doc: any, index: number) => ({
          ...doc,
          uploadedAt: new Date().toISOString().replace('T', ' ').substring(0, 16)
        })),
        workflowNodes: [], // Main application will initialize workflow nodes for new clients
        overallStatus: 'draft'
      };

      onClientCreated(completedClient);
      onClose();
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to synthesize client using Gemini AI');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-lg p-6 max-w-xl w-full mx-auto">
      <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100 mb-5">
        <div className="p-2.5 bg-blue-50 rounded-xl text-blue-600 animate-spin-slow">
          <Bot className="w-5.5 h-5.5" />
        </div>
        <div>
          <h3 className="font-semibold text-slate-900 text-sm flex items-center gap-1.5">
            AI Corporate Profile Synthesizer
            <span className="px-2 py-0.5 rounded-full text-[9px] font-mono font-bold uppercase tracking-wider bg-blue-100 text-blue-800">
              Gemini Powered
            </span>
          </h3>
          <p className="text-xs text-slate-500">Draft fully interactive corporate scenarios instantly</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wide font-mono mb-1.5">
            Describe the Corporate Entity to Onboard
          </label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            disabled={loading}
            rows={3}
            placeholder="e.g., A renewable hydrogen producer in Munich, Germany. Clear financials, 2 executive founders, highly capital intensive but zero regulatory sanctions..."
            className="w-full border border-slate-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 rounded-lg p-3 text-xs outline-none bg-slate-5/50 text-slate-800 resize-none"
          />
        </div>

        {/* Preset Prompt Suggestions */}
        <div>
          <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
            Or Click a Sample Compliance Preset:
          </span>
          <div className="grid grid-cols-1 gap-2">
            {SAMPLE_PROMPTS.map((preset, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setPrompt(preset)}
                disabled={loading}
                className="text-[11px] text-left px-3 py-2 border border-slate-100 hover:border-blue-100 hover:bg-blue-50/30 text-slate-600 hover:text-blue-900 rounded-md transition-colors duration-150 cursor-pointer"
              >
                {preset}
              </button>
            ))}
          </div>
        </div>

        {error && (
          <div className="flex items-start gap-1.5 p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800 font-sans">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        <div className="flex gap-2.5 pt-2 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            disabled={loading}
            className="flex-1 py-2 border border-slate-200 hover:bg-slate-50 text-slate-600 font-semibold rounded-lg text-xs transition cursor-pointer text-center"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading || !prompt.trim()}
            className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white font-semibold rounded-md text-xs transition shadow-sm flex items-center justify-center gap-1.5 cursor-pointer"
          >
            {loading ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" /> Synthesizing Profile...
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5" /> Generate Entity Sandbox
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
