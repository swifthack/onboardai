import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import {
  Building2,
  User,
  ShieldCheck,
  Landmark,
  Wallet,
  FileCheck,
  Activity,
  Sparkles,
  Database,
  FileText,
  ChevronDown,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Network,
  CheckCircle2,
  AlertTriangle,
  Info,
  GitBranch,
  Layers,
  RotateCcw,
  RefreshCw
} from 'lucide-react';
import cytoscape, { Core, EventObject } from 'cytoscape';
// @ts-ignore
import fcose from 'cytoscape-fcose';
import { ClientProfile } from '../../types';
import { MOCK_CLIENTS } from '../../mockData';

// Register fCoSE extension with Cytoscape
try {
  cytoscape.use(fcose);
} catch {
  // Safe if already initialized
}

// Types
export type NodeVerificationStatus = 'verified' | 'pending' | 'flagged' | 'amber';
export type NodeType = 'entity' | 'individual' | 'wallet' | 'regulatory' | 'account' | 'tax';
export type CategoryFilter = 'all' | 'ownership' | 'management' | 'subsidiaries' | 'banking';

export interface DataField {
  name: string;
  value: string;
  confidence: number;
  source?: string;
  stagePopulated?: string;
}

export interface NodeDocumentRequirement {
  id: string;
  name: string;
  category: string;
  status: 'verified' | 'uploaded' | 'pending' | 'missing';
  uploadedDocId?: string;
  mandatory: boolean;
}

export interface GraphNode {
  id: string;
  label: string;
  subLabel: string;
  type: NodeType;
  status: NodeVerificationStatus;
  categories: ('ownership' | 'management' | 'subsidiaries' | 'banking')[];
  shape: 'hexagon' | 'round-rectangle' | 'ellipse' | 'diamond' | 'octagon';
  bgColor: string;
  width: number;
  height: number;
  position: { x: number; y: number };
  parent?: string;
  stageOrigin: string;
  stageCode: string;
  details: {
    legalName: string;
    registration: string;
    jurisdiction: string;
    statusText: string;
    directorsCount?: number;
    directorsList?: string[];
    source: string;
    lastUpdated: string;
    confidence: number;
    dataFields: DataField[];
    documents: NodeDocumentRequirement[];
  };
}

export interface GraphEdge {
  id: string;
  from: string;
  to: string;
  label: string;
  tooltip: string;
  lineColor: string;
  lineStyle?: 'solid' | 'dashed';
  width?: number;
  arrowShape?: 'triangle' | 'none';
  category?: 'ownership' | 'management' | 'subsidiaries' | 'banking';
}

export interface EventTimelineItem {
  id: string;
  eventType: string;
  timestamp: string;
  description: string;
  stageName: string;
  nodeId?: string;
  badgeColor: string;
}

export interface DigitalTwinExplorerProps {
  clients?: ClientProfile[];
  activeClient?: ClientProfile;
  selectedClientId?: string;
  onSelectClient?: (clientId: string) => void;
  onAddDocument?: (newDoc: any, targetClientId?: string) => void;
  onUpdateClient?: (clientUpdates: Partial<ClientProfile>) => void;
}

// Helper to construct dynamic Knowledge Graph matching reference topology (13 total entities)
function buildCustomerGraphData(client: ClientProfile) {
  const isApproved = client.overallStatus === 'approved';
  const isRejected = client.overallStatus === 'rejected';
  const centerStatus: NodeVerificationStatus = isApproved ? 'verified' : isRejected ? 'flagged' : 'amber';

  const centerNodeId = client.id;
  const isMeridian = client.id === 'client_meridian' || client.companyName.toLowerCase().includes('meridian');
  const companyTitle = isMeridian ? 'Meridian Components Intl Ltd.' : client.companyName;

  const nodes: GraphNode[] = [];
  const edges: GraphEdge[] = [];

  // 1. Center Corporate Node (Hexagon, Royal Deep Sapphire #2563eb)
  nodes.push({
    id: centerNodeId,
    label: companyTitle,
    subLabel: `${client.industry || 'High-Precision Electronic Components'} • ${client.jurisdiction}`,
    type: 'entity',
    shape: 'hexagon',
    bgColor: '#2563eb',
    width: 64,
    height: 64,
    position: { x: 500, y: 350 },
    status: centerStatus,
    categories: ['ownership', 'management', 'subsidiaries', 'banking'],
    stageOrigin: 'Stage #1 (Prospect Intake) & Stage #2 (Entity Resolution)',
    stageCode: 'STAGE_01_02',
    details: {
      legalName: companyTitle,
      registration: client.registrationNumber,
      jurisdiction: client.jurisdiction,
      statusText: `ONBOARDING: ${client.overallStatus.toUpperCase()}`,
      directorsCount: 3,
      directorsList: ['Sir Arthur Vance (Executive Chairman)', 'Julian Vance, CFA (Group CFO)', 'Dr. Klaus Keller (CTO)'],
      source: `${client.jurisdiction} Official Companies Registry`,
      lastUpdated: 'Live Knowledge Base Synced',
      confidence: 0.99,
      dataFields: [
        { name: 'Legal Company Name', value: companyTitle, confidence: 1.0, source: 'Business Registry', stagePopulated: 'Stage #2: Entity Resolution' },
        { name: 'Registration UEN/ID', value: client.registrationNumber, confidence: 0.99, source: 'Govt Registry Extract', stagePopulated: 'Stage #2: Entity Resolution' },
        { name: 'Jurisdiction', value: client.jurisdiction, confidence: 1.0, source: 'Statutory Registry', stagePopulated: 'Stage #2: Entity Resolution' },
        { name: 'Industry Segment', value: client.industry, confidence: 0.98, source: 'SSIC / NAICS DB', stagePopulated: 'Stage #1: Prospect Intake' },
        { name: 'Annual Revenue', value: client.financials?.revenue || '£285,000,000 / annum', confidence: 0.96, source: 'Financial Audit', stagePopulated: 'Stage #4: Risk Assessment' },
        { name: 'Credit Score Rating', value: client.financials?.rating || 'AAA', confidence: 0.97, source: 'Internal Risk Engine', stagePopulated: 'Stage #4: Risk Assessment' }
      ],
      documents: [
        { id: 'doc_incorp', name: 'Certificate of Incorporation', category: 'Entity Legal Records', status: 'verified', mandatory: true },
        { id: 'doc_const', name: 'Articles of Association & Constitution', category: 'Entity Legal Records', status: 'verified', mandatory: true },
        { id: 'doc_audit', name: 'Audited Annual Financials (£285M Revenue)', category: 'Financial Proof', status: 'verified', mandatory: false }
      ]
    }
  });

  // OWNERSHIP NODES:
  // 2. Vance-Hartford Capital S.à r.l. (Round Rectangle, Elegant Slate Navy #1e293b)
  const vanceHartfordId = `${centerNodeId}_vance_hartford`;
  nodes.push({
    id: vanceHartfordId,
    label: 'Vance-Hartford Capital S.à r.l.',
    subLabel: 'Luxembourg Holding Vehicle (68% Direct Equity)',
    type: 'entity',
    shape: 'round-rectangle',
    bgColor: '#1e293b',
    width: 56,
    height: 50,
    position: { x: 230, y: 135 },
    status: 'verified',
    categories: ['ownership'],
    stageOrigin: 'Stage #2 • Ownership Mapping',
    stageCode: 'STAGE_02',
    details: {
      legalName: 'Vance-Hartford Capital S.à r.l.',
      registration: 'Luxembourg RCS: B-209481',
      jurisdiction: 'Luxembourg / Grand Duchy',
      statusText: 'UBO Holding Verified (68% Direct Equity)',
      source: 'CSSF & Luxembourg Trade and Companies Register (RCS)',
      lastUpdated: 'Indexed via Stage #2',
      confidence: 0.99,
      dataFields: [
        { name: 'Direct Equity Stake', value: '68.0% Direct Shareholding', confidence: 1.0, source: 'Register of Members', stagePopulated: 'Stage #2: Ownership' },
        { name: 'Corporate Form', value: 'Société à responsabilité limitée (S.à r.l.)', confidence: 1.0, source: 'RCS Luxembourg', stagePopulated: 'Stage #2: Ownership' },
        { name: 'LEI Code', value: '5493006VHC9920LU8102', confidence: 0.99, source: 'GLEIF Database', stagePopulated: 'Stage #2: Ownership' }
      ],
      documents: [
        { id: 'doc_vh_rcs', name: 'RCS Luxembourg Certificate of Good Standing', category: 'Holding Records', status: 'verified', mandatory: true }
      ]
    }
  });

  // Edge: Vance-Hartford -> Meridian (68% Direct Equity, Blue, width 3)
  edges.push({
    id: 'e_vh_to_center',
    from: vanceHartfordId,
    to: centerNodeId,
    label: '68% Direct Equity',
    tooltip: 'Direct Majority Equity Shareholder (68%)',
    lineColor: '#2563eb',
    width: 3,
    arrowShape: 'triangle',
    category: 'ownership'
  });

  // 3. Eleanor Vance (Circle, Forest Sage Emerald #059669)
  const eleanorId = `${centerNodeId}_eleanor_vance`;
  nodes.push({
    id: eleanorId,
    label: 'Eleanor Vance',
    subLabel: 'Beneficial Owner (29.2% of Vance-Hartford)',
    type: 'individual',
    shape: 'ellipse',
    bgColor: '#059669',
    width: 48,
    height: 48,
    position: { x: 520, y: 65 },
    status: 'verified',
    categories: ['ownership'],
    stageOrigin: 'Stage #2 • Beneficial Ownership & Identity',
    stageCode: 'STAGE_02',
    details: {
      legalName: 'Lady Eleanor Vance',
      registration: 'UBO ID: EV-UK-1982',
      jurisdiction: 'United Kingdom',
      statusText: 'UBO Identity & Source of Wealth Cleared',
      source: 'UK Companies House PSC & Identity Verification',
      lastUpdated: 'Indexed via Stage #2',
      confidence: 0.99,
      dataFields: [
        { name: 'Holding in Vance-Hartford', value: '29.2% Direct Shareholding', confidence: 1.0, source: 'Share Register', stagePopulated: 'Stage #2: Ownership' },
        { name: 'Indirect Stake in Meridian', value: '19.85% Indirect Equity', confidence: 0.99, source: 'UBO Calculation Engine', stagePopulated: 'Stage #2: Ownership' },
        { name: 'PEP / Sanctions Screening', value: 'Clean (Zero Watchlist Matches)', confidence: 1.0, source: 'World-Check', stagePopulated: 'Stage #4: Sanctions' }
      ],
      documents: [
        { id: 'doc_eleanor_id', name: 'Passport & Identity Verification Extract', category: 'Identity Proof', status: 'verified', mandatory: true }
      ]
    }
  });

  // Edge: Eleanor Vance -> Vance-Hartford (29.2% Ownership, Blue)
  edges.push({
    id: 'e_eleanor_to_vh',
    from: eleanorId,
    to: vanceHartfordId,
    label: '29.2% Ownership',
    tooltip: 'Direct 29.2% Shareholding in Vance-Hartford S.à r.l.',
    lineColor: '#2563eb',
    width: 2,
    arrowShape: 'triangle',
    category: 'ownership'
  });

  // 4. Sir Arthur Vance (Circle, Forest Sage Emerald #059669) - Belongs to Ownership & Management
  const arthurId = `${centerNodeId}_sir_arthur_vance`;
  nodes.push({
    id: arthurId,
    label: 'Sir Arthur Vance',
    subLabel: 'Executive Chairman & Controlling UBO (70.8%)',
    type: 'individual',
    shape: 'ellipse',
    bgColor: '#059669',
    width: 48,
    height: 48,
    position: { x: 470, y: 170 },
    status: 'verified',
    categories: ['ownership', 'management'],
    stageOrigin: 'Stage #2 (Ownership) & Stage #3 (Board KYC)',
    stageCode: 'STAGE_02_03',
    details: {
      legalName: 'Sir Arthur Vance, KBE',
      registration: 'Director Mandate #1 / UBO Reg: AV-9021',
      jurisdiction: 'United Kingdom',
      statusText: 'Executive Chairman & Ultimate Controlling Person',
      source: 'UK Companies House Register of Directors & PSC',
      lastUpdated: 'Indexed via Stage #2 & #3',
      confidence: 1.0,
      dataFields: [
        { name: 'Governance Role', value: 'Executive Chairman of the Board', confidence: 1.0, source: 'Board Minutes', stagePopulated: 'Stage #3: Management' },
        { name: 'Holding in Vance-Hartford', value: '70.8% Majority Ownership', confidence: 1.0, source: 'Share Register', stagePopulated: 'Stage #2: Ownership' },
        { name: 'Effective Control', value: 'Ultimate Controlling Beneficial Owner', confidence: 1.0, source: 'PSC Register', stagePopulated: 'Stage #2: Ownership' }
      ],
      documents: [
        { id: 'doc_arthur_consent', name: 'Director Consent to Act & Certified ID', category: 'Governance Proof', status: 'verified', mandatory: true }
      ]
    }
  });

  // Edge: Sir Arthur Vance -> Vance-Hartford (70.8% Ownership, Blue)
  edges.push({
    id: 'e_arthur_to_vh',
    from: arthurId,
    to: vanceHartfordId,
    label: '70.8% Ownership',
    tooltip: 'Direct 70.8% Controlling Interest in Vance-Hartford S.à r.l.',
    lineColor: '#2563eb',
    width: 2,
    arrowShape: 'triangle',
    category: 'ownership'
  });

  // Edge: Sir Arthur Vance -> Meridian (Executive Chairman, Cerulean)
  edges.push({
    id: 'e_arthur_to_center',
    from: arthurId,
    to: centerNodeId,
    label: 'Executive Chairman',
    tooltip: 'Executive Chairman of the Board of Directors',
    lineColor: '#0284c7',
    width: 2,
    arrowShape: 'triangle',
    category: 'management'
  });

  // 5. Apex Nordic Tech Fund IV SCSp (Round Rectangle, Elegant Slate Navy #1e293b)
  const apexNordicId = `${centerNodeId}_apex_nordic`;
  nodes.push({
    id: apexNordicId,
    label: 'Apex Nordic Tech Fund IV SCSp',
    subLabel: 'Institutional Partner (22% Equity Partner)',
    type: 'entity',
    shape: 'round-rectangle',
    bgColor: '#1e293b',
    width: 56,
    height: 50,
    position: { x: 740, y: 175 },
    status: 'verified',
    categories: ['ownership'],
    stageOrigin: 'Stage #2 • Institutional Ownership Mapping',
    stageCode: 'STAGE_02',
    details: {
      legalName: 'Apex Nordic Tech Fund IV SCSp',
      registration: 'Luxembourg SCSp Reg: B-240182',
      jurisdiction: 'Luxembourg / European Union',
      statusText: 'Regulated Institutional Special Limited Partnership',
      source: 'CSSF Luxembourg Regulatory Database',
      lastUpdated: 'Indexed via Stage #2',
      confidence: 0.99,
      dataFields: [
        { name: 'Equity Stake', value: '22.0% Equity Partner', confidence: 1.0, source: 'Partnership Agreement', stagePopulated: 'Stage #2: Ownership' },
        { name: 'Fund Manager', value: 'Apex Asset Management Europe S.A.', confidence: 0.99, source: 'CSSF Filing', stagePopulated: 'Stage #2: Ownership' },
        { name: 'Regulatory Standing', value: 'Regulated AIFMD Alternative Fund', confidence: 1.0, source: 'CSSF Ledger', stagePopulated: 'Stage #2: Ownership' }
      ],
      documents: [
        { id: 'doc_apex_cert', name: 'Institutional Fund Formation & Register of LP Interests', category: 'Partnership Proof', status: 'verified', mandatory: true }
      ]
    }
  });

  // Edge: Apex Nordic Fund -> Meridian (22% Equity Partner, Blue)
  edges.push({
    id: 'e_apex_to_center',
    from: apexNordicId,
    to: centerNodeId,
    label: '22% Equity Partner',
    tooltip: 'Institutional Partner (22% Direct Equity)',
    lineColor: '#2563eb',
    width: 2,
    arrowShape: 'triangle',
    category: 'ownership'
  });

  // MANAGEMENT NODES:
  // 6. Julian Vance, CFA (Diamond, Executive Marine Cerulean #0284c7)
  const julianId = `${centerNodeId}_julian_vance`;
  nodes.push({
    id: julianId,
    label: 'Julian Vance, CFA',
    subLabel: 'Group CFO / Director',
    type: 'individual',
    shape: 'diamond',
    bgColor: '#0284c7',
    width: 50,
    height: 50,
    position: { x: 815, y: 275 },
    status: 'verified',
    categories: ['management'],
    stageOrigin: 'Stage #3 • Executive & Financial Management KYC',
    stageCode: 'STAGE_03',
    details: {
      legalName: 'Julian Vance, CFA',
      registration: 'Director Mandate #2 / ICAEW / CFA Charter #81920',
      jurisdiction: client.jurisdiction,
      statusText: 'Group CFO & Authorized Banking Signatory',
      source: 'UK Companies House & CFA Institute Roster',
      lastUpdated: 'Indexed via Stage #3',
      confidence: 0.99,
      dataFields: [
        { name: 'Executive Role', value: 'Group Chief Financial Officer & Director', confidence: 1.0, source: 'Board Appointment', stagePopulated: 'Stage #3: Management' },
        { name: 'Signing Authority', value: 'Sole Signatory up to £2,000,000', confidence: 1.0, source: 'Board Banking Resolution', stagePopulated: 'Stage #3: Management' },
        { name: 'Biometric Verification', value: 'Passed 99.1% Liveness Score', confidence: 0.99, source: 'Biometric Engine', stagePopulated: 'Stage #3: Management' }
      ],
      documents: [
        { id: 'doc_julian_passport', name: 'Certified Passport & Biometric Face Match', category: 'Identity Proof', status: 'verified', mandatory: true }
      ]
    }
  });

  // Edge: Julian Vance -> Meridian (Group CFO / Director, Cerulean)
  edges.push({
    id: 'e_julian_to_center',
    from: julianId,
    to: centerNodeId,
    label: 'Group CFO / Director',
    tooltip: 'Executive Director and Group Chief Financial Officer',
    lineColor: '#0284c7',
    width: 2,
    arrowShape: 'triangle',
    category: 'management'
  });

  // 7. Dr. Klaus Keller (Diamond, Executive Marine Cerulean #0284c7)
  const klausId = `${centerNodeId}_klaus_keller`;
  nodes.push({
    id: klausId,
    label: 'Dr. Klaus Keller',
    subLabel: 'CTO / Technical Director',
    type: 'individual',
    shape: 'diamond',
    bgColor: '#0284c7',
    width: 50,
    height: 50,
    position: { x: 940, y: 310 },
    status: 'verified',
    categories: ['management'],
    stageOrigin: 'Stage #3 • Technical Governance KYC',
    stageCode: 'STAGE_03',
    details: {
      legalName: 'Dr. Klaus Keller, Ph.D.',
      registration: 'Director Mandate #3',
      jurisdiction: 'Germany / United Kingdom',
      statusText: 'Chief Technology Officer & Executive Board Member',
      source: 'UK Companies House Registry Extract',
      lastUpdated: 'Indexed via Stage #3',
      confidence: 0.98,
      dataFields: [
        { name: 'Corporate Role', value: 'Chief Technology Officer & Board Director', confidence: 1.0, source: 'Board Minutes', stagePopulated: 'Stage #3: Management' },
        { name: 'Appointment Date', value: '18 March 2021', confidence: 0.99, source: 'Statutory Filings', stagePopulated: 'Stage #3: Management' },
        { name: 'Sanctions Clearance', value: 'Screened Negative (Zero Hits)', confidence: 1.0, source: 'World-Check', stagePopulated: 'Stage #4: Sanctions' }
      ],
      documents: [
        { id: 'doc_klaus_id', name: 'German National Identity Card & Director Mandate', category: 'Identity Proof', status: 'verified', mandatory: true }
      ]
    }
  });

  // Edge: Dr. Klaus Keller -> Julian Vance (Cerulean line, no arrow)
  edges.push({
    id: 'e_klaus_to_julian',
    from: klausId,
    to: julianId,
    label: '',
    tooltip: 'Joint Executive Committee Governance',
    lineColor: '#0284c7',
    width: 1.5,
    arrowShape: 'none',
    category: 'management'
  });

  // Edge: Dr. Klaus Keller -> Meridian (CTO / Technical Director, Cerulean)
  edges.push({
    id: 'e_klaus_to_center',
    from: klausId,
    to: centerNodeId,
    label: 'CTO / Technical Director',
    tooltip: 'Chief Technology Officer & Technical Director',
    lineColor: '#0284c7',
    width: 2,
    arrowShape: 'triangle',
    category: 'management'
  });

  // REGULATORY / COMPLIANCE NODE:
  // 8. Global Sanctions & PEP Gateway (Octagon, Slate Titanium #475569)
  const sanctionsId = `${centerNodeId}_sanctions_gateway`;
  nodes.push({
    id: sanctionsId,
    label: 'Global Sanctions & PEP Gateway',
    subLabel: 'Regulatory & Adverse Media Screening Engine',
    type: 'regulatory',
    shape: 'octagon',
    bgColor: '#475569',
    width: 52,
    height: 52,
    position: { x: 865, y: 400 },
    status: 'verified',
    categories: ['ownership'],
    stageOrigin: 'Stage #4 • Sanctions, PEP & Adverse Media Screening',
    stageCode: 'STAGE_04',
    details: {
      legalName: 'Global Real-Time Sanctions, PEP & Watchlist Gateway',
      registration: 'Gateway Audit ID: GW-2026-0914',
      jurisdiction: 'UN / OFAC / EU / UK HM Treasury',
      statusText: 'Continuous Screening Passed (0 Flags / Clean)',
      source: 'Refinitiv World-Check One & Dow Jones Risk & Compliance',
      lastUpdated: 'Continuous Real-Time Feed',
      confidence: 1.0,
      dataFields: [
        { name: 'OFAC SDN List Status', value: 'Zero Matches (Cleared)', confidence: 1.0, source: 'US OFAC Feed', stagePopulated: 'Stage #4: Sanctions' },
        { name: 'EU Financial Sanctions', value: 'Zero Matches (Cleared)', confidence: 1.0, source: 'EEAS Sanctions Database', stagePopulated: 'Stage #4: Sanctions' },
        { name: 'UK HM Treasury Sanctions', value: 'Zero Matches (Cleared)', confidence: 1.0, source: 'OFSI Consolidated List', stagePopulated: 'Stage #4: Sanctions' },
        { name: 'Adverse Media Findings', value: 'No Material Adverse Findings', confidence: 0.98, source: 'Global Media Engine', stagePopulated: 'Stage #4: Sanctions' }
      ],
      documents: [
        { id: 'doc_sanctions_audit', name: 'Consolidated AML/PEP Screening Clearance Certificate', category: 'Compliance Audit', status: 'verified', mandatory: true }
      ]
    }
  });

  // Edge: Global Sanctions Gateway -> Meridian (Screening Passed (0 flags), Slate)
  edges.push({
    id: 'e_sanctions_to_center',
    from: sanctionsId,
    to: centerNodeId,
    label: 'Screening Passed (0 flags)',
    tooltip: 'Sanctions, PEP & Adverse Media Audit Passed with Zero Flags',
    lineColor: '#64748b',
    width: 2,
    arrowShape: 'triangle',
    category: 'ownership'
  });

  // SUBSIDIARY NODES:
  // 9. Meridian Precision GmbH (Round Rectangle, Refined Slate Indigo #4f46e5)
  const precisionGmbhId = `${centerNodeId}_sub_precision_gmbh`;
  nodes.push({
    id: precisionGmbhId,
    label: 'Meridian Precision GmbH',
    subLabel: 'Munich, Germany • 100% Wholly Owned Subsidiary',
    type: 'entity',
    shape: 'round-rectangle',
    bgColor: '#4f46e5',
    width: 54,
    height: 48,
    position: { x: 135, y: 440 },
    status: 'verified',
    categories: ['subsidiaries'],
    stageOrigin: 'Stage #2 • Corporate Group Hierarchy',
    stageCode: 'STAGE_02',
    details: {
      legalName: 'Meridian Precision Optics GmbH',
      registration: 'Handelsregister: HRB 248910 (Amtsgericht München)',
      jurisdiction: 'Germany / Bavaria',
      statusText: 'Wholly-Owned Operating Subsidiary (100% Owned)',
      source: 'German Commercial Register (Handelsregister)',
      lastUpdated: 'Indexed via Stage #2',
      confidence: 0.99,
      dataFields: [
        { name: 'Ownership Stake', value: '100.0% Wholly Owned', confidence: 1.0, source: 'Commercial Register Extract', stagePopulated: 'Stage #2: Subsidiaries' },
        { name: 'Operational Focus', value: 'High-Precision Electronic Fabrication', confidence: 0.98, source: 'Corporate Profile', stagePopulated: 'Stage #2: Subsidiaries' },
        { name: 'Paid-Up Share Capital', value: '€2,500,000 Fully Paid', confidence: 0.99, source: 'Audit Report', stagePopulated: 'Stage #2: Subsidiaries' }
      ],
      documents: [
        { id: 'doc_gmbh_hrb', name: 'Handelsregister Extract (HRB Munich)', category: 'Subsidiary Records', status: 'verified', mandatory: true }
      ]
    }
  });

  // Edge: Meridian -> Meridian Precision GmbH (100% Wholly Owned, Dashed Slate)
  edges.push({
    id: 'e_center_to_gmbh',
    from: centerNodeId,
    to: precisionGmbhId,
    label: '100% Wholly Owned',
    tooltip: 'Wholly-Owned German Operating Subsidiary',
    lineColor: '#64748b',
    lineStyle: 'dashed',
    width: 2,
    arrowShape: 'triangle',
    category: 'subsidiaries'
  });

  // 10. Meridian APAC Pte. Ltd. (Round Rectangle, Refined Slate Indigo #4f46e5)
  const apacPteId = `${centerNodeId}_sub_apac_pte`;
  nodes.push({
    id: apacPteId,
    label: 'Meridian APAC Pte. Ltd.',
    subLabel: 'Singapore • 100% Wholly Owned Subsidiary',
    type: 'entity',
    shape: 'round-rectangle',
    bgColor: '#4f46e5',
    width: 54,
    height: 48,
    position: { x: 215, y: 560 },
    status: 'verified',
    categories: ['subsidiaries'],
    stageOrigin: 'Stage #2 • Corporate Group Hierarchy',
    stageCode: 'STAGE_02',
    details: {
      legalName: 'Meridian APAC Pte. Ltd.',
      registration: 'UEN: 202109841K',
      jurisdiction: 'Singapore',
      statusText: 'Wholly-Owned Regional Operating Hub',
      source: 'ACRA Singapore Statutory Register',
      lastUpdated: 'Indexed via Stage #2',
      confidence: 0.99,
      dataFields: [
        { name: 'Ownership Stake', value: '100.0% Wholly Owned', confidence: 1.0, source: 'ACRA Registry Feed', stagePopulated: 'Stage #2: Subsidiaries' },
        { name: 'Regional Mandate', value: 'Asia-Pacific Supply Chain & Logistics Center', confidence: 0.98, source: 'BizProfile', stagePopulated: 'Stage #2: Subsidiaries' },
        { name: 'Tax Compliance Status', value: 'IRAS Compliant (No Outstanding Returns)', confidence: 1.0, source: 'ACRA BizProfile', stagePopulated: 'Stage #2: Subsidiaries' }
      ],
      documents: [
        { id: 'doc_apac_bizprofile', name: 'ACRA Electronic BizProfile Extract', category: 'Subsidiary Records', status: 'verified', mandatory: true }
      ]
    }
  });

  // Edge: Meridian -> Meridian APAC Pte. Ltd. (100% Wholly Owned, Dashed Slate)
  edges.push({
    id: 'e_center_to_apac',
    from: centerNodeId,
    to: apacPteId,
    label: '100% Wholly Owned',
    tooltip: 'Wholly-Owned APAC Regional Operating Hub',
    lineColor: '#64748b',
    lineStyle: 'dashed',
    width: 2,
    arrowShape: 'triangle',
    category: 'subsidiaries'
  });

  // 11. Meridian Components Americas LLC (Round Rectangle, Refined Slate Indigo #4f46e5)
  const americasLlcId = `${centerNodeId}_sub_americas_llc`;
  nodes.push({
    id: americasLlcId,
    label: 'Meridian Components Americas LLC',
    subLabel: 'Delaware, USA • 100% Wholly Owned Subsidiary',
    type: 'entity',
    shape: 'round-rectangle',
    bgColor: '#4f46e5',
    width: 54,
    height: 48,
    position: { x: 375, y: 640 },
    status: 'verified',
    categories: ['subsidiaries'],
    stageOrigin: 'Stage #2 • Corporate Group Hierarchy',
    stageCode: 'STAGE_02',
    details: {
      legalName: 'Meridian Components Americas LLC',
      registration: 'Delaware Division of Corps No: 7192841',
      jurisdiction: 'United States (Delaware)',
      statusText: 'Wholly-Owned Operating Subsidiary',
      source: 'Delaware Secretary of State / Div of Corporations',
      lastUpdated: 'Indexed via Stage #2',
      confidence: 0.99,
      dataFields: [
        { name: 'Ownership Stake', value: '100.0% Single-Member LLC', confidence: 1.0, source: 'Delaware Certificate of Formation', stagePopulated: 'Stage #2: Subsidiaries' },
        { name: 'Standing', value: 'Certificate of Good Standing Issued', confidence: 1.0, source: 'State of Delaware', stagePopulated: 'Stage #2: Subsidiaries' },
        { name: 'US Tax ID (EIN)', value: 'XX-XXX8921', confidence: 0.99, source: 'IRS Confirmation Letter', stagePopulated: 'Stage #2: Subsidiaries' }
      ],
      documents: [
        { id: 'doc_americas_cert', name: 'Delaware Certificate of Formation & Good Standing', category: 'Subsidiary Records', status: 'verified', mandatory: true }
      ]
    }
  });

  // Edge: Meridian -> Meridian Components Americas LLC (100% Wholly Owned, Dashed Slate)
  edges.push({
    id: 'e_center_to_americas',
    from: centerNodeId,
    to: americasLlcId,
    label: '100% Wholly Owned',
    tooltip: 'Wholly-Owned North American Operating Subsidiary',
    lineColor: '#64748b',
    lineStyle: 'dashed',
    width: 2,
    arrowShape: 'triangle',
    category: 'subsidiaries'
  });

  // BANKING / TREASURY NODES:
  // 12. Onboard.ai Multi-Currency Treasury Hub (Round Rectangle, Cobalt Royal Blue #2563eb)
  const treasuryHubId = `${centerNodeId}_treasury_hub`;
  nodes.push({
    id: treasuryHubId,
    label: 'Onboard.ai Multi-Currency Treasury Hub',
    subLabel: 'Global Liquidity Pool & FX Hedging',
    type: 'account',
    shape: 'round-rectangle',
    bgColor: '#2563eb',
    width: 54,
    height: 48,
    position: { x: 745, y: 510 },
    status: 'verified',
    categories: ['banking'],
    stageOrigin: 'Stage #6 • Global Liquidity & Treasury Provisioning',
    stageCode: 'STAGE_06',
    details: {
      legalName: 'Onboard.ai Institutional Multi-Currency Treasury Hub',
      registration: 'Hub Facility Ref: HUB-UK-98210',
      jurisdiction: 'Global Institutional Clearing',
      statusText: 'Multi-Currency Liquidity Pool Active',
      source: 'Institutional Core Banking & Liquidity Gateway',
      lastUpdated: 'Indexed via Stage #6',
      confidence: 1.0,
      dataFields: [
        { name: 'Supported Currencies', value: 'GBP, EUR, USD, SGD, JPY (Real-Time Clearing)', confidence: 1.0, source: 'Treasury Engine', stagePopulated: 'Stage #6: Banking' },
        { name: 'Daily Settlement Cap', value: '£25,000,000 / day', confidence: 0.99, source: 'Risk Credit Committee', stagePopulated: 'Stage #6: Banking' },
        { name: 'Automated Sweeping', value: 'Zero-Balance Sweep to Master Account', confidence: 1.0, source: 'Treasury Mandate', stagePopulated: 'Stage #6: Banking' }
      ],
      documents: [
        { id: 'doc_treasury_mandate', name: 'Institutional Treasury Liquidity Agreement', category: 'Banking Mandate', status: 'verified', mandatory: true }
      ]
    }
  });

  // Edge: Meridian -> Onboard.ai Multi-Currency Treasury Hub (Global Liquidity Pool, Blue)
  edges.push({
    id: 'e_center_to_hub',
    from: centerNodeId,
    to: treasuryHubId,
    label: 'Global Liquidity Pool',
    tooltip: 'Automated Global Liquidity Pool & Multi-Currency Clearing',
    lineColor: '#2563eb',
    width: 2,
    arrowShape: 'triangle',
    category: 'banking'
  });

  // 13. Onboard.ai Master GBP Account (Round Rectangle, Marine Cerulean #0284c7)
  const masterGbpId = `${centerNodeId}_master_gbp_account`;
  nodes.push({
    id: masterGbpId,
    label: 'Onboard.ai Master GBP Account',
    subLabel: 'Primary Operating Mandate',
    type: 'account',
    shape: 'round-rectangle',
    bgColor: '#0284c7',
    width: 54,
    height: 48,
    position: { x: 620, y: 630 },
    status: 'verified',
    categories: ['banking'],
    stageOrigin: 'Stage #6 • Master Operating CASA Provisioning',
    stageCode: 'STAGE_06',
    details: {
      legalName: `Commercial Operating CASA Facility (${companyTitle})`,
      registration: 'Sort: 40-12-88 • Acc No: 81920481',
      jurisdiction: 'United Kingdom (CHAPS / Faster Payments)',
      statusText: 'Primary Operating Mandate Provisioned & Active',
      source: 'Core Banking Engine & Clearing Gateway',
      lastUpdated: 'Indexed via Stage #6',
      confidence: 1.0,
      dataFields: [
        { name: 'Account Type', value: 'Commercial Corporate Current Operating (CASA)', confidence: 1.0, source: 'Core Banking Ledger', stagePopulated: 'Stage #6: Banking' },
        { name: 'Primary Currency', value: 'GBP (British Pounds Sterling)', confidence: 1.0, source: 'Account Mandate', stagePopulated: 'Stage #6: Banking' },
        { name: 'Authorized Dual Signatories', value: 'Julian Vance & Sir Arthur Vance', confidence: 1.0, source: 'Board Banking Resolution', stagePopulated: 'Stage #6: Banking' }
      ],
      documents: [
        { id: 'doc_casa_agreement', name: 'Master Commercial Banking SLA & Account Mandate', category: 'Banking Mandate', status: 'verified', mandatory: true }
      ]
    }
  });

  // Edge: Meridian -> Onboard.ai Master GBP Account (Primary Operating Mandate, Blue)
  edges.push({
    id: 'e_center_to_gbp',
    from: centerNodeId,
    to: masterGbpId,
    label: 'Primary Operating Mandate',
    tooltip: 'Primary Commercial Current Operating Account Mandate',
    lineColor: '#2563eb',
    width: 2,
    arrowShape: 'triangle',
    category: 'banking'
  });

  // Stage Timeline
  const events: EventTimelineItem[] = [
    {
      id: 'ev1',
      eventType: 'PROSPECT_INTAKE',
      stageName: 'Stage #1: Prospect Qualification',
      timestamp: 'Today 09:00',
      description: `Ingested ${companyTitle} statutory records, UK Companies House registration (${client.registrationNumber}), and group hierarchy.`,
      nodeId: centerNodeId,
      badgeColor: 'bg-blue-50 text-blue-700 border border-blue-200'
    },
    {
      id: 'ev2',
      eventType: 'ENTITY_RESOLVED',
      stageName: 'Stage #2: Entity Resolution & UBO Chain',
      timestamp: 'Today 09:15',
      description: 'Vance-Hartford Capital S.à r.l. (68%) and Apex Nordic Tech Fund IV SCSp (22%) resolved as principal equity holders.',
      nodeId: vanceHartfordId,
      badgeColor: 'bg-blue-50 text-blue-700 border border-blue-200'
    },
    {
      id: 'ev3',
      eventType: 'DYNAMIC_KYC_INDEXED',
      stageName: 'Stage #3: Management & Board KYC',
      timestamp: 'Today 09:28',
      description: 'Sir Arthur Vance, Julian Vance, CFA, and Dr. Klaus Keller verified as directors and executive signatories.',
      nodeId: julianId,
      badgeColor: 'bg-emerald-50 text-emerald-700 border border-emerald-200'
    },
    {
      id: 'ev4',
      eventType: 'SANCTIONS_CLEARED',
      stageName: 'Stage #4: Sanctions & PEP Gateway',
      timestamp: 'Today 09:40',
      description: 'Global screening completed across OFAC, EU, and UK HM Treasury databases. Zero flags detected.',
      nodeId: sanctionsId,
      badgeColor: 'bg-emerald-50 text-emerald-700 border border-emerald-200'
    },
    {
      id: 'ev5',
      eventType: 'CASA_PROVISIONED',
      stageName: 'Stage #6: Banking & Treasury Provisioning',
      timestamp: 'Today 10:05',
      description: 'Master GBP operating current account and Multi-Currency Treasury Hub provisioned and linked.',
      nodeId: masterGbpId,
      badgeColor: 'bg-emerald-50 text-emerald-700 border border-emerald-200'
    }
  ];

  return { nodes, edges, events };
}

export const DigitalTwinExplorer: React.FC<DigitalTwinExplorerProps> = ({
  clients = MOCK_CLIENTS,
  activeClient,
  selectedClientId,
  onSelectClient,
  onAddDocument,
  onUpdateClient
}) => {
  const currentClient = useMemo(() => {
    if (selectedClientId) {
      const match = clients.find((c) => c.id === selectedClientId);
      if (match) return match;
    }
    return activeClient || clients[0] || MOCK_CLIENTS[0];
  }, [clients, activeClient, selectedClientId]);

  // Full Graph Data (Total 13 nodes)
  const { nodes, edges, events } = useMemo(() => {
    return buildCustomerGraphData(currentClient);
  }, [currentClient]);

  // Selected Node State
  const [selectedNodeId, setSelectedNodeId] = useState<string>(currentClient.id);
  const [activeTab, setActiveTab] = useState<'details' | 'timeline' | 'fcose_specs'>('details');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Active Category Filter: 'all' | 'ownership' | 'management' | 'subsidiaries' | 'banking'
  const [activeFilter, setActiveFilter] = useState<CategoryFilter>('all');

  // DOM Refs
  const cyContainerRef = useRef<HTMLDivElement>(null);
  const cyRef = useRef<Core | null>(null);

  // Filtered Nodes & Edges based on activeFilter
  const { filteredNodes, filteredEdges } = useMemo(() => {
    let resultNodes: GraphNode[] = [];

    if (activeFilter === 'all') {
      resultNodes = nodes;
    } else {
      resultNodes = nodes.filter((n) => n.categories.includes(activeFilter));
    }

    const nodeIds = new Set(resultNodes.map((n) => n.id));
    const resultEdges = edges.filter((e) => nodeIds.has(e.from) && nodeIds.has(e.to));

    return { filteredNodes: resultNodes, filteredEdges: resultEdges };
  }, [nodes, edges, activeFilter]);

  // Category Node Counts
  const counts = useMemo(() => {
    return {
      all: nodes.length, // exactly 13
      ownership: nodes.filter((n) => n.categories.includes('ownership')).length,
      management: nodes.filter((n) => n.categories.includes('management')).length,
      subsidiaries: nodes.filter((n) => n.categories.includes('subsidiaries')).length,
      banking: nodes.filter((n) => n.categories.includes('banking')).length
    };
  }, [nodes]);

  // Selected Node Object
  const selectedNode = useMemo(() => {
    const found = filteredNodes.find((n) => n.id === selectedNodeId);
    if (found) return found;
    return filteredNodes[0] || nodes[0];
  }, [filteredNodes, nodes, selectedNodeId]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Build Cytoscape Elements
  const cyElements = useMemo(() => {
    const elements: any[] = [];

    // Add Nodes
    filteredNodes.forEach((node) => {
      const isCenter = node.id === currentClient.id;
      const isPep = node.details.statusText.includes('PEP');
      elements.push({
        data: {
          id: node.id,
          label: node.label,
          subLabel: node.subLabel,
          type: node.type,
          status: node.status,
          shape: node.shape,
          bgColor: node.bgColor,
          width: node.width,
          height: node.height,
          isPep: isPep,
          isCenter: isCenter
        },
        position: { ...node.position }
      });
    });

    // Add Edges
    filteredEdges.forEach((edge) => {
      elements.push({
        data: {
          id: edge.id,
          source: edge.from,
          target: edge.to,
          label: edge.label,
          tooltip: edge.tooltip,
          lineColor: edge.lineColor,
          lineStyle: edge.lineStyle || 'solid',
          width: edge.width || 2,
          arrowShape: edge.arrowShape || 'triangle'
        }
      });
    });

    return elements;
  }, [filteredNodes, filteredEdges, currentClient.id]);

  // Apply Preset Reference Layout
  const applyPresetLayout = useCallback((animate = true) => {
    const cy = cyRef.current;
    if (!cy) return;

    if (animate) {
      cy.batch(() => {
        filteredNodes.forEach((node) => {
          const cyNode = cy.getElementById(node.id);
          if (cyNode.length > 0) {
            cyNode.animate({
              position: { ...node.position },
              duration: 450,
              easing: 'ease-out-cubic' as any
            });
          }
        });
      });
      setTimeout(() => {
        try {
          cy.fit(undefined, 40);
        } catch {}
      }, 480);
    } else {
      const layout = cy.layout({
        name: 'preset',
        fit: true,
        padding: 40
      });
      layout.run();
    }
  }, [filteredNodes]);

  // Execute fCoSE Layout
  const executeFCoSE = useCallback(() => {
    const cy = cyRef.current;
    if (!cy) return;

    try {
      const layout = cy.layout({
        name: 'fcose',
        quality: 'default',
        randomize: false,
        animate: true,
        animationDuration: 700,
        animationEasing: 'ease-out',
        fit: true,
        padding: 45,
        nodeRepulsion: (node: any) => 6500,
        idealEdgeLength: (edge: any) => 130,
        edgeElasticity: 0.45,
        nestingFactor: 0.1,
        gravity: 0.25,
        numIter: 2500,
        tile: true
      });
      layout.run();
    } catch (e) {
      console.warn('Falling back to preset reference layout:', e);
      try {
        applyPresetLayout(true);
      } catch {}
    }
  }, [applyPresetLayout]);

  // Initialize and update Cytoscape instance
  useEffect(() => {
    if (!cyContainerRef.current) return;

    // Cytoscape Stylesheet tailored for Clean & Elegant Presentation
    const stylesheet: any[] = [
      // Base Node Style
      {
        selector: 'node',
        style: {
          'label': 'data(label)',
          'color': '#0f172a',
          'font-size': '11px',
          'font-weight': 700,
          'font-family': 'Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
          'text-valign': 'bottom',
          'text-halign': 'center',
          'text-margin-y': 7,
          'text-wrap': 'wrap',
          'text-max-width': 120,
          'shape': 'data(shape)',
          'background-color': 'data(bgColor)',
          'width': 'data(width)',
          'height': 'data(height)',
          'border-width': 2.5,
          'border-color': '#ffffff',
          'border-opacity': 0.95,
          'text-background-color': '#ffffff',
          'text-background-opacity': 0.9,
          'text-background-padding': 2.5,
          'text-background-shape': 'roundrectangle',
          'text-border-color': '#e2e8f0',
          'text-border-width': 0.75,
          'text-border-opacity': 0.85,
          'transition-property': 'background-color, border-color, border-width, width, height',
          'transition-duration': 0.2
        }
      },
      // Center Corporate Entity Styling
      {
        selector: 'node[?isCenter]',
        style: {
          'border-width': 3.5,
          'border-color': '#ffffff',
          'border-opacity': 1,
          'font-size': '12px',
          'font-weight': 800,
          'color': '#0f172a'
        }
      },
      // Selected Node Highlighting
      {
        selector: 'node:selected',
        style: {
          'border-color': '#2563eb',
          'border-width': 3.5,
          'border-opacity': 1,
          'shadow-blur': 12,
          'shadow-color': '#2563eb',
          'shadow-opacity': 0.3
        }
      },
      // Edge Base Style
      {
        selector: 'edge',
        style: {
          'curve-style': 'bezier',
          'line-color': 'data(lineColor)',
          'line-style': 'data(lineStyle)',
          'line-dash-pattern': [6, 3],
          'width': 'data(width)',
          'target-arrow-shape': 'data(arrowShape)',
          'target-arrow-color': 'data(lineColor)',
          'arrow-scale': 1.1,
          'label': 'data(label)',
          'font-size': '8.5px',
          'font-family': 'Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
          'font-weight': 600,
          'color': '#1e293b',
          'text-background-color': '#ffffff',
          'text-background-opacity': 0.96,
          'text-background-padding': 3,
          'text-background-shape': 'roundrectangle',
          'text-border-color': '#cbd5e1',
          'text-border-width': 0.8,
          'text-border-opacity': 0.95,
          'text-rotation': 'autorotate'
        }
      },
      // Selected / Active Edge
      {
        selector: 'edge:selected',
        style: {
          'width': 3.5,
          'color': '#0f172a',
          'text-border-color': '#64748b'
        }
      }
    ];

    // Create Cytoscape instance
    const cy = cytoscape({
      container: cyContainerRef.current,
      elements: cyElements,
      style: stylesheet,
      boxSelectionEnabled: false,
      autounselectify: false,
      wheelSensitivity: 0.25
    });

    cyRef.current = cy;

    // Node click handler
    cy.on('tap', 'node', (evt: EventObject) => {
      const node = evt.target;
      setSelectedNodeId(node.id());
    });

    // Default to clean reference layout, fitted to viewport
    applyPresetLayout(false);

    return () => {
      cy.destroy();
    };
  }, [cyElements, applyPresetLayout]);

  // When activeFilter changes, smoothly fit or reposition
  useEffect(() => {
    applyPresetLayout(true);
  }, [activeFilter, applyPresetLayout]);

  // Actions
  const handleVerifyNode = () => {
    showToast(`Node ${selectedNode.label} status verified.`);
  };

  const handleDocumentVerify = (docId: string) => {
    showToast(`Document ${docId} verified in Knowledge Graph.`);
  };

  return (
    <div className="flex flex-col min-h-[780px] bg-white text-slate-800 rounded-2xl overflow-hidden border border-slate-200 shadow-sm font-sans relative">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white border border-slate-700 px-4 py-2 rounded-xl shadow-xl text-xs font-semibold flex items-center gap-2 animate-bounce">
          <Sparkles className="w-4 h-4 text-blue-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* TOP HEADER: ENTITY DIGITAL TWIN TITLE & ENTITY SELECTOR */}
      <div className="px-6 py-4 bg-white border-b border-slate-200 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 shrink-0">
        
        {/* Left: Title & Algorithm Badge */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 w-full lg:w-auto">
          <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl border border-blue-200 shrink-0">
            <Network className="w-5 h-5 text-blue-600" />
          </div>

          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-base font-bold text-slate-900 tracking-tight">
                Entity Digital Twin
              </h2>
              <span className="px-2.5 py-0.5 rounded-full text-[9px] font-bold bg-blue-50 text-blue-700 border border-blue-200 font-mono flex items-center gap-1">
                <Activity className="w-3 h-3 text-blue-600" />
                SPECTRAL DRAFT + FORCE-DIRECTED POLISH
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[9px] font-bold bg-slate-100 text-slate-700 border border-slate-200 font-mono">
                13 TOPOLOGY NODES
              </span>
            </div>

            {/* Customer Dropdown Selector */}
            <div className="flex items-center gap-2 mt-1">
              <span className="text-xs text-slate-400 font-mono font-bold shrink-0">
                Active Corporate Entity:
              </span>
              <div className="relative">
                <select
                  value={currentClient.id}
                  onChange={(e) => {
                    if (onSelectClient) onSelectClient(e.target.value);
                  }}
                  className="bg-slate-50 hover:bg-slate-100 text-slate-900 font-bold text-xs px-3 py-1.5 pr-8 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer shadow-xs appearance-none font-sans"
                >
                  {clients.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.companyName} ({c.jurisdiction})
                    </option>
                  ))}
                </select>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>
          </div>
        </div>

        {/* Right: Client Metadata Pills */}
        <div className="flex items-center gap-2.5 flex-wrap text-xs font-mono">
          <div className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center gap-2">
            <Building2 className="w-3.5 h-3.5 text-blue-600" />
            <span className="text-slate-600">UEN: <strong className="text-slate-900">{currentClient.registrationNumber}</strong></span>
          </div>

          <div className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center gap-2">
            <FileText className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-slate-600">Docs Attached: <strong className="text-slate-900">{(currentClient.documents || []).length}</strong></span>
          </div>

          <div className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center gap-2">
            <span className="text-slate-500">Lifecycle:</span>
            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
              currentClient.overallStatus === 'approved'
                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                : currentClient.overallStatus === 'rejected'
                ? 'bg-rose-50 text-rose-700 border border-rose-200'
                : 'bg-amber-50 text-amber-700 border border-amber-200'
            }`}>
              {currentClient.overallStatus}
            </span>
          </div>
        </div>
      </div>

      {/* CATEGORY FILTERS TOOLBAR (All Entities, Ownership, Management, Subsidiaries, Banking) */}
      <div className="px-6 py-2.5 bg-slate-50/80 border-b border-slate-200 flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
        {/* Left: Entity Category Filter Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-slate-400 font-mono text-[10px] uppercase font-bold tracking-wider mr-1">
            Filter View:
          </span>

          {/* All Entities (13) */}
          <button
            type="button"
            onClick={() => setActiveFilter('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-2xs ${
              activeFilter === 'all'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <span>All Entities</span>
            <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
              activeFilter === 'all' ? 'bg-blue-700 text-blue-100' : 'bg-slate-100 text-slate-600'
            }`}>
              ({counts.all})
            </span>
          </button>

          {/* Ownership */}
          <button
            type="button"
            onClick={() => setActiveFilter('ownership')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-2xs ${
              activeFilter === 'ownership'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <span>Ownership</span>
            <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
              activeFilter === 'ownership' ? 'bg-blue-700 text-blue-100' : 'bg-slate-100 text-slate-600'
            }`}>
              ({counts.ownership})
            </span>
          </button>

          {/* Management */}
          <button
            type="button"
            onClick={() => setActiveFilter('management')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-2xs ${
              activeFilter === 'management'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <span>Management</span>
            <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
              activeFilter === 'management' ? 'bg-blue-700 text-blue-100' : 'bg-slate-100 text-slate-600'
            }`}>
              ({counts.management})
            </span>
          </button>

          {/* Subsidiaries */}
          <button
            type="button"
            onClick={() => setActiveFilter('subsidiaries')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-2xs ${
              activeFilter === 'subsidiaries'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <span>Subsidiaries</span>
            <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
              activeFilter === 'subsidiaries' ? 'bg-blue-700 text-blue-100' : 'bg-slate-100 text-slate-600'
            }`}>
              ({counts.subsidiaries})
            </span>
          </button>

          {/* Banking */}
          <button
            type="button"
            onClick={() => setActiveFilter('banking')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-2xs ${
              activeFilter === 'banking'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <span>Banking</span>
            <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
              activeFilter === 'banking' ? 'bg-blue-700 text-blue-100' : 'bg-slate-100 text-slate-600'
            }`}>
              ({counts.banking})
            </span>
          </button>
        </div>

        {/* Right: Layout Actions & Zoom Controls */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Reference Layout & fCoSE Triggers */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => applyPresetLayout(true)}
              className="px-2.5 py-1 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg transition cursor-pointer shadow-2xs flex items-center gap-1"
              title="Align nodes according to verified institutional hierarchy"
            >
              <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
              <span>Reset Layout</span>
            </button>
            <button
              type="button"
              onClick={() => executeFCoSE()}
              className="px-2.5 py-1 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition cursor-pointer shadow-xs flex items-center gap-1"
              title="Run fast compound force-directed physics layout"
            >
              <RefreshCw className="w-3.5 h-3.5 text-white" />
              <span>fCoSE Auto-Balance</span>
            </button>
          </div>

          <div className="flex items-center bg-white rounded-lg border border-slate-200 p-0.5 shadow-2xs">
            <button
              type="button"
              onClick={() => cyRef.current?.zoom(cyRef.current.zoom() * 0.8)}
              className="p-1 text-slate-500 hover:text-slate-900 transition cursor-pointer"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => cyRef.current?.zoom(cyRef.current.zoom() * 1.25)}
              className="p-1 text-slate-500 hover:text-slate-900 transition cursor-pointer"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => cyRef.current?.fit(undefined, 40)}
              className="p-1 text-slate-500 hover:text-slate-900 border-l border-slate-200 ml-1 transition cursor-pointer"
              title="Fit View"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* MAIN TWO-COLUMN SPLIT: INTERACTIVE fCoSE CANVAS (LEFT) & KNOWLEDGE INSPECTOR (RIGHT) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 flex-1 relative bg-white">
        
        {/* ==================== LEFT GRAPH VIEW (7 cols) ==================== */}
        <div className="lg:col-span-7 bg-slate-100/70 border-r border-slate-200 p-3 flex flex-col relative min-h-[600px]">
          
          {/* Cytoscape Canvas Container */}
          <div className="relative flex-1 w-full h-full min-h-[560px]">
            <div
              ref={cyContainerRef}
              className="w-full h-full absolute inset-0 bg-transparent cursor-grab active:cursor-grabbing"
            />
          </div>

          {/* Floating Canvas Taxonomy Legend */}
          <div className="absolute bottom-4 left-4 z-10 bg-white/95 backdrop-blur-md border border-slate-200/90 rounded-xl p-3.5 shadow-sm text-[11px] max-w-sm">
            <div className="font-mono text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2.5 flex items-center justify-between">
              <span>Entity Node Taxonomy</span>
              <span className="text-blue-600 font-bold">fCoSE Layout</span>
            </div>
            <div className="grid grid-cols-2 gap-x-3 gap-y-2 font-medium">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-xs bg-[#2563eb] ring-1 ring-slate-200 inline-block shrink-0" />
                <span className="text-slate-700 font-semibold">Central Corporate</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-xs bg-[#1e293b] ring-1 ring-slate-200 inline-block shrink-0" />
                <span className="text-slate-700">Parent / Fund</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-[#059669] ring-1 ring-slate-200 inline-block shrink-0" />
                <span className="text-slate-700">Beneficial Owner (UBO)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rotate-45 rounded-xs bg-[#0284c7] ring-1 ring-slate-200 inline-block shrink-0" />
                <span className="text-slate-700">Executive Officer</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-xs bg-[#475569] ring-1 ring-slate-200 inline-block shrink-0" />
                <span className="text-slate-700">Regulatory Gateway</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-xs bg-[#4f46e5] ring-1 ring-slate-200 inline-block shrink-0" />
                <span className="text-slate-700">Subsidiary Entity</span>
              </div>
              <div className="flex items-center gap-2 col-span-2 pt-1 border-t border-slate-100">
                <span className="w-3 h-3 rounded-xs bg-[#2563eb] ring-1 ring-slate-200 inline-block shrink-0" />
                <span className="text-slate-700">Treasury Hub & Master Operating Account</span>
              </div>
            </div>
          </div>
        </div>

        {/* ==================== RIGHT INSPECTION PANEL (5 cols) ==================== */}
        <div className="lg:col-span-5 bg-white p-5 flex flex-col min-h-[580px] overflow-y-auto">
          {/* Sub-Tabs: Node Details vs Stage Timeline vs fCoSE Spec */}
          <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setActiveTab('details')}
                className={`text-xs font-bold px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  activeTab === 'details' ? 'bg-blue-50 text-blue-700 border border-blue-200' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                Node Inspection
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('timeline')}
                className={`text-xs font-bold px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  activeTab === 'timeline' ? 'bg-blue-50 text-blue-700 border border-blue-200' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                Knowledge Timeline
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('fcose_specs')}
                className={`text-xs font-bold px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  activeTab === 'fcose_specs' ? 'bg-blue-50 text-blue-700 border border-blue-200' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                fCoSE Spec
              </button>
            </div>

            <span className="text-[10px] font-mono text-slate-400 font-bold uppercase">
              CONFIDENCE: {Math.round(selectedNode.details.confidence * 100)}%
            </span>
          </div>

          {/* TAB 1: NODE DETAILS */}
          {activeTab === 'details' && (
            <div className="space-y-4 text-left">
              {/* Node Card Header */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">
                      {selectedNode.type} RECORD
                    </span>
                    <h3 className="text-sm font-bold text-slate-900 leading-snug mt-0.5">
                      {selectedNode.label}
                    </h3>
                    <p className="text-xs text-slate-500 font-mono mt-0.5">
                      {selectedNode.details.registration}
                    </p>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase font-mono border ${
                    selectedNode.status === 'verified'
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      : selectedNode.status === 'flagged'
                      ? 'bg-rose-50 text-rose-700 border border-rose-200'
                      : 'bg-amber-50 text-amber-700 border border-amber-200'
                  }`}>
                    {selectedNode.details.statusText}
                  </span>
                </div>

                <div className="mt-2.5 pt-2.5 border-t border-slate-200/80 flex items-center justify-between text-[11px] text-slate-500">
                  <span className="truncate">Source: <strong className="text-slate-700 font-medium">{selectedNode.details.source}</strong></span>
                  <button
                    type="button"
                    onClick={handleVerifyNode}
                    className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer shrink-0"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Verify Node</span>
                  </button>
                </div>
              </div>

              {/* Data Fields Table */}
              <div>
                <h4 className="text-xs font-bold text-slate-700 uppercase font-mono tracking-wider mb-2 flex items-center gap-1">
                  <Database className="w-3.5 h-3.5 text-blue-500" />
                  Verified Entity Attributes ({selectedNode.details.dataFields.length})
                </h4>
                <div className="border border-slate-200 rounded-xl overflow-hidden divide-y divide-slate-100">
                  {selectedNode.details.dataFields.map((field, idx) => (
                    <div key={idx} className="p-2.5 hover:bg-slate-50 transition text-xs flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <span className="text-slate-500 block text-[11px]">{field.name}</span>
                        <strong className="text-slate-800 font-semibold truncate block mt-0.5">
                          {field.value}
                        </strong>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                          {Math.round(field.confidence * 100)}%
                        </span>
                        <span className="block text-[9px] text-slate-400 font-mono mt-0.5">
                          {field.source}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Document Checklist */}
              <div>
                <h4 className="text-xs font-bold text-slate-700 uppercase font-mono tracking-wider mb-2 flex items-center gap-1">
                  <FileCheck className="w-3.5 h-3.5 text-blue-500" />
                  Associated Verification Documents ({selectedNode.details.documents.length})
                </h4>
                <div className="space-y-2">
                  {selectedNode.details.documents.map((doc) => (
                    <div key={doc.id} className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-slate-800 truncate">{doc.name}</p>
                        <p className="text-[10px] text-slate-400 font-mono">{doc.category}</p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                          doc.status === 'verified'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}>
                          {doc.status}
                        </span>
                        {doc.status !== 'verified' && (
                          <button
                            type="button"
                            onClick={() => handleDocumentVerify(doc.id)}
                            className="p-1 text-blue-600 hover:bg-blue-50 rounded cursor-pointer transition"
                            title="Verify Document"
                          >
                            <CheckCircle2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: KNOWLEDGE ACCUMULATION TIMELINE */}
          {activeTab === 'timeline' && (
            <div className="space-y-3 text-left">
              <div className="p-2.5 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-800 flex items-start gap-2">
                <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <span>Knowledge Graph nodes are dynamically synthesized and indexed as the customer progresses across autonomous workflow stages.</span>
              </div>

              <div className="relative border-l-2 border-slate-200 ml-3 space-y-4 pt-1">
                {events.map((ev) => (
                  <div key={ev.id} className="relative pl-5">
                    <span className="absolute -left-[7px] top-1 w-3 h-3 rounded-full bg-blue-600 ring-4 ring-white" />
                    <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs">
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="font-bold text-slate-800">{ev.stageName}</span>
                        <span className="text-[10px] font-mono text-slate-400">{ev.timestamp}</span>
                      </div>
                      <p className="text-slate-600 text-[11px] leading-relaxed">
                        {ev.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: fCoSE ALGORITHM SPECIFICATIONS & PRINCIPLES */}
          {activeTab === 'fcose_specs' && (
            <div className="space-y-3.5 text-left text-xs">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <h4 className="font-bold text-slate-900 mb-1 flex items-center gap-1.5">
                  <Network className="w-4 h-4 text-blue-600" />
                  fCoSE Graph Engine
                </h4>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  <strong>fCoSE</strong> combines spectral graph drawing (instant algebraic draft) with force-directed spring embedder physics polish for institutional ownership networks.
                </p>
              </div>

              <div className="grid grid-cols-1 gap-2.5">
                <div className="p-3 border border-slate-200 rounded-xl bg-white">
                  <h5 className="font-bold text-slate-800 text-[11px] flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-blue-600" />
                    Spectral Draft Phase
                  </h5>
                  <p className="text-slate-600 text-[11px] mt-1 leading-normal">
                    Computes eigenvectors of the graph Laplacian matrix to establish a fast, globally balanced initial planar layout.
                  </p>
                </div>

                <div className="p-3 border border-slate-200 rounded-xl bg-white">
                  <h5 className="font-bold text-slate-800 text-[11px] flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-600" />
                    Force-Directed Polish Phase
                  </h5>
                  <p className="text-slate-600 text-[11px] mt-1 leading-normal">
                    Applies spring embedder physics, grid repulsion, and edge elasticity to remove node overlaps and minimize crossing lines.
                  </p>
                </div>

                <div className="p-3 border border-slate-200 rounded-xl bg-white">
                  <h5 className="font-bold text-slate-800 text-[11px] flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-blue-600" />
                    Dynamic Categorical Filtering
                  </h5>
                  <p className="text-slate-600 text-[11px] mt-1 leading-normal">
                    Instant subnetwork projection across Ownership, Management, Subsidiaries, and Banking with animated fCoSE spring transitions.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DigitalTwinExplorer;
