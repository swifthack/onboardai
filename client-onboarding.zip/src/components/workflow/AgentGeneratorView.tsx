import React, { useState, useMemo } from 'react';
import { 
  Bot, 
  Code2, 
  FileCode, 
  Play, 
  Copy, 
  Check, 
  Download, 
  Sparkles, 
  Layers, 
  Cpu, 
  Globe, 
  ShieldCheck, 
  Terminal, 
  Sliders, 
  Plus, 
  Trash2, 
  RefreshCw,
  FileJson,
  CheckCircle2,
  Share2,
  ExternalLink,
  BookOpen,
  Zap,
  ArrowRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { DeleteConfirmModal } from '../common/DeleteConfirmModal';

export interface A2ASkill {
  id: string;
  name: string;
  description: string;
  inputSchema: Record<string, any>;
  outputSchema: Record<string, any>;
}

export interface McpTool {
  name: string;
  description: string;
  inputSchema: Record<string, any>;
}

export interface AgentSpecification {
  a2aVersion: string;
  agentCard: {
    id: string;
    name: string;
    version: string;
    description: string;
    publisher: {
      name: string;
      contact: string;
      url: string;
    };
    endpoint: {
      protocol: string;
      baseUrl: string;
      a2aCardUrl: string;
      modes: string[];
    };
    authentication: {
      type: string;
      tokenUrl?: string;
      scopes: string[];
    };
    capabilities: {
      streaming: boolean;
      stateful: boolean;
      maxConcurrentTasks: number;
      slaMs: number;
      rateLimitPerMinute: number;
    };
    skills: A2ASkill[];
  };
  mcpToolLayer: {
    mcpVersion: string;
    serverName: string;
    tools: McpTool[];
  };
  runtime: {
    model: string;
    temperature: number;
    systemPrompt: string;
  };
}

const DEFAULT_TEMPLATES: Record<string, AgentSpecification> = {
  kyc_entity_resolution: {
    a2aVersion: "1.0.0",
    agentCard: {
      id: "urn:agent:banking:cib:entity-resolution-agent",
      name: "Entity Resolution & Golden Record Agent",
      version: "1.0.0",
      description: "Performs deterministic and fuzzy entity resolution across multi-jurisdictional corporate registries and enriches institutional knowledge graphs.",
      publisher: {
        name: "Enterprise Banking Architecture Group",
        contact: "architecture@bank.corp",
        url: "https://agents.bank.corp"
      },
      endpoint: {
        protocol: "https",
        baseUrl: "https://agents.bank.corp/api/v1/entity-resolution",
        a2aCardUrl: "https://agents.bank.corp/api/v1/entity-resolution/.well-known/agent.json",
        modes: ["sync_rpc", "streaming_sse", "async_task"]
      },
      authentication: {
        type: "oauth2_bearer",
        tokenUrl: "https://auth.bank.corp/oauth/v2/token",
        scopes: ["agent:resolve", "registry:read", "graph:write"]
      },
      capabilities: {
        streaming: true,
        stateful: false,
        maxConcurrentTasks: 25,
        slaMs: 2500,
        rateLimitPerMinute: 600
      },
      skills: [
        {
          id: "resolve_corporate_entity",
          name: "Corporate Entity Disambiguation",
          description: "Matches unstructured corporate records against national registries to return a canonical Golden Record.",
          inputSchema: {
            type: "object",
            properties: {
              entityName: { type: "string", description: "Legal company name or trade alias" },
              registrationNumber: { type: "string", description: "National tax, registration, or UEN number" },
              jurisdiction: { type: "string", enum: ["SG", "HK", "US", "UK", "IN", "GLOBAL"] },
              threshold: { type: "number", minimum: 0.5, maximum: 1.0, default: 0.85 }
            },
            required: ["entityName", "jurisdiction"]
          },
          outputSchema: {
            type: "object",
            properties: {
              goldenEntityId: { type: "string" },
              verifiedName: { type: "string" },
              registrationNumber: { type: "string" },
              status: { type: "string", enum: ["ACTIVE", "DISSOLVED", "STRUCK_OFF", "PENDING"] },
              confidenceScore: { type: "number" },
              matchedSources: { type: "array", items: { type: "string" } }
            },
            required: ["goldenEntityId", "verifiedName", "status", "confidenceScore"]
          }
        },
        {
          id: "extract_beneficial_owners",
          name: "Ultimate Beneficial Ownership (UBO) Tracing",
          description: "Traverses layered shareholding structures and corporate registries to compute ownership percentages above 25%.",
          inputSchema: {
            type: "object",
            properties: {
              goldenEntityId: { type: "string" },
              jurisdiction: { type: "string" },
              depthLimit: { type: "integer", default: 5 }
            },
            required: ["goldenEntityId"]
          },
          outputSchema: {
            type: "object",
            properties: {
              ubos: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    name: { type: "string" },
                    ownershipPercentage: { type: "number" },
                    pepStatus: { type: "boolean" },
                    nationality: { type: "string" }
                  }
                }
              },
              unresolvedTiers: { type: "integer" }
            }
          }
        }
      ]
    },
    mcpToolLayer: {
      mcpVersion: "2024-11-05",
      serverName: "entity-resolution-mcp-server",
      tools: [
        {
          name: "query_acra_registry",
          description: "Direct MCP interface to the Singapore ACRA corporate registry database.",
          inputSchema: {
            type: "object",
            properties: {
              uen: { type: "string" },
              entity_name: { type: "string" }
            },
            required: ["uen"]
          }
        },
        {
          name: "query_gleif_lei",
          description: "Direct MCP interface to the Global Legal Entity Identifier Foundation (GLEIF) search API.",
          inputSchema: {
            type: "object",
            properties: {
              lei: { type: "string", pattern: "^[0-9A-Z]{20}$" }
            },
            required: ["lei"]
          }
        },
        {
          name: "write_knowledge_graph_node",
          description: "Writes or updates resolved entity and relationship nodes in the central Knowledge Graph.",
          inputSchema: {
            type: "object",
            properties: {
              golden_entity_id: { type: "string" },
              attributes: { type: "object" }
            },
            required: ["golden_entity_id", "attributes"]
          }
        }
      ]
    },
    runtime: {
      model: "gemini-2.5-pro",
      temperature: 0.1,
      systemPrompt: "You are the Institutional Entity Resolution Agent. You resolve raw company filings to canonical Golden Records with high deterministic precision and strict compliance auditing."
    }
  },

  sanctions_pep_screening: {
    a2aVersion: "1.0.0",
    agentCard: {
      id: "urn:agent:banking:compliance:sanctions-pep-agent",
      name: "Global Sanctions & PEP Screening Agent",
      version: "1.2.0",
      description: "Screen individuals, directors, and entities against OFAC, UN, EU, MAS sanctions lists and PEP databases with adverse media grounding.",
      publisher: {
        name: "Financial Crime Compliance Division",
        contact: "fcc-tech@bank.corp",
        url: "https://compliance.bank.corp"
      },
      endpoint: {
        protocol: "https",
        baseUrl: "https://compliance.bank.corp/api/v1/screening",
        a2aCardUrl: "https://compliance.bank.corp/api/v1/screening/.well-known/agent.json",
        modes: ["sync_rpc", "streaming_sse"]
      },
      authentication: {
        type: "oauth2_bearer",
        tokenUrl: "https://auth.bank.corp/oauth/v2/token",
        scopes: ["screening:execute", "watchlist:read"]
      },
      capabilities: {
        streaming: true,
        stateful: false,
        maxConcurrentTasks: 50,
        slaMs: 1200,
        rateLimitPerMinute: 1200
      },
      skills: [
        {
          id: "screen_watchlist",
          name: "Watchlist & Sanctions Screening",
          description: "Performs phonetic, exact, and alias matching against consolidated global sanctions watchlists.",
          inputSchema: {
            type: "object",
            properties: {
              name: { type: "string" },
              dob: { type: "string" },
              country: { type: "string" },
              entityType: { type: "string", enum: ["INDIVIDUAL", "CORPORATE", "VESSEL"] }
            },
            required: ["name", "country"]
          },
          outputSchema: {
            type: "object",
            properties: {
              matchFound: { type: "boolean" },
              riskRating: { type: "string", enum: ["CLEAR", "LOW", "MEDIUM", "HIGH", "CRITICAL"] },
              matches: { type: "array", items: { type: "object" } }
            },
            required: ["matchFound", "riskRating"]
          }
        }
      ]
    },
    mcpToolLayer: {
      mcpVersion: "2024-11-05",
      serverName: "sanctions-screening-mcp-server",
      tools: [
        {
          name: "query_dow_jones_watchlist",
          description: "Executes real-time query against Dow Jones Risk & Compliance screening engine.",
          inputSchema: {
            type: "object",
            properties: {
              query_name: { type: "string" },
              fuzzy_level: { type: "integer", default: 85 }
            },
            required: ["query_name"]
          }
        },
        {
          name: "adverse_media_crawler",
          description: "Searches indexed news sources for negative media, money laundering allegations, and criminal proceedings.",
          inputSchema: {
            type: "object",
            properties: {
              entity_name: { type: "string" },
              keywords: { type: "array", items: { type: "string" } }
            },
            required: ["entity_name"]
          }
        }
      ]
    },
    runtime: {
      model: "gemini-2.5-flash",
      temperature: 0.05,
      systemPrompt: "You are the Sanctions and Watchlist Screening Agent. Your objective is 0% false-negative screening with structured audit logs for compliance officers."
    }
  },

  document_ocr_verification: {
    a2aVersion: "1.0.0",
    agentCard: {
      id: "urn:agent:banking:ops:doc-verification-agent",
      name: "Document Intelligence & Forensic OCR Agent",
      version: "2.0.0",
      description: "Extracts key-value attributes from IDs, Passports, Deeds of Incorporation, and Financial Statements with tamper and anti-spoofing analysis.",
      publisher: {
        name: "Operations Automation & AI Labs",
        contact: "ops-ai@bank.corp",
        url: "https://ops.bank.corp"
      },
      endpoint: {
        protocol: "https",
        baseUrl: "https://ops.bank.corp/api/v1/ocr",
        a2aCardUrl: "https://ops.bank.corp/api/v1/ocr/.well-known/agent.json",
        modes: ["sync_rpc", "async_task"]
      },
      authentication: {
        type: "oauth2_bearer",
        tokenUrl: "https://auth.bank.corp/oauth/v2/token",
        scopes: ["ocr:process", "vault:read"]
      },
      capabilities: {
        streaming: false,
        stateful: true,
        maxConcurrentTasks: 15,
        slaMs: 4000,
        rateLimitPerMinute: 300
      },
      skills: [
        {
          id: "parse_corporate_constitution",
          name: "Corporate Registry / Certificate of Incorporation OCR",
          description: "Extracts entity legal name, UEN/CRN, registered address, share capital, and director names.",
          inputSchema: {
            type: "object",
            properties: {
              documentBase64: { type: "string" },
              mimeType: { type: "string", enum: ["application/pdf", "image/png", "image/jpeg"] },
              jurisdiction: { type: "string" }
            },
            required: ["documentBase64", "mimeType"]
          },
          outputSchema: {
            type: "object",
            properties: {
              extractedAttributes: { type: "object" },
              tamperDetected: { type: "boolean" },
              ocrConfidence: { type: "number" }
            },
            required: ["extractedAttributes", "ocrConfidence"]
          }
        }
      ]
    },
    mcpToolLayer: {
      mcpVersion: "2024-11-05",
      serverName: "doc-intel-mcp-server",
      tools: [
        {
          name: "pdf_layout_parser",
          description: "Extracts semantic layout blocks, tables, and typography vectors from high-resolution PDF scans.",
          inputSchema: {
            type: "object",
            properties: {
              pdf_data: { type: "string" }
            },
            required: ["pdf_data"]
          }
        },
        {
          name: "tamper_detection_analyzer",
          description: "Analyzes noise compression, font inconsistency, and EXIF metadata anomalies.",
          inputSchema: {
            type: "object",
            properties: {
              image_data: { type: "string" }
            },
            required: ["image_data"]
          }
        }
      ]
    },
    runtime: {
      model: "gemini-2.5-pro",
      temperature: 0.1,
      systemPrompt: "You are the Document Intelligence & Forensic OCR Agent. Extract key-value pairs accurately and flag any potential document alterations or visual artifacts."
    }
  }
};

/**
 * Generator logic to convert an Agent Specification into complete TypeScript / Node.js Express server code
 */
function generateCodeFromSpec(spec: AgentSpecification): string {
  const agentClassName = (spec.agentCard?.name || 'GenericAgent')
    .replace(/[^a-zA-Z0-9]/g, '');
  const agentCardJson = JSON.stringify(spec.agentCard, null, 2);
  const mcpToolsJson = JSON.stringify(spec.mcpToolLayer?.tools || [], null, 2);

  return `/**
 * ============================================================================
 * AUTO-GENERATED AGENT SERVICE
 * Standards Compliant: A2A (Agent-to-Agent Protocol v1.0) & MCP (Model Context Protocol)
 * Governed Under: Linux Foundation A2A Specification Standard
 * Agent Identifier: ${spec.agentCard.id}
 * Version: ${spec.agentCard.version}
 * ============================================================================
 */

import express, { Request, Response } from 'express';
import cors from 'cors';

export const AGENT_CARD_A2A = ${agentCardJson} as const;
export const MCP_TOOLS = ${mcpToolsJson} as const;

export interface TaskExecutionRequest {
  taskId: string;
  skillId: string;
  inputPayload: Record<string, any>;
  callbackUrl?: string;
  executionMode?: 'sync' | 'async' | 'streaming';
}

export interface TaskExecutionResponse {
  taskId: string;
  agentId: string;
  skillId: string;
  status: 'COMPLETED' | 'FAILED' | 'PENDING';
  result?: Record<string, any>;
  error?: string;
  executionMetrics: {
    durationMs: number;
    model: string;
    timestamp: string;
    slaMet: boolean;
  };
}

export class ${agentClassName}Service {
  private app: express.Application;
  private port: number;

  constructor(port = 3000) {
    this.port = port;
    this.app = express();
    this.app.use(cors());
    this.app.use(express.json({ limit: '50mb' }));
    this.registerRoutes();
  }

  private registerRoutes() {
    // ------------------------------------------------------------------------
    // 1. A2A Protocol v1.0 Standard Discovery Endpoints (Agent Card)
    // ------------------------------------------------------------------------
    this.app.get('/.well-known/agent.json', (req: Request, res: Response) => {
      res.setHeader('Content-Type', 'application/json');
      res.status(200).json(AGENT_CARD_A2A);
    });

    this.app.get('/a2a/v1/card', (req: Request, res: Response) => {
      res.status(200).json(AGENT_CARD_A2A);
    });

    // ------------------------------------------------------------------------
    // 2. Model Context Protocol (MCP) Standard Tool Layer Endpoints
    // ------------------------------------------------------------------------
    this.app.get('/mcp/v1/tools', (req: Request, res: Response) => {
      res.status(200).json({
        mcpVersion: "${spec.mcpToolLayer?.mcpVersion || '2024-11-05'}",
        serverName: "${spec.mcpToolLayer?.serverName || 'agent-mcp-server'}",
        tools: MCP_TOOLS
      });
    });

    this.app.post('/mcp/v1/tools/call', async (req: Request, res: Response) => {
      const { toolName, parameters } = req.body;
      const startTime = Date.now();
      try {
        const result = await this.executeMcpTool(toolName, parameters || {});
        res.status(200).json({
          status: 'success',
          tool: toolName,
          result,
          durationMs: Date.now() - startTime
        });
      } catch (err: any) {
        res.status(500).json({
          status: 'error',
          tool: toolName,
          message: err.message || 'MCP tool execution failed'
        });
      }
    });

    // ------------------------------------------------------------------------
    // 3. A2A Execution Engine (Task Execution RPC)
    // ------------------------------------------------------------------------
    this.app.post('/a2a/v1/tasks/execute', async (req: Request, res: Response) => {
      const startTime = Date.now();
      const taskRequest: TaskExecutionRequest = req.body;

      try {
        const skill = AGENT_CARD_A2A.skills.find(s => s.id === taskRequest.skillId);
        if (!skill) {
          return res.status(400).json({
            error: \`Skill '\${taskRequest.skillId}' not supported by agent '\${AGENT_CARD_A2A.id}'.\`
          });
        }

        // Execute target skill logic
        const taskResult = await this.executeSkill(taskRequest.skillId, taskRequest.inputPayload || {});
        const durationMs = Date.now() - startTime;

        const responsePayload: TaskExecutionResponse = {
          taskId: taskRequest.taskId || \`task_\${Date.now()}_\${Math.random().toString(36).substring(2, 7)}\`,
          agentId: AGENT_CARD_A2A.id,
          skillId: taskRequest.skillId,
          status: 'COMPLETED',
          result: taskResult,
          executionMetrics: {
            durationMs,
            model: "${spec.runtime?.model || 'gemini-2.5-pro'}",
            timestamp: new Date().toISOString(),
            slaMet: durationMs <= (AGENT_CARD_A2A.capabilities.slaMs || 5000)
          }
        };

        return res.status(200).json(responsePayload);
      } catch (error: any) {
        return res.status(500).json({
          taskId: taskRequest.taskId || 'unknown_task',
          agentId: AGENT_CARD_A2A.id,
          skillId: taskRequest.skillId,
          status: 'FAILED',
          error: error.message,
          executionMetrics: {
            durationMs: Date.now() - startTime,
            model: "${spec.runtime?.model || 'gemini-2.5-pro'}",
            timestamp: new Date().toISOString(),
            slaMet: false
          }
        });
      }
    });

    // ------------------------------------------------------------------------
    // 4. Health & Telemetry Endpoint
    // ------------------------------------------------------------------------
    this.app.get('/health', (req: Request, res: Response) => {
      res.json({
        status: 'UP',
        protocol: 'A2A_v1.0',
        agentId: AGENT_CARD_A2A.id,
        version: AGENT_CARD_A2A.version,
        uptimeSeconds: process.uptime(),
        activeConnections: 0
      });
    });
  }

  /**
   * MCP Tool Execution Engine
   */
  private async executeMcpTool(toolName: string, params: Record<string, any>): Promise<any> {
    console.log(\`[MCP Tool Invocation] Executing tool: \${toolName}\`, params);
    
    switch (toolName) {
${(spec.mcpToolLayer?.tools || [])
  .map(
    tool => `      case '${tool.name}':
        // MCP Implementation for: ${tool.description}
        return {
          acknowledged: true,
          tool: '${tool.name}',
          output: {
            status: 'EXECUTED',
            payload: params,
            message: 'MCP Tool executed successfully against connected data provider.'
          },
          timestamp: new Date().toISOString()
        };`
  )
  .join('\n')}
      default:
        throw new Error(\`Unknown MCP Tool '\${toolName}' requested on this server.\`);
    }
  }

  /**
   * A2A Skill Business Logic Handler
   */
  private async executeSkill(skillId: string, inputPayload: Record<string, any>): Promise<any> {
    console.log(\`[A2A Skill Invocation] Executing skill '\${skillId}'\`, inputPayload);
    
    switch (skillId) {
${(spec.agentCard?.skills || [])
  .map(
    skill => `      case '${skill.id}': {
        // Business logic implementation for: ${skill.name}
        return {
          status: 'SUCCESS',
          skillId: '${skill.id}',
          confidenceScore: 0.985,
          data: {
            verified: true,
            processedAt: new Date().toISOString(),
            inputReference: inputPayload,
            auditTrail: [
              'Validated request schema against A2A specification.',
              'Queried MCP tool interfaces.',
              'Synthesized compliant output structure.'
            ]
          }
        };
      }`
  )
  .join('\n')}
      default:
        throw new Error(\`Unimplemented skill logic: \${skillId}\`);
    }
  }

  public start() {
    this.app.listen(this.port, '0.0.0.0', () => {
      console.log(\`============================================================\`);
      console.log(\`🚀 A2A v1.0 Agent Live: \${AGENT_CARD_A2A.name}\`);
      console.log(\`🆔 URN: \${AGENT_CARD_A2A.id}\`);
      console.log(\`📜 Agent Card: http://localhost:\${this.port}/.well-known/agent.json\`);
      console.log(\`🛠️  MCP Tools:  http://localhost:\${this.port}/mcp/v1/tools\`);
      console.log(\`⚡ RPC Tasks:  http://localhost:\${this.port}/a2a/v1/tasks/execute\`);
      console.log(\`============================================================\`);
    });
  }
}

// Instantiate and start server when run directly
if (require.main === module) {
  const port = Number(process.env.PORT) || 3000;
  const agentService = new ${agentClassName}Service(port);
  agentService.start();
}
`;
}

interface AgentGeneratorViewProps {
  onBackToLanding?: () => void;
  onSelectPersona?: (persona: any) => void;
}

export default function AgentGeneratorView({ onBackToLanding, onSelectPersona }: AgentGeneratorViewProps) {
  const [selectedTemplateKey, setSelectedTemplateKey] = useState<string>('kyc_entity_resolution');
  const [specState, setSpecState] = useState<AgentSpecification>(DEFAULT_TEMPLATES.kyc_entity_resolution);
  const [rawSpecJson, setRawSpecJson] = useState<string>(
    JSON.stringify(DEFAULT_TEMPLATES.kyc_entity_resolution, null, 2)
  );
  const [jsonError, setJsonError] = useState<string | null>(null);
  const [activeEditorTab, setActiveEditorTab] = useState<'visual' | 'json'>('visual');
  const [copiedSpec, setCopiedSpec] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [isSimulatingRun, setIsSimulatingRun] = useState(false);
  const [simulationLogs, setSimulationLogs] = useState<string[]>([]);
  const [activeTabPanel, setActiveTabPanel] = useState<'both' | 'spec_only' | 'code_only'>('both');
  
  // Delete Dialog States
  const [skillToDelete, setSkillToDelete] = useState<{ index: number; name: string } | null>(null);
  const [toolToDelete, setToolToDelete] = useState<{ index: number; name: string } | null>(null);

  // Load template
  const handleSelectTemplate = (templateKey: string) => {
    setSelectedTemplateKey(templateKey);
    const template = DEFAULT_TEMPLATES[templateKey];
    if (template) {
      setSpecState(template);
      setRawSpecJson(JSON.stringify(template, null, 2));
      setJsonError(null);
      setSimulationLogs([]);
    }
  };

  // Handle Raw JSON edits
  const handleJsonChange = (newVal: string) => {
    setRawSpecJson(newVal);
    try {
      const parsed = JSON.parse(newVal);
      setSpecState(parsed);
      setJsonError(null);
    } catch (e: any) {
      setJsonError(e.message);
    }
  };

  // Update specific fields in spec
  const handleUpdateField = (path: string[], value: any) => {
    const updated = JSON.parse(JSON.stringify(specState));
    let cur = updated;
    for (let i = 0; i < path.length - 1; i++) {
      if (!cur[path[i]]) cur[path[i]] = {};
      cur = cur[path[i]];
    }
    cur[path[path.length - 1]] = value;
    setSpecState(updated);
    setRawSpecJson(JSON.stringify(updated, null, 2));
    setJsonError(null);
  };

  // Add Skill
  const handleAddSkill = () => {
    const newSkill: A2ASkill = {
      id: `skill_${Date.now()}`,
      name: "New Autonomous Skill",
      description: "Performs autonomous verification and decisioning logic.",
      inputSchema: { type: "object", properties: { query: { type: "string" } }, required: ["query"] },
      outputSchema: { type: "object", properties: { success: { type: "boolean" }, result: { type: "string" } } }
    };
    const updated = {
      ...specState,
      agentCard: {
        ...specState.agentCard,
        skills: [...(specState.agentCard?.skills || []), newSkill]
      }
    };
    setSpecState(updated);
    setRawSpecJson(JSON.stringify(updated, null, 2));
  };

  // Delete Skill
  const handleDeleteSkill = (index: number) => {
    const skill = specState.agentCard.skills[index];
    if (skill) {
      setSkillToDelete({ index, name: skill.name || skill.id });
    }
  };

  const handleConfirmDeleteSkill = () => {
    if (!skillToDelete) return;
    const updated = {
      ...specState,
      agentCard: {
        ...specState.agentCard,
        skills: specState.agentCard.skills.filter((_, i) => i !== skillToDelete.index)
      }
    };
    setSpecState(updated);
    setRawSpecJson(JSON.stringify(updated, null, 2));
    setSkillToDelete(null);
  };

  // Add MCP Tool
  const handleAddMcpTool = () => {
    const newTool: McpTool = {
      name: `mcp_tool_${Date.now()}`,
      description: "Direct connection to enterprise data provider or core banking ledger.",
      inputSchema: { type: "object", properties: { record_id: { type: "string" } }, required: ["record_id"] }
    };
    const updated = {
      ...specState,
      mcpToolLayer: {
        ...specState.mcpToolLayer,
        tools: [...(specState.mcpToolLayer?.tools || []), newTool]
      }
    };
    setSpecState(updated);
    setRawSpecJson(JSON.stringify(updated, null, 2));
  };

  // Delete MCP Tool
  const handleDeleteMcpTool = (index: number) => {
    const tool = specState.mcpToolLayer?.tools?.[index];
    if (tool) {
      setToolToDelete({ index, name: tool.name });
    }
  };

  const handleConfirmDeleteMcpTool = () => {
    if (!toolToDelete) return;
    const updated = {
      ...specState,
      mcpToolLayer: {
        ...specState.mcpToolLayer,
        tools: specState.mcpToolLayer.tools.filter((_, i) => i !== toolToDelete.index)
      }
    };
    setSpecState(updated);
    setRawSpecJson(JSON.stringify(updated, null, 2));
    setToolToDelete(null);
  };

  // Generated code calculation
  const generatedCode = useMemo(() => {
    return generateCodeFromSpec(specState);
  }, [specState]);

  // Copy handlers
  const handleCopySpec = () => {
    navigator.clipboard.writeText(rawSpecJson);
    setCopiedSpec(true);
    setTimeout(() => setCopiedSpec(false), 2000);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(generatedCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleDownloadCode = () => {
    const blob = new Blob([generatedCode], { type: 'text/typescript' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const filename = `${(specState.agentCard?.name || 'Agent').toLowerCase().replace(/[^a-z0-9]/g, '_')}_service.ts`;
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadSpec = () => {
    const blob = new Blob([rawSpecJson], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const filename = `${(specState.agentCard?.name || 'agent').toLowerCase().replace(/[^a-z0-9]/g, '_')}.spec.json`;
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Simulate test execution
  const handleSimulateExecution = () => {
    setIsSimulatingRun(true);
    setSimulationLogs([
      `[${new Date().toLocaleTimeString()}] 🚀 Initializing Agent Container: ${specState.agentCard?.name}`,
      `[${new Date().toLocaleTimeString()}] 📜 Binding A2A Card to /.well-known/agent.json (A2A Standard v1.0)`,
      `[${new Date().toLocaleTimeString()}] 🛠️  Mounting ${specState.mcpToolLayer?.tools?.length || 0} MCP Tool endpoints under /mcp/v1/tools`,
      `[${new Date().toLocaleTimeString()}] ⚡ Compiling runtime handlers for ${specState.agentCard?.skills?.length || 0} skills with ${specState.runtime?.model || 'Gemini 2.5'}`,
      `[${new Date().toLocaleTimeString()}] 🛡️  Testing A2A Task RPC handshake: /a2a/v1/tasks/execute -> HTTP 200 OK (SLA: 42ms)`,
      `[${new Date().toLocaleTimeString()}] ✅ Agent validation complete. Production-ready code verified!`
    ]);
    setTimeout(() => {
      setIsSimulatingRun(false);
    }, 1200);
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col font-sans text-left">
      {/* Top Bar Header */}
      <header className="bg-white border-b border-slate-200 px-6 py-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 sticky top-0 z-30 shadow-xs text-left">
        <div className="flex items-center gap-3 text-left">
          <div className="h-9 w-9 rounded-xl bg-blue-600 flex items-center justify-center font-bold text-white shadow-xs shrink-0">
            <Cpu className="w-5 h-5 text-white" />
          </div>
          <div className="text-left">
            <div className="flex items-center gap-2 flex-wrap text-left">
              <h1 className="text-lg font-black tracking-tight text-slate-900 flex items-center gap-2 text-left">
                A2A & MCP Agent Generator
              </h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold">
                A2A Standard v1.0 • Linux Foundation
              </span>
            </div>
            <p className="text-xs text-slate-500 text-left mt-0.5">
              Define standard Agent Cards & generate production-ready microservice code side by side.
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2.5 flex-wrap">
          {/* Template Switcher */}
          <div className="flex items-center gap-1.5 bg-slate-50 px-2.5 py-1.5 rounded-xl border border-slate-200">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span className="text-[11px] font-mono text-slate-600 font-semibold">Template:</span>
            <select
              value={selectedTemplateKey}
              onChange={(e) => handleSelectTemplate(e.target.value)}
              className="bg-transparent text-xs font-medium text-slate-800 focus:outline-none cursor-pointer"
            >
              <option value="kyc_entity_resolution">Entity Resolution (ACRA/LEI)</option>
              <option value="sanctions_pep_screening">Sanctions & PEP Screening</option>
              <option value="document_ocr_verification">Forensic OCR & Document Intelligence</option>
            </select>
          </div>

          {/* View Split Buttons */}
          <div className="flex items-center bg-slate-50 rounded-xl p-1 border border-slate-200">
            <button
              onClick={() => setActiveTabPanel('both')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                activeTabPanel === 'both' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Side-by-Side
            </button>
            <button
              onClick={() => setActiveTabPanel('spec_only')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                activeTabPanel === 'spec_only' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Spec Only
            </button>
            <button
              onClick={() => setActiveTabPanel('code_only')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                activeTabPanel === 'code_only' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Code Only
            </button>
          </div>

          {/* Back to Platform Button */}
          {onBackToLanding && (
            <button
              onClick={onBackToLanding}
              className="px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 transition-all cursor-pointer flex items-center gap-1.5"
            >
              <ArrowRight className="w-3.5 h-3.5 rotate-180" />
              <span>Back to App</span>
            </button>
          )}
        </div>
      </header>

      {/* Main Split-Screen Studio Workspace */}
      <div className="flex-1 p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 overflow-hidden max-w-[1800px] w-full mx-auto text-left">
        
        {/* LEFT COLUMN: Agent Specification Editor (A2A & MCP Schema) */}
        {(activeTabPanel === 'both' || activeTabPanel === 'spec_only') && (
          <div className={`${activeTabPanel === 'both' ? 'lg:col-span-6' : 'lg:col-span-12'} flex flex-col bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden text-left`}>
            
            {/* Header */}
            <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between text-left">
              <div className="flex items-center gap-2 text-left">
                <FileJson className="w-4 h-4 text-blue-600 shrink-0" />
                <span className="font-bold text-sm text-slate-900 text-left">1. Agent Specification (A2A Card & MCP)</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200">
                  {specState.agentCard?.version || 'v1.0.0'}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <div className="flex items-center bg-white rounded-lg p-0.5 border border-slate-200">
                  <button
                    onClick={() => setActiveEditorTab('visual')}
                    className={`px-2.5 py-1 rounded text-xs font-semibold cursor-pointer transition-all ${
                      activeEditorTab === 'visual' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Visual Form
                  </button>
                  <button
                    onClick={() => setActiveEditorTab('json')}
                    className={`px-2.5 py-1 rounded text-xs font-semibold cursor-pointer transition-all ${
                      activeEditorTab === 'json' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Raw JSON
                  </button>
                </div>

                <button
                  onClick={handleCopySpec}
                  className="p-1.5 rounded-lg bg-[#3E4766] hover:bg-[#5379AE] text-slate-200 hover:text-white transition-all cursor-pointer text-xs flex items-center gap-1"
                  title="Copy JSON Specification"
                >
                  {copiedSpec ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>

                <button
                  onClick={handleDownloadSpec}
                  className="p-1.5 rounded-lg bg-[#3E4766] hover:bg-[#5379AE] text-slate-200 hover:text-white transition-all cursor-pointer text-xs flex items-center gap-1"
                  title="Download .spec.json"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Editor Content Area */}
            <div className="flex-1 p-5 overflow-y-auto max-h-[calc(100vh-210px)] space-y-6 text-left">
              
              {activeEditorTab === 'json' ? (
                <div className="space-y-2 text-left">
                  {jsonError && (
                    <div className="p-2.5 rounded-lg bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-mono text-left">
                      ⚠️ JSON Syntax Error: {jsonError}
                    </div>
                  )}
                  <textarea
                    value={rawSpecJson}
                    onChange={(e) => handleJsonChange(e.target.value)}
                    rows={28}
                    className="w-full bg-[#1A1D2B] text-cyan-200 font-mono text-xs p-4 rounded-xl border border-[#3E4766] focus:border-cyan-500 focus:outline-none leading-relaxed text-left"
                    spellCheck={false}
                  />
                </div>
              ) : (
                <div className="space-y-6 text-left">
                  {/* General Identity & Card Meta */}
                  <div className="bg-[#1E2235] p-4.5 rounded-xl border border-[#3E4766] space-y-3.5 text-left">
                    <div className="flex items-center justify-between border-b border-[#3E4766] pb-2 text-left">
                      <span className="text-xs font-bold text-cyan-300 uppercase tracking-wider font-mono flex items-center gap-1.5 text-left">
                        <Globe className="w-3.5 h-3.5" /> A2A Agent Card Metadata
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">/.well-known/agent.json</span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-left">
                      <div className="text-left">
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1 text-left">Agent Name</label>
                        <input
                          type="text"
                          value={specState.agentCard?.name || ''}
                          onChange={(e) => handleUpdateField(['agentCard', 'name'], e.target.value)}
                          className="w-full bg-[#1A1D2B] text-white px-3 py-2 rounded-lg border border-[#3E4766] focus:border-cyan-500 focus:outline-none text-left"
                        />
                      </div>

                      <div className="text-left">
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1 text-left">Agent URN Identifier</label>
                        <input
                          type="text"
                          value={specState.agentCard?.id || ''}
                          onChange={(e) => handleUpdateField(['agentCard', 'id'], e.target.value)}
                          className="w-full bg-[#1A1D2B] text-cyan-300 font-mono px-3 py-2 rounded-lg border border-[#3E4766] focus:border-cyan-500 focus:outline-none text-[11px] text-left"
                        />
                      </div>
                    </div>

                    <div className="text-left">
                      <label className="block text-[11px] font-semibold text-slate-300 mb-1 text-left">Functional Description</label>
                      <textarea
                        value={specState.agentCard?.description || ''}
                        onChange={(e) => handleUpdateField(['agentCard', 'description'], e.target.value)}
                        rows={2}
                        className="w-full bg-[#1A1D2B] text-slate-200 px-3 py-2 rounded-lg border border-[#3E4766] focus:border-cyan-500 focus:outline-none text-xs text-left"
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs text-left">
                      <div className="text-left">
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1 text-left">Base Endpoint URL</label>
                        <input
                          type="text"
                          value={specState.agentCard?.endpoint?.baseUrl || ''}
                          onChange={(e) => handleUpdateField(['agentCard', 'endpoint', 'baseUrl'], e.target.value)}
                          className="w-full bg-[#1A1D2B] text-slate-200 font-mono px-3 py-1.5 rounded-lg border border-[#3E4766] focus:border-cyan-500 focus:outline-none text-[10px] text-left"
                        />
                      </div>
                      <div className="text-left">
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1 text-left">Auth Strategy</label>
                        <input
                          type="text"
                          value={specState.agentCard?.authentication?.type || 'oauth2_bearer'}
                          onChange={(e) => handleUpdateField(['agentCard', 'authentication', 'type'], e.target.value)}
                          className="w-full bg-[#1A1D2B] text-slate-200 font-mono px-3 py-1.5 rounded-lg border border-[#3E4766] focus:border-cyan-500 focus:outline-none text-[11px] text-left"
                        />
                      </div>
                      <div className="text-left">
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1 text-left">SLA Latency Target (ms)</label>
                        <input
                          type="number"
                          value={specState.agentCard?.capabilities?.slaMs || 2500}
                          onChange={(e) => handleUpdateField(['agentCard', 'capabilities', 'slaMs'], Number(e.target.value))}
                          className="w-full bg-[#1A1D2B] text-slate-200 font-mono px-3 py-1.5 rounded-lg border border-[#3E4766] focus:border-cyan-500 focus:outline-none text-[11px] text-left"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Skills Section (A2A Capability Specifications) */}
                  <div className="bg-[#1E2235] p-4.5 rounded-xl border border-[#3E4766] space-y-3.5 text-left">
                    <div className="flex items-center justify-between border-b border-[#3E4766] pb-2 text-left">
                      <span className="text-xs font-bold text-amber-300 uppercase tracking-wider font-mono flex items-center gap-1.5 text-left">
                        <Zap className="w-3.5 h-3.5" /> A2A Skills & Execution Contracts ({specState.agentCard?.skills?.length || 0})
                      </span>
                      <button
                        onClick={handleAddSkill}
                        className="px-2 py-1 rounded bg-[#0474C4] hover:bg-[#00A3E0] text-white text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer"
                      >
                        <Plus className="w-3 h-3" /> Add Skill
                      </button>
                    </div>

                    <div className="space-y-3 text-left">
                      {(specState.agentCard?.skills || []).map((skill, sIdx) => (
                        <div key={sIdx} className="bg-[#1A1D2B] p-3.5 rounded-lg border border-[#3E4766] space-y-2 text-left">
                          <div className="flex items-center justify-between text-left">
                            <input
                              type="text"
                              value={skill.name}
                              onChange={(e) => {
                                const newSkills = [...specState.agentCard.skills];
                                newSkills[sIdx].name = e.target.value;
                                handleUpdateField(['agentCard', 'skills'], newSkills);
                              }}
                              className="bg-transparent font-bold text-xs text-white border-b border-dashed border-[#3E4766] focus:border-cyan-400 focus:outline-none text-left"
                            />
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950 px-1.5 py-0.5 rounded border border-cyan-800">
                                {skill.id}
                              </span>
                              <button
                                onClick={() => handleDeleteSkill(sIdx)}
                                className="text-slate-400 hover:text-rose-400 p-1 transition-colors cursor-pointer"
                                title="Delete Skill"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>

                          <input
                            type="text"
                            value={skill.description}
                            onChange={(e) => {
                              const newSkills = [...specState.agentCard.skills];
                              newSkills[sIdx].description = e.target.value;
                              handleUpdateField(['agentCard', 'skills'], newSkills);
                            }}
                            className="w-full bg-[#1E2235] text-slate-300 text-[11px] px-2.5 py-1.5 rounded border border-[#3E4766] focus:outline-none text-left"
                            placeholder="Skill purpose description"
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* MCP Tool Layer Configuration */}
                  <div className="bg-[#1E2235] p-4.5 rounded-xl border border-[#3E4766] space-y-3.5 text-left">
                    <div className="flex items-center justify-between border-b border-[#3E4766] pb-2 text-left">
                      <span className="text-xs font-bold text-emerald-300 uppercase tracking-wider font-mono flex items-center gap-1.5 text-left">
                        <Layers className="w-3.5 h-3.5" /> MCP Tool Layer ({specState.mcpToolLayer?.tools?.length || 0} Tools)
                      </span>
                      <button
                        onClick={handleAddMcpTool}
                        className="px-2 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer"
                      >
                        <Plus className="w-3 h-3" /> Add MCP Tool
                      </button>
                    </div>

                    <div className="space-y-3 text-left">
                      {(specState.mcpToolLayer?.tools || []).map((tool, tIdx) => (
                        <div key={tIdx} className="bg-[#1A1D2B] p-3.5 rounded-lg border border-[#3E4766] space-y-2 text-left">
                          <div className="flex items-center justify-between text-left">
                            <input
                              type="text"
                              value={tool.name}
                              onChange={(e) => {
                                const newTools = [...specState.mcpToolLayer.tools];
                                newTools[tIdx].name = e.target.value;
                                handleUpdateField(['mcpToolLayer', 'tools'], newTools);
                              }}
                              className="bg-transparent font-mono text-xs font-bold text-emerald-300 border-b border-dashed border-[#3E4766] focus:border-emerald-400 focus:outline-none text-left"
                            />
                            <button
                              onClick={() => handleDeleteMcpTool(tIdx)}
                              className="text-slate-400 hover:text-rose-400 p-1 transition-colors cursor-pointer"
                              title="Delete MCP Tool"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <input
                            type="text"
                            value={tool.description}
                            onChange={(e) => {
                              const newTools = [...specState.mcpToolLayer.tools];
                              newTools[tIdx].description = e.target.value;
                              handleUpdateField(['mcpToolLayer', 'tools'], newTools);
                            }}
                            className="w-full bg-[#1E2235] text-slate-300 text-[11px] px-2.5 py-1.5 rounded border border-[#3E4766] focus:outline-none text-left"
                            placeholder="MCP tool purpose"
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Runtime & Model Prompting */}
                  <div className="bg-[#1E2235] p-4.5 rounded-xl border border-[#3E4766] space-y-3 text-left">
                    <span className="text-xs font-bold text-sky-300 uppercase tracking-wider font-mono flex items-center gap-1.5 text-left">
                      <Cpu className="w-3.5 h-3.5" /> Runtime & Foundation Model
                    </span>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-left">
                      <div className="text-left">
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1 text-left">Target Model</label>
                        <select
                          value={specState.runtime?.model || 'gemini-2.5-pro'}
                          onChange={(e) => handleUpdateField(['runtime', 'model'], e.target.value)}
                          className="w-full bg-[#1A1D2B] text-white px-3 py-2 rounded-lg border border-[#3E4766] focus:border-blue-500 focus:outline-none text-left"
                        >
                          <option value="gemini-2.5-pro">Gemini 2.5 Pro (Deep Reasoning & Governance)</option>
                          <option value="gemini-2.5-flash">Gemini 2.5 Flash (Ultra-Low Latency Screening)</option>
                          <option value="gemini-2.5-flash-thinking">Gemini 2.5 Flash Thinking</option>
                        </select>
                      </div>
                      <div className="text-left">
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1 text-left">Temperature</label>
                        <input
                          type="number"
                          step="0.05"
                          min="0"
                          max="1"
                          value={specState.runtime?.temperature || 0.1}
                          onChange={(e) => handleUpdateField(['runtime', 'temperature'], Number(e.target.value))}
                          className="w-full bg-[#1A1D2B] text-white px-3 py-2 rounded-lg border border-[#3E4766] focus:border-blue-500 focus:outline-none font-mono text-left"
                        />
                      </div>
                    </div>
                  </div>

                </div>
              )}
            </div>
          </div>
        )}

        {/* RIGHT COLUMN: Auto-Generated TypeScript Server Code & Validation */}
        {(activeTabPanel === 'both' || activeTabPanel === 'code_only') && (
          <div className={`${activeTabPanel === 'both' ? 'lg:col-span-6' : 'lg:col-span-12'} flex flex-col bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden text-left`}>
            
            {/* Header */}
            <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between text-left">
              <div className="flex items-center gap-2 text-left">
                <Code2 className="w-4 h-4 text-blue-600 shrink-0" />
                <span className="font-bold text-sm text-slate-900 text-left">2. Generated Microservice Code (A2A + MCP)</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                  TypeScript • Express • Node.js
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleSimulateExecution}
                  disabled={isSimulatingRun}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    isSimulatingRun ? 'bg-amber-600 text-white animate-pulse' : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                  }`}
                  title="Run A2A & MCP Protocol Handshake Verification"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>{isSimulatingRun ? 'Testing...' : 'Test A2A Handshake'}</span>
                </button>

                <button
                  onClick={handleCopyCode}
                  className="p-1.5 rounded-lg bg-[#3E4766] hover:bg-[#5379AE] text-slate-200 hover:text-white transition-all cursor-pointer text-xs flex items-center gap-1"
                  title="Copy TypeScript Code"
                >
                  {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>

                <button
                  onClick={handleDownloadCode}
                  className="p-1.5 rounded-lg bg-[#3E4766] hover:bg-[#5379AE] text-slate-200 hover:text-white transition-all cursor-pointer text-xs flex items-center gap-1"
                  title="Download .ts Microservice File"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Code Body Area */}
            <div className="flex-1 p-5 overflow-y-auto max-h-[calc(100vh-210px)] space-y-4 text-left">
              
              {/* Protocol Compliance Badges */}
              <div className="grid grid-cols-3 gap-2.5 text-left text-[10px] font-mono">
                <div className="bg-[#1A1D2B] p-2.5 rounded-lg border border-emerald-500/30 text-emerald-300 text-left">
                  <div className="font-bold flex items-center justify-start gap-1">
                    <CheckCircle2 className="w-3 h-3 shrink-0" /> A2A Discovery
                  </div>
                  <span className="text-[9px] text-slate-400 block text-left mt-0.5">/.well-known/agent.json</span>
                </div>
                <div className="bg-[#1A1D2B] p-2.5 rounded-lg border border-cyan-500/30 text-cyan-300 text-left">
                  <div className="font-bold flex items-center justify-start gap-1">
                    <CheckCircle2 className="w-3 h-3 shrink-0" /> MCP Tool Layer
                  </div>
                  <span className="text-[9px] text-slate-400 block text-left mt-0.5">/mcp/v1/tools/call</span>
                </div>
                <div className="bg-[#1A1D2B] p-2.5 rounded-lg border border-blue-500/30 text-blue-300 text-left">
                  <div className="font-bold flex items-center justify-start gap-1">
                    <CheckCircle2 className="w-3 h-3 shrink-0" /> Task RPC
                  </div>
                  <span className="text-[9px] text-slate-400 block text-left mt-0.5">/a2a/v1/tasks/execute</span>
                </div>
              </div>

              {/* Simulation Logs Output */}
              {simulationLogs.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-[#141724] border border-emerald-500/50 rounded-xl p-3.5 font-mono text-[11px] text-emerald-300 space-y-1 text-left"
                >
                  <div className="font-bold text-white flex items-center justify-between pb-1 border-b border-slate-800 text-[10px] text-left">
                    <span className="flex items-center gap-1.5 text-left">
                      <Terminal className="w-3.5 h-3.5 text-emerald-400 shrink-0" /> A2A v1.0 Standard Test Console
                    </span>
                    <button onClick={() => setSimulationLogs([])} className="text-slate-400 hover:text-white text-[9px] cursor-pointer">Clear</button>
                  </div>
                  {simulationLogs.map((log, lIdx) => (
                    <div key={lIdx} className="leading-tight text-left">{log}</div>
                  ))}
                </motion.div>
              )}

              {/* Code Display */}
              <div className="relative text-left">
                <pre className="w-full bg-[#141724] text-slate-200 font-mono text-[11px] p-4 rounded-xl border border-[#3E4766] overflow-x-auto leading-relaxed select-text text-left">
                  <code className="text-left">{generatedCode}</code>
                </pre>
              </div>

            </div>
          </div>
        )}

      </div>

      {/* Delete Skill Confirmation Dialog */}
      <DeleteConfirmModal
        isOpen={!!skillToDelete}
        onClose={() => setSkillToDelete(null)}
        onConfirm={handleConfirmDeleteSkill}
        title="Delete Agent Skill"
        description={`Are you sure you want to delete skill "${skillToDelete?.name}" from this agent specification?`}
        confirmLabel="Delete Skill"
      />

      {/* Delete MCP Tool Confirmation Dialog */}
      <DeleteConfirmModal
        isOpen={!!toolToDelete}
        onClose={() => setToolToDelete(null)}
        onConfirm={handleConfirmDeleteMcpTool}
        title="Delete MCP Tool"
        description={`Are you sure you want to delete tool "${toolToDelete?.name}" from the MCP layer definition?`}
        confirmLabel="Delete Tool"
      />
    </div>
  );
}
