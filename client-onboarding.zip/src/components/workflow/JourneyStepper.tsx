import React, { useState, useEffect, useMemo } from 'react';
import { Lock, Compass } from 'lucide-react';
import { WorkflowNode, ClientProfile } from '../../types';
import { Journey, JourneyStage, DEFAULT_JOURNEYS } from '../common/PersonaSubviews';

interface JourneyStepperProps {
  nodes: WorkflowNode[];
  selectedNodeId: string;
  onSelectNode: (nodeId: string) => void;
  activeRunningNodeId?: string;
  onReorderNodes?: (reorderedNodes: WorkflowNode[]) => void;
  activeClient?: ClientProfile;
  showDependencyGraph?: boolean;
  onToggleDependencyGraph?: (show: boolean) => void;
}

export const JourneyStepper: React.FC<JourneyStepperProps> = ({
  nodes,
  selectedNodeId,
  onSelectNode,
  activeRunningNodeId,
  onReorderNodes,
  activeClient,
  showDependencyGraph = false,
  onToggleDependencyGraph
}) => {
  const [lockToast, setLockToast] = useState<string | null>(null);

  // Dynamically source journeys from Platform Admin (localStorage + sync events)
  const [journeys, setJourneys] = useState<Journey[]>(() => {
    try {
      const saved = localStorage.getItem('onboarding_journeys');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // fallback
    }
    return DEFAULT_JOURNEYS;
  });

  useEffect(() => {
    const handleSync = () => {
      try {
        const saved = localStorage.getItem('onboarding_journeys');
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) {
            setJourneys(parsed);
            return;
          }
        }
      } catch {
        // fallback
      }
      setJourneys(DEFAULT_JOURNEYS);
    };

    window.addEventListener('onboarding_journeys_updated', handleSync);
    window.addEventListener('storage', handleSync);
    return () => {
      window.removeEventListener('onboarding_journeys_updated', handleSync);
      window.removeEventListener('storage', handleSync);
    };
  }, []);

  // Determine active journey for the current client
  const activeJourney = useMemo(() => {
    const targetJourneyId = activeClient?.journeyId || 'corporate_onboarding_journey';
    return journeys.find(j => j.id === targetJourneyId) || journeys[0] || DEFAULT_JOURNEYS[0];
  }, [journeys, activeClient?.journeyId]);

  // Clean and format stage titles for clean UI presentation
  const cleanStageName = (rawName: string, index: number): string => {
    if (!rawName) return `Stage ${index + 1}`;
    // Strip "STAGE X:" or "PHASE X:" or "STEP X:"
    let cleaned = rawName.replace(/^(STAGE|PHASE|STEP)\s*\d+[\s:\-–—]*/i, '').trim();
    // If it's all uppercase and longer than 3 chars, convert to title case
    if (cleaned.length > 3 && cleaned === cleaned.toUpperCase()) {
      cleaned = cleaned
        .toLowerCase()
        .split(' ')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
    }
    return cleaned || rawName;
  };

  // Build the dynamic stages list sourced from the underlying configured journey
  const stages = useMemo(() => {
    const rawStages: JourneyStage[] = (activeJourney.stages && activeJourney.stages.length > 0)
      ? activeJourney.stages
      : (activeJourney.phases && activeJourney.phases.length > 0)
      ? activeJourney.phases
      : (DEFAULT_JOURNEYS[0]?.stages || []);

    return rawStages.map((st, idx) => {
      // Match by exact stage ID or fallback to node at index
      const matchingNode = nodes.find(n => n.id === st.id) || nodes[idx];
      const nodeId = matchingNode?.id || st.id || `stage_${idx + 1}`;
      const stageNumber = idx + 1;
      const displayName = cleanStageName(st.name, idx);

      let percentage = 0;
      if (matchingNode) {
        if (matchingNode.status === 'completed') {
          percentage = 100;
        } else if (matchingNode.status === 'running' || matchingNode.id === activeRunningNodeId) {
          percentage = 50;
        } else if (matchingNode.status === 'flagged') {
          percentage = 30;
        } else {
          percentage = 0;
        }
      } else {
        // Fallback percentage based on index if client initialized
        percentage = idx === 0 ? 100 : 0;
      }

      return {
        id: st.id || `stage_${stageNumber}`,
        stageNumber,
        name: displayName,
        rawName: st.name,
        description: st.description,
        nodeId,
        node: matchingNode,
        percentage,
        status: matchingNode?.status || (percentage === 100 ? 'completed' : 'pending')
      };
    });
  }, [activeJourney, nodes, activeRunningNodeId]);

  const completedStagesCount = stages.filter(s => s.percentage === 100 || s.status === 'completed').length;
  const totalStages = stages.length;

  // Clean journey name for display
  const journeyDisplayName = activeJourney.name.replace(/^[^\w\s]+/g, '').trim();

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-6 mb-6 shadow-xs relative">
      {/* Optional Notification Toast */}
      {lockToast && (
        <div className="mb-4 p-3 bg-amber-500/15 border border-amber-500/40 text-amber-800 rounded-lg text-xs font-semibold flex items-center justify-between gap-2 shadow-xs animate-pulse">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-amber-600 shrink-0" />
            <span>{lockToast}</span>
          </div>
          <button 
            type="button"
            onClick={() => setLockToast(null)}
            className="text-[10px] font-mono uppercase underline text-amber-700 hover:text-amber-900 cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Card Header: Onboarding Stages · Click any stage to inspect verified data fields */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3.5 border-b border-slate-100">
        <div className="flex flex-wrap items-center gap-2">
          <h2 className="text-base font-bold text-slate-900 tracking-tight">
            Onboarding Stages
          </h2>
          <span className="text-xs text-slate-500 font-normal">
            &bull; Click any stage to inspect verified data fields
          </span>
          <span className="text-[11px] font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
            Journey: {journeyDisplayName}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="font-mono text-xs font-bold px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200">
            {completedStagesCount === totalStages
              ? `Stages 1 to ${totalStages} Completed`
              : `Stage ${completedStagesCount} of ${totalStages} Completed`}
          </span>

          {onToggleDependencyGraph && (
            <button
              type="button"
              onClick={() => onToggleDependencyGraph(!showDependencyGraph)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer border shadow-2xs ${
                showDependencyGraph
                  ? 'bg-blue-600 text-white border-blue-600 hover:bg-blue-700'
                  : 'bg-white hover:bg-slate-50 text-slate-700 hover:text-blue-600 border-slate-200'
              }`}
              title={showDependencyGraph ? 'Switch to Verified Stage Content' : 'View Visual Dependency Graph & Workflow DAG'}
            >
              <Compass className={`w-3.5 h-3.5 ${showDependencyGraph ? 'text-white' : 'text-blue-600'}`} />
              <span>{showDependencyGraph ? 'Hide Dependency Graph' : 'Dependency Graph'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Dynamic Stages Grid in Card Layout with Reduced Card Width */}
      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-7 xl:grid-cols-8 2xl:grid-cols-11 gap-2.5 mt-4">
        {stages.map((stage, idx) => {
          const isSelected = selectedNodeId === stage.nodeId || (!selectedNodeId && idx === 0);

          return (
            <div
              key={stage.id}
              role="button"
              tabIndex={0}
              onClick={() => onSelectNode(stage.nodeId)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  onSelectNode(stage.nodeId);
                }
              }}
              className={`p-2.5 rounded-xl border text-left transition-all duration-200 cursor-pointer flex flex-col justify-between group ${
                isSelected 
                  ? 'border-blue-500 ring-2 ring-blue-500/20 bg-blue-50/30 shadow-xs' 
                  : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50/60 bg-white shadow-2xs'
              }`}
            >
              <div className="w-full">
                {/* Stage number with small text & Percentage */}
                <div className="flex items-center justify-between gap-1 mb-1">
                  <span className="text-[10px] font-mono font-medium text-slate-400">
                    Stage {stage.stageNumber}
                  </span>
                  <span className={`text-[11px] font-bold font-mono ${stage.percentage === 100 ? 'text-emerald-600' : 'text-slate-800'}`}>
                    {stage.percentage}%
                  </span>
                </div>

                {/* Stage name with normal text (not all capitals) */}
                <h3 className="text-xs font-semibold text-slate-900 leading-tight mb-2 line-clamp-2 min-h-[2rem]">
                  {stage.name}
                </h3>
              </div>

              {/* Small progress bar on completion with a small circular pointer showing the progress */}
              <div className="w-full relative py-0.5 mt-auto">
                <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full transition-all duration-300 ${
                      stage.percentage === 100 
                        ? 'bg-emerald-500' 
                        : stage.percentage > 0 
                        ? 'bg-blue-600' 
                        : 'bg-slate-200'
                    }`}
                    style={{ width: `${stage.percentage}%` }}
                  />
                </div>
                {/* Small circular pointer showing the progress */}
                <div 
                  className={`absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-2 h-2 rounded-full border shadow-2xs transition-all duration-300 pointer-events-none ${
                    stage.percentage === 100
                      ? 'bg-emerald-500 border-white ring-1 ring-emerald-500'
                      : stage.percentage > 0
                      ? 'bg-blue-600 border-white ring-1 ring-blue-600'
                      : 'bg-slate-300 border-white ring-1 ring-slate-300'
                  }`}
                  style={{ left: `${Math.max(4, Math.min(96, stage.percentage))}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default JourneyStepper;
