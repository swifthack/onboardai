import React, { useState, useMemo, useRef } from 'react';
import { 
  Network, 
  Plus, 
  Play, 
  Save, 
  Trash2, 
  Settings, 
  ToggleLeft, 
  ToggleRight, 
  Cpu, 
  Database, 
  Sparkles, 
  Layers, 
  Bot, 
  Cable,
  CheckCircle,
  HelpCircle,
  Server,
  Activity,
  X,
  PlusCircle,
  Sliders,
  Check,
  Zap,
  ArrowRight,
  MoveUp,
  MoveDown,
  AlertTriangle,
  Mail,
  Globe,
  HardDrive,
  Terminal,
  GripVertical,
  Link2,
  Unlink,
  ExternalLink,
  Code,
  Send,
  RefreshCw,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Search,
  Filter,
  LayoutGrid,
  List,
  Eye,
  Edit3,
  ArrowLeft,
  Workflow
} from 'lucide-react';
import { OrchestrationAgent, AgentOrchestration, HybridStage } from '../../types';
import { motion, AnimatePresence } from 'motion/react';
import { DEFAULT_JOURNEYS } from '../common/PersonaSubviews';
import { INITIAL_AGENTS, INITIAL_ORCHESTRATIONS } from '../../agents/definitions';
import { DeleteConfirmModal } from '../common/DeleteConfirmModal';

// Palette step templates for n8n-style drag and drop step builder
interface PaletteTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  agentClass: 'super' | 'normal';
  usesGoogleProtocol: boolean;
  nodeType: 'agent' | 'mcp' | 'api' | 'email' | 'database';
  mcpServerUrl?: string;
  mcpApis?: string[];
  mcpConnectedSources?: string[];
  apiEndpoint?: string;
  httpMethod?: 'GET' | 'POST' | 'PUT' | 'DELETE';
  emailRecipient?: string;
  emailSubject?: string;
  dbTable?: string;
  model?: string;
}

const PALETTE_STEP_TEMPLATES: PaletteTemplate[] = [
  // Agents
  {
    id: 'tpl_agent_onboarding',
    name: 'Onboarding Coordinator Agent',
    description: 'Manages kickoff, invites RM, tracks SLA deadlines.',
    category: 'core',
    agentClass: 'super',
    nodeType: 'agent',
    usesGoogleProtocol: true,
    model: 'Claude 3.5 Sonnet'
  },
  {
    id: 'tpl_agent_kyc',
    name: 'KYC & Sanctions Agent',
    description: 'Verifies passports, biometric selfies, PEP lists.',
    category: 'kyc',
    agentClass: 'super',
    nodeType: 'agent',
    usesGoogleProtocol: true,
    model: 'GPT-4o'
  },
  {
    id: 'tpl_agent_credit',
    name: 'Credit Underwriting Agent',
    description: 'Calculates debt service ratios and trade limit approvals.',
    category: 'underwriting',
    agentClass: 'normal',
    nodeType: 'agent',
    usesGoogleProtocol: true,
    model: 'Claude 3.5 Haiku'
  },
  // MCP Tools
  {
    id: 'tpl_mcp_acra',
    name: 'ACRA Registry MCP Server',
    description: 'Model Context Protocol tool querying company registry.',
    category: 'mcp_tool',
    agentClass: 'normal',
    nodeType: 'mcp',
    usesGoogleProtocol: true,
    mcpServerUrl: 'mcp://acra.gov.sg/registry-v2',
    mcpApis: ['getCompanyProfile', 'getShareholderTree', 'getDirectorList'],
    mcpConnectedSources: ['Singapore ACRA Registry', 'Delaware Corp Portal']
  },
  {
    id: 'tpl_mcp_lexisnexis',
    name: 'LexisNexis Adverse Media MCP',
    description: 'Scans global news feeds and sanctions databases.',
    category: 'mcp_tool',
    agentClass: 'normal',
    nodeType: 'mcp',
    usesGoogleProtocol: true,
    mcpServerUrl: 'mcp://compliance.lexisnexis.com/adverse-news',
    mcpApis: ['searchAdverseNews', 'classifySentiment'],
    mcpConnectedSources: ['Global News API', 'LexisNexis Newsdesk']
  },
  {
    id: 'tpl_mcp_product_catalog',
    name: 'Product Matrix MCP Server',
    description: 'Banking product suitability rules and trade limit parameters.',
    category: 'mcp_tool',
    agentClass: 'normal',
    nodeType: 'mcp',
    usesGoogleProtocol: true,
    mcpServerUrl: 'mcp://products.bank.internal/matrix',
    mcpApis: ['queryProductLimits', 'validateEligibility'],
    mcpConnectedSources: ['Core Banking Engine']
  },
  // External REST APIs
  {
    id: 'tpl_api_core_banking',
    name: 'Core Banking REST API',
    description: 'Provisions virtual ledger accounts & sets credit caps.',
    category: 'api_endpoint',
    agentClass: 'normal',
    nodeType: 'api',
    usesGoogleProtocol: false,
    apiEndpoint: 'https://api.corebank.internal/v1/accounts/provision',
    httpMethod: 'POST'
  },
  {
    id: 'tpl_api_sanctions_gateway',
    name: 'Sanctions Screening Webhook',
    description: 'REST webhook connecting to OFAC & UN sanctions list.',
    category: 'api_endpoint',
    agentClass: 'normal',
    nodeType: 'api',
    usesGoogleProtocol: false,
    apiEndpoint: 'https://compliance.gateway.com/v2/pep-screening',
    httpMethod: 'POST'
  },
  // Outreach & Email
  {
    id: 'tpl_email_outreach',
    name: 'Client Email Dispatch',
    description: 'Sends personalized onboarding welcome emails & doc links.',
    category: 'communication',
    agentClass: 'normal',
    nodeType: 'email',
    usesGoogleProtocol: false,
    emailRecipient: 'Authorized Representative / Client',
    emailSubject: 'Action Required: Complete Corporate Onboarding'
  },
  {
    id: 'tpl_email_escalation',
    name: 'Ops Escalation Dispatch',
    description: 'Alerts compliance leads for high-risk manual review.',
    category: 'communication',
    agentClass: 'normal',
    nodeType: 'email',
    usesGoogleProtocol: false,
    emailRecipient: 'Compliance & Ops Lead',
    emailSubject: 'High Priority Alert: Onboarding Exception Triggered'
  },
  // Databases
  {
    id: 'tpl_db_customer_vault',
    name: 'Customer 360 Vault DB',
    description: 'Encrypted database storing company records & risk scores.',
    category: 'database',
    agentClass: 'normal',
    nodeType: 'database',
    usesGoogleProtocol: false,
    dbTable: 'customer_360_profiles'
  },
  {
    id: 'tpl_db_audit_ledger',
    name: 'Immutable Audit Ledger DB',
    description: 'Regulatory audit log recording all agent actions & decision rationale.',
    category: 'database',
    agentClass: 'normal',
    nodeType: 'database',
    usesGoogleProtocol: false,
    dbTable: 'audit_logs_compliance'
  }
];

interface AgentOrchestratorProps {
  agents: OrchestrationAgent[];
  setAgents: React.Dispatch<React.SetStateAction<OrchestrationAgent[]>>;
  orchestrations: AgentOrchestration[];
  setOrchestrations: React.Dispatch<React.SetStateAction<AgentOrchestration[]>>;
}

export default function AgentOrchestrator({
  agents,
  setAgents,
  orchestrations,
  setOrchestrations
}: AgentOrchestratorProps) {
  // Main view navigation: 'list' (catalog) vs 'designer' (visual canvas)
  const [viewMode, setViewMode] = useState<'list' | 'designer'>('list');
  const [selectedOrchestrationId, setSelectedOrchestrationId] = useState<string>('hybrid_enterprise_onboarding');
  
  // Selection and edit states
  const [editingAgentId, setEditingAgentId] = useState<string | null>('onboarding_agent');
  const [isOnboardingNewAgent, setIsOnboardingNewAgent] = useState(false);
  
  // Interactive canvas drag, connect & zoom state
  const canvasRef = useRef<HTMLDivElement>(null);
  const [draggingNodeId, setDraggingNodeId] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [connectingFromId, setConnectingFromId] = useState<string | null>(null);
  const [mouseCanvasPos, setMouseCanvasPos] = useState<{ x: number; y: number } | null>(null);
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [paletteCategory, setPaletteCategory] = useState<string>('all');
  const [inspectorTab, setInspectorTab] = useState<'general' | 'params' | 'connections'>('general');
  const [testPayloadResult, setTestPayloadResult] = useState<string | null>(null);

  // Save & New Canvas State
  const [showSavePromptModal, setShowSavePromptModal] = useState(false);
  const [saveToast, setSaveToast] = useState<string | null>(null);
  const [isDirty, setIsDirty] = useState(false);

  // Forced Name Modal state
  const [showNameRequiredModal, setShowNameRequiredModal] = useState(false);
  const [pendingPipelineName, setPendingPipelineName] = useState('');
  const [nameError, setNameError] = useState<string | null>(null);
  const [onSaveSuccessCallback, setOnSaveSuccessCallback] = useState<(() => void) | null>(null);
  const [modalNameError, setModalNameError] = useState<string | null>(null);

  // New Workflow State
  const [isCreatingWorkflow, setIsCreatingWorkflow] = useState(false);
  const [editingWorkflowId, setEditingWorkflowId] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [deleteErrorMsg, setDeleteErrorMsg] = useState<string | null>(null);
  const [newWorkflowName, setNewWorkflowName] = useState('');
  
  // Step Node & Canvas Deletion Modals
  const [nodeToRemove, setNodeToRemove] = useState<OrchestrationAgent | null>(null);
  const [showClearCanvasConfirm, setShowClearCanvasConfirm] = useState(false);
  const [newWorkflowDesc, setNewWorkflowDesc] = useState('');
  const [newWorkflowType, setNewWorkflowType] = useState<'corporate' | 'funds' | 'custom'>('custom');
  const [selectedAgentIds, setSelectedAgentIds] = useState<string[]>([]);

  // Simulation play state
  const [simulatingNodeIds, setSimulatingNodeIds] = useState<string[]>([]);
  const [simulationLogs, setSimulationLogs] = useState<string[]>([]);
  const [isSimulating, setIsSimulating] = useState(false);

  // New Agent Form State
  const [newAgentName, setNewAgentName] = useState('');
  const [newAgentDesc, setNewAgentDesc] = useState('');
  const [newAgentCategory, setNewAgentCategory] = useState<'core' | 'kyc' | 'product' | 'risk' | 'document'>('kyc');
  const [newAgentMcp, setNewAgentMcp] = useState('');
  const [newAgentToolsInput, setNewAgentToolsInput] = useState('');

  const activeOrchestration = useMemo(() => {
    return orchestrations.find(o => o.id === selectedOrchestrationId) || orchestrations[0] || INITIAL_ORCHESTRATIONS[0];
  }, [orchestrations, selectedOrchestrationId]);

  // Compute active canvas nodes
  const canvasNodes = useMemo(() => {
    if (!activeOrchestration) return agents;
    return activeOrchestration.agentIds.map(id => {
      return agents.find(a => a.id === id);
    }).filter(Boolean) as OrchestrationAgent[];
  }, [activeOrchestration, agents]);

  const editingAgent = useMemo(() => {
    if (!editingAgentId) return null;
    return agents.find(a => a.id === editingAgentId) || null;
  }, [agents, editingAgentId]);

  // Node Type styling metadata
  const getNodeTypeMeta = (nodeType?: string) => {
    switch (nodeType) {
      case 'mcp':
        return {
          label: 'MCP TOOL',
          badgeBg: 'bg-purple-100 text-purple-800 border-purple-200',
          cardBorder: 'hover:border-purple-300',
          activeBorder: 'border-purple-600 ring-2 ring-purple-500/25',
          headerBg: 'bg-purple-50/80 text-purple-950 border-purple-200',
          icon: <Cable className="w-3.5 h-3.5 text-purple-600" />,
          wireColor: '#a855f7',
          wireLabel: 'MCP Tool Call'
        };
      case 'api':
        return {
          label: 'REST API',
          badgeBg: 'bg-amber-100 text-amber-800 border-amber-200',
          cardBorder: 'hover:border-amber-300',
          activeBorder: 'border-amber-600 ring-2 ring-amber-500/25',
          headerBg: 'bg-amber-50/80 text-amber-950 border-amber-200',
          icon: <Globe className="w-3.5 h-3.5 text-amber-600" />,
          wireColor: '#f59e0b',
          wireLabel: 'REST Webhook'
        };
      case 'email':
        return {
          label: 'EMAIL',
          badgeBg: 'bg-emerald-100 text-emerald-800 border-emerald-200',
          cardBorder: 'hover:border-emerald-300',
          activeBorder: 'border-emerald-600 ring-2 ring-emerald-500/25',
          headerBg: 'bg-emerald-50/80 text-emerald-950 border-emerald-200',
          icon: <Mail className="w-3.5 h-3.5 text-emerald-600" />,
          wireColor: '#10b981',
          wireLabel: 'Email Dispatch'
        };
      case 'database':
        return {
          label: 'DATABASE',
          badgeBg: 'bg-cyan-100 text-cyan-800 border-cyan-200',
          cardBorder: 'hover:border-cyan-300',
          activeBorder: 'border-cyan-600 ring-2 ring-cyan-500/25',
          headerBg: 'bg-cyan-50/80 text-cyan-950 border-cyan-200',
          icon: <Database className="w-3.5 h-3.5 text-cyan-600" />,
          wireColor: '#06b6d4',
          wireLabel: 'Data Vault'
        };
      default:
        return {
          label: 'AGENT',
          badgeBg: 'bg-blue-100 text-blue-800 border-blue-200',
          cardBorder: 'hover:border-blue-300',
          activeBorder: 'border-blue-600 ring-2 ring-blue-500/25',
          headerBg: 'bg-blue-50/80 text-blue-950 border-blue-200',
          icon: <Bot className="w-3.5 h-3.5 text-blue-600" />,
          wireColor: '#3b82f6',
          wireLabel: 'A2A Protocol'
        };
    }
  };

  const getConnectionMeta = (fromNode?: OrchestrationAgent, toNode?: OrchestrationAgent) => {
    if (fromNode?.nodeType === 'mcp' || toNode?.nodeType === 'mcp') {
      return { color: '#a855f7', label: 'MCP Tool Call', badgeClass: 'bg-purple-100 text-purple-800 border-purple-200', markerId: 'purple' };
    }
    if (fromNode?.nodeType === 'api' || toNode?.nodeType === 'api') {
      return { color: '#f59e0b', label: 'REST Webhook', badgeClass: 'bg-amber-100 text-amber-800 border-amber-200', markerId: 'amber' };
    }
    if (fromNode?.nodeType === 'email' || toNode?.nodeType === 'email') {
      return { color: '#10b981', label: 'Email Outreach', badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-200', markerId: 'emerald' };
    }
    if (fromNode?.nodeType === 'database' || toNode?.nodeType === 'database') {
      return { color: '#06b6d4', label: 'Data Vault', badgeClass: 'bg-cyan-100 text-cyan-800 border-cyan-200', markerId: 'cyan' };
    }
    return { color: '#3b82f6', label: 'A2A Protocol', badgeClass: 'bg-blue-100 text-blue-800 border-blue-200', markerId: 'blue' };
  };

  // Drag and drop mechanics for canvas nodes
  const handleNodeMouseDown = (e: React.MouseEvent, nodeId: string) => {
    e.stopPropagation();
    setEditingAgentId(nodeId);
    if (!canvasRef.current) return;
    const canvasRect = canvasRef.current.getBoundingClientRect();
    const node = agents.find(a => a.id === nodeId);
    const nodeX = node?.position?.x || 0;
    const nodeY = node?.position?.y || 0;

    const clickX = (e.clientX - canvasRect.left) / zoomLevel;
    const clickY = (e.clientY - canvasRect.top) / zoomLevel;

    setDragOffset({
      x: clickX - nodeX,
      y: clickY - nodeY
    });
    setDraggingNodeId(nodeId);
  };

  const handleCanvasMouseMove = (e: React.MouseEvent) => {
    if (!canvasRef.current) return;
    const canvasRect = canvasRef.current.getBoundingClientRect();
    const currentX = (e.clientX - canvasRect.left) / zoomLevel;
    const currentY = (e.clientY - canvasRect.top) / zoomLevel;

    if (connectingFromId) {
      setMouseCanvasPos({ x: currentX, y: currentY });
    }

    if (!draggingNodeId) return;

    const newX = Math.max(10, Math.min(2000, currentX - dragOffset.x));
    const newY = Math.max(10, Math.min(1100, currentY - dragOffset.y));

    setAgents(prev => prev.map(a => {
      if (a.id === draggingNodeId) {
        return { ...a, position: { x: Math.round(newX), y: Math.round(newY) } };
      }
      return a;
    }));
  };

  const handleCanvasMouseUp = () => {
    if (draggingNodeId) {
      setDraggingNodeId(null);
    }
  };

  // Drag and drop HTML5 for palette templates
  const handlePaletteDragStart = (e: React.DragEvent, template: PaletteTemplate) => {
    e.dataTransfer.setData('application/json', JSON.stringify(template));
    e.dataTransfer.effectAllowed = 'copy';
  };

  const handleCanvasDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
  };

  const handleCanvasDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (!canvasRef.current || !activeOrchestration) return;

    try {
      const dataStr = e.dataTransfer.getData('application/json');
      if (!dataStr) return;
      const template = JSON.parse(dataStr) as PaletteTemplate;

      const canvasRect = canvasRef.current.getBoundingClientRect();
      const dropX = Math.max(20, Math.min(2000, (e.clientX - canvasRect.left) / zoomLevel));
      const dropY = Math.max(20, Math.min(1100, (e.clientY - canvasRect.top) / zoomLevel));

      const newId = `${template.nodeType}_${Date.now().toString().slice(-4)}`;

      const newAgent: OrchestrationAgent = {
        id: newId,
        name: template.name,
        description: template.description,
        category: template.category,
        isEnabled: true,
        agentClass: template.agentClass,
        usesGoogleProtocol: template.usesGoogleProtocol,
        nodeType: template.nodeType,
        apiEndpoint: template.apiEndpoint,
        httpMethod: template.httpMethod,
        emailRecipient: template.emailRecipient,
        emailSubject: template.emailSubject,
        dbTable: template.dbTable,
        mcpServerUrl: template.mcpServerUrl,
        mcpApis: template.mcpApis,
        mcpConnectedSources: template.mcpConnectedSources,
        model: template.model,
        position: { x: Math.round(dropX), y: Math.round(dropY) }
      };

      setAgents(prev => [...prev, newAgent]);

      setOrchestrations(prev => prev.map(o => {
        if (o.id === activeOrchestration.id) {
          return {
            ...o,
            agentIds: [...(o.agentIds || []), newId]
          };
        }
        return o;
      }));

      setEditingAgentId(newId);
      setIsDirty(true);
    } catch (err) {
      console.error('Error dropping palette step node onto canvas:', err);
    }
  };

  // Add step directly from palette click
  const handleAddTemplateClick = (template: PaletteTemplate) => {
    if (!activeOrchestration) return;
    const newId = `${template.nodeType}_${Date.now().toString().slice(-4)}`;
    
    // Auto calculate staggering position
    const count = canvasNodes.length;
    const dropX = Math.min(650, 40 + (count % 4) * 200);
    const dropY = Math.min(280, 40 + Math.floor(count / 4) * 110);

    const newAgent: OrchestrationAgent = {
      id: newId,
      name: template.name,
      description: template.description,
      category: template.category,
      isEnabled: true,
      agentClass: template.agentClass,
      usesGoogleProtocol: template.usesGoogleProtocol,
      nodeType: template.nodeType,
      apiEndpoint: template.apiEndpoint,
      httpMethod: template.httpMethod,
      emailRecipient: template.emailRecipient,
      emailSubject: template.emailSubject,
      dbTable: template.dbTable,
      mcpServerUrl: template.mcpServerUrl,
      mcpApis: template.mcpApis,
      mcpConnectedSources: template.mcpConnectedSources,
      model: template.model,
      position: { x: dropX, y: dropY }
    };

    setAgents(prev => [...prev, newAgent]);
    setOrchestrations(prev => prev.map(o => {
      if (o.id === activeOrchestration.id) {
        return {
          ...o,
          agentIds: [...(o.agentIds || []), newId]
        };
      }
      return o;
    }));
    setEditingAgentId(newId);
    setIsDirty(true);
  };

  // Connections handling
  const handlePortClick = (e: React.MouseEvent, nodeId: string, portType: 'input' | 'output') => {
    e.stopPropagation();
    if (portType === 'output') {
      setConnectingFromId(nodeId);
    } else if (portType === 'input' && connectingFromId) {
      if (connectingFromId === nodeId) {
        setConnectingFromId(null);
        return;
      }
      addConnection(connectingFromId, nodeId);
      setConnectingFromId(null);
    }
  };

  const addConnection = (fromId: string, toId: string) => {
    if (!activeOrchestration) return;
    const existing = activeOrchestration.connections || [];
    if (existing.some(c => c.from === fromId && c.to === toId)) return;

    const updatedConns = [...existing, { from: fromId, to: toId }];
    setOrchestrations(prev => prev.map(o => {
      if (o.id === activeOrchestration.id) {
        return { ...o, connections: updatedConns };
      }
      return o;
    }));
    setIsDirty(true);
  };

  const removeConnection = (fromId: string, toId: string) => {
    if (!activeOrchestration) return;
    const updatedConns = (activeOrchestration.connections || []).filter(c => !(c.from === fromId && c.to === toId));
    setOrchestrations(prev => prev.map(o => {
      if (o.id === activeOrchestration.id) {
        return { ...o, connections: updatedConns };
      }
      return o;
    }));
    setIsDirty(true);
  };

  const removeAgentFromPipeline = (agentId: string) => {
    if (!activeOrchestration) return;
    setOrchestrations(prev => prev.map(o => {
      if (o.id === activeOrchestration.id) {
        return {
          ...o,
          agentIds: o.agentIds.filter(id => id !== agentId),
          connections: o.connections.filter(c => c.from !== agentId && c.to !== agentId)
        };
      }
      return o;
    }));
    if (editingAgentId === agentId) {
      setEditingAgentId(null);
    }
    setIsDirty(true);
  };

  const toggleAgentEnable = (agentId: string) => {
    setAgents(prev => prev.map(a => a.id === agentId ? { ...a, isEnabled: !a.isEnabled } : a));
  };

  const clearCanvas = () => {
    if (!activeOrchestration) return;
    setOrchestrations(prev => prev.map(o => {
      if (o.id === activeOrchestration.id) {
        return { ...o, agentIds: [], connections: [] };
      }
      return o;
    }));
    setEditingAgentId(null);
  };

  // Test payload simulation
  const handleTestStepPayload = (node: OrchestrationAgent) => {
    let payloadObj: any = {};
    if (node.nodeType === 'mcp') {
      payloadObj = {
        mcpServer: node.mcpServerUrl || 'mcp://localhost:3011/tool-server',
        status: 'CONNECTED',
        latency: '42ms',
        exposedTools: node.mcpApis || ['queryData', 'validateRule'],
        connectedDataSources: node.mcpConnectedSources || ['Singapore ACRA Registry'],
        sampleOutput: {
          companyStatus: 'Active Standing',
          registrationNo: '202301982K',
          directorsVerified: 3,
          complianceScore: 0.98
        }
      };
    } else if (node.nodeType === 'api') {
      payloadObj = {
        endpoint: node.apiEndpoint || 'https://api.corebank.internal/v1/accounts/provision',
        method: node.httpMethod || 'POST',
        status: 200,
        statusText: 'OK',
        executionTime: '112ms',
        response: {
          accountId: `ACC-${Math.floor(100000 + Math.random() * 900000)}`,
          status: 'PROVISIONED',
          creditLimit: '$5,000,000 USD',
          currency: 'USD'
        }
      };
    } else if (node.nodeType === 'email') {
      payloadObj = {
        transport: 'SMTP / SendGrid Gateway',
        recipient: node.emailRecipient || 'Authorized Representative',
        subject: node.emailSubject || 'Welcome to Corporate Banking',
        status: 'DELIVERED',
        deliveredAt: new Date().toISOString(),
        messageId: `<msg-${Math.random().toString(36).substring(2, 9)}@bank.internal>`
      };
    } else if (node.nodeType === 'database') {
      payloadObj = {
        dbEngine: 'Encrypted PostgreSQL Vault',
        targetTable: node.dbTable || 'customer_360_profiles',
        operation: 'UPSERT',
        affectedRows: 1,
        executionTime: '6ms',
        lastSync: new Date().toISOString()
      };
    } else {
      payloadObj = {
        agentId: node.id,
        agentClass: node.agentClass,
        protocol: node.usesGoogleProtocol ? 'Enterprise Agent Protocol (A2A)' : 'Standard WebSocket',
        model: node.model || 'Claude 3.5 Sonnet',
        status: 'ACTIVE_LISTENING',
        lastPulse: new Date().toISOString()
      };
    }
    setTestPayloadResult(JSON.stringify(payloadObj, null, 2));
  };

  // Dry Run Engine
  const triggerDryRun = () => {
    if (isSimulating || !activeOrchestration) return;
    setIsSimulating(true);
    setSimulationLogs([]);
    setSimulatingNodeIds([]);

    const sequence = canvasNodes.filter(n => n.isEnabled);
    if (sequence.length === 0) {
      setSimulationLogs(['[SYSTEM] No active step nodes present on canvas. Add steps to execute.']);
      setIsSimulating(false);
      return;
    }

    setSimulationLogs(['🚀 [INIT] Booting Dry Run Execution Pipeline across active nodes...']);

    sequence.forEach((node, idx) => {
      setTimeout(() => {
        setSimulatingNodeIds(prev => [...prev, node.id]);
        const typeMeta = getNodeTypeMeta(node.nodeType);
        
        let detailLog = '';
        if (node.nodeType === 'mcp') {
          detailLog = `[${typeMeta.label}] Connected to ${node.mcpServerUrl || 'MCP Server'} • Querying tools [${node.mcpApis?.slice(0, 2).join(', ') || 'registry'}]`;
        } else if (node.nodeType === 'api') {
          detailLog = `[${typeMeta.label}] ${node.httpMethod || 'POST'} ${node.apiEndpoint || 'Webhook Endpoint'} -> 200 OK (112ms)`;
        } else if (node.nodeType === 'email') {
          detailLog = `[${typeMeta.label}] Dispatched outreach email to [${node.emailRecipient || 'Client'}] -> Subject: "${node.emailSubject || 'Welcome'}"`;
        } else if (node.nodeType === 'database') {
          detailLog = `[${typeMeta.label}] UPSERT table [${node.dbTable || 'vault'}] -> 1 row committed (6ms)`;
        } else {
          detailLog = `[${typeMeta.label}] Executed ${node.name} via ${node.usesGoogleProtocol ? 'Enterprise Agent Protocol' : 'Internal Engine'}`;
        }

        setSimulationLogs(prev => [
          ...prev,
          `⚡ Step ${idx + 1}/${sequence.length}: ${node.name} -> ${detailLog}`
        ]);

        if (idx === sequence.length - 1) {
          setTimeout(() => {
            setSimulationLogs(prev => [...prev, '✅ [SUCCESS] Execution pipeline completed cleanly. All node packets processed.']);
            setIsSimulating(false);
            setSimulatingNodeIds([]);
          }, 1000);
        }
      }, (idx + 1) * 900);
    });
  };

  // Name validation check helper
  const isNameInvalid = (name?: string) => {
    if (!name) return true;
    const trimmed = name.trim().toLowerCase();
    return trimmed === '' || trimmed === 'untitled' || trimmed.startsWith('untitled');
  };

  const executeSave = (customName?: string) => {
    if (!activeOrchestration) return false;
    const finalName = (customName || activeOrchestration.name).trim();

    setOrchestrations(prev => {
      const updated = prev.map(o => {
        if (o.id === activeOrchestration.id) {
          return { ...o, name: finalName };
        }
        return o;
      });
      localStorage.setItem('agent_orchestrations', JSON.stringify(updated));
      return updated;
    });

    setIsDirty(false);
    setSaveToast(`Pipeline "${finalName}" saved to workspace.`);
    setTimeout(() => setSaveToast(null), 3000);
    return true;
  };

  // Explicit Save Pipeline Handler with forced name check
  const handleSavePipeline = (onSuccess?: () => void) => {
    if (!activeOrchestration) return;

    if (isNameInvalid(activeOrchestration.name)) {
      const initialVal = activeOrchestration.name && !activeOrchestration.name.toLowerCase().startsWith('untitled') 
        ? activeOrchestration.name 
        : '';
      setPendingPipelineName(initialVal);
      setNameError(null);
      setOnSaveSuccessCallback(() => (typeof onSuccess === 'function' ? onSuccess : null));
      setShowNameRequiredModal(true);
      return;
    }

    executeSave();
    if (typeof onSuccess === 'function') {
      onSuccess();
    }
  };

  const handleConfirmSaveName = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (isNameInvalid(pendingPipelineName)) {
      setNameError('Pipeline name cannot be empty or start with "Untitled". Please enter a valid name.');
      return;
    }

    executeSave(pendingPipelineName);
    setShowNameRequiredModal(false);
    if (onSaveSuccessCallback) {
      const cb = onSaveSuccessCallback;
      setOnSaveSuccessCallback(null);
      cb();
    }
  };

  // Create fresh blank pipeline instance
  const createFreshBlankPipeline = () => {
    const newId = `pipeline_${Date.now().toString().slice(-6)}`;
    const newWf: AgentOrchestration = {
      id: newId,
      name: 'Untitled Component Pipeline',
      description: 'Custom stage component pipeline created in Agent Studio.',
      type: 'custom',
      strategy: 'sequential',
      agentIds: [],
      connections: []
    };

    setOrchestrations(prev => {
      const updated = [...prev, newWf];
      localStorage.setItem('agent_orchestrations', JSON.stringify(updated));
      return updated;
    });
    setSelectedOrchestrationId(newId);
    setEditingAgentId(null);
    setIsDirty(false);
    setSaveToast('Created fresh blank pipeline canvas.');
    setTimeout(() => setSaveToast(null), 3000);
  };

  // Check if pipeline is tagged to any journey in localStorage or default journeys
  const checkPipelineJourneyTag = (pipelineId: string) => {
    let savedJourneys: any[] = [];
    try {
      const raw = localStorage.getItem('onboarding_journeys');
      if (raw) savedJourneys = JSON.parse(raw);
    } catch (e) {
      savedJourneys = [];
    }

    if (!savedJourneys || savedJourneys.length === 0) {
      savedJourneys = DEFAULT_JOURNEYS;
    }

    for (const j of savedJourneys) {
      if (j.linkedPipelineId === pipelineId) {
        return { isTagged: true, journeyName: j.name, reason: 'linked as primary journey pipeline' };
      }
      const stages = j.stages || j.phases || [];
      for (const s of stages) {
        if (s.linkedPipelineId === pipelineId) {
          return { isTagged: true, journeyName: `${j.name} (${s.name || 'Stage Component'})`, reason: 'wired to journey stage component' };
        }
      }
    }

    return { isTagged: false };
  };

  const handleDeletePipelineClick = (pipelineId?: string) => {
    if (!pipelineId) return;
    const targetOrch = orchestrations.find(o => o.id === pipelineId);
    if (!targetOrch) return;

    const tagCheck = checkPipelineJourneyTag(pipelineId);

    if (tagCheck.isTagged) {
      setDeleteErrorMsg(`Cannot delete pipeline "${targetOrch.name}" because it is currently tagged to Journey: "${tagCheck.journeyName}" (${tagCheck.reason}). Please untag or reassign this pipeline from the Journey design before deleting.`);
      setDeleteConfirmId(null);
    } else {
      setDeleteErrorMsg(null);
      setDeleteConfirmId(pipelineId);
    }
  };

  const handleConfirmDeletePipeline = () => {
    if (!deleteConfirmId) return;
    const targetOrch = orchestrations.find(o => o.id === deleteConfirmId);
    const targetName = targetOrch ? targetOrch.name : 'Pipeline';

    const updatedOrchs = orchestrations.filter(o => o.id !== deleteConfirmId);
    setOrchestrations(updatedOrchs);
    localStorage.setItem('agent_orchestrations', JSON.stringify(updatedOrchs));

    if (selectedOrchestrationId === deleteConfirmId) {
      if (updatedOrchs.length > 0) {
        setSelectedOrchestrationId(updatedOrchs[0].id);
      } else {
        createFreshBlankPipeline();
      }
    }

    setDeleteConfirmId(null);
    setDeleteErrorMsg(null);
    setSaveToast(`Pipeline "${targetName}" deleted successfully.`);
    setTimeout(() => setSaveToast(null), 3000);
  };

  // Handle New Pipeline click: prompt to save if canvas has active nodes or edits
  const handleNewPipelineClick = () => {
    if ((canvasNodes && canvasNodes.length > 0) || isDirty) {
      setShowSavePromptModal(true);
    } else {
      createFreshBlankPipeline();
    }
  };

  const handleOpenEditWorkflow = () => {
    if (!activeOrchestration) return;
    setEditingWorkflowId(activeOrchestration.id);
    setNewWorkflowName(activeOrchestration.name);
    setNewWorkflowDesc(activeOrchestration.description);
    setNewWorkflowType(activeOrchestration.type || 'custom');
    setSelectedAgentIds([...activeOrchestration.agentIds]);
    setModalNameError(null);
    setIsCreatingWorkflow(true);
  };

  const handleSaveWorkflowModal = (e: React.FormEvent) => {
    e.preventDefault();
    if (isNameInvalid(newWorkflowName)) {
      setModalNameError('Pipeline name cannot be empty or start with "Untitled".');
      return;
    }
    setModalNameError(null);

    if (editingWorkflowId) {
      setOrchestrations(prev => prev.map(o => {
        if (o.id === editingWorkflowId) {
          return {
            ...o,
            name: newWorkflowName.trim(),
            description: newWorkflowDesc.trim(),
            type: newWorkflowType,
            agentIds: selectedAgentIds,
            connections: o.connections.filter(c => selectedAgentIds.includes(c.from) && selectedAgentIds.includes(c.to))
          };
        }
        return o;
      }));
    } else {
      const newId = `wf_${Date.now().toString().slice(-6)}`;
      const autoConns: { from: string; to: string }[] = [];
      for (let i = 0; i < selectedAgentIds.length - 1; i++) {
        autoConns.push({ from: selectedAgentIds[i], to: selectedAgentIds[i + 1] });
      }

      const newWf: AgentOrchestration = {
        id: newId,
        name: newWorkflowName.trim(),
        description: newWorkflowDesc.trim() || 'Custom agent execution flow.',
        type: newWorkflowType,
        strategy: 'sequential',
        agentIds: selectedAgentIds,
        connections: autoConns
      };

      setOrchestrations(prev => [...prev, newWf]);
      setSelectedOrchestrationId(newId);
    }

    setIsCreatingWorkflow(false);
    setIsDirty(false);
    setSaveToast(`Pipeline "${newWorkflowName.trim()}" saved.`);
    setTimeout(() => setSaveToast(null), 3000);
  };

  const filteredPaletteTemplates = useMemo(() => {
    if (paletteCategory === 'all') return PALETTE_STEP_TEMPLATES;
    return PALETTE_STEP_TEMPLATES.filter(t => t.nodeType === paletteCategory);
  }, [paletteCategory]);

  const handleOpenOnboardNewWorkflow = () => {
    setEditingWorkflowId(null);
    setNewWorkflowName('');
    setNewWorkflowDesc('');
    setNewWorkflowType('custom');
    setSelectedAgentIds([]);
    setModalNameError(null);
    setIsCreatingWorkflow(true);
  };

  const handleModifyWorkflow = (orchId: string) => {
    setSelectedOrchestrationId(orchId);
    setViewMode('designer');
    setIsDirty(false);
  };

  const handleOpenWorkflowSettings = (orch: AgentOrchestration) => {
    setEditingWorkflowId(orch.id);
    setNewWorkflowName(orch.name);
    setNewWorkflowDesc(orch.description);
    setNewWorkflowType(orch.type || 'custom');
    setSelectedAgentIds([...orch.agentIds]);
    setModalNameError(null);
    setIsCreatingWorkflow(true);
  };

  return (
    <div className="space-y-6">
      {/* Top Level Navigation Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white border border-slate-200 rounded-xl p-4 md:p-5 shadow-sm text-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-blue-50 border border-blue-200 rounded-xl text-blue-700">
            <Workflow className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-extrabold text-base text-slate-950">
                Agentic Process Flows
              </h2>
              <span className="text-[10px] font-mono font-bold bg-blue-50 text-blue-700 px-2.5 py-0.5 border border-blue-200 rounded-full uppercase">
                {viewMode === 'list' ? 'Flows Catalog' : 'Autonomous Flow Designer'}
              </span>
            </div>
            <p className="text-xs text-slate-500">
              {viewMode === 'list' 
                ? 'Comprehensive catalog of all institutional onboarding process flows. Onboard new flows or modify existing pipelines.'
                : `Designing and wiring active process flow: "${activeOrchestration?.name || 'Pipeline'}"`}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap w-full sm:w-auto justify-start sm:justify-end">
          {/* Onboard New Flow Quick Action Button */}
          <button
            onClick={handleOpenOnboardNewWorkflow}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-xs transition flex items-center gap-1.5 cursor-pointer shadow-sm ml-auto sm:ml-0"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Onboard New Flow</span>
          </button>
        </div>
      </div>

      {/* Save Toast Notification Banner */}
      <AnimatePresence>
        {saveToast && (
          <motion.div
            key="save-toast-banner"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-emerald-700 text-white rounded-lg p-3 flex items-center justify-between font-mono text-xs shadow-md border border-emerald-600"
          >
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-200" />
              <span className="font-semibold">{saveToast}</span>
            </div>
            <button
              onClick={() => setSaveToast(null)}
              className="text-emerald-200 hover:text-white p-0.5 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ========================================================================= */}
      {/* 1. PROCESS FLOWS CATALOG (LIST FIRST VIEW)                                */}
      {/* ========================================================================= */}
      {viewMode === 'list' && (
        <div className="space-y-6">
          {/* Process Flows Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {orchestrations.map(orch => {
              const isSelected = orch.id === selectedOrchestrationId;
              const typeIcon = orch.type === 'corporate' ? '🏢' : orch.type === 'funds' ? '🏦' : '⚙️';
              const typeBadge = orch.type === 'corporate' 
                ? 'bg-blue-50 text-blue-700 border-blue-200' 
                : orch.type === 'funds' 
                ? 'bg-purple-50 text-purple-700 border-purple-200' 
                : 'bg-slate-100 text-slate-700 border-slate-200';

              return (
                <div
                  key={orch.id}
                  className={`bg-white rounded-xl border transition duration-200 shadow-sm flex flex-col justify-between hover:shadow-md ${
                    isSelected ? 'border-blue-500 ring-2 ring-blue-500/20' : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="p-5">
                    {/* Header: Type and Actions */}
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <div className="flex items-center gap-2">
                        <span className="text-xl">{typeIcon}</span>
                        <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border uppercase ${typeBadge}`}>
                          {orch.type || 'Custom Flow'}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleDeletePipelineClick(orch.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition cursor-pointer"
                          title="Delete process flow"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Flow Name & ID */}
                    <h3 className="font-extrabold text-sm text-slate-900 mb-1 line-clamp-1">
                      {orch.name}
                    </h3>
                    <p className="text-[10px] font-mono text-slate-400 mb-3">
                      ID: {orch.id}
                    </p>

                    {/* Description */}
                    <p className="text-xs text-slate-600 leading-relaxed line-clamp-2">
                      {orch.description}
                    </p>
                  </div>

                  {/* Card Bottom Action Bar */}
                  <div className="px-5 py-3.5 bg-slate-50/70 border-t border-slate-100 rounded-b-xl flex items-center">
                    <button
                      onClick={() => handleModifyWorkflow(orch.id)}
                      className="w-full justify-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-lg shadow-xs transition cursor-pointer flex items-center gap-1.5"
                    >
                      <Network className="w-3.5 h-3.5" />
                      <span>Canvas</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Empty State */}
          {orchestrations.length === 0 && (
            <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
              <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center mx-auto mb-3 border border-blue-100">
                <Workflow className="w-6 h-6" />
              </div>
              <h3 className="font-extrabold text-sm text-slate-900 mb-1">No Process Flows Configured</h3>
              <p className="text-xs text-slate-500 mb-4">
                Click below to onboard and configure your first autonomous process flow.
              </p>
              <div className="flex justify-center gap-2">
                <button
                  onClick={handleOpenOnboardNewWorkflow}
                  className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-lg cursor-pointer flex items-center gap-1.5"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>Onboard New Flow</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. VISUAL FLOW DESIGNER CANVAS (WHEN IN DESIGNER MODE)                     */}
      {/* ========================================================================= */}
      {viewMode === 'designer' && (
        <div className="space-y-6">
          {/* Back to Catalog Breadcrumb / Canvas Controller Banner */}
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 bg-white border border-slate-200 rounded-xl p-4 md:p-5 shadow-sm text-slate-800">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setViewMode('list')}
                className="p-2 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-lg text-slate-700 transition cursor-pointer"
                title="Back to All Process Flows Catalog"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="font-extrabold text-sm md:text-base text-slate-950">
                    Modifying: {activeOrchestration?.name || 'Pipeline Canvas'}
                  </h2>
                  <span className="text-[10px] font-mono font-bold bg-emerald-50 text-emerald-700 px-2 py-0.5 border border-emerald-200 rounded-full uppercase">
                    Interactive Mode
                  </span>
                </div>
                <p className="text-xs text-slate-500">
                  Drag nodes, configure parameters on the right inspector, wire execution connections, and dry-run execution.
                </p>
              </div>
            </div>

            {/* Templates Selector & Action Controls */}
            <div className="flex items-center gap-2 font-mono flex-wrap">
              <select
                value={selectedOrchestrationId}
                onChange={(e) => {
                  setSelectedOrchestrationId(e.target.value);
                  setIsDirty(false);
                }}
                className="bg-white border border-slate-200 rounded-md px-3 py-1.5 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 cursor-pointer max-w-[180px] sm:max-w-none shadow-2xs"
              >
                {orchestrations.map(o => (
                  <option key={o.id} value={o.id}>
                    {o.type === 'corporate' ? '🏢 ' : o.type === 'funds' ? '🏦 ' : '⚙️ '} {o.name}
                  </option>
                ))}
              </select>

              {/* Editable Active Pipeline Name Input */}
              <input
                type="text"
                value={activeOrchestration?.name || ''}
                onChange={(e) => {
                  const val = e.target.value;
                  setOrchestrations(prev => prev.map(o => {
                    if (o.id === activeOrchestration?.id) {
                      return { ...o, name: val };
                    }
                    return o;
                  }));
                  setIsDirty(true);
                }}
                placeholder="Pipeline Title..."
                className="bg-slate-50 border border-slate-200 focus:bg-white rounded px-2.5 py-1.5 text-xs font-bold text-slate-900 outline-none focus:ring-1 focus:ring-blue-500 w-[190px]"
                title="Click to edit current pipeline name inline"
              />

              {/* Explicit Save Pipeline Button */}
              <button
                onClick={() => handleSavePipeline()}
                className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-md text-xs transition flex items-center gap-1.5 cursor-pointer shadow-xs relative"
                title="Save current pipeline topology to workspace"
              >
                <Save className="w-3.5 h-3.5 text-emerald-200" />
                <span>Save Pipeline</span>
                {isDirty && (
                  <span className="w-2 h-2 rounded-full bg-amber-300 animate-ping absolute -top-1 -right-1" />
                )}
              </button>

              {/* New Pipeline Button */}
              <button
                onClick={handleNewPipelineClick}
                className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-900 font-bold rounded-md text-xs transition flex items-center gap-1.5 cursor-pointer text-white shadow-xs"
                title="Start a fresh blank component pipeline canvas"
              >
                <PlusCircle className="w-3.5 h-3.5" /> New Pipeline
              </button>

              {/* Edit Flow Settings Modal Button */}
              <button
                onClick={handleOpenEditWorkflow}
                className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 font-bold rounded-md text-xs transition flex items-center gap-1 cursor-pointer"
                title="Configure pipeline metadata and node assignments"
              >
                <Sliders className="w-3.5 h-3.5" />
              </button>

              {/* Delete Pipeline Button */}
              <button
                onClick={() => handleDeletePipelineClick(activeOrchestration?.id)}
                className="px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 font-bold rounded-md text-xs transition flex items-center gap-1 cursor-pointer"
                title="Delete current component pipeline"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

      {/* Save Toast Notification Banner */}
      <AnimatePresence>
        {saveToast && (
          <motion.div
            key="save-toast-banner"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-emerald-700 text-white rounded-lg p-3 flex items-center justify-between font-mono text-xs shadow-md border border-emerald-600"
          >
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-200" />
              <span className="font-semibold">{saveToast}</span>
            </div>
            <button
              onClick={() => setSaveToast(null)}
              className="text-emerald-200 hover:text-white p-0.5 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Active Connecting Banner Indicator */}
      <AnimatePresence>
        {connectingFromId && (
          <motion.div
            key="connecting-banner"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-blue-600 text-white rounded-lg p-3 flex items-center justify-between font-mono text-xs shadow-md"
          >
            <div className="flex items-center gap-2">
              <Link2 className="w-4 h-4 animate-spin" />
              <span>
                Connecting from <strong>{agents.find(a => a.id === connectingFromId)?.name}</strong>... Click the <strong>Input Port (Left Circle)</strong> on another step to link them!
              </span>
            </div>
            <button
              onClick={() => setConnectingFromId(null)}
              className="px-2 py-0.5 bg-blue-800 hover:bg-blue-900 text-white rounded text-[10px] font-bold cursor-pointer"
            >
              Cancel Link
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Orchestration Splits */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Interactive Flow Canvas Panel (8 cols) */}
        <div className="lg:col-span-8 flex flex-col gap-4">
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm relative overflow-hidden">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 mb-4 z-10 relative bg-white/90 backdrop-blur-sm">
              <div>
                <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                  Visual Execution Pipeline
                  <span className="text-[10px] font-mono text-slate-400 font-normal">({canvasNodes.length} Nodes Connected)</span>
                </h3>
                <p className="text-[10px] font-mono text-slate-400">INTERACTIVE CANVAS • DRAG NODES • WIRE PORTS</p>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                {/* Dropdown list of agents/steps to add */}
                <div className="relative">
                  <select
                    defaultValue=""
                    onChange={(e) => {
                      const value = e.target.value;
                      if (!value) return;
                      const tpl = PALETTE_STEP_TEMPLATES.find(t => t.id === value);
                      if (tpl) {
                        handleAddTemplateClick(tpl);
                      } else {
                        // Check if existing agent
                        const existing = agents.find(a => a.id === value);
                        if (existing && activeOrchestration && !activeOrchestration.agentIds.includes(existing.id)) {
                          setOrchestrations(prev => prev.map(o => {
                            if (o.id === activeOrchestration.id) {
                              return { ...o, agentIds: [...o.agentIds, existing.id] };
                            }
                            return o;
                          }));
                          setEditingAgentId(existing.id);
                        }
                      }
                      e.target.value = "";
                    }}
                    className="bg-blue-600 hover:bg-blue-700 text-white font-mono font-bold text-xs px-3 py-1.5 rounded-md shadow-sm transition cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none pr-8"
                  >
                    <option value="" disabled>+ Add Agent / Step...</option>
                    <optgroup label="🤖 Autonomous Agents">
                      {PALETTE_STEP_TEMPLATES.filter(t => t.nodeType === 'agent').map(t => (
                        <option key={t.id} value={t.id} className="bg-white text-slate-800 font-sans">
                          {t.name}
                        </option>
                      ))}
                    </optgroup>
                    <optgroup label="🔌 MCP Tools">
                      {PALETTE_STEP_TEMPLATES.filter(t => t.nodeType === 'mcp').map(t => (
                        <option key={t.id} value={t.id} className="bg-white text-slate-800 font-sans">
                          {t.name}
                        </option>
                      ))}
                    </optgroup>
                    <optgroup label="🌐 REST Webhooks & APIs">
                      {PALETTE_STEP_TEMPLATES.filter(t => t.nodeType === 'api').map(t => (
                        <option key={t.id} value={t.id} className="bg-white text-slate-800 font-sans">
                          {t.name}
                        </option>
                      ))}
                    </optgroup>
                    <optgroup label="📧 Outreach Dispatches">
                      {PALETTE_STEP_TEMPLATES.filter(t => t.nodeType === 'email').map(t => (
                        <option key={t.id} value={t.id} className="bg-white text-slate-800 font-sans">
                          {t.name}
                        </option>
                      ))}
                    </optgroup>
                    <optgroup label="💾 Databases & Vaults">
                      {PALETTE_STEP_TEMPLATES.filter(t => t.nodeType === 'database').map(t => (
                        <option key={t.id} value={t.id} className="bg-white text-slate-800 font-sans">
                          {t.name}
                        </option>
                      ))}
                    </optgroup>
                  </select>
                  <Plus className="w-3.5 h-3.5 text-white absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>

                {/* Zoom Controls */}
                <div className="flex items-center bg-slate-100 border border-slate-200 rounded-md p-0.5">
                  <button
                    onClick={() => setZoomLevel(prev => Math.max(0.75, prev - 0.1))}
                    className="p-1 hover:bg-slate-200 rounded text-slate-600 cursor-pointer"
                    title="Zoom Out"
                  >
                    <ZoomOut className="w-3.5 h-3.5" />
                  </button>
                  <span className="text-[10px] font-mono font-bold px-1.5 text-slate-600">
                    {Math.round(zoomLevel * 100)}%
                  </span>
                  <button
                    onClick={() => setZoomLevel(prev => Math.min(1.5, prev + 0.1))}
                    className="p-1 hover:bg-slate-200 rounded text-slate-600 cursor-pointer"
                    title="Zoom In"
                  >
                    <ZoomIn className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setZoomLevel(1)}
                    className="p-1 hover:bg-slate-200 rounded text-slate-600 cursor-pointer text-[9px] font-bold"
                    title="Reset Zoom"
                  >
                    100%
                  </button>
                </div>

                <button
                  onClick={() => setShowClearCanvasConfirm(true)}
                  className="px-2.5 py-1.5 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 font-mono font-bold text-xs rounded-md shadow-sm transition flex items-center gap-1 cursor-pointer"
                  title="Clear all steps from active canvas"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Clear
                </button>

                <button
                  onClick={triggerDryRun}
                  disabled={isSimulating}
                  className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-300 text-white font-mono font-bold text-xs rounded-md shadow-sm transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Play className="w-3 h-3 text-emerald-400" /> 
                  {isSimulating ? 'Dry Run Running...' : 'Execute Dry Run'}
                </button>
              </div>
            </div>

            {/* Scrollable Canvas Viewport Container */}
            <div className="w-full overflow-auto max-h-[640px] min-h-[480px] rounded-xl border border-slate-200 bg-slate-100/80 p-1 relative shadow-inner custom-scrollbar">
              {/* Canvas grid background resembling professional wire diagram builders */}
              <div
                ref={canvasRef}
                onDragOver={handleCanvasDragOver}
                onDrop={handleCanvasDrop}
                onMouseMove={handleCanvasMouseMove}
                onMouseUp={handleCanvasMouseUp}
                className="relative min-w-[2000px] min-h-[1200px] w-[2200px] h-[1400px] rounded-lg bg-slate-50 p-6 select-none shadow-xs"
                style={{ transform: `scale(${zoomLevel})`, transformOrigin: 'top left' }}
              >
              
              {/* Dynamic SVG Connective Lines */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
                <defs>
                  <marker id="arrow-blue" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                    <path d="M 0 1 L 10 5 L 0 9 z" fill="#3b82f6" />
                  </marker>
                  <marker id="arrow-purple" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                    <path d="M 0 1 L 10 5 L 0 9 z" fill="#a855f7" />
                  </marker>
                  <marker id="arrow-amber" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                    <path d="M 0 1 L 10 5 L 0 9 z" fill="#f59e0b" />
                  </marker>
                  <marker id="arrow-emerald" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                    <path d="M 0 1 L 10 5 L 0 9 z" fill="#10b981" />
                  </marker>
                  <marker id="arrow-cyan" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                    <path d="M 0 1 L 10 5 L 0 9 z" fill="#06b6d4" />
                  </marker>
                  <marker id="arrow-slate" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                    <path d="M 0 1 L 10 5 L 0 9 z" fill="#cbd5e1" />
                  </marker>
                </defs>

                {(activeOrchestration?.connections || []).map((conn, idx) => {
                  const fromNode = canvasNodes.find(n => n.id === conn.from);
                  const toNode = canvasNodes.find(n => n.id === conn.to);

                  if (!fromNode || !toNode) return null;

                  // Right edge center of source node (+ symbol)
                  const fromX = (fromNode.position?.x || 0) + 170;
                  const fromY = (fromNode.position?.y || 0) + 65;
                  
                  // Left edge center of target node (In symbol)
                  const toX = (toNode.position?.x || 0);
                  const toY = (toNode.position?.y || 0) + 65;

                  const dx = Math.max(40, Math.abs(toX - fromX) * 0.5);
                  const controlX1 = fromX + (toX >= fromX ? dx : 60);
                  const controlX2 = toX - (toX >= fromX ? dx : 60);

                  const isPathEnabled = fromNode.isEnabled && toNode.isEnabled;
                  const isSimulatingPath = simulatingNodeIds.includes(fromNode.id);
                  const connMeta = getConnectionMeta(fromNode, toNode);

                  const midX = (fromX + toX) / 2;
                  const midY = (fromY + toY) / 2;

                  return (
                    <g key={`${conn.from}_${conn.to}_${idx}`}>
                      <path
                        d={`M ${fromX} ${fromY} C ${controlX1} ${fromY}, ${controlX2} ${toY}, ${toX} ${toY}`}
                        fill="none"
                        stroke={isPathEnabled ? connMeta.color : '#cbd5e1'}
                        strokeWidth={isPathEnabled ? 2.5 : 1.5}
                        strokeDasharray={isPathEnabled ? 'none' : '4,4'}
                        markerEnd={isPathEnabled ? `url(#arrow-${connMeta.markerId})` : 'url(#arrow-slate)'}
                        className="transition-all duration-300"
                      />
                      {isSimulatingPath && (
                        <circle r="5" fill="#10b981">
                          <animateMotion
                            dur="1.2s"
                            repeatCount="indefinite"
                            path={`M ${fromX} ${fromY} C ${controlX1} ${fromY}, ${controlX2} ${toY}, ${toX} ${toY}`}
                          />
                        </circle>
                      )}

                      {/* Connection Wire Midpoint Label & Disconnect button */}
                      <foreignObject
                        x={midX - 45}
                        y={midY - 12}
                        width="90"
                        height="24"
                        className="pointer-events-auto"
                      >
                        <div className="flex items-center justify-center gap-1 group">
                          <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded shadow-xs border ${connMeta.badgeClass}`}>
                            {connMeta.label}
                          </span>
                          <button
                            type="button"
                            onClick={() => removeConnection(conn.from, conn.to)}
                            className="hidden group-hover:flex p-0.5 bg-red-600 text-white rounded hover:bg-red-700 cursor-pointer shadow"
                            title="Disconnect step link"
                          >
                            <X className="w-2.5 h-2.5" />
                          </button>
                        </div>
                      </foreignObject>
                    </g>
                  );
                })}

                {/* Active connecting wire preview when linking from + port */}
                {connectingFromId && mouseCanvasPos && (() => {
                  const sourceNode = canvasNodes.find(n => n.id === connectingFromId);
                  if (!sourceNode) return null;
                  const sX = (sourceNode.position?.x || 0) + 170;
                  const sY = (sourceNode.position?.y || 0) + 65;
                  const eX = mouseCanvasPos.x;
                  const eY = mouseCanvasPos.y;
                  const dx = Math.max(30, Math.abs(eX - sX) * 0.5);
                  const cX1 = sX + (eX >= sX ? dx : 50);
                  const cX2 = eX - (eX >= sX ? dx : 50);
                  return (
                    <g>
                      <path
                        d={`M ${sX} ${sY} C ${cX1} ${sY}, ${cX2} ${eY}, ${eX} ${eY}`}
                        fill="none"
                        stroke="#3b82f6"
                        strokeWidth={2.5}
                        strokeDasharray="6,4"
                        className="animate-pulse"
                        markerEnd="url(#arrow-blue)"
                      />
                      <circle cx={eX} cy={eY} r={4} fill="#3b82f6" />
                    </g>
                  );
                })()}
              </svg>

              {/* Render Canvas Nodes */}
              <div className="relative w-full h-full min-h-[380px] z-10">
                {canvasNodes.length === 0 && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 z-10 pointer-events-none">
                    <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl text-slate-400 mb-3 shadow-xs">
                      <Network className="w-8 h-8 text-blue-500/70 animate-pulse" />
                    </div>
                    <h4 className="font-extrabold text-slate-800 text-sm">Blank Component Pipeline Canvas</h4>
                    <p className="text-xs text-slate-500 max-w-sm mt-1 leading-relaxed">
                      Select <strong>"+ Add Agent / Step..."</strong> at the top right or drag templates from the palette on the right to start building your multi-agent flow.
                    </p>
                  </div>
                )}
                {canvasNodes.map((node, idx) => {
                  const isEditing = editingAgentId === node.id;
                  const isSimActive = simulatingNodeIds.includes(node.id);
                  const isConnectingSource = connectingFromId === node.id;
                  const meta = getNodeTypeMeta(node.nodeType);

                  return (
                    <div
                      key={`${node.id}_${idx}`}
                      onClick={() => setEditingAgentId(node.id)}
                      style={{ 
                        left: `${node.position?.x}px`, 
                        top: `${node.position?.y}px`,
                        position: 'absolute'
                      }}
                      className={`w-[170px] h-[130px] flex flex-col justify-between bg-white border rounded-xl shadow-sm select-none cursor-pointer transition-all duration-200 group relative ${
                        isEditing 
                          ? `${meta.activeBorder} scale-102 shadow-md` 
                          : `border-slate-200 ${meta.cardBorder} hover:scale-101`
                      } ${isSimActive ? 'ring-4 ring-emerald-100 animate-pulse border-emerald-500' : ''} ${
                        isConnectingSource ? 'ring-2 ring-blue-500 ring-offset-2' : ''
                      }`}
                    >
                      {/* Left Port Handle (INPUT "In") */}
                      <button
                        type="button"
                        onClick={(e) => handlePortClick(e, node.id, 'input')}
                        className={`absolute -left-3 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full border-2 flex items-center justify-center text-[9px] font-mono font-extrabold transition-all duration-200 z-20 cursor-pointer shadow-sm ${
                          connectingFromId && connectingFromId !== node.id
                            ? 'border-emerald-500 bg-emerald-50 text-emerald-700 ring-4 ring-emerald-400/30 scale-125 animate-bounce'
                            : 'border-slate-300 bg-white text-slate-500 hover:border-blue-500 hover:text-blue-600 hover:bg-blue-50 hover:scale-110'
                        }`}
                        title="In Port (Click to complete connection from +)"
                      >
                        In
                      </button>

                      {/* Right Port Handle (OUTPUT "+") */}
                      <button
                        type="button"
                        onClick={(e) => handlePortClick(e, node.id, 'output')}
                        className={`absolute -right-3 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full border-2 flex items-center justify-center text-[11px] font-mono font-extrabold transition-all duration-200 z-20 cursor-pointer shadow-sm ${
                          isConnectingSource
                            ? 'border-blue-600 bg-blue-600 text-white ring-4 ring-blue-400/30 scale-125'
                            : 'border-slate-300 bg-white text-slate-600 hover:border-emerald-500 hover:text-emerald-600 hover:bg-emerald-50 hover:scale-110'
                        }`}
                        title="+ Port (Click to start connecting link to In)"
                      >
                        +
                      </button>

                      {/* Header with drag handle */}
                      <div
                        onMouseDown={(e) => handleNodeMouseDown(e, node.id)}
                        className={`p-2.5 rounded-t-xl border-b flex items-center justify-between cursor-grab active:cursor-grabbing ${meta.headerBg}`}
                      >
                        <div className="flex items-center gap-1.5 min-w-0">
                          <GripVertical className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          {meta.icon}
                          <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded border uppercase truncate ${meta.badgeBg}`}>
                            {meta.label}
                          </span>
                        </div>

                        <button
                          type="button"
                          title="Remove step from active pipeline"
                          onClick={(e) => {
                            e.stopPropagation();
                            removeAgentFromPipeline(node.id);
                          }}
                          className="text-slate-400 hover:text-red-600 hover:bg-red-50 p-0.5 rounded transition cursor-pointer"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Card Body */}
                      <div className="p-3">
                        <h4 className="text-xs font-bold text-slate-800 group-hover:text-blue-600 transition-colors truncate">
                          {node.name}
                        </h4>
                        <p className="text-[9px] text-slate-400 line-clamp-2 mt-1 leading-tight h-6">
                          {node.description}
                        </p>

                        {/* Connection count & state indicator */}
                        <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[8px] font-mono text-slate-400">
                          <span>{node.isEnabled ? 'ACTIVE' : 'STANDBY'}</span>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleAgentEnable(node.id);
                            }}
                            className="text-slate-400 hover:text-blue-600 cursor-pointer"
                          >
                            {node.isEnabled ? (
                              <ToggleRight className="w-4 h-4 text-blue-500" />
                            ) : (
                              <ToggleLeft className="w-4 h-4 text-slate-300" />
                            )}
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

          {/* Bottom Terminal Dry-Run Output */}
          <div className="bg-[#0F172A] border border-slate-800 rounded-xl p-4 font-mono text-xs shadow-inner">
            <h4 className="text-[10px] font-bold text-slate-400 tracking-widest uppercase pb-2 border-b border-slate-800 flex justify-between">
              <span className="flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5 text-emerald-400" /> Dry-Run Execution Terminal
              </span>
              <span className={isSimulating ? 'text-emerald-400 animate-pulse' : 'text-slate-500'}>
                {isSimulating ? '● EXECUTING FLOW...' : '● READY'}
              </span>
            </h4>
            <div className="mt-3 text-[10px] text-emerald-400/90 leading-relaxed max-h-[140px] overflow-y-auto space-y-1 scrollbar-thin">
              {simulationLogs.length === 0 ? (
                <div className="text-slate-500 italic">Click "Execute Dry Run" at the top to simulate packet flow through connected step nodes.</div>
              ) : (
                simulationLogs.map((log, idx) => <div key={idx}>{log}</div>)
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Detailed Node Inspector Panel (4 cols) */}
        <div className="lg:col-span-4 sticky top-24">
          <AnimatePresence mode="wait">
            {editingAgent ? (
              <motion.div
                key={editingAgent.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden"
              >
                {/* Header banner color-coded by node type */}
                {(() => {
                  const meta = getNodeTypeMeta(editingAgent.nodeType);
                  return (
                    <div className="p-4 bg-[#1E293B] text-white flex items-center justify-between">
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="p-1.5 bg-blue-500/10 border border-blue-500/20 rounded-md">
                          {meta.icon}
                        </div>
                        <div className="min-w-0">
                          <h3 className="font-bold text-[10px] uppercase tracking-wider font-mono text-blue-400">
                            {meta.label} Inspector
                          </h3>
                          <h4 className="font-extrabold text-xs text-white truncate">{editingAgent.name}</h4>
                        </div>
                      </div>
                      <button 
                        onClick={() => setEditingAgentId(null)}
                        className="p-1 hover:bg-slate-800 rounded-md text-slate-400 hover:text-white cursor-pointer"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  );
                })()}

                {/* Inspector Tab Buttons */}
                <div className="flex border-b border-slate-100 font-mono text-[10px]">
                  <button
                    onClick={() => setInspectorTab('general')}
                    className={`flex-1 py-2 font-bold text-center border-b-2 transition cursor-pointer ${
                      inspectorTab === 'general'
                        ? 'border-blue-600 text-blue-600 bg-blue-50/50'
                        : 'border-transparent text-slate-400 hover:text-slate-700'
                    }`}
                  >
                    General
                  </button>
                  <button
                    onClick={() => setInspectorTab('params')}
                    className={`flex-1 py-2 font-bold text-center border-b-2 transition cursor-pointer ${
                      inspectorTab === 'params'
                        ? 'border-blue-600 text-blue-600 bg-blue-50/50'
                        : 'border-transparent text-slate-400 hover:text-slate-700'
                    }`}
                  >
                    Params
                  </button>
                  <button
                    onClick={() => setInspectorTab('connections')}
                    className={`flex-1 py-2 font-bold text-center border-b-2 transition cursor-pointer ${
                      inspectorTab === 'connections'
                        ? 'border-blue-600 text-blue-600 bg-blue-50/50'
                        : 'border-transparent text-slate-400 hover:text-slate-700'
                    }`}
                  >
                    Links
                  </button>
                </div>

                <div className="p-4 space-y-4">
                  {/* TAB 1: GENERAL CONFIG */}
                  {inspectorTab === 'general' && (
                    <div className="space-y-3">
                      <div>
                        <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">Step Name</label>
                        <input
                          type="text"
                          value={editingAgent.name}
                          onChange={(e) => {
                            const val = e.target.value;
                            setAgents(prev => prev.map(a => a.id === editingAgent.id ? { ...a, name: val } : a));
                          }}
                          className="w-full text-xs font-semibold border border-slate-200 rounded-md p-2 outline-none focus:ring-1 focus:ring-blue-500"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">Step Category</label>
                        <input
                          type="text"
                          value={editingAgent.category}
                          onChange={(e) => {
                            const val = e.target.value;
                            setAgents(prev => prev.map(a => a.id === editingAgent.id ? { ...a, category: val } : a));
                          }}
                          className="w-full text-xs font-mono border border-slate-200 rounded-md p-2 outline-none focus:ring-1 focus:ring-blue-500"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">Mission Description</label>
                        <textarea
                          value={editingAgent.description}
                          onChange={(e) => {
                            const val = e.target.value;
                            setAgents(prev => prev.map(a => a.id === editingAgent.id ? { ...a, description: val } : a));
                          }}
                          rows={3}
                          className="w-full text-xs border border-slate-200 rounded-md p-2 outline-none focus:ring-1 focus:ring-blue-500 resize-none"
                        />
                      </div>

                      <div className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-100 rounded-lg">
                        <div>
                          <span className="text-xs font-bold text-slate-800 block">Node Execution State</span>
                          <span className="text-[10px] text-slate-400">Include step in active workflow DAG</span>
                        </div>
                        <button
                          onClick={() => toggleAgentEnable(editingAgent.id)}
                          className="cursor-pointer"
                        >
                          {editingAgent.isEnabled ? (
                            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full uppercase">Enabled</span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full uppercase">Disabled</span>
                          )}
                        </button>
                      </div>
                    </div>
                  )}

                  {/* TAB 2: ENDPOINT & PARAMETERS */}
                  {inspectorTab === 'params' && (
                    <div className="space-y-3">
                      {editingAgent.nodeType === 'mcp' && (
                        <>
                          <div>
                            <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">MCP SERVER URL</label>
                            <input
                              type="text"
                              value={editingAgent.mcpServerUrl || 'mcp://localhost:3011/server'}
                              onChange={(e) => {
                                const val = e.target.value;
                                setAgents(prev => prev.map(a => a.id === editingAgent.id ? { ...a, mcpServerUrl: val } : a));
                              }}
                              className="w-full text-xs font-mono border border-slate-200 rounded-md p-2 outline-none focus:ring-1 focus:ring-purple-500 bg-purple-50/20"
                            />
                          </div>

                          <div>
                            <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">EXPOSED MCP FUNCTIONS</label>
                            <div className="space-y-1">
                              {(editingAgent.mcpApis || ['queryData', 'validateRule']).map((fn, idx) => (
                                <div key={idx} className="flex items-center justify-between p-1.5 bg-slate-50 border border-slate-100 rounded text-xs font-mono text-slate-700">
                                  <span>{fn}</span>
                                  <span className="text-[9px] text-purple-600 font-bold bg-purple-50 px-1 rounded">MCP</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </>
                      )}

                      {editingAgent.nodeType === 'api' && (
                        <>
                          <div className="grid grid-cols-3 gap-2">
                            <div>
                              <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">HTTP METHOD</label>
                              <select
                                value={editingAgent.httpMethod || 'POST'}
                                onChange={(e) => {
                                  const val = e.target.value as any;
                                  setAgents(prev => prev.map(a => a.id === editingAgent.id ? { ...a, httpMethod: val } : a));
                                }}
                                className="w-full text-xs font-mono font-bold border border-slate-200 rounded-md p-2 outline-none focus:ring-1 focus:ring-amber-500"
                              >
                                <option value="POST">POST</option>
                                <option value="GET">GET</option>
                                <option value="PUT">PUT</option>
                                <option value="DELETE">DELETE</option>
                              </select>
                            </div>

                            <div className="col-span-2">
                              <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">ENDPOINT URL</label>
                              <input
                                type="text"
                                value={editingAgent.apiEndpoint || 'https://api.corebank.internal/v1/accounts/provision'}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  setAgents(prev => prev.map(a => a.id === editingAgent.id ? { ...a, apiEndpoint: val } : a));
                                }}
                                className="w-full text-xs font-mono border border-slate-200 rounded-md p-2 outline-none focus:ring-1 focus:ring-amber-500 bg-amber-50/20"
                              />
                            </div>
                          </div>
                        </>
                      )}

                      {editingAgent.nodeType === 'email' && (
                        <>
                          <div>
                            <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">RECIPIENT / ROLE</label>
                            <input
                              type="text"
                              value={editingAgent.emailRecipient || 'Authorized Representative'}
                              onChange={(e) => {
                                const val = e.target.value;
                                setAgents(prev => prev.map(a => a.id === editingAgent.id ? { ...a, emailRecipient: val } : a));
                              }}
                              className="w-full text-xs border border-slate-200 rounded-md p-2 outline-none focus:ring-1 focus:ring-emerald-500"
                            />
                          </div>

                          <div>
                            <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">EMAIL SUBJECT TEMPLATE</label>
                            <input
                              type="text"
                              value={editingAgent.emailSubject || 'Welcome to Corporate Banking'}
                              onChange={(e) => {
                                const val = e.target.value;
                                setAgents(prev => prev.map(a => a.id === editingAgent.id ? { ...a, emailSubject: val } : a));
                              }}
                              className="w-full text-xs border border-slate-200 rounded-md p-2 outline-none focus:ring-1 focus:ring-emerald-500"
                            />
                          </div>
                        </>
                      )}

                      {editingAgent.nodeType === 'database' && (
                        <>
                          <div>
                            <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">VAULT DB TABLE NAME</label>
                            <input
                              type="text"
                              value={editingAgent.dbTable || 'customer_360_profiles'}
                              onChange={(e) => {
                                const val = e.target.value;
                                setAgents(prev => prev.map(a => a.id === editingAgent.id ? { ...a, dbTable: val } : a));
                              }}
                              className="w-full text-xs font-mono border border-slate-200 rounded-md p-2 outline-none focus:ring-1 focus:ring-cyan-500 bg-cyan-50/20"
                            />
                          </div>
                        </>
                      )}

                      {(!editingAgent.nodeType || editingAgent.nodeType === 'agent') && (
                        <>
                          <div>
                            <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">MODEL BACKBONE</label>
                            <input
                              type="text"
                              value={editingAgent.model || 'Claude 3.5 Sonnet'}
                              onChange={(e) => {
                                const val = e.target.value;
                                setAgents(prev => prev.map(a => a.id === editingAgent.id ? { ...a, model: val } : a));
                              }}
                              className="w-full text-xs font-mono border border-slate-200 rounded-md p-2 outline-none focus:ring-1 focus:ring-blue-500"
                            />
                          </div>

                          {/* Temperature Slider & Max Tokens */}
                          <div className="grid grid-cols-2 gap-2 pt-1">
                            <div>
                              <div className="flex justify-between items-center mb-1">
                                <label className="text-[10px] font-mono text-slate-400 uppercase font-bold">TEMPERATURE</label>
                                <span className="text-[10px] font-mono font-bold text-blue-600">
                                  {editingAgent.temperature !== undefined ? editingAgent.temperature : 0.2}
                                </span>
                              </div>
                              <input
                                type="range"
                                min="0.0"
                                max="1.0"
                                step="0.05"
                                value={editingAgent.temperature !== undefined ? editingAgent.temperature : 0.2}
                                onChange={(e) => {
                                  const val = parseFloat(e.target.value);
                                  setAgents(prev => prev.map(a => a.id === editingAgent.id ? { ...a, temperature: val } : a));
                                }}
                                className="w-full accent-blue-600 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
                              />
                            </div>

                            <div>
                              <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">MAX OUTPUT TOKENS</label>
                              <select
                                value={editingAgent.maxTokens || 4096}
                                onChange={(e) => {
                                  const val = parseInt(e.target.value, 10);
                                  setAgents(prev => prev.map(a => a.id === editingAgent.id ? { ...a, maxTokens: val } : a));
                                }}
                                className="w-full text-xs font-mono border border-slate-200 rounded-md p-1.5 outline-none focus:ring-1 focus:ring-blue-500 bg-white"
                              >
                                <option value={1024}>1,024 Tokens</option>
                                <option value={2048}>2,048 Tokens</option>
                                <option value={4096}>4,096 Tokens</option>
                                <option value={8192}>8,192 Tokens</option>
                              </select>
                            </div>
                          </div>

                          {/* Reasoning Style Toggle */}
                          <div>
                            <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">REASONING STYLE</label>
                            <div className="grid grid-cols-2 gap-1 bg-slate-100 p-1 rounded-md text-xs font-semibold">
                              <button
                                type="button"
                                onClick={() => setAgents(prev => prev.map(a => a.id === editingAgent.id ? { ...a, reasoningStyle: 'analytical' } : a))}
                                className={`py-1 px-2 rounded text-[11px] font-mono transition cursor-pointer ${
                                  (editingAgent.reasoningStyle || 'analytical') === 'analytical'
                                    ? 'bg-white text-blue-700 shadow-sm font-bold border border-slate-200'
                                    : 'text-slate-500 hover:text-slate-800'
                                }`}
                              >
                                Chain-of-Thought
                              </button>
                              <button
                                type="button"
                                onClick={() => setAgents(prev => prev.map(a => a.id === editingAgent.id ? { ...a, reasoningStyle: 'fast' } : a))}
                                className={`py-1 px-2 rounded text-[11px] font-mono transition cursor-pointer ${
                                  editingAgent.reasoningStyle === 'fast'
                                    ? 'bg-white text-emerald-700 shadow-sm font-bold border border-slate-200'
                                    : 'text-slate-500 hover:text-slate-800'
                                }`}
                              >
                                Fast Direct
                              </button>
                            </div>
                          </div>

                          {/* Match Confidence Threshold Slider */}
                          <div className="pt-1">
                            <div className="flex justify-between items-center mb-1">
                              <label className="text-[10px] font-mono text-slate-400 uppercase font-bold">MATCH CONFIDENCE THRESHOLD</label>
                              <span className="text-[10px] font-mono font-bold text-amber-600">
                                {editingAgent.confidenceThreshold || 85}%
                              </span>
                            </div>
                            <input
                              type="range"
                              min="50"
                              max="99"
                              step="1"
                              value={editingAgent.confidenceThreshold || 85}
                              onChange={(e) => {
                                const val = parseInt(e.target.value, 10);
                                setAgents(prev => prev.map(a => a.id === editingAgent.id ? { ...a, confidenceThreshold: val } : a));
                              }}
                              className="w-full accent-amber-600 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
                            />
                          </div>

                          {/* Guardrails Toggles: PII Redaction & Hallucination/Fallback */}
                          <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg space-y-2 text-xs">
                            <span className="text-[10px] font-mono text-slate-500 uppercase font-extrabold block">SAFETY & GUARDRAILS</span>
                            
                            <div className="flex items-center justify-between">
                              <span className="text-slate-700 font-medium text-[11px]">PII Redaction & Masking</span>
                              <input
                                type="checkbox"
                                checked={editingAgent.piiRedaction !== false}
                                onChange={(e) => {
                                  const checked = e.target.checked;
                                  setAgents(prev => prev.map(a => a.id === editingAgent.id ? { ...a, piiRedaction: checked } : a));
                                }}
                                className="w-4 h-4 accent-emerald-600 cursor-pointer"
                              />
                            </div>

                            <div className="flex items-center justify-between">
                              <span className="text-slate-700 font-medium text-[11px]">Hallucination & RM Escalation Fallback</span>
                              <input
                                type="checkbox"
                                checked={editingAgent.hallucinationFallback !== false}
                                onChange={(e) => {
                                  const checked = e.target.checked;
                                  setAgents(prev => prev.map(a => a.id === editingAgent.id ? { ...a, hallucinationFallback: checked } : a));
                                }}
                                className="w-4 h-4 accent-emerald-600 cursor-pointer"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">COMMUNICATION PROTOCOL</label>
                            <div className="flex items-center justify-between p-2 bg-slate-50 border border-slate-200 rounded-md text-xs font-mono">
                              <span>Enterprise A2A Protocol</span>
                              <span className="text-[9px] font-bold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200">
                                ACTIVE
                              </span>
                            </div>
                          </div>
                        </>
                      )}

                      {/* Instant Test Step Payload Button */}
                      <div className="pt-2">
                        <button
                          type="button"
                          onClick={() => handleTestStepPayload(editingAgent)}
                          className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white font-mono font-bold text-xs rounded-md shadow-sm transition flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <Send className="w-3.5 h-3.5 text-amber-400" /> Test Step Payload
                        </button>
                      </div>

                      {testPayloadResult && (
                        <div className="p-2.5 bg-[#0F172A] border border-slate-800 rounded-md text-white font-mono text-[9px] relative">
                          <button
                            onClick={() => setTestPayloadResult(null)}
                            className="absolute top-1 right-1 text-slate-400 hover:text-white p-0.5"
                          >
                            <X className="w-3 h-3" />
                          </button>
                          <pre className="text-emerald-400 overflow-x-auto max-h-[140px]">
                            {testPayloadResult}
                          </pre>
                        </div>
                      )}
                    </div>
                  )}

                  {/* TAB 3: OUTGOING CONNECTIONS */}
                  {inspectorTab === 'connections' && (
                    <div className="space-y-3">
                      <div>
                        <span className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">
                          OUTGOING CONNECTIONS
                        </span>
                        {activeOrchestration?.connections.filter(c => c.from === editingAgent.id).length === 0 ? (
                          <div className="text-xs text-slate-400 italic p-3 bg-slate-50 border border-slate-100 rounded-md">
                            No outgoing step links. Use the dropdown below to connect this step to another step.
                          </div>
                        ) : (
                          <div className="space-y-1.5">
                            {activeOrchestration?.connections.filter(c => c.from === editingAgent.id).map(c => {
                              const targetNode = agents.find(a => a.id === c.to);
                              return (
                                <div key={c.to} className="flex items-center justify-between p-2 bg-slate-50 border border-slate-100 rounded-md text-xs">
                                  <div className="flex items-center gap-1.5 min-w-0">
                                    <ArrowRight className="w-3 h-3 text-blue-600 shrink-0" />
                                    <span className="font-semibold text-slate-800 truncate">{targetNode?.name || c.to}</span>
                                  </div>
                                  <button
                                    onClick={() => removeConnection(editingAgent.id, c.to)}
                                    className="p-1 text-slate-400 hover:text-red-600 rounded transition cursor-pointer"
                                    title="Remove Link"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>

                      {/* Add link dropdown */}
                      <div>
                        <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">
                          + CONNECT TO ANOTHER STEP NODE
                        </label>
                        <select
                          onChange={(e) => {
                            if (e.target.value) {
                              addConnection(editingAgent.id, e.target.value);
                              e.target.value = '';
                            }
                          }}
                          defaultValue=""
                          className="w-full text-xs font-semibold border border-slate-200 rounded-md p-2 outline-none focus:ring-1 focus:ring-blue-500 bg-white cursor-pointer"
                        >
                          <option value="" disabled>Select target step node...</option>
                          {canvasNodes.filter(n => n.id !== editingAgent.id).map(n => (
                            <option key={n.id} value={n.id}>→ {n.name} ({n.nodeType || 'agent'})</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  )}

                  {/* Remove step button */}
                  <div className="pt-3 border-t border-slate-100 mt-2">
                    <button
                      type="button"
                      onClick={() => setNodeToRemove(editingAgent)}
                      className="w-full py-2 px-3 border border-red-200 text-red-600 hover:bg-red-50 font-bold text-xs rounded-lg transition flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Remove {editingAgent.name}
                    </button>
                  </div>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="empty-inspector"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="bg-white rounded-xl border border-slate-200 p-6 text-center text-slate-400 italic"
              >
                Select any step node on the visual canvas to configure parameters, endpoints, or connection links.
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
      </div>
      )}

      {/* Edit / New Workflow Modal Overlay */}
      <AnimatePresence>
        {isCreatingWorkflow && (
          <motion.div
            key="modal-create-workflow"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-xl border border-slate-200 shadow-xl p-6 max-w-lg w-full"
            >
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
                <div className="flex items-center gap-2">
                  <Network className="w-5 h-5 text-blue-600" />
                  <h3 className="font-extrabold text-sm text-slate-900">
                    {editingWorkflowId ? 'Edit Pipeline Structure' : 'Design New Execution Pipeline'}
                  </h3>
                </div>
                <button 
                  onClick={() => setIsCreatingWorkflow(false)}
                  className="p-1 hover:bg-slate-100 rounded-md text-slate-400 hover:text-slate-900 transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSaveWorkflowModal} className="space-y-4">
                <div>
                  <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">Pipeline Name *</label>
                  <input
                    type="text"
                    required
                    value={newWorkflowName}
                    onChange={(e) => {
                      setNewWorkflowName(e.target.value);
                      if (modalNameError) setModalNameError(null);
                    }}
                    placeholder="e.g., Hedge Fund Fast-Track Pipeline"
                    className="w-full border border-slate-200 rounded-md px-3 py-2 text-xs outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  />
                  {modalNameError && (
                    <p className="text-[11px] font-medium text-red-600 mt-1 flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3 text-red-500 shrink-0" /> {modalNameError}
                    </p>
                  )}
                </div>

                <div>
                  <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">Description</label>
                  <textarea
                    value={newWorkflowDesc}
                    onChange={(e) => setNewWorkflowDesc(e.target.value)}
                    placeholder="e.g., Multi-node execution pipeline for corporate client onboarding."
                    rows={2}
                    className="w-full border border-slate-200 rounded-md px-3 py-2 text-xs outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 resize-none"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">Pipeline Category</label>
                  <select
                    value={newWorkflowType}
                    onChange={(e) => setNewWorkflowType(e.target.value as any)}
                    className="w-full border border-slate-200 rounded-md px-3 py-2 text-xs outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 cursor-pointer"
                  >
                    <option value="corporate">🏢 Corporate Onboarding</option>
                    <option value="funds">🏦 Funds & Institutional</option>
                    <option value="custom">⚙️ Custom Multi-Agent Pipeline</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-2">ONBOARDED NODES IN PIPELINE</label>
                  <div className="max-h-[160px] overflow-y-auto space-y-1.5 pr-1 border border-slate-100 rounded-md p-2 bg-slate-50/50">
                    {agents.map(ag => {
                      const isChecked = selectedAgentIds.includes(ag.id);
                      return (
                        <label key={ag.id} className="flex items-center justify-between p-1.5 bg-white border border-slate-100 rounded hover:bg-slate-50 cursor-pointer text-xs">
                          <div className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={() => {
                                if (isChecked) {
                                  setSelectedAgentIds(prev => prev.filter(id => id !== ag.id));
                                } else {
                                  setSelectedAgentIds(prev => [...prev, ag.id]);
                                }
                              }}
                              className="rounded text-blue-600 focus:ring-blue-500"
                            />
                            <span className="font-semibold text-slate-800">{ag.name}</span>
                          </div>
                          <span className="text-[9px] font-mono uppercase text-slate-400">{ag.nodeType || 'agent'}</span>
                        </label>
                      );
                    })}
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                  <div>
                    {editingWorkflowId && (
                      <button
                        type="button"
                        onClick={() => {
                          const targetId = editingWorkflowId;
                          setIsCreatingWorkflow(false);
                          handleDeletePipelineClick(targetId);
                        }}
                        className="px-3 py-2 border border-rose-200 text-rose-600 hover:bg-rose-50 font-semibold text-xs rounded-md transition cursor-pointer flex items-center gap-1.5"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Delete Pipeline</span>
                      </button>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setIsCreatingWorkflow(false)}
                      className="px-4 py-2 border border-slate-200 text-slate-600 font-semibold text-xs rounded-md hover:bg-slate-50 transition cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-md shadow-sm transition cursor-pointer"
                    >
                      Save Pipeline
                    </button>
                  </div>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Confirm Save before New Pipeline Modal */}
      <AnimatePresence>
        {showSavePromptModal && (
          <motion.div
            key="modal-save-prompt"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-xl border border-slate-200 shadow-xl p-6 max-w-md w-full"
            >
              <div className="flex items-center gap-3 pb-3 border-b border-slate-100 mb-4">
                <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-amber-600">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900">Save Existing Pipeline Work?</h3>
                  <p className="text-xs text-slate-500">You have active nodes on the canvas.</p>
                </div>
              </div>

              <p className="text-xs text-slate-700 mb-5 leading-relaxed">
                Do you want to save your current work on <strong>"{activeOrchestration?.name || 'Current Pipeline'}"</strong> before opening a fresh blank pipeline canvas?
              </p>

              <div className="flex flex-col sm:flex-row gap-2 justify-end">
                <button
                  type="button"
                  onClick={() => setShowSavePromptModal(false)}
                  className="px-3.5 py-2 border border-slate-200 text-slate-600 font-semibold text-xs rounded-lg hover:bg-slate-50 transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowSavePromptModal(false);
                    createFreshBlankPipeline();
                  }}
                  className="px-3.5 py-2 border border-red-200 text-red-600 hover:bg-red-50 font-semibold text-xs rounded-lg transition cursor-pointer"
                >
                  Discard & Create Blank
                </button>
                <button
                  type="button"
                  onClick={() => {
                    handleSavePipeline(() => {
                      setShowSavePromptModal(false);
                      createFreshBlankPipeline();
                    });
                  }}
                  className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg shadow-sm transition cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" /> Save & Create Blank
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Name Required Modal when saving an Untitled / blank named pipeline */}
      <AnimatePresence>
        {showNameRequiredModal && (
          <motion.div
            key="modal-name-required"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-xl border border-slate-200 shadow-xl p-6 max-w-md w-full"
            >
              <div className="flex items-center gap-3 pb-3 border-b border-slate-100 mb-4">
                <div className="p-2.5 bg-blue-50 border border-blue-200 rounded-xl text-blue-600">
                  <Sliders className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900">Name Your Pipeline</h3>
                  <p className="text-xs text-slate-500">A custom name is required before saving this pipeline.</p>
                </div>
              </div>

              <form onSubmit={handleConfirmSaveName} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Pipeline Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={pendingPipelineName}
                    onChange={(e) => {
                      setPendingPipelineName(e.target.value);
                      if (nameError) setNameError(null);
                    }}
                    placeholder="e.g. KYB Risk & UBO Screening Pipeline"
                    autoFocus
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  {nameError && (
                    <p className="text-[11px] font-medium text-red-600 mt-1 flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3 text-red-500 shrink-0" /> {nameError}
                    </p>
                  )}
                </div>

                <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => {
                      setShowNameRequiredModal(false);
                      setOnSaveSuccessCallback(null);
                    }}
                    className="px-3.5 py-2 border border-slate-200 text-slate-600 font-semibold text-xs rounded-lg hover:bg-slate-50 transition cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg shadow-sm transition cursor-pointer flex items-center gap-1.5"
                  >
                    <Save className="w-3.5 h-3.5" /> Save Pipeline
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Confirm Delete Pipeline Modal */}
      <AnimatePresence>
        {deleteConfirmId && (
          <motion.div
            key="modal-delete-confirm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-xl border border-slate-200 shadow-xl p-6 max-w-md w-full"
            >
              <div className="flex items-center gap-3 pb-3 border-b border-slate-100 mb-4">
                <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-600">
                  <Trash2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900">Delete Pipeline Configuration</h3>
                  <p className="text-xs text-slate-500">Pipeline is untagged and eligible for removal.</p>
                </div>
              </div>

              <p className="text-xs text-slate-700 mb-5 leading-relaxed">
                Are you sure you want to permanently delete <strong>"{orchestrations.find(o => o.id === deleteConfirmId)?.name || 'this pipeline'}"</strong>? This component pipeline is not tagged to any journey design.
              </p>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setDeleteConfirmId(null)}
                  className="px-3.5 py-2 border border-slate-200 text-slate-600 font-semibold text-xs rounded-lg hover:bg-slate-50 transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmDeletePipeline}
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-lg shadow-sm transition cursor-pointer flex items-center gap-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Confirm Delete</span>
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Blocked Deletion Modal (Tagged to Journey) */}
      <AnimatePresence>
        {deleteErrorMsg && (
          <motion.div
            key="modal-delete-error"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-xl border border-red-200 shadow-xl p-6 max-w-md w-full"
            >
              <div className="flex items-center gap-3 pb-3 border-b border-slate-100 mb-4">
                <div className="p-2.5 bg-red-50 border border-red-200 rounded-xl text-red-600">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900">Deletion Blocked</h3>
                  <p className="text-xs text-red-600 font-semibold">Active Journey Association Detected</p>
                </div>
              </div>

              <p className="text-xs text-slate-700 mb-5 leading-relaxed bg-red-50/50 p-3 rounded-lg border border-red-100">
                {deleteErrorMsg}
              </p>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setDeleteErrorMsg(null)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs rounded-lg shadow-sm transition cursor-pointer"
                >
                  Acknowledge & Close
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Remove Step Node Modal */}
      <DeleteConfirmModal
        isOpen={!!nodeToRemove}
        onClose={() => setNodeToRemove(null)}
        onConfirm={() => {
          if (nodeToRemove) {
            removeAgentFromPipeline(nodeToRemove.id);
            setNodeToRemove(null);
          }
        }}
        title="Remove Step Node"
        description={`Are you sure you want to remove step node "${nodeToRemove?.name}" from this process flow canvas?`}
        confirmLabel="Remove Step"
      />

      {/* Clear Canvas Modal */}
      <DeleteConfirmModal
        isOpen={showClearCanvasConfirm}
        onClose={() => setShowClearCanvasConfirm(false)}
        onConfirm={() => {
          clearCanvas();
          setShowClearCanvasConfirm(false);
        }}
        title="Clear Flow Canvas"
        description="Are you sure you want to clear all step nodes and connection links from the active process flow canvas?"
        confirmLabel="Clear Canvas"
      />
    </div>
  );
}
