import React, { useState, useEffect } from 'react';
import { 
  Play, Sparkles, AlertCircle, CheckCircle, HelpCircle, Layers, Globe, 
  CheckSquare, Square, ChevronRight, Bot, FileText, Check, Loader2, 
  ArrowLeft, ArrowRight, ShieldCheck, UserCheck, Building2, CreditCard, 
  X, MapPin, Mail, Phone, Lock, GitBranch, Shield
} from 'lucide-react';
import { ClientProfile, WorkflowNode, NodeStatus, HybridStage } from '../../types';
import { Journey, JourneyStep, DEFAULT_JOURNEYS } from '../common/PersonaSubviews';

interface JourneyInitiatorProps {
  onClientCreated: (client: ClientProfile) => void;
  onClose: () => void;
}

const AVAILABLE_JURISDICTIONS = [
  { code: 'SG', name: 'Singapore (SG)', desc: 'MAS TRM Standard Compliance & Singpass MyInfo Sync' },
  { code: 'HK', name: 'Hong Kong (HK)', desc: 'HKMA Regulated Offshore Shield & CR Gateway' },
  { code: 'IN', name: 'India (IN)', desc: 'RBI Corporate KYC, MCA21 & AML Gateway' },
  { code: 'UK', name: 'United Kingdom (UK)', desc: 'FCA Registry & Companies House Direct Sync' },
  { code: 'US', name: 'United States (US)', desc: 'SEC / FINRA Entity Verification & Delaware Registry' },
  { code: 'China', name: 'China (China)', desc: 'PBOC Sovereign Entity Clearance' },
];

const AVAILABLE_PRODUCTS = [
  { id: 'casa', name: 'Corporate Cash Account (CASA)', description: 'Primary operating account with multi-currency sweeps & zero minimum balance.' },
  { id: 'trade', name: 'Trade Finance Suite', description: 'Letters of credit, cross-border remittance, and invoice discounting.' },
  { id: 'fx', name: 'FX Treasury Desk', description: 'Spot, forward hedging, and cross-currency liquidity management.' },
  { id: 'credit', name: 'Risk & Credit Underwriting', description: 'Revolving credit facilities, commercial loans, and working capital buffers.' },
  { id: 'cards', name: 'Commercial Corporate Cards', description: 'Smart spending limits, employee virtual cards, automatic ledger syncing.' },
  { id: 'wealth', name: 'Wealth & Offshore Trust', description: 'Bespoke capital preservation vehicles and institutional wealth management.' },
  { id: 'custody', name: 'Digital Asset Custody', description: 'MPC cold storage for corporate digital assets & tokenized securities.' },
];

export default function JourneyInitiator({ onClientCreated, onClose }: JourneyInitiatorProps) {
  // Wizard Navigation Step: 1 = Form Inputs, 2 = Execution Topography & Confirmation
  const [formStep, setFormStep] = useState<1 | 2>(1);

  // Form Fields
  const [clientName, setClientName] = useState('');
  const [regNumber, setRegNumber] = useState('');
  const [pocName, setPocName] = useState('');
  const [pocEmail, setPocEmail] = useState('');
  const [pocPhone, setPocPhone] = useState('');
  const [selectedJurisdiction, setSelectedJurisdiction] = useState('SG');
  const [selectedProducts, setSelectedProducts] = useState<string[]>(['casa', 'trade']);
  const [selectedJourneyId, setSelectedJourneyId] = useState('');
  const [error, setError] = useState('');

  // AI Transcript Ingestion State (cib_onb_agent)
  const [showTranscriptModal, setShowTranscriptModal] = useState(false);
  const [rawTranscript, setRawTranscript] = useState('');
  const [isParsingTranscript, setIsParsingTranscript] = useState(false);
  const [extractedJsonPayload, setExtractedJsonPayload] = useState<any>(null);
  const [extractedMeta, setExtractedMeta] = useState<{
    registeredAddress?: string;
    industrySector?: string;
    parentCompany?: string;
    revenue?: string;
    cash?: string;
    ebitda?: string;
    debtRatio?: string;
    auditor?: string;
    primaryBank?: string;
  } | null>(null);

  const SAMPLE_RM_TRANSCRIPT = `Meeting Notes (04 Aug 2026): Met with Sarah Lin, Managing Director of Zenith Global Logistics Pte Ltd (GLEI: 25490033281144001188, Reg No: 202619882K, Incorporated in Singapore SG on 2026-03-15).
Primary contact: sarah.lin@zenithlogistics.com (+65 91234567).
They require Corporate Cash Account (ACCOUNT), Cross-Border Remittance (CROSS_BORDER), Trade Finance Suite (TRADE), and FX Treasury Desk (FX).
Anticipated monthly volume: $2,500,000 USD. Preferred contact mode: EMAIL.
Submitted Documents: Certificate of Incorporation, Board Resolution.`;

  const parseOnboardingText = (textToParse: string) => {
    const text = textToParse.trim();

    // 1. Legal Name / Company Name
    let client_name = '';
    const legalNameMatch = text.match(/(?:Company Overview)?(?:Legal Name|Company Name|Client Name|Entity Name|Corporate Name)\s*:\s*([^\n\r]+?)(?=(?:Registration|UEN|Reg No|Incorporation|Registered Address|Address|Ownership|Parent|Industry|Relationship|Business Model|Primary Bank|Financial Profile|\n|\r|$))/i);
    if (legalNameMatch && legalNameMatch[1]?.trim()) {
      client_name = legalNameMatch[1].trim().replace(/^[^\w]+|[^\w.)\]]+$/g, '');
    } else {
      const metWithMatch = text.match(/(?:Met with|Meeting with|Call with)\s+[^,]+,\s*(?:Managing Director|Director|CFO|CEO|Treasury Director|President)?\s*(?:of|from)\s+([A-Za-z0-9\s.,&'-]+?(?:Pte\.?\s*Ltd\.?|Ltd\.?|LLC|Inc\.?|Corp\.?|Corporation|Holdings|Group|Co\.?|Limited|GmbH|B\.V\.?|PLC))/i);
      if (metWithMatch && metWithMatch[1]?.trim()) {
        client_name = metWithMatch[1].trim();
      } else {
        const generalEntityMatch = text.match(/\b([A-Z][A-Za-z0-9\s.,&'-]+?(?:Pte\.?\s*Ltd\.?|Ltd\.?|LLC|Inc\.?|Corp\.?|Corporation|Holdings|Group|Co\.?|Limited|GmbH|B\.V\.?|PLC))\b/);
        if (generalEntityMatch && generalEntityMatch[1]?.trim()) {
          client_name = generalEntityMatch[1].trim();
        }
      }
    }
    if (!client_name) {
      client_name = 'Corporate Client Entity';
    }

    // 2. Registration / UEN / LEI
    let incorporation_number = '';
    const regMatch = text.match(/(?:Registration\s*(?:\/\s*UEN)?|UEN|Reg(?:\s*No\.?|\s*Number)?|Registration No\.?|CRN|Company No\.?|GLEI|LEI)\s*:\s*([A-Za-z0-9\-_]{6,25})/i);
    if (regMatch && regMatch[1]?.trim()) {
      incorporation_number = regMatch[1].trim();
    } else {
      const uenPatternMatch = text.match(/\b(?:19|20)\d{7}[A-Za-z]\b/);
      if (uenPatternMatch && uenPatternMatch[0]) {
        incorporation_number = uenPatternMatch[0].toUpperCase();
      } else {
        const leiPatternMatch = text.match(/\b[0-9A-Z]{20}\b/);
        if (leiPatternMatch && leiPatternMatch[0]) {
          incorporation_number = leiPatternMatch[0];
        }
      }
    }

    // 3. Registered Address
    let registered_address = '';
    const addrMatch = text.match(/(?:Registered Address|Address|Office Address|Registered Office)\s*:\s*([^\n\r]+?)(?=(?:Ownership|Parent|Industry|Relationship|Business Model|Primary Bank|Financial Profile|\n|\r|$))/i);
    if (addrMatch && addrMatch[1]?.trim()) {
      registered_address = addrMatch[1].trim();
    }

    // 4. Incorporation Date
    let incorporation_date = '';
    const incDateMatch = text.match(/(?:Incorporation Date|Date of Incorporation|Incorporated on|Incorporated in [A-Za-z\s]+ on)\s*[:]?\s*([0-9]{1,2}\s+[A-Za-z]+\s+[0-9]{4}|[0-9]{4}-[0-9]{2}-[0-9]{2})/i);
    if (incDateMatch && incDateMatch[1]?.trim()) {
      incorporation_date = incDateMatch[1].trim();
    }

    // 5. Industry Sector
    let industry_sector = '';
    const indMatch = text.match(/(?:Industry Sector|Industry|Business Sector|Sector)\s*:\s*([^\n\r]+?)(?=(?:Relationship Manager|RM|Business Model|Core Business|Primary Bank|Financial Profile|\n|\r|$))/i);
    if (indMatch && indMatch[1]?.trim()) {
      industry_sector = indMatch[1].trim();
    }

    // 6. Ownership / Parent Company
    let parent_company = '';
    const parentMatch = text.match(/(?:Ownership\s*\/\s*Parent|Ownership|Parent Company|Parent Entity|Parent)\s*:\s*([^\n\r]+?)(?=(?:Industry Sector|Industry|Relationship Manager|RM|Business Model|\n|\r|$))/i);
    if (parentMatch && parentMatch[1]?.trim()) {
      parent_company = parentMatch[1].trim();
    }

    // 7. Point of Contact / Signatory / Relationship Manager
    let poc_name = '';
    const pocMatch = text.match(/(?:Authorized Signatory|Contact Person|Primary Contact|POC|Representative|Relationship Manager|RM)\s*:\s*([A-Za-z\s.'-]+?)(?=(?:\s*\(|\s*,|\s*\+[\d\s]+|\s*<|\s*Email|\s*Phone|\s*Mobile|\s*Business|\s*Core|\s*Registration|\s*Registered|\s*Auditor|\s*Next Steps|\n|\r|$))/i);
    if (pocMatch && pocMatch[1]?.trim()) {
      poc_name = pocMatch[1].trim();
    } else {
      const metWithPoc = text.match(/(?:Met with|Meeting with|Call with|Speaking with)\s+([A-Za-z\s.'-]+?)(?:,|\s+Managing|\s+Director|\s+of|\s+from|\s*\()/i);
      if (metWithPoc && metWithPoc[1]?.trim()) {
        poc_name = metWithPoc[1].trim();
      }
    }
    if (!poc_name) {
      poc_name = 'Authorized Signatory';
    }

    // 8. Contact Email
    let poc_email = '';
    const emailMatch = text.match(/\b([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})\b/);
    if (emailMatch && emailMatch[1]) {
      poc_email = emailMatch[1];
    } else {
      const cleanName = poc_name.toLowerCase().replace(/[^a-z0-9]/g, '.');
      const cleanCompany = client_name.toLowerCase().replace(/\s+(pte\.?|ltd\.?|llc|inc\.?|corp\.?|holdings|group|co\.?)/gi, '').replace(/[^a-z0-9]/g, '');
      poc_email = `${cleanName || 'contact'}@${cleanCompany || 'corporate'}.com`;
    }

    // 9. Contact Phone
    let poc_mobile_number = '';
    const phoneMatch = text.match(/(?:Phone|Mobile|Tel|Contact No\.?|Cell)\s*:\s*([+\d\s().-]{7,20})/i) || text.match(/\b(\+\d{1,3}[\s-]?\(?\d{2,4}\)?[\s-]?\d{3,4}[\s-]?\d{3,5})\b/);
    if (phoneMatch && phoneMatch[1]?.trim()) {
      poc_mobile_number = phoneMatch[1].trim();
    } else {
      poc_mobile_number = '+65 6823 4567';
    }

    // 10. Jurisdiction
    let incorporation_country = 'SG';
    if (/(?:Singapore|SG|Singapore\s+\d{6}|068898|Pte\.?\s*Ltd\.?|ACRA|MAS)/i.test(text)) {
      incorporation_country = 'SG';
    } else if (/(?:Hong Kong|HK|HKMA|Central,\s*Hong Kong)/i.test(text)) {
      incorporation_country = 'HK';
    } else if (/(?:India|IN|Mumbai|Delhi|MCA21|GSTIN|PAN)/i.test(text)) {
      incorporation_country = 'IN';
    } else if (/(?:United Kingdom|UK|London|Companies House|FCA)/i.test(text)) {
      incorporation_country = 'UK';
    } else if (/(?:United States|US|Delaware|SEC|New York)/i.test(text)) {
      incorporation_country = 'US';
    } else if (/(?:China|Beijing|Shanghai|PBOC)/i.test(text)) {
      incorporation_country = 'China';
    }

    // 11. Products Interested
    const products_interested: string[] = [];
    if (/(?:casa|cash\s*account|cash\s*management|sweeping|pooling|virtual\s*account|operational\s*account|deposit|liquidity)/i.test(text)) {
      products_interested.push('casa');
    }
    if (/(?:trade|trade\s*finance|revolving\s*trade|letters?\s*of\s*credit|cross-border|vendor\s*orders?|remittance|invoice|import|export)/i.test(text)) {
      products_interested.push('trade');
    }
    if (/(?:foreign\s*exchange|fx|hedg(?:e|ing)|spot|forward|currency\s*exposure|treasury\s*desk|cross-currency)/i.test(text)) {
      products_interested.push('fx');
    }
    if (/(?:credit|working\s*capital|revolving\s*(?:credit|loan|facility)|loan|commercial\s*loan|debt|underwriting|leverage)/i.test(text)) {
      products_interested.push('credit');
    }
    if (/(?:cards?|corporate\s*cards?|commercial\s*cards?)/i.test(text)) {
      products_interested.push('cards');
    }
    if (/(?:wealth|trust|offshore\s*trust|wealth\s*management|private\s*wealth)/i.test(text)) {
      products_interested.push('wealth');
    }
    if (/(?:custody|digital\s*asset|tokenized|crypto|mpc\s*cold\s*storage)/i.test(text)) {
      products_interested.push('custody');
    }
    if (products_interested.length === 0) {
      products_interested.push('casa', 'trade');
    }

    // 12. Financials
    let revenue = '$12.5M USD';
    const revMatch = text.match(/(?:Annual Revenue|Revenue|Turnover)\s*:\s*([^\n\r]+?)(?=(?:EBITDA|Net Profit|Leverage|Cash|Auditor|\n|\r|$))/i);
    if (revMatch && revMatch[1]?.trim()) {
      revenue = revMatch[1].trim();
    }

    let ebitda = '';
    const ebitdaMatch = text.match(/EBITDA\s*:\s*([^\n\r]+?)(?=(?:Net Profit|Leverage|Cash|Auditor|\n|\r|$))/i);
    if (ebitdaMatch && ebitdaMatch[1]?.trim()) {
      ebitda = ebitdaMatch[1].trim();
    }

    let netProfit = '';
    const profitMatch = text.match(/Net Profit\s*:\s*([^\n\r]+?)(?=(?:Leverage|Cash|Auditor|\n|\r|$))/i);
    if (profitMatch && profitMatch[1]?.trim()) {
      netProfit = profitMatch[1].trim();
    }

    let cash = '$8.2M USD';
    const cashMatch = text.match(/(?:Cash & Equivalents|Cash)\s*:\s*([^\n\r]+?)(?=(?:Auditor|Current Banking|\n|\r|$))/i);
    if (cashMatch && cashMatch[1]?.trim()) {
      cash = cashMatch[1].trim();
    }

    let debtRatio = '0.18';
    const levMatch = text.match(/(?:Leverage Ratio|Debt\s*\/\s*EBITDA|Debt Ratio)\s*:\s*([^\n\r]+?)(?=(?:Cash|Auditor|\n|\r|$))/i);
    if (levMatch && levMatch[1]?.trim()) {
      debtRatio = levMatch[1].trim();
    }

    let auditor = '';
    const audMatch = text.match(/Auditor\s*:\s*([^\n\r]+?)(?=(?:Current Banking|Primary Bank|\n|\r|$))/i);
    if (audMatch && audMatch[1]?.trim()) {
      auditor = audMatch[1].trim();
    }

    let primaryBank = '';
    const pbMatch = text.match(/Primary Bank\s*:\s*([^\n\r]+?)(?=(?:Secondary Bank|Wallet Share|\n|\r|$))/i);
    if (pbMatch && pbMatch[1]?.trim()) {
      primaryBank = pbMatch[1].trim();
    }

    return {
      submission_channel: "RELATIONSHIP_MANAGER",
      client_name,
      incorporation_number: incorporation_number || `${incorporation_country}-${Math.floor(Math.random() * 900000 + 100000)}`,
      incorporation_country,
      incorporation_date,
      registered_address,
      industry_sector,
      parent_company,
      point_of_contact: {
        poc_name,
        poc_email,
        poc_mobile_number
      },
      products_interested,
      financials: {
        revenue,
        ebitda,
        netProfit,
        cash,
        debtRatio,
        auditor,
        rating: 'A+'
      },
      banking_relationships: {
        primaryBank,
      },
      documents_submitted: [
        "Certificate of Incorporation",
        "Board Resolution",
        "Audited Financial Report"
      ],
      confidence_score: 98.4
    };
  };

  const handleParseTranscriptWithOnboardingBuddy = () => {
    const textToParse = rawTranscript.trim() || SAMPLE_RM_TRANSCRIPT;
    setIsParsingTranscript(true);

    setTimeout(() => {
      const outputPayload = parseOnboardingText(textToParse);

      setExtractedJsonPayload(outputPayload);
      setExtractedMeta({
        registeredAddress: outputPayload.registered_address,
        industrySector: outputPayload.industry_sector,
        parentCompany: outputPayload.parent_company,
        revenue: outputPayload.financials?.revenue,
        cash: outputPayload.financials?.cash,
        ebitda: outputPayload.financials?.ebitda,
        debtRatio: outputPayload.financials?.debtRatio,
        auditor: outputPayload.financials?.auditor,
        primaryBank: outputPayload.banking_relationships?.primaryBank,
      });

      setClientName(outputPayload.client_name);
      setRegNumber(outputPayload.incorporation_number);
      setPocName(outputPayload.point_of_contact.poc_name);
      setPocEmail(outputPayload.point_of_contact.poc_email);
      setPocPhone(outputPayload.point_of_contact.poc_mobile_number);
      setSelectedJurisdiction(outputPayload.incorporation_country);
      setSelectedProducts(outputPayload.products_interested);
      setIsParsingTranscript(false);
    }, 600);
  };

  // Load available journeys
  const [journeys, setJourneys] = useState<Journey[]>([]);

  useEffect(() => {
    const syncJourneys = () => {
      const saved = localStorage.getItem('onboarding_journeys');
      const loadedJourneys: Journey[] = saved ? JSON.parse(saved) : DEFAULT_JOURNEYS;
      setJourneys(loadedJourneys);
      if (loadedJourneys.length > 0) {
        setSelectedJourneyId(prev => prev || loadedJourneys[0].id);
      }
    };

    syncJourneys();

    window.addEventListener('onboarding_journeys_updated', syncJourneys);
    window.addEventListener('storage', syncJourneys);
    return () => {
      window.removeEventListener('onboarding_journeys_updated', syncJourneys);
      window.removeEventListener('storage', syncJourneys);
    };
  }, []);

  const toggleProduct = (productId: string) => {
    if (selectedProducts.includes(productId)) {
      if (selectedProducts.length > 1) {
        setSelectedProducts(selectedProducts.filter(id => id !== productId));
      }
    } else {
      setSelectedProducts([...selectedProducts, productId]);
    }
  };

  const handleProceedToPreview = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!clientName.trim()) {
      setError('Please enter a valid Corporate Legal Entity Name.');
      return;
    }
    if (!selectedJourneyId) {
      setError('Please select an Onboarding Journey Type / Template.');
      return;
    }
    if (selectedProducts.length === 0) {
      setError('Please select at least one interested financial product.');
      return;
    }

    setFormStep(2);
  };

  // Compute calculated workflow nodes and stage groups for chosen journey
  const computeCalculatedWorkflow = () => {
    const journey = journeys.find(j => j.id === selectedJourneyId);
    if (!journey) return { mappedNodes: [], stageGroups: [], journeyName: 'Default Journey' };

    let savedAgents: any[] = [];
    try {
      const raw = localStorage.getItem('orchestration_agents');
      if (raw) savedAgents = JSON.parse(raw);
    } catch (e) {
      console.error(e);
    }

    const formatAgentName = (agentId: string) => {
      const found = savedAgents.find((a: any) => a.id === agentId);
      if (found?.name) return found.name;

      const AGENT_NAMES_MAP: Record<string, string> = {
        'lead_intelligence_agent': 'Lead Intelligence Agent',
        'entity_resolution_agent': 'Entity Resolution Agent',
        'research_agent': 'Autonomous Entity Research Agent',
        'registry_connector_agent': 'Registry Connector Agent',
        'regulatory_database_agent': 'Regulatory Database Agent',
        'ownership_agent': 'Ownership Structure Mapping Agent',
        'ubo_agent': 'UBO Unwrapping Agent',
        'vie_structure_agent': 'VIE & Complex Structure Agent',
        'director_verification_agent': 'Director Verification Agent',
        'identity_verification_agent': 'Identity Verification Agent',
        'vlei_agent': 'vLEI Credential Verifier',
        'kyc_engine_agent': 'Dynamic KYC Engine Agent',
        'regulatory_rules_agent': 'Regulatory Rules Engine',
        'client_outreach_agent': 'Client Outreach Agent',
        'document_intelligence_agent': 'Document Intelligence Agent',
        'ocr_agent': 'OCR Extraction Agent',
        'cross_validation_agent': 'Cross-Validation Engine',
        'sanctions_screening_agent': 'Sanctions Screening Agent',
        'pep_screening_agent': 'PEP Screening Agent',
        'adverse_media_agent': 'Adverse Media Screening Agent',
        'risk_assessment_agent': 'Risk Assessment Matrix Agent',
        'edd_trigger_agent': 'EDD Trigger Agent',
        'approval_gateway_agent': 'Approval Gateway Agent',
        'signatory_intelligence_agent': 'Signatory Intelligence Agent',
        'casa_provisioning_agent': 'CASA Provisioning Agent',
        'fx_mm_provisioning_agent': 'FX/MM Provisioning Agent',
        'trade_finance_provisioning_agent': 'Trade Finance Provisioning Agent',
        'derivatives_provisioning_agent': 'Derivatives Provisioning Agent',
        'digital_asset_provisioning_agent': 'Digital Asset Provisioning Agent',
        'rtt_validation_agent': 'Ready to Trade Validation Agent',
        'perpetual_kyc_agent': 'Perpetual KYC Agent',
      };

      if (AGENT_NAMES_MAP[agentId]) return AGENT_NAMES_MAP[agentId];

      return agentId
        .replace(/_/g, ' ')
        .replace(/\b\w/g, c => c.toUpperCase());
    };

    const journeyStages = (journey as any).stages || (journey as any).phases;

    if (journeyStages && journeyStages.length > 0) {
      // Journey defines explicit multi-stage structure (e.g. 11 stages)
      const stageGroups: { name: string; mode: 'sequential' | 'parallel'; steps: JourneyStep[] }[] = [];
      const mappedNodes: WorkflowNode[] = [];

      journeyStages.forEach((stage: any, stageIdx: number) => {
        const attachedAgentIds: string[] = stage.attachedAgentIds || [];
        const mode: 'sequential' | 'parallel' = stage.executionMode || 'sequential';

        const stageSteps: JourneyStep[] = attachedAgentIds.map((agId) => ({
          id: `${stage.id}_${agId}`,
          name: formatAgentName(agId),
          agentId: agId,
          executionType: mode,
          failureHandling: 'escalate'
        }));

        stageGroups.push({
          name: stage.name || `STAGE ${stageIdx + 1}`,
          mode,
          steps: stageSteps.length > 0 ? stageSteps : [{
            id: `${stage.id}_default`,
            name: stage.name || `Stage ${stageIdx + 1} Agent`,
            agentId: stage.linkedPipelineId || 'default_agent',
            executionType: mode,
            failureHandling: 'escalate'
          }]
        });

        // Clean stage-to-stage dependency mapping
        let dependsOn: string[] = [];
        if (stage.dependsOnStages && Array.isArray(stage.dependsOnStages)) {
          dependsOn = stage.dependsOnStages;
        } else if (stage.id === 'stage_1' || stage.id === 'fund_stage_1' || stageIdx === 0) {
          dependsOn = [];
        } else if (stage.id === 'stage_2' || stage.id === 'fund_stage_2') {
          dependsOn = ['stage_1'];
        } else if (stage.id === 'stage_3' || stage.id === 'fund_stage_3') {
          dependsOn = ['stage_1'];
        } else if (stage.id === 'stage_4' || stage.id === 'fund_stage_4') {
          dependsOn = ['stage_2', 'stage_3'];
        } else if (stage.id === 'stage_5' || stage.id === 'fund_stage_5') {
          dependsOn = ['stage_4'];
        } else if (stage.id === 'stage_6' || stage.id === 'fund_stage_6') {
          dependsOn = ['stage_4'];
        } else if (stage.id === 'stage_7' || stage.id === 'fund_stage_7') {
          dependsOn = ['stage_5', 'stage_6'];
        } else if (stage.id === 'stage_8' || stage.id === 'fund_stage_8') {
          dependsOn = ['stage_7'];
        } else if (stage.id === 'stage_9' || stage.id === 'fund_stage_9') {
          dependsOn = ['stage_8'];
        } else if (stage.id === 'stage_10' || stage.id === 'fund_stage_10') {
          dependsOn = ['stage_9'];
        } else if (stage.id === 'stage_11' || stage.id === 'fund_stage_11') {
          dependsOn = ['stage_10'];
        } else {
          const prevStage = journeyStages[stageIdx - 1];
          dependsOn = prevStage ? [prevStage.id] : [];
        }

        let agentType: WorkflowNode['agentType'] = 'data_aggregator';
        let team = 'Onboarding Operations';

        const sid = (stage.id || '').toLowerCase();
        if (sid.includes('stage_1') || sid.includes('stage_2')) {
          agentType = 'data_aggregator';
          team = 'Registry & Lead Intelligence Engine';
        } else if (sid.includes('stage_3')) {
          agentType = 'data_aggregator';
          team = 'Director & Identity Registry Engine';
        } else if (sid.includes('stage_4')) {
          agentType = 'legal_compliance';
          team = 'Dynamic KYC Engine';
        } else if (sid.includes('stage_5')) {
          agentType = 'legal_compliance';
          team = 'Client Outreach & Compliance Engine';
        } else if (sid.includes('stage_6')) {
          agentType = 'name_screening';
          team = 'Global Sanctions & PEP Screening';
        } else if (sid.includes('stage_7')) {
          agentType = 'client_risk';
          team = 'Multi-Factor Risk Engine';
        } else if (sid.includes('stage_8')) {
          agentType = 'legal_compliance';
          team = 'Approval Gateway';
        } else if (sid.includes('stage_9')) {
          agentType = 'credit_risk';
          team = 'Product Provisioning Engine';
        } else if (sid.includes('stage_10')) {
          agentType = 'legal_compliance';
          team = 'Ready-to-Trade Validation';
        } else if (sid.includes('stage_11')) {
          agentType = 'aml';
          team = 'Perpetual KYC Monitor';
        }

        const agentNames = attachedAgentIds.map(agId => formatAgentName(agId));

        const node: WorkflowNode = {
          id: stage.id,
          name: stage.name,
          agentType,
          team,
          description: stage.description || `Automated compliance processing for ${stage.name}.`,
          status: 'pending' as NodeStatus,
          dependsOn,
          logs: [`[Journey Orchestrator] Stage ${stageIdx + 1} (${stage.name}) initialized. Attached agents: ${agentNames.length > 0 ? agentNames.join(', ') : 'System Engine'}.`],
          assignedAgentId: attachedAgentIds[0] || stage.linkedPipelineId || 'journey_engine',
          attachedAgentIds,
          pipelines: stage.pipelines || [],
          executionMode: mode
        };

        mappedNodes.push(node);
      });

      return { mappedNodes, stageGroups, journeyName: journey.name };
    }

    let steps = journey.steps || [];
    let hybridStages = (journey as any).hybridStages as HybridStage[] | undefined;

    try {
      const savedOrchs = localStorage.getItem('agent_orchestrations');
      const orchestrations: any[] = savedOrchs ? JSON.parse(savedOrchs) : [];

      // ONLY match if orchestration ID matches journey ID exactly (do not match single stage linkedPipelineId)
      const linkedOrch = orchestrations.find(o => o.id === journey.id);
      if (linkedOrch) {
        hybridStages = linkedOrch.hybridStages || hybridStages;
        steps = linkedOrch.agentIds.map((agId: string, idx: number) => {
          let execType: 'sequential' | 'parallel' = 'sequential';
          if (linkedOrch.strategy === 'parallel') {
            execType = 'parallel';
          } else if (linkedOrch.strategy === 'hybrid' && linkedOrch.hybridStages) {
            const stage = linkedOrch.hybridStages.find((s: any) => s.agentIds.includes(agId));
            if (stage && stage.executionMode === 'parallel') {
              execType = 'parallel';
            }
          }
          return {
            id: `step_${idx + 1}`,
            name: formatAgentName(agId),
            agentId: agId,
            executionType: execType,
            failureHandling: 'escalate' as const
          };
        });
      }
    } catch (e) {
      console.error('Failed to sync dynamic orchestration steps in JourneyInitiator', e);
    }

    const getStepId = (st: JourneyStep, idx: number) => st.id || `${st.agentId}_step_${idx}`;
    const dependsOnMap = new Map<number, string[]>();

    if (hybridStages && hybridStages.length > 0) {
      const stageBuckets: { name: string; mode: 'sequential' | 'parallel'; stepIndices: number[] }[] = [];
      
      hybridStages.forEach(stage => {
        const stepIndices: number[] = [];
        stage.agentIds.forEach(agId => {
          steps.forEach((st, idx) => {
            if ((st.agentId === agId || st.id === agId) && !stepIndices.includes(idx)) {
              stepIndices.push(idx);
            }
          });
        });
        if (stepIndices.length > 0) {
          stageBuckets.push({
            name: stage.name,
            mode: stage.executionMode,
            stepIndices
          });
        }
      });

      const covered = new Set(stageBuckets.flatMap(b => b.stepIndices));
      steps.forEach((st, idx) => {
        if (!covered.has(idx)) {
          stageBuckets.push({
            name: `Stage ${stageBuckets.length + 1}: ${st.name}`,
            mode: st.executionType || 'sequential',
            stepIndices: [idx]
          });
        }
      });

      stageBuckets.forEach((bucket, bIdx) => {
        const prevBucket = bIdx > 0 ? stageBuckets[bIdx - 1] : null;
        bucket.stepIndices.forEach((sIdx, posInBucket) => {
          if (bucket.mode === 'sequential' && posInBucket > 0) {
            const prevSIdx = bucket.stepIndices[posInBucket - 1];
            dependsOnMap.set(sIdx, [getStepId(steps[prevSIdx], prevSIdx)]);
          } else if (prevBucket) {
            const exitSIndices = prevBucket.mode === 'parallel'
              ? prevBucket.stepIndices
              : [prevBucket.stepIndices[prevBucket.stepIndices.length - 1]];
            const prevIds = exitSIndices.map(pIdx => getStepId(steps[pIdx], pIdx));
            dependsOnMap.set(sIdx, prevIds);
          } else {
            dependsOnMap.set(sIdx, []);
          }
        });
      });
    } else {
      const stageBuckets: { mode: 'sequential' | 'parallel'; stepIndices: number[] }[] = [];
      let currentBucket: { mode: 'sequential' | 'parallel'; stepIndices: number[] } | null = null;

      steps.forEach((st, idx) => {
        const mode = st.executionType || 'sequential';
        if (!currentBucket || currentBucket.mode !== mode || mode === 'sequential') {
          if (currentBucket) stageBuckets.push(currentBucket);
          currentBucket = { mode, stepIndices: [idx] };
        } else {
          currentBucket.stepIndices.push(idx);
        }
      });
      if (currentBucket) stageBuckets.push(currentBucket);

      stageBuckets.forEach((bucket, bIdx) => {
        const prevBucket = bIdx > 0 ? stageBuckets[bIdx - 1] : null;
        bucket.stepIndices.forEach((sIdx, posInBucket) => {
          if (bucket.mode === 'sequential' && posInBucket > 0) {
            const prevSIdx = bucket.stepIndices[posInBucket - 1];
            dependsOnMap.set(sIdx, [getStepId(steps[prevSIdx], prevSIdx)]);
          } else if (prevBucket) {
            const exitSIndices = prevBucket.mode === 'parallel'
              ? prevBucket.stepIndices
              : [prevBucket.stepIndices[prevBucket.stepIndices.length - 1]];
            const prevIds = exitSIndices.map(pIdx => getStepId(steps[pIdx], pIdx));
            dependsOnMap.set(sIdx, prevIds);
          } else {
            dependsOnMap.set(sIdx, []);
          }
        });
      });
    }

    const mappedNodes: WorkflowNode[] = steps.map((step, index) => {
      let agentType: WorkflowNode['agentType'] = 'data_aggregator';
      let team = 'Onboarding Operations';

      const aid = step.agentId.toLowerCase();
      const sname = step.name.toLowerCase();

      if (aid.includes('kyb') || sname.includes('registry') || sname.includes('extract')) {
        agentType = 'data_aggregator';
        team = 'Registry Aggregation Engine';
      } else if (aid.includes('ocr') || aid.includes('doc') || sname.includes('document')) {
        agentType = 'legal_compliance';
        team = 'Document & Compliance Engine';
      } else if (aid.includes('kyc') || sname.includes('biometric') || sname.includes('identity')) {
        agentType = 'data_aggregator';
        team = 'Identity Registry Engine';
      } else if (aid.includes('sanctions') || aid.includes('watchlist') || sname.includes('screening') || sname.includes('pep')) {
        agentType = 'name_screening';
        team = 'Compliance Screening Module';
      } else if (aid.includes('ubo') || aid.includes('aml') || sname.includes('unwrap')) {
        agentType = 'aml';
        team = 'AML & KYB Compliance Team';
      } else if (aid.includes('risk') || aid.includes('scoring') || sname.includes('risk')) {
        agentType = 'client_risk';
        team = 'Risk Operations Team';
      } else if (aid.includes('credit') || sname.includes('underwriting') || sname.includes('financial')) {
        agentType = 'credit_risk';
        team = 'Credit Assessment Team';
      } else if (aid.includes('legal') || aid.includes('compliance') || aid.includes('agreement') || sname.includes('master') || sname.includes('intake') || aid.includes('rm_copilot')) {
        agentType = 'legal_compliance';
        team = 'General Legal Team';
      } else {
        const types: WorkflowNode['agentType'][] = [
          'data_aggregator',
          'name_screening',
          'aml',
          'client_risk',
          'credit_risk',
          'legal_compliance',
        ];
        agentType = types[index % types.length];
      }

      const dependsOn = dependsOnMap.get(index) || [];
      const stepId = getStepId(step, index);

      return {
        id: stepId,
        name: step.name,
        agentType,
        team,
        description: `This automated step executes compliance checks via agent ${step.agentId}. Handled using ${step.executionType} parameters with ${step.failureHandling} policies.`,
        status: 'pending' as NodeStatus,
        dependsOn,
        logs: [`[Journey Orchestrator] Enqueued step ${index + 1}: ${step.name} using agent ${step.agentId}. Awaiting RM launch confirmation.`],
        results: undefined,
      };
    });

    // Compute Stage Groups for UI render
    let stageGroups: { name: string; mode: 'sequential' | 'parallel'; steps: JourneyStep[] }[] = [];
    if (hybridStages && hybridStages.length > 0) {
      hybridStages.forEach(stage => {
        const matchedSteps = steps.filter(st => stage.agentIds.includes(st.agentId) || stage.agentIds.includes(st.id));
        if (matchedSteps.length > 0) {
          stageGroups.push({
            name: stage.name,
            mode: stage.executionMode,
            steps: matchedSteps
          });
        }
      });
      const coveredIds = new Set(stageGroups.flatMap(g => g.steps.map(s => s.id)));
      const unassigned = steps.filter(s => !coveredIds.has(s.id));
      if (unassigned.length > 0) {
        stageGroups.push({
          name: 'Additional Execution Steps',
          mode: 'sequential',
          steps: unassigned
        });
      }
    } else {
      steps.forEach(st => {
        const mode = st.executionType || 'sequential';
        const lastGroup = stageGroups[stageGroups.length - 1];
        if (!lastGroup || lastGroup.mode !== mode || mode === 'sequential') {
          stageGroups.push({
            name: mode === 'parallel' ? 'Parallel Fan-Out Track' : `Stage ${stageGroups.length + 1}`,
            mode,
            steps: [st]
          });
        } else {
          lastGroup.steps.push(st);
        }
      });
    }

    return { mappedNodes, stageGroups, journeyName: journey.name };
  };

  const handleConfirmAndLaunchExecution = () => {
    const { mappedNodes } = computeCalculatedWorkflow();
    const jurDetails = AVAILABLE_JURISDICTIONS.find(j => j.code === selectedJurisdiction);
    const prodNames = AVAILABLE_PRODUCTS
      .filter(p => selectedProducts.includes(p.id))
      .map(p => p.name)
      .join(', ');

    const newClient: ClientProfile = {
      id: `client_journey_${Date.now()}`,
      companyName: clientName.trim(),
      registrationNumber: regNumber.trim() || `${selectedJurisdiction}-${Math.floor(Math.random() * 900000 + 100000)}`,
      jurisdiction: jurDetails?.name || selectedJurisdiction,
      industry: extractedMeta?.industrySector 
        ? `${extractedMeta.industrySector} (${prodNames})` 
        : `Interested Products: ${prodNames}`,
      authorizedRepresentative: {
        name: pocName.trim() || 'Authorized Signatory',
        role: 'Managing Director',
        email: pocEmail.trim() || `onboarding@${clientName.trim().toLowerCase().replace(/[^a-z0-9]/g, '') || 'company'}.com`,
        phone: pocPhone.trim() || '+65 9123 4567',
        biometricVerified: false,
        biometricMatchScore: 0,
        biometricSelfieUrl: '',
      },
      shareholders: extractedMeta?.parentCompany
        ? [
            { name: extractedMeta.parentCompany, equity: 100.0, pepStatus: false }
          ]
        : [
            { name: 'Core Managing Principal', equity: 75.0, pepStatus: false },
            { name: 'Sovereign Holding Co', equity: 25.0, pepStatus: false },
          ],
      financials: {
        revenue: extractedMeta?.revenue || '$12.5M USD',
        assets: extractedMeta?.cash || '$8.2M USD',
        debtRatio: extractedMeta?.debtRatio || '0.18',
        rating: 'A+',
      },
      documents: [],
      workflowNodes: mappedNodes,
      journeyId: selectedJourneyId,
      journeyName: journeyName,
      overallStatus: 'draft',
    };

    onClientCreated(newClient);
    onClose();
  };

  const { stageGroups, journeyName } = computeCalculatedWorkflow();

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-4xl w-full mx-auto text-left flex flex-col max-h-[90vh] overflow-hidden">
      {/* Modal Header (RM Worklist Aesthetic) */}
      <div className="px-6 py-4 bg-white border-b border-slate-200 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-600 shadow-2xs shrink-0">
            <Play className="w-4 h-4 fill-current" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-slate-900 text-base tracking-tight">
                Initiate New Onboarding Journey
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider bg-blue-50 text-blue-700 border border-blue-200">
                RM Portal
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              {formStep === 1 
                ? 'Configure client corporate profile, booking jurisdiction, and subscribed product scope' 
                : 'Review automated execution topology, worker agent fan-out, and authorize workflow dispatch'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {formStep === 1 && (
            <button
              type="button"
              onClick={() => setShowTranscriptModal(true)}
              className="px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-2xs"
              title="Auto-fill form from meeting notes or call transcripts using AI"
            >
              <Bot className="w-3.5 h-3.5 text-blue-600" />
              <span>Ingest Call Notes</span>
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Stepper Tabs Bar (RM Aesthetic) */}
      <div className="bg-slate-50/80 border-b border-slate-200 px-6 py-2.5 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-5 text-xs">
          <button
            type="button"
            onClick={() => setFormStep(1)}
            className={`flex items-center gap-2 font-bold transition cursor-pointer ${
              formStep === 1 ? 'text-blue-600' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
              formStep === 1 
                ? 'bg-blue-600 text-white shadow-xs' 
                : 'bg-emerald-100 text-emerald-700'
            }`}>
              {formStep === 2 ? '✓' : '1'}
            </span>
            <span>Client & Scope Configuration</span>
          </button>

          <ChevronRight className="w-3.5 h-3.5 text-slate-300" />

          <button
            type="button"
            onClick={() => {
              if (clientName.trim()) {
                setFormStep(2);
              }
            }}
            disabled={!clientName.trim()}
            className={`flex items-center gap-2 font-bold transition ${
              formStep === 2 
                ? 'text-blue-600' 
                : clientName.trim() 
                  ? 'text-slate-500 hover:text-slate-800 cursor-pointer' 
                  : 'text-slate-300 cursor-not-allowed'
            }`}
          >
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
              formStep === 2 
                ? 'bg-blue-600 text-white shadow-xs' 
                : 'bg-slate-200 text-slate-500'
            }`}>
              2
            </span>
            <span>Topology & Execution Review</span>
          </button>
        </div>

        <div className="hidden sm:flex items-center gap-2 text-[11px] font-mono text-slate-400">
          <span>Target Engine:</span>
          <span className="font-bold text-slate-700 bg-white px-2 py-0.5 rounded border border-slate-200">
            {selectedJurisdiction} • MAS / CIB
          </span>
        </div>
      </div>

      {/* AI Transcript / RM Notes Ingestion Modal Banner (RM Aesthetic) */}
      {showTranscriptModal && formStep === 1 && (
        <div className="p-4 bg-blue-50/40 border-b border-blue-100 space-y-3 shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center border border-blue-200 shrink-0">
                <Bot className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-900 font-mono">Onboarding Buddy (cib_onb_agent) Pre-Fill Engine</span>
                  <span className="px-2 py-0.5 bg-blue-100 text-blue-800 font-mono text-[9px] rounded-full font-bold border border-blue-200">Gemini 2.5 Pro</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Paste raw RM call notes or client emails. AI will extract corporate name, registration number, contact person, jurisdiction, and product intent.
                </p>
              </div>
            </div>
            <button 
              type="button" 
              onClick={() => setShowTranscriptModal(false)}
              className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-2">
            <textarea
              rows={3}
              value={rawTranscript}
              onChange={(e) => setRawTranscript(e.target.value)}
              placeholder={`Paste meeting notes or click "Load Sample Transcript"...`}
              className="w-full bg-white border border-slate-200 rounded-xl p-3 text-xs text-slate-800 font-mono outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 shadow-2xs"
            />

            <div className="flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => setRawTranscript(SAMPLE_RM_TRANSCRIPT)}
                className="text-xs text-blue-600 hover:text-blue-800 font-semibold cursor-pointer"
              >
                + Load Sample RM Meeting Notes
              </button>

              <button
                type="button"
                onClick={handleParseTranscriptWithOnboardingBuddy}
                disabled={isParsingTranscript}
                className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-xs"
              >
                {isParsingTranscript ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Extracting Structured Fields...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                    <span>Auto-Populate Form Fields</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {extractedJsonPayload && (
            <div className="p-3.5 bg-white rounded-xl border border-emerald-200 text-xs text-slate-700 space-y-2.5 shadow-2xs">
              <div className="flex items-center justify-between text-emerald-700 font-bold border-b border-emerald-100 pb-2 text-[11px]">
                <span className="flex items-center gap-1.5"><Check className="w-3.5 h-3.5 text-emerald-600" /> Fields Successfully Extracted & Applied to Form</span>
                <span className="text-[9px] bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded-full font-mono font-bold">cib_onb_agent • 98.4% Confidence</span>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-[11px]">
                <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200/60">
                  <span className="text-slate-400 block text-[9px] uppercase font-mono font-bold">Legal Entity</span>
                  <span className="font-bold text-slate-900 truncate block">{extractedJsonPayload.client_name}</span>
                </div>
                <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200/60">
                  <span className="text-slate-400 block text-[9px] uppercase font-mono font-bold">Registration / UEN</span>
                  <span className="font-bold text-emerald-700 font-mono block">{extractedJsonPayload.incorporation_number}</span>
                </div>
                <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200/60">
                  <span className="text-slate-400 block text-[9px] uppercase font-mono font-bold">Jurisdiction</span>
                  <span className="font-bold text-blue-700 font-mono block">{extractedJsonPayload.incorporation_country} (Singapore)</span>
                </div>
                <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200/60">
                  <span className="text-slate-400 block text-[9px] uppercase font-mono font-bold">Contact / Signatory</span>
                  <span className="font-bold text-slate-800 truncate block">{extractedJsonPayload.point_of_contact?.poc_name || 'N/A'}</span>
                </div>
              </div>

              {extractedMeta?.revenue && (
                <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-100 text-[10px] font-mono text-slate-600">
                  <span className="text-slate-400 font-bold">Financial Profile:</span>
                  <span className="bg-slate-100 px-2 py-0.5 rounded text-emerald-800 font-semibold">Rev: {extractedMeta.revenue}</span>
                  {extractedMeta.ebitda && <span className="bg-slate-100 px-2 py-0.5 rounded text-blue-800 font-semibold">EBITDA: {extractedMeta.ebitda}</span>}
                  {extractedMeta.cash && <span className="bg-slate-100 px-2 py-0.5 rounded text-teal-800 font-semibold">Cash: {extractedMeta.cash}</span>}
                  {extractedMeta.auditor && <span className="bg-slate-100 px-2 py-0.5 rounded text-slate-800 font-semibold">Auditor: {extractedMeta.auditor}</span>}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Scrollable Main Form Body */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50/50">
        {formStep === 1 ? (
          <form id="journey-initiator-form" onSubmit={handleProceedToPreview} className="space-y-6">
            {/* Section 1: Client Corporate Details */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
              <div className="flex items-center gap-2.5 border-b border-slate-100 pb-3">
                <div className="w-7 h-7 rounded-lg bg-blue-50 border border-blue-100 text-blue-600 flex items-center justify-center shrink-0">
                  <Building2 className="w-3.5 h-3.5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider font-mono">
                    1. Client Corporate & Contact Details
                  </h4>
                  <p className="text-[11px] text-slate-500">Legal entity registration, authorized signers, and communications channel</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5 md:col-span-2">
                  <label className="block text-xs font-bold text-slate-700">
                    Company / Legal Entity Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    placeholder="e.g. Aegis Institutional Capital Pte Ltd"
                    className="w-full border border-slate-200 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 rounded-xl p-2.5 text-xs outline-none bg-white text-slate-900 font-bold placeholder-slate-400 transition shadow-2xs"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700">
                    Registration No / UEN / LEI
                  </label>
                  <input
                    type="text"
                    value={regNumber}
                    onChange={(e) => setRegNumber(e.target.value)}
                    placeholder="e.g. 202688910K"
                    className="w-full border border-slate-200 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 rounded-xl p-2.5 text-xs outline-none bg-white text-slate-800 font-mono transition shadow-2xs"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700">
                    Authorized Signatory / Contact Person
                  </label>
                  <input
                    type="text"
                    value={pocName}
                    onChange={(e) => setPocName(e.target.value)}
                    placeholder="e.g. David Chen"
                    className="w-full border border-slate-200 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 rounded-xl p-2.5 text-xs outline-none bg-white text-slate-800 transition shadow-2xs"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700">
                    Contact Email Address
                  </label>
                  <input
                    type="email"
                    value={pocEmail}
                    onChange={(e) => setPocEmail(e.target.value)}
                    placeholder="e.g. d.chen@aegiscap.com"
                    className="w-full border border-slate-200 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 rounded-xl p-2.5 text-xs outline-none bg-white text-slate-800 transition shadow-2xs"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700">
                    Contact Phone / Mobile
                  </label>
                  <input
                    type="text"
                    value={pocPhone}
                    onChange={(e) => setPocPhone(e.target.value)}
                    placeholder="e.g. +65 9812 3456"
                    className="w-full border border-slate-200 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 rounded-xl p-2.5 text-xs outline-none bg-white text-slate-800 font-mono transition shadow-2xs"
                  />
                </div>
              </div>
            </div>

            {/* Section 2: Jurisdiction & Journey Type */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
              <div className="flex items-center gap-2.5 border-b border-slate-100 pb-3">
                <div className="w-7 h-7 rounded-lg bg-blue-50 border border-blue-100 text-blue-600 flex items-center justify-center shrink-0">
                  <Globe className="w-3.5 h-3.5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider font-mono">
                    2. Booking Jurisdiction & Journey Template
                  </h4>
                  <p className="text-[11px] text-slate-500">Regulatory framework and automated stage sequencing rulebook</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700">
                    Incorporation / Booking Jurisdiction <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={selectedJurisdiction}
                    onChange={(e) => setSelectedJurisdiction(e.target.value)}
                    className="w-full border border-slate-200 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 rounded-xl p-2.5 text-xs outline-none bg-white text-slate-800 font-bold cursor-pointer transition shadow-2xs"
                  >
                    {AVAILABLE_JURISDICTIONS.map(jur => (
                      <option key={jur.code} value={jur.code}>
                        {jur.name}
                      </option>
                    ))}
                  </select>
                  <p className="text-[10px] text-slate-500 italic">
                    {AVAILABLE_JURISDICTIONS.find(j => j.code === selectedJurisdiction)?.desc}
                  </p>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700">
                    Onboarding Journey Template <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={selectedJourneyId}
                    onChange={(e) => setSelectedJourneyId(e.target.value)}
                    className="w-full border border-slate-200 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 rounded-xl p-2.5 text-xs outline-none bg-white text-slate-800 font-bold cursor-pointer transition shadow-2xs"
                  >
                    {journeys.map(j => {
                      const count = (j as any).stages?.length || (j as any).phases?.length || j.steps?.length || 0;
                      return (
                        <option key={j.id} value={j.id}>
                          {j.name} ({count} Automated Stages)
                        </option>
                      );
                    })}
                  </select>
                  <p className="text-[10px] text-slate-500 italic truncate">
                    {journeys.find(j => j.id === selectedJourneyId)?.description || 'Configures compliance workflow steps.'}
                  </p>
                </div>
              </div>
            </div>

            {/* Section 3: Interested Financial Products */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-blue-50 border border-blue-100 text-blue-600 flex items-center justify-center shrink-0">
                    <CreditCard className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider font-mono">
                      3. Interested Financial Products <span className="text-rose-500">*</span>
                    </h4>
                    <p className="text-[11px] text-slate-500">Select commercial banking solutions to configure tailored documents & KYC tracks</p>
                  </div>
                </div>
                <span className="text-[10px] font-mono text-blue-700 font-bold bg-blue-50 border border-blue-200 px-2.5 py-1 rounded-full">
                  {selectedProducts.length} Selected
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                {AVAILABLE_PRODUCTS.map(prod => {
                  const isSelected = selectedProducts.includes(prod.id);
                  return (
                    <button
                      key={prod.id}
                      type="button"
                      onClick={() => toggleProduct(prod.id)}
                      className={`flex items-start gap-3 p-3.5 text-left border rounded-xl transition cursor-pointer ${
                        isSelected 
                          ? 'bg-blue-50/60 border-blue-500 text-slate-900 shadow-2xs' 
                          : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-slate-50/50'
                      }`}
                    >
                      <div className="mt-0.5 text-blue-600 shrink-0">
                        {isSelected ? (
                          <CheckSquare className="w-4 h-4 text-blue-600" />
                        ) : (
                          <Square className="w-4 h-4 text-slate-300" />
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <span className="text-xs font-bold block text-slate-900">{prod.name}</span>
                        <p className="text-[11px] text-slate-500 leading-snug mt-0.5">{prod.description}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2.5 p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 font-medium">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{error}</span>
              </div>
            )}
          </form>
        ) : (
          /* Step 2: Stages Execution Topography & Request for Confirmation */
          <div className="space-y-6">
            {/* Summary Highlights Card (RM Aesthetic) */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-blue-50 border border-blue-100 text-blue-600 flex items-center justify-center shrink-0">
                    <ShieldCheck className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <span className="text-xs font-mono font-bold text-slate-900 uppercase tracking-wider">
                      Client Onboarding Profile Summary
                    </span>
                    <p className="text-[11px] text-slate-500">Verified core attributes ready for orchestration</p>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 font-mono text-[10px] font-bold border border-emerald-200 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  Ready for RM Confirmation
                </span>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <span className="text-[10px] font-mono text-slate-400 block uppercase font-bold">Client Legal Entity</span>
                  <span className="font-bold text-slate-900 text-xs truncate block mt-0.5">{clientName}</span>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <span className="text-[10px] font-mono text-slate-400 block uppercase font-bold">Registration / LEI</span>
                  <span className="font-mono text-slate-700 font-bold block mt-0.5">{regNumber || 'Auto-generated'}</span>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <span className="text-[10px] font-mono text-slate-400 block uppercase font-bold">Jurisdiction</span>
                  <span className="font-bold text-blue-700 block mt-0.5">{selectedJurisdiction}</span>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <span className="text-[10px] font-mono text-slate-400 block uppercase font-bold">Signatory Contact</span>
                  <span className="text-slate-800 font-medium truncate block mt-0.5">{pocName || 'Authorized Signatory'}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 font-medium">Interested Products:</span>
                  <span className="font-bold text-slate-900 bg-slate-50 px-2 py-0.5 rounded border border-slate-200">
                    {AVAILABLE_PRODUCTS.filter(p => selectedProducts.includes(p.id)).map(p => p.name).join(', ')}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 font-medium">Journey Template:</span>
                  <span className="font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">{journeyName}</span>
                </div>
              </div>
            </div>

            {/* Execution Stages Topography Display */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-blue-50 border border-blue-100 text-blue-600 flex items-center justify-center shrink-0">
                    <Layers className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-mono font-bold text-slate-900 uppercase tracking-wider">
                      Execution Stages & Worker Topology
                    </h4>
                    <p className="text-[11px] text-slate-500">Dynamic agent fan-out and sequential dependency gates</p>
                  </div>
                </div>
                <span className="text-[10px] font-mono font-bold px-2.5 py-1 bg-blue-50 text-blue-700 rounded-full border border-blue-200">
                  {stageGroups.length} Execution Stages
                </span>
              </div>

              <div className="space-y-3">
                {stageGroups.map((group, idx) => (
                  <div 
                    key={idx} 
                    className={`p-4 rounded-xl border transition ${
                      group.mode === 'parallel'
                        ? 'bg-blue-50/40 border-blue-200 text-slate-900 shadow-2xs'
                        : 'bg-slate-50/70 border-slate-200 text-slate-800 shadow-2xs'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-mono font-bold uppercase tracking-wider flex items-center gap-2">
                        {group.mode === 'parallel' ? (
                          <span className="text-blue-700 flex items-center gap-2">
                            <GitBranch className="w-4 h-4 text-blue-600" />
                            <span>{group.name}</span>
                            <span className="text-[9px] bg-blue-100 text-blue-800 border border-blue-200 px-2 py-0.5 rounded-full font-bold font-mono">
                              PARALLEL FAN-OUT
                            </span>
                          </span>
                        ) : (
                          <span className="text-slate-800 flex items-center gap-2">
                            <span className="text-xs">⛓️</span>
                            <span>{group.name}</span>
                            <span className="text-[9px] bg-slate-200 text-slate-700 px-2 py-0.5 rounded-full font-bold font-mono">
                              SEQUENTIAL CHAIN
                            </span>
                          </span>
                        )}
                      </span>

                      <span className="text-[10px] font-mono text-slate-500 font-bold bg-white px-2 py-0.5 rounded border border-slate-200">
                        {group.steps.length} {group.steps.length === 1 ? 'Worker Agent' : 'Worker Agents'}
                      </span>
                    </div>

                    <div className={`grid gap-2.5 ${group.mode === 'parallel' ? 'grid-cols-1 sm:grid-cols-2' : 'grid-cols-1'}`}>
                      {group.steps.map((st, sIdx) => (
                        <div 
                          key={st.id || sIdx} 
                          className="p-3 rounded-lg border border-slate-200 bg-white text-xs font-medium flex items-center justify-between shadow-2xs"
                        >
                          <div className="flex items-center gap-2.5 truncate">
                            <div className="w-6 h-6 rounded-md bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 border border-blue-100">
                              <Bot className="w-3 h-3" />
                            </div>
                            <span className="truncate font-semibold text-slate-900">{st.name}</span>
                          </div>
                          <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-600 font-bold shrink-0 border border-slate-200">
                            {st.agentId}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Confirmation Box (RM Aesthetic) */}
            <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
              <div className="p-2 bg-amber-100 border border-amber-200 rounded-lg text-amber-800 shrink-0 mt-0.5">
                <Shield className="w-4 h-4" />
              </div>
              <div className="space-y-1 text-xs text-amber-950">
                <h5 className="font-bold uppercase font-mono tracking-wider text-amber-950 flex items-center gap-1.5">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                  RM Onboarding Execution Authorization
                </h5>
                <p className="leading-relaxed text-[11px] text-amber-900">
                  By clicking <strong>Confirm & Launch Execution</strong>, you confirm the client parameters above and authorize the system to start Stage 1 automated execution, issue customer outreach, and dispatch compliance audit logs.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Modal Sticky Footer Action Bar (RM Aesthetic) */}
      <div className="px-6 py-4 bg-white border-t border-slate-200 flex items-center justify-between shrink-0">
        {formStep === 1 ? (
          <>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold rounded-xl text-xs transition cursor-pointer shadow-2xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              form="journey-initiator-form"
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs transition shadow-xs flex items-center gap-2 cursor-pointer"
            >
              <span>Preview Execution Plan</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </>
        ) : (
          <>
            <button
              type="button"
              onClick={() => setFormStep(1)}
              className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5 shadow-2xs"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Edit Details</span>
            </button>
            <button
              type="button"
              onClick={handleConfirmAndLaunchExecution}
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs transition shadow-xs flex items-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Confirm & Launch Onboarding Execution</span>
            </button>
          </>
        )}
      </div>
    </div>
  );
}
