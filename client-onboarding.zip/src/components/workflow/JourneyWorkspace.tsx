import React, { useState, useEffect, useMemo } from 'react';
import { 
  Building2, 
  Play, 
  Mail, 
  Compass, 
  Users, 
  ShieldAlert, 
  TrendingUp, 
  Award,
  Lock,
  FileText,
  Eye,
  Plus,
  MapPin,
  CheckCircle2,
  FileCheck2,
  Clock
} from 'lucide-react';
import { ClientProfile, WorkflowNode, AppPersona, OrchestrationAgent, UploadedDocument } from '../../types';
import WorkflowGraph from './WorkflowGraph';
import NodeDetail from './NodeDetail';
import JourneyStepper from './JourneyStepper';
import StageVerifiedContent from './StageVerifiedContent';
import { Journey, DEFAULT_JOURNEYS } from '../common/PersonaSubviews';
import { DocumentViewerModal } from '../common/DocumentViewerModal';

interface JourneyWorkspaceProps {
  activeClient: ClientProfile;
  clients: ClientProfile[];
  selectedClientId: string;
  selectedNodeId: string;
  activeRunningNodeId?: string;
  isAutoProcessing: boolean;
  activePersona: AppPersona;
  agents: OrchestrationAgent[];
  handleSelectClient: (clientId: string) => void;
  setIsInitiatingJourney: (val: boolean) => void;
  handleSendOutreachEmail: (customClient?: ClientProfile) => void;
  handleTriggerAutonomousFlow: () => void;
  handleResetWorkflow: () => void;
  handleCleanupRMWorkspace?: () => void;
  setSelectedNodeId: (id: string) => void;
  handleAddDocument: (doc: any, targetClientId?: string) => void;
  handleDeleteDocument: (docId: string) => void;
  handleBiometricComplete: (score: number, photoUrl: string) => void;
  handleUpdateNode: (nodeId: string, updatedFields: Partial<WorkflowNode>, targetClientId?: string) => void;
  handleRunAutonomousNode: (nodeId: string, customClientId?: string) => Promise<boolean>;
  handleReorderNodes?: (reorderedNodes: WorkflowNode[], targetClientId?: string) => void;
}

export const JourneyWorkspace: React.FC<JourneyWorkspaceProps> = ({
  activeClient,
  clients,
  selectedClientId,
  selectedNodeId,
  activeRunningNodeId,
  isAutoProcessing,
  activePersona,
  agents,
  handleSelectClient,
  setIsInitiatingJourney,
  handleSendOutreachEmail,
  handleTriggerAutonomousFlow,
  handleResetWorkflow,
  handleCleanupRMWorkspace,
  setSelectedNodeId,
  handleAddDocument,
  handleDeleteDocument,
  handleBiometricComplete,
  handleUpdateNode,
  handleRunAutonomousNode,
  handleReorderNodes
}) => {
  const activeNode = activeClient.workflowNodes.find(n => n.id === selectedNodeId) || activeClient.workflowNodes[0];
  const isComplianceOfficer = activePersona === 'compliance_officer';
  const [viewingDocument, setViewingDocument] = useState<UploadedDocument | null>(null);
  const [showDependencyGraph, setShowDependencyGraph] = useState<boolean>(false);

  // Dynamic Journeys synchronization sourced from Platform Admin
  const [journeys, setJourneys] = useState<Journey[]>(() => {
    try {
      const saved = localStorage.getItem('onboarding_journeys');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // fallback
    }
    return DEFAULT_JOURNEYS;
  });

  useEffect(() => {
    const handleSync = () => {
      try {
        const saved = localStorage.getItem('onboarding_journeys');
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) {
            setJourneys(parsed);
            return;
          }
        }
      } catch {
        // fallback
      }
      setJourneys(DEFAULT_JOURNEYS);
    };

    window.addEventListener('onboarding_journeys_updated', handleSync);
    window.addEventListener('storage', handleSync);
    return () => {
      window.removeEventListener('onboarding_journeys_updated', handleSync);
      window.removeEventListener('storage', handleSync);
    };
  }, []);

  const activeJourney = useMemo(() => {
    const targetId = activeClient.journeyId || 'corporate_onboarding_journey';
    return journeys.find(j => j.id === targetId) || journeys[0] || DEFAULT_JOURNEYS[0];
  }, [journeys, activeClient.journeyId]);

  const activeJourneyStages = useMemo(() => {
    return (activeJourney.stages && activeJourney.stages.length > 0)
      ? activeJourney.stages
      : (activeJourney.phases && activeJourney.phases.length > 0)
      ? activeJourney.phases
      : DEFAULT_JOURNEYS[0].stages || [];
  }, [activeJourney]);

  // Clean and format stage titles
  const cleanStageName = (rawName: string, index: number): string => {
    if (!rawName) return `Stage ${index + 1}`;
    let cleaned = rawName.replace(/^(STAGE|PHASE|STEP)\s*\d+[\s:\-–—]*/i, '').trim();
    if (cleaned.length > 3 && cleaned === cleaned.toUpperCase()) {
      cleaned = cleaned
        .toLowerCase()
        .split(' ')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
    }
    return cleaned || rawName;
  };

  const selectedStageIndex = useMemo(() => {
    const idxById = activeJourneyStages.findIndex(s => s.id === selectedNodeId);
    if (idxById >= 0) return idxById;
    const nodeIdx = activeClient.workflowNodes.findIndex(n => n.id === selectedNodeId);
    return nodeIdx >= 0 ? nodeIdx : 0;
  }, [activeJourneyStages, selectedNodeId, activeClient.workflowNodes]);

  const currentStage = activeJourneyStages[selectedStageIndex];
  const currentStageName = currentStage ? cleanStageName(currentStage.name, selectedStageIndex) : (activeNode?.name || `Stage ${selectedStageIndex + 1}`);
  const currentStageDesc = currentStage?.description || activeNode?.description;

  // Card 1 Metadata and Progress Computation
  const isMeridian = activeClient.id === 'client_meridian' || activeClient.companyName?.toLowerCase().includes('meridian');
  const caseReference = isMeridian ? 'ONB-2025-8841' : (activeClient.id === 'client_apex' ? 'ONB-2025-9102' : activeClient.id === 'client_aethelgard' ? 'ONB-2025-9430' : `ONB-2025-${activeClient.registrationNumber?.slice(-4) || '8841'}`);
  const leiNumber = isMeridian ? '5493001KJTIIGC8Y1R12' : ((activeClient as any).lei || '5493001KJTIIGC8Y1R12');
  const clientManager = 'Sarah Jenkins (Senior Director, Institutional Coverage)';
  const targetGoLive = isMeridian ? '2025-03-31' : ((activeClient as any).targetLive || '2025-03-31');
  const overallPercentage = isMeridian ? 48 : Math.round((activeClient.workflowNodes.filter(n => n.status === 'completed').length / Math.max(1, activeClient.workflowNodes.length)) * 100);
  const daysElapsed = isMeridian ? 14 : (activeClient.id === 'client_apex' ? 22 : (activeClient.id === 'client_aethelgard' ? 8 : 12));
  const journeyStartDate = isMeridian ? 'Feb 24, 2025' : (activeClient.id === 'client_apex' ? 'Feb 16, 2025' : (activeClient.id === 'client_aethelgard' ? 'Mar 2, 2025' : 'Feb 26, 2025'));

  return (
    <>
      {/* CARD 1: ACTIVE CLIENT JOURNEY & OVERALL ONBOARDING */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 mb-6 shadow-xs">
        {/* Top Header Row: Reference, Active Status, Jurisdiction & Active Journey Switcher */}
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div className="flex flex-wrap items-center gap-2.5">
            <span className="font-mono text-xs font-bold px-2.5 py-1 rounded-lg bg-slate-100 text-slate-800 border border-slate-200">
              {caseReference}
            </span>

            <span className="inline-flex items-center gap-1.5 text-xs font-bold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Active Client Journey
            </span>

            <div className="flex items-center gap-1.5 text-xs font-medium text-slate-500">
              <MapPin className="w-3.5 h-3.5 text-slate-400" />
              <span>{activeClient.jurisdiction}</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono text-slate-400 font-bold uppercase tracking-wide">Active Journey:</span>
            <select
              value={selectedClientId}
              onChange={(e) => handleSelectClient(e.target.value)}
              className="border border-slate-200 bg-white rounded-lg px-2.5 py-1 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 cursor-pointer"
            >
              {clients.map((c, idx) => (
                <option key={`${c.id}_${idx}`} value={c.id}>
                  {c.companyName}
                </option>
              ))}
            </select>
            {!isComplianceOfficer && (
              <button
                type="button"
                onClick={() => setIsInitiatingJourney(true)}
                className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-xs transition flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" /> Initiate Onboarding Journey
              </button>
            )}
          </div>
        </div>

        {/* Main Entity Details & Overall Onboarding Section */}
        <div className="pt-4 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          {/* Left: Entity Name & Metadata */}
          <div className="flex-1 min-w-0 space-y-2">
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
              {activeClient.companyName}
            </h1>

            <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1.5 text-xs text-slate-600">
              <span className="font-mono text-slate-700">
                <span className="text-slate-400 font-normal">LEI: </span>
                <strong className="font-semibold text-slate-800">{leiNumber}</strong>
              </span>
              <span className="text-slate-300">·</span>
              <span className="text-slate-700">
                <span className="text-slate-400 font-normal">Client Manager: </span>
                <strong className="font-semibold text-slate-800">{clientManager}</strong>
              </span>
              <span className="text-slate-300">·</span>
              <span className="text-slate-700">
                <span className="text-slate-400 font-normal">Target Go-Live: </span>
                <strong className="font-semibold text-slate-800">{targetGoLive}</strong>
              </span>
            </div>
          </div>

          {/* Right: Overall Onboarding Card */}
          <div className="w-full lg:w-96 shrink-0 bg-slate-50/90 border border-slate-200/90 rounded-xl p-4 shadow-2xs">
            {/* Top Label */}
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-slate-700 uppercase font-mono tracking-wider">
                Overall Onboarding
              </span>
              <span className="text-[11px] font-mono text-slate-500 font-medium">
                {activeClient.workflowNodes.filter(n => n.status === 'completed').length} of {activeClient.workflowNodes.length} Stages
              </span>
            </div>

            {/* Main Progress Row with Round Progress Bar & Days Elapsed */}
            <div className="flex items-center gap-4 py-1">
              {/* Round Progress Bar */}
              <div className="relative w-20 h-20 shrink-0 flex items-center justify-center">
                <svg className="w-20 h-20 -rotate-90" viewBox="0 0 80 80">
                  <circle
                    cx="40"
                    cy="40"
                    r="33"
                    stroke="currentColor"
                    strokeWidth="6"
                    fill="transparent"
                    className="text-slate-200"
                  />
                  <circle
                    cx="40"
                    cy="40"
                    r="33"
                    stroke="currentColor"
                    strokeWidth="6"
                    fill="transparent"
                    strokeDasharray={2 * Math.PI * 33}
                    strokeDashoffset={2 * Math.PI * 33 - (overallPercentage / 100) * (2 * Math.PI * 33)}
                    strokeLinecap="round"
                    className="text-blue-600 transition-all duration-700 ease-out"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                  <span className="text-lg font-black text-slate-900 font-mono leading-none">
                    {overallPercentage}%
                  </span>
                  <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider mt-0.5">
                    Complete
                  </span>
                </div>
              </div>

              {/* Journey Duration Stats */}
              <div className="flex-1 min-w-0 space-y-1">
                <div className="flex items-center gap-1.5 text-xs text-slate-700">
                  <Clock className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  <span>Started <strong className="font-bold text-slate-900 font-mono">{daysElapsed} days</strong> ago</span>
                </div>
                <div className="text-[11px] text-slate-500 pl-5">
                  Launch Date: <span className="font-mono text-slate-700 font-medium">{journeyStartDate}</span>
                </div>
              </div>
            </div>

            {/* Bottom: On-Track for Q1 Target */}
            <div className="mt-3 pt-2.5 border-t border-slate-200/80 flex items-center justify-between">
              <span className="text-[11px] font-medium text-slate-500">Milestone Pace</span>
              <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                On-Track for Q1 Target
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* CARD 2: ONBOARDING STAGES */}
      <JourneyStepper 
        nodes={activeClient.workflowNodes}
        selectedNodeId={selectedNodeId}
        onSelectNode={setSelectedNodeId}
        activeRunningNodeId={activeRunningNodeId}
        onReorderNodes={(newNodes) => handleReorderNodes?.(newNodes, activeClient.id)}
        activeClient={activeClient}
        showDependencyGraph={showDependencyGraph}
        onToggleDependencyGraph={setShowDependencyGraph}
      />

      {isComplianceOfficer ? (
        /* COMPLIANCE & RISK OFFICER REARRANGED LAYOUT */
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
          {/* LEFT COLUMN: Stage Verified Content / Dependency Graph, Corporate Registry, etc. (xl:col-span-7) */}
          <div className="xl:col-span-7 flex flex-col gap-6">
            
            {/* BY DEFAULT: DISPLAY VERIFIED CONTENT FOR EACH STAGE; VISUAL GRAPH SHOWN BY CLICKING BUTTON */}
            {!showDependencyGraph ? (
              <StageVerifiedContent
                client={activeClient}
                selectedNode={activeNode || activeClient.workflowNodes[0]}
                stageIndex={selectedStageIndex}
                totalStages={activeJourneyStages.length}
                stageName={currentStageName}
                stageDescription={currentStageDesc}
                onViewDocument={(doc) => setViewingDocument(doc)}
                onShowGraph={() => setShowDependencyGraph(true)}
                onTriggerOutreach={() => handleSendOutreachEmail()}
              />
            ) : (
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 mb-4 gap-2">
                  <div className="flex items-center gap-2">
                    <Compass className="w-5 h-5 text-blue-600" />
                    <div>
                      <h2 className="font-bold text-slate-900 text-sm">Visual Dependency Graph &amp; Processing Flow</h2>
                      <p className="text-[10px] font-mono text-slate-400 uppercase">CONNECTED WORKFLOW DAG &bull; DYNAMIC SEQUENCE DEPENDENCIES</p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowDependencyGraph(false)}
                    className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer self-start sm:self-auto shadow-2xs"
                  >
                    <FileCheck2 className="w-3.5 h-3.5 text-blue-600" />
                    <span>Show Verified Stage Content (Default)</span>
                  </button>
                </div>

                <WorkflowGraph
                  nodes={activeClient.workflowNodes}
                  selectedNodeId={selectedNodeId}
                  onSelectNode={(id) => setSelectedNodeId(id)}
                  activeNodeId={activeRunningNodeId}
                />
              </div>
            )}

            {/* Compliance Query to RM Banner */}
            <div className="bg-gradient-to-r from-amber-50/80 via-blue-50/40 to-slate-50/10 border border-amber-200/60 rounded-xl p-4.5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-amber-500/10 text-amber-600 rounded-lg shrink-0 mt-0.5">
                  <Mail className="w-4.5 h-4.5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-800">Compliance Query & RM Escalation Dispatch</h4>
                  <p className="text-[11px] text-slate-500 mt-1 leading-normal max-w-xl">
                    Initiate formal compliance query, document escalation, or risk review notice directly to the assigned Relationship Manager for <strong className="text-slate-700">{activeClient.companyName}</strong>.
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => handleSendOutreachEmail()}
                  className="w-full sm:w-auto px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold tracking-wider transition shadow-sm cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Mail className="w-3.5 h-3.5" /> Initiate Email to RM
                </button>
              </div>
            </div>

            {/* Ingested Document Vault Panel (Compliance View) */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
              <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
                <h3 className="font-bold text-slate-900 text-xs uppercase tracking-wider font-mono flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-blue-500" />
                  Ingested Verification Documents ({activeClient.documents?.length || 0})
                </h3>
                <span className="text-[10px] font-mono text-slate-400">CLICK TO INSPECT FILE CONTENTS</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {activeClient.documents && activeClient.documents.length > 0 ? (
                  activeClient.documents.map((doc) => (
                    <div 
                      key={doc.id}
                      onClick={() => setViewingDocument(doc)}
                      className="p-3.5 rounded-xl border border-slate-200 bg-white hover:border-blue-400 hover:bg-slate-50 transition-all cursor-pointer group flex items-center justify-between gap-3 shadow-2xs"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="p-2 rounded-lg bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors shrink-0">
                          <FileText className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <h5 className="text-xs font-bold text-slate-900 truncate group-hover:text-blue-600 transition-colors">
                            {doc.name}
                          </h5>
                          <span className="text-[10px] text-slate-400 font-mono block truncate">
                            {doc.type} • {doc.size}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-bold uppercase ${
                          doc.status === 'verified' ? 'bg-emerald-100 text-emerald-800' :
                          doc.status === 'rejected' ? 'bg-rose-100 text-rose-800' :
                          'bg-amber-100 text-amber-800'
                        }`}>
                          {doc.status}
                        </span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setViewingDocument(doc);
                          }}
                          className="px-2 py-1 rounded bg-blue-600 hover:bg-blue-700 text-white text-[10px] font-bold transition flex items-center gap-1 cursor-pointer"
                        >
                          <Eye className="w-3 h-3" />
                          <span>View</span>
                        </button>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="col-span-2 text-xs text-slate-400 italic text-center py-4">No documents submitted yet.</p>
                )}
              </div>
            </div>

          </div>

          {/* RIGHT COLUMN: Node Detail & Compliance Sign-off Panel (xl:col-span-5) */}
          <div className="xl:col-span-5 h-full sticky top-24">
            {activeNode ? (
              <NodeDetail
                node={activeNode}
                client={activeClient}
                activePersona={activePersona}
                onUpdateNode={handleUpdateNode}
                onRunAutonomousNode={handleRunAutonomousNode}
                onTriggerAutonomousFlow={handleTriggerAutonomousFlow}
                isProcessing={activeRunningNodeId === activeNode.id}
                agents={agents}
              />
            ) : (
              <div className="bg-white rounded-xl border border-slate-200 p-6 text-center text-slate-400 italic">
                Select a stage in the onboarding stepper above to inspect compliance logs and perform supervisor sign-offs.
              </div>
            )}
          </div>
        </div>
      ) : (
        /* STANDARD LAYOUT FOR OTHER PERSONAS */
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
          <div className="xl:col-span-8 flex flex-col gap-6">
            {/* BY DEFAULT: DISPLAY VERIFIED CONTENT FOR EACH STAGE; VISUAL GRAPH SHOWN BY CLICKING BUTTON */}
            {!showDependencyGraph ? (
              <StageVerifiedContent
                client={activeClient}
                selectedNode={activeNode || activeClient.workflowNodes[0]}
                stageIndex={selectedStageIndex}
                totalStages={activeJourneyStages.length}
                stageName={currentStageName}
                stageDescription={currentStageDesc}
                onViewDocument={(doc) => setViewingDocument(doc)}
                onShowGraph={() => setShowDependencyGraph(true)}
                onTriggerOutreach={() => handleSendOutreachEmail()}
              />
            ) : (
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 mb-4 gap-2">
                  <div className="flex items-center gap-2">
                    <Compass className="w-5 h-5 text-blue-600" />
                    <div>
                      <h2 className="font-bold text-slate-900 text-sm">Visual Dependency Graph &amp; Processing Flow</h2>
                      <p className="text-[10px] font-mono text-slate-400 uppercase">CONNECTED WORKFLOW DAG &bull; DYNAMIC SEQUENCE DEPENDENCIES</p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowDependencyGraph(false)}
                    className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer self-start sm:self-auto shadow-2xs"
                  >
                    <FileCheck2 className="w-3.5 h-3.5 text-blue-600" />
                    <span>Show Verified Stage Content (Default)</span>
                  </button>
                </div>

                <WorkflowGraph
                  nodes={activeClient.workflowNodes}
                  selectedNodeId={selectedNodeId}
                  onSelectNode={(id) => setSelectedNodeId(id)}
                  activeNodeId={activeRunningNodeId}
                />
              </div>
            )}

            {/* Ingested Document Vault Panel (RM / Platform Admin / Operations View) */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
              <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-blue-500" />
                  <h3 className="font-bold text-slate-900 text-xs uppercase tracking-wider font-mono">
                    Ingested Verification Documents ({activeClient.documents?.length || 0})
                  </h3>
                </div>
                <span className="text-[10px] font-mono text-slate-400">READ-ONLY SECURE VIEWER</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {activeClient.documents && activeClient.documents.length > 0 ? (
                  activeClient.documents.map((doc) => (
                    <div 
                      key={doc.id}
                      onClick={() => setViewingDocument(doc)}
                      className="p-3.5 rounded-xl border border-slate-200 bg-white hover:border-blue-400 hover:bg-slate-50 transition-all cursor-pointer group flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="p-2 rounded-lg bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors shrink-0">
                          <FileText className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <h5 className="text-xs font-bold text-slate-900 truncate group-hover:text-blue-600 transition-colors">
                              {doc.name}
                            </h5>
                            <span className={`px-1.5 py-0.5 rounded text-[8px] font-mono font-bold uppercase tracking-wider ${
                              doc.source === 'externally_sourced' 
                                ? 'bg-emerald-100 text-emerald-700 border border-emerald-200' 
                                : 'bg-blue-100 text-blue-700 border border-blue-200'
                            }`}>
                              {doc.source === 'externally_sourced' ? '🌐 Externally Sourced' : '👤 Customer Provided'}
                            </span>
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono block truncate mt-0.5">
                            {doc.type} • {doc.size} {doc.sourceDetails ? `• ${doc.sourceDetails}` : ''}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-center">
                        <span className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-bold uppercase ${
                          doc.status === 'verified' ? 'bg-emerald-100 text-emerald-800' :
                          doc.status === 'rejected' ? 'bg-rose-100 text-rose-800' :
                          'bg-amber-100 text-amber-800'
                        }`}>
                          {doc.status}
                        </span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setViewingDocument(doc);
                          }}
                          className="px-2.5 py-1 rounded bg-blue-600 hover:bg-blue-700 text-white text-[10px] font-bold transition flex items-center gap-1 cursor-pointer shadow-xs"
                        >
                          <Eye className="w-3 h-3" />
                          <span>View</span>
                        </button>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="col-span-2 text-xs text-slate-400 italic text-center py-4">No documents submitted yet.</p>
                )}
              </div>
            </div>
          </div>

          <div className="xl:col-span-4 h-full sticky top-24">
            {activeNode ? (
              <NodeDetail
                node={activeNode}
                client={activeClient}
                activePersona={activePersona}
                onUpdateNode={handleUpdateNode}
                onRunAutonomousNode={handleRunAutonomousNode}
                onTriggerAutonomousFlow={handleTriggerAutonomousFlow}
                isProcessing={activeRunningNodeId === activeNode.id}
                agents={agents}
              />
            ) : (
              <div className="bg-white rounded-xl border border-slate-200 p-6 text-center text-slate-400 italic">
                Select a node in the workflow graph to inspect logs and perform compliance sign-offs.
              </div>
            )}
          </div>
        </div>
      )}

      {/* CENTRAL REACT DOCUMENT VIEWER MODAL (READ ONLY, NO DOWNLOAD) */}
      <DocumentViewerModal
        document={viewingDocument}
        isOpen={Boolean(viewingDocument)}
        onClose={() => setViewingDocument(null)}
        readOnly={false}
        userRole={isComplianceOfficer ? 'compliance' : 'rm'}
        onApprove={(docId) => {
          handleAddDocument?.(
            activeClient.documents.find(d => d.id === docId)
              ? { ...activeClient.documents.find(d => d.id === docId)!, status: 'verified' }
              : null,
            activeClient.id
          );
          setViewingDocument(null);
        }}
        onReject={(docId) => {
          handleDeleteDocument?.(docId);
          setViewingDocument(null);
        }}
      />
    </>
  );
};

export default JourneyWorkspace;
