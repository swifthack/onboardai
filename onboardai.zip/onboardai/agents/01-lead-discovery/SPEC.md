# Agent 1 — Lead Discovery Agent

Read [`shared/ARCHITECTURE.md`](../../shared/ARCHITECTURE.md) first — this
spec assumes the event envelope, Digital Twin schema, field-provenance
convention, and stub-adapter convention defined there.

## Purpose

Enrich every incoming lead before an RM looks at it, so the first RM
touchpoint starts from a company summary, a propensity read, and known
internal relationships — never a blank name and email. Target turnaround:
under 2 minutes from `LEAD_SUBMITTED` to `LEAD_ENRICHED`, since this runs
ahead of a live RM conversation in the common case (conference upload,
inbound web form) and the RM is often looking at the record within minutes.

## Position in the mesh

This is the entry point of the entire mesh — the only agent that fires on
an event (`LEAD_SUBMITTED`) that precedes a `client_id` existing.

```
LEAD_SUBMITTED  (no client_id yet)
      │
      ▼
[1] Lead Discovery Agent
      │  creates clients row, runs enrichment, writes candidate entities row
      ▼
LEAD_ENRICHED + ENTITY_CREATED  (client_id now exists)
      │
      ▼
[2] Entity Resolution Agent
```

**Handoff note for Agent 2** (flagging, not deciding — this belongs in
Agent 2's spec): Agent 1 publishes `ENTITY_CREATED` for the *candidate*
entity it derived from the lead's company name — unresolved, potentially a
duplicate of something already in the Knowledge Graph. Agents 3–8 are
specced to trigger off `ENTITY_CREATED` too, but the interaction map has
them firing only after Agent 2 has run (`[2] → Knowledge Graph →
[3][4][5][6][7][8]`). Two ways to reconcile this, both workable, and the
choice belongs to Agent 2's spec: (a) Agent 2 re-publishes `ENTITY_CREATED`
on the resolved entity once it confirms new-vs-duplicate, and 3–8 are
written to ignore a candidate's *first* `ENTITY_CREATED` and only act on
the one Agent 2 emits; or (b) Agent 1's candidate event is named something
else (e.g. `ENTITY_CANDIDATE_PROPOSED`) and only Agent 2's output is ever
called `ENTITY_CREATED`. This spec uses `ENTITY_CREATED` for Agent 1's
output to stay literal to the given trigger list, but (b) is cleaner and
worth revisiting when Agent 2 is specced.

## Trigger & subscribed events

| Event | Source | Notes |
|---|---|---|
| `LEAD_SUBMITTED` | CRM entry, web form, conference upload, broker referral, fund directory match | Payload shape below. This is the only trigger — Agent 1 does not run on a schedule or re-fire on existing clients. |

Input payload (what a producer must supply — CRM/web-form/upload
integrations are outside this agent's scope, but this is the contract they
write to):

```json
{
  "event_type": "LEAD_SUBMITTED",
  "correlation_id": "uuid",
  "payload": {
    "source": "crm_entry | web_form | conference_upload | broker_referral | fund_directory_match",
    "company_name": "string, required",
    "jurisdiction_hint": "ISO 3166-1 alpha-2 | null",
    "contact_name": "string | null",
    "contact_email": "string | null",
    "product_interest_hint": ["casa","digital_asset_custody","markets","trade_finance", "..."] ,
    "submitted_by_rm": "rm_id | null",
    "raw_notes": "string | null"
  }
}
```

`company_name` is the only hard requirement. Everything else narrows the
enrichment but the pipeline degrades gracefully without it (see §
Confidence & data-quality rules).

## Data sources & adapters

All adapters implement `SourceAdapter` from ARCHITECTURE.md §5. Stub mode
for every source in this pass (per build decision) — table below notes
which sources are realistically free/keyless and could go live first once
code is built.

| Adapter | Used for | Live-mode reality check |
|---|---|---|
| `crunchbase_adapter` | Company profile, funding history, estimated revenue band | Paid API (Crunchbase Enterprise). Stub only until licensed. |
| `pitchbook_adapter` | AUM (for funds/asset managers), investor relationships, deal history | Paid, enterprise-only licensing. Stub only. |
| `bloomberg_company_search_adapter` | Financials for listed/large private companies, credit signals | Requires Bloomberg Terminal/B-PIPE entitlement. Stub only. |

| `news_api_adapter` | Recent press mentions, funding announcements, leadership changes | Several viable free/cheap tiers (NewsAPI.org, GDELT DOC API — already integrated in `adversemedia/mlp`, worth reusing directly rather than a new adapter). Could go live early. |
| `gleif_adapter` | LEI lookup — resolves legal name/jurisdiction ambiguity before it reaches Agent 2 | **Free, keyless.** GLEIF's LEI search API has no auth requirement — candidate for live mode from day one. |
| `bank_crm_adapter` | Existing relationship check: is this company, or any known affiliate/contact, already in the bank's CRM | Internal system — "stub" here means a mocked internal API shape, not a licensing gap. This is the one adapter that should go live first in the real build, since it's the source of the "known banking relationships" output field and has no external dependency. |

## Processing pipeline

1. **Normalize input.** Trim/case-fold `company_name`, resolve
   `jurisdiction_hint` to ISO 3166-1 alpha-2 if given as free text.
2. **Cheap replay guard.** Check for a `clients` row created from a
   `LEAD_SUBMITTED` with a fuzzy-matching `company_name` (pg_trgm
   similarity) in the last 24h — if found, treat this as a duplicate
   submission and re-fire `LEAD_ENRICHED` from the existing record instead
   of creating a new client. This is *not* entity resolution (Agent 2 owns
   that, against the full Knowledge Graph, permanently) — it's narrowly
   scoped to stop the same conference-badge-scan or double-submitted web
   form from spawning two client records in the same day.
3. **Create `clients` row** (`stage = 'lead'`) — this is what gives every
   subsequent step a `client_id` to attach to.
4. **Parallel adapter queries**: `crunchbase_adapter`, `pitchbook_adapter`,
   `bloomberg_company_search_adapter`, `linkedin_adapter`,
   `news_api_adapter`, `gleif_adapter`, `bank_crm_adapter` — all called
   concurrently, each with its own timeout (suggest 8s) so one slow/dead
   source doesn't block the 2-minute target.
5. **Reconcile into a company summary.** LLM synthesis step, grounded only
   in the structured `AdapterResult` payloads from step 4 — same
   grounding discipline as the adverse-media chain (no field asserted that
   isn't traceable to a specific adapter's `data`). Where adapters
   disagree (e.g. Crunchbase and Bloomberg give different revenue
   figures), keep both, tag each with its source, don't silently pick one.
6. **Estimate AUM/revenue.** Prefer Pitchbook/Bloomberg point figures where
   available (fund AUM, public financials). Where nothing but funding-round
   data exists (Crunchbase), output a *band*, not a point estimate (e.g.
   `"$10M-$50M revenue (inferred from Series B raise size)"`), and mark
   confidence in the inferred band, not the funding-round-amount band.
7. **Product propensity score.** See § Scoring/reasoning logic.
8. **Known banking relationships.** From `bank_crm_adapter`: does this
   legal entity, or any individual named as `contact_name` / found via
   LinkedIn leadership data, already exist as a client, prospect, or prior
   applicant in the CRM. This is also a cheap early duplicate-client signal
   worth surfacing to the RM even though it isn't a substitute for Agent
   2's formal resolution.
9. **RM talking points.** LLM generation, grounded in the structured
   output of steps 5–8 only (no re-querying the open web inside this
   step) — 3–5 bullets, each tagged with which field it draws from, so an
   RM can trace "why is the model telling me this."
10. **Write outputs**: candidate `entities` row, `field_provenance` rows
    for every enriched fact (§ Digital Twin writes), then publish events.

## Output & published events

```json
{
  "event_type": "LEAD_ENRICHED",
  "client_id": "uuid",
  "correlation_id": "uuid",
  "producer_agent": "lead-discovery-agent",
  "confidence": 0.0,
  "payload": {
    "company_summary": "string, 2-4 sentences, cites source per claim",
    "estimated_financials": {
      "type": "aum | revenue",
      "value_or_band": "string",
      "basis": "string — which adapter/signal this is inferred from",
      "confidence": 0.0
    },
    "product_propensity": {
      "score": 0,
      "band": "low | medium | high",
      "top_signals": [{"signal": "string", "weight": 0.0}]
    },
    "known_banking_relationships": [
      {"relationship_type": "existing_client | prior_prospect | affiliate_is_client",
       "detail": "string", "confidence": 0.0}
    ],
    "rm_talking_points": ["string", "..."],
    "source_coverage": {"crunchbase": "hit|miss|stub", "pitchbook": "...", "...": "..."}
  }
}
```

```json
{
  "event_type": "ENTITY_CREATED",
  "client_id": "uuid",
  "correlation_id": "uuid",
  "producer_agent": "lead-discovery-agent",
  "payload": {
    "entity_id": "uuid",
    "legal_name_candidate": "string",
    "jurisdiction_candidate": "ISO 3166-1 alpha-2 | null",
    "gleif_lei": "string | null"
  }
}
```

## Digital Twin writes

- `clients` — one row, `stage = 'lead'`.
- `entities` — one candidate row, `is_primary = true`, only the fields
  observed at this stage populated (`legal_name`, best-effort
  `incorporation_jurisdiction`, `lei` if GLEIF resolved it). Everything
  else (registration number, directors, address) is Agent 3's job, not
  this agent's — Agent 1 does not call any corporate registry API.
- `field_provenance` — one row per enriched fact (company summary claims,
  financial estimate, propensity score inputs), each tagged with the
  producing adapter as `source_system` and this agent as `source_agent`.
- `events` — `LEAD_ENRICHED`, `ENTITY_CREATED`.

## Scoring/reasoning logic — product propensity

A rubric, not a single opaque LLM number — this score has to be
defensible to an RM who asks "why medium and not high." Weighted sum,
0–100, components re-normalized over whichever signals are actually
available (missing signals don't silently drag the score down, they widen
the confidence interval instead — see next section):

| Signal | Weight | How derived |
|---|---|---|
| Stated product interest match | 30% | `product_interest_hint` overlap with the bank's active product suite — **open question, needs the actual product list**, see below |
| Company maturity/size band | 25% | Funding stage (Crunchbase) or AUM band (Pitchbook) mapped to a maturity curve — very early-stage and very large-listed both typically score lower propensity for a mid-market relationship bank than the growth/scale-up band |
| Digital asset activity evidence | 20% | Explicit mentions in news/LinkedIn of on-chain treasury, stablecoin usage, tokenization activity, VASP licensing — proxies future Layer 5 product fit |
| Existing internal relationship | 15% | Warm (existing contact/affiliate in CRM) scores higher than fully cold |
| Comparable-client cohort signal | 10% | Placeholder weight — **there is no historical win-rate data yet** to drive this; starts neutral (contributes 0 either direction) until Agent 47 (Cross-Sell Intelligence, later phase) or a feedback loop from actual conversion outcomes exists to calibrate it |

`band` is a direct threshold on `score` (suggest low <40, medium 40–70,
high >70) — configurable, not hardcoded, since risk appetite / product
strategy owns this threshold, not the agent.

## Confidence & data-quality rules

Per ARCHITECTURE.md §3 bands, source-specific:

| Source | Typical confidence |
|---|---|
| `gleif_adapter` (LEI match) | 0.95+ (registry-grade, exact match) |
| `bank_crm_adapter` | 0.90+ (bank's own system of record) |
| `bloomberg_company_search_adapter` | 0.75–0.85 |
| `crunchbase_adapter` / `pitchbook_adapter` / `linkedin_adapter` | 0.60–0.79 |
| `news_api_adapter` (unstructured mention → structured fact) | 0.40–0.59 |

The event-level `confidence` on `LEAD_ENRICHED` is the data-completeness
read, not the propensity score's confidence — i.e. "how much of this
profile is real signal vs. gaps," computed as the share of adapters that
returned `found: true` weighted by their table above. A lead enriched from
`bank_crm_adapter` + `gleif_adapter` alone (both high-confidence sources)
but nothing else should still report a *lower* event confidence than one
where 5/7 adapters hit, even though the two sources that did hit are
individually trustworthy — completeness and per-field trust are separate
axes and both matter to an RM deciding how much to lean on this.

## Known v1 limitations

- All external paid sources (Crunchbase, Pitchbook, Bloomberg) are stub-only
  in this pass — realistic fixtures, clearly marked `_stub: true`, but not
  real data. `bank_crm_adapter` and `gleif_adapter` are the two adapters
  worth wiring live first when code is built.
- `linkedin_adapter` cannot literally be LinkedIn's own API for
  company-search/enrichment at any budget — the real build needs a named
  data-vendor decision (Proxycurl/Coresignal/similar), not a LinkedIn
  developer credential.
- AUM/revenue for private, unlisted companies is frequently unavailable
  from any of these sources at all — the pipeline must degrade to
  `"insufficient data"` rather than fabricate a figure, and that case
  needs to visibly lower the `LEAD_ENRICHED` confidence, not just omit the
  field silently.
- Product propensity's cohort-comparison term has no real weight behind it
  yet (no conversion history to learn from) — it's a placeholder in the
  rubric on purpose, not an oversight.
- The 24h replay guard (step 2) is a cheap heuristic, not entity
  resolution — it will miss a duplicate submitted under a materially
  different name variant, and that's fine because Agent 2 is the real
  backstop.

## Open questions

1. **Product suite list** — the propensity rubric's highest-weighted
   signal (30%) needs the bank's actual active product catalogue to map
   `product_interest_hint` against. Placeholder in this spec; needs a real
   list before the scoring logic can be implemented, not just specced.
2. **Conference-upload format** — is this structured (CSV/vCard export
   from a badge scanner) or images requiring OCR before `company_name`
   etc. can even be extracted? Changes whether Document Intelligence
   (Agent 10) is a dependency of Agent 1 for that one source, or whether
   conference uploads are pre-normalized before they ever reach
   `LEAD_SUBMITTED`.
3. **Relationship-check scope** — should `bank_crm_adapter`'s existing-
   relationship check look only at the submitted legal entity, or also
   sweep affiliated entities/individuals (parent company, known
   directors)? The latter is more useful but overlaps with Agent 8's job
   and shouldn't be duplicated without a clear boundary.
4. **SLA** — is the 2-minute target real, or does conference-upload
   (batch, post-event) tolerate a much looser SLA than an inbound web-form
   lead (where an RM may be live with the prospect)? Affects whether
   adapter timeouts should differ by `source`.
