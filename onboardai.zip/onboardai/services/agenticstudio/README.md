# AgenticStudio

Node/Express service — backend for the Nexum **Process Flow matrix**
(P-01..P-27) and the 19 agents that implement it. Backed by Postgres.
Reference data (which agents belong to which pipeline, and each
pipeline's ordered steps) is seeded from a single catalog file; pipeline
*execution* is a generic engine that walks that data and calls each
step's agent, persisting run/step state and an event trail.

## Local dev

```bash
docker compose up -d        # starts Postgres on localhost:55441
cp .env.example .env
npm install
npm run db:init              # applies db/schema.sql
npm run db:seed              # loads db/seed/catalog.js (19 agents, 27 pipelines)
npm run dev                  # http://localhost:4001
```

## API

| Method & path | Purpose |
|---|---|
| `GET /health` / `GET /health/ready` | liveness / readiness (checks Postgres) |
| `GET /agents` | list all agents (the 19 seeded KYC-mesh agents plus any created via the API) |
| `GET /agents/:id` | agent detail + every pipeline it participates in (role/scope differ per pipeline) |
| `POST /agents` | create — body `{ id?, name, config? }`; `config` is an opaque bag for whatever shape the caller wants (the frontend's Agent Studio stores its full rich agent model here) |
| `PUT /agents/:id` | update `name`/`config` (whole `config` object replaces the existing one when provided) |
| `DELETE /agents/:id` | delete — `409` if the agent is still referenced by a pipeline's step/agent list |
| `GET /pipelines` | list all 27 pipelines, `P-01`..`P-27` |
| `GET /pipelines/topology` | pipelines grouped by topology stage (Prospecting, Entity Graph, ... Activation) |
| `GET /pipelines/:id` | full spec: role, in/out scope, associated agents, ordered steps |
| `GET /pipelines/:id/runs` | run history for one pipeline |
| `POST /pipelines/:id/runs` | execute the pipeline now — body `{ input?, clientId? }` |
| `GET /runs/:id` | a single run (any pipeline) with all step results |
| `GET /guardrail-domains` | list the 13 guardrail domains, each with its guardrail count |
| `GET /guardrail-domains/:id` | domain detail + its full guardrail list |
| `POST /guardrail-domains` | create a domain — body `{ id, name, description, sequence? }` |
| `PUT /guardrail-domains/:id` | update a domain's name/description/sequence |
| `DELETE /guardrail-domains/:id` | delete a domain — `409` if any guardrail still references it |
| `GET /guardrails` | list guardrails — filter with `?domain=<id>` and/or `?enabled=true\|false` |
| `GET /guardrails/:id` | a single guardrail |
| `POST /guardrails` | create — body `{ domain_id, name, description, severity?, enforcement?, config?, enabled? }` |
| `PUT /guardrails/:id` | partial update — omitted fields unchanged |
| `DELETE /guardrails/:id` | delete |
| `GET /api-catalog` | list APIs — filter with `?domain=`, `?pipelineId=`, `?status=`, `?method=` |
| `GET /api-catalog/:id` | full detail: sample request, sample response, OpenAPI v3 operation object |
| `POST /api-catalog` | create — body `{ name, method, path, description, domain, pipelineId?, processLabel?, rateLimit?, version?, authType?, sampleRequest?, sampleResponse?, openapiSpec?, status? }` |
| `PUT /api-catalog/:id` | partial update |
| `DELETE /api-catalog/:id` | delete (cascades to any MCP gateway bindings wrapping it) |
| `GET /mcp-gateways` | list gateways with binding counts |
| `GET /mcp-gateways/:id` | gateway detail + every bound API/tool |
| `POST /mcp-gateways` | create — body `{ name, description, status? }` |
| `PUT /mcp-gateways/:id` | update name/description/status |
| `DELETE /mcp-gateways/:id` | delete (cascades to its bindings) |
| `POST /mcp-gateways/:id/bindings` | bind one API or tool — body `{ exposedName, apiId? }` or `{ exposedName, toolName, toolDescription, toolConfig? }` (exactly one of `apiId`/`toolName`) |
| `PUT /mcp-gateways/:id/bindings/:bindingId` | update `exposedName`/`toolConfig`/`enabled` |
| `DELETE /mcp-gateways/:id/bindings/:bindingId` | unbind |
| `GET /custom-orchestrations` | list user-authored agent workflows (the frontend's Agent Studio canvas), newest first |
| `GET /custom-orchestrations/:id` | detail |
| `POST /custom-orchestrations` | create — body `{ id, name, description?, type?, strategy?, agentIds?, connections?, stages?, layout? }` |
| `PUT /custom-orchestrations/:id` | partial update (array/object fields fully replace when provided) |
| `DELETE /custom-orchestrations/:id` | delete |
| `GET /custom-journeys` | list client onboarding journey templates, newest first |
| `GET /custom-journeys/:id` | detail |
| `POST /custom-journeys` | create — body `{ id, name, description?, expectedSla?, primaryAnchorId?, status?, linkedPipelineId?, intakeDocuments?, riskEscalationThreshold?, contractingMethod?, targetEntity?, parallelBranchRules?, stages?, phases?, hybridStages?, steps? }` |
| `PUT /custom-journeys/:id` | partial update (array/object fields fully replace when provided) |
| `DELETE /custom-journeys/:id` | delete |

### Guardrails

The 13 domains — **input, prompt, retrieval, tools, output, runtime,
memory, tokenomics, security, regulatory, agentic_ai, observability,
cost_optimization** — are a fixed taxonomy seeded from
[`db/seed/guardrails-catalog.js`](db/seed/guardrails-catalog.js) (also
creatable/editable via the domain CRUD above, e.g. to add a 14th). Each
domain ships with 5 starter guardrails (severity `low|medium|high|critical`,
enforcement `block|warn|log`, plus a free-form `config` JSONB for
domain-specific parameters) — full CRUD lives on the `guardrails` table
itself via `src/routes/guardrails.js`, so these are edited/added/removed at
runtime, not just at seed time. Re-running `npm run db:seed` only inserts
starter guardrails into domains that are still empty — it never
resurrects ones you've since edited or deleted.

### API Catalog & MCP Gateways

`api_catalog` is a registry of the external/internal APIs the agent mesh
calls (registries, screening providers, credential verifiers) — each
entry carries method/path, a domain tag, an optional link to the
P-01..P-27 pipeline it primarily serves (`pipeline_id` + a display
`process_label`), rate limit, version, auth type, a sample request, a
sample response, and a synthesized OpenAPI v3 operation object. Seeded
from [`db/seed/api-catalog.js`](db/seed/api-catalog.js) with 7 starter
entries (ACRA, UK Companies House, GLEIF LEI, OFAC SDN, Dow Jones adverse
media, GLEIF vLEI, IRS GIIN) spanning several pipelines; full CRUD via
`src/routes/apiCatalog.js`.

An **MCP gateway** (`mcp_gateways`) is a bridge that exposes one or more
of those APIs — or standalone tools that aren't backed by an HTTP API at
all — as MCP-callable tools for an agent. Each association is a row in
`mcp_gateway_bindings`: either `api_id` is set (wraps a catalog entry) or
`tool_name`/`tool_description`/`tool_config` are set directly (a
standalone tool) — never both — and `exposed_name` is what the tool is
called over MCP (unique per gateway). Two starter gateways are seeded:
*Corporate Registry Gateway* (ACRA + Companies House + GLEIF, all
API-backed) and *Compliance Screening Gateway* (OFAC + adverse media,
plus one standalone `internal_watchlist_fuzzy_match` tool with no
API-catalog entry) — demonstrating both binding shapes. Full CRUD via
`src/routes/mcpGateways.js`.

### Custom Orchestrations & Client Journeys

Two more tables back the frontend's own visual builders, both deliberately
kept **separate** from the fixed `pipelines` (P-01..P-27) reference data:

- **`custom_orchestrations`** — a single user-authored agent workflow
  (a graph of agents wired together: sequential/parallel/hub-and-spoke/
  hybrid), built in the frontend's Agent Studio canvas. Full CRUD via
  `src/routes/customOrchestrations.js`.
- **`custom_journeys`** — a client onboarding journey *template*: an
  ordered set of stages, each stage linking to a `custom_orchestrations`
  pipeline and a set of attached agents — composes multiple pipelines
  into one end-to-end client lifecycle (unlike a single orchestration).
  Full CRUD via `src/routes/customJourneys.js`.

Both use frontend-minted `TEXT` ids (e.g. `pipeline_482913`,
`corporate_onboarding_journey`) rather than server-generated UUIDs, so the
frontend's own id scheme round-trips unchanged. Row shapes mirror the
frontend's `AgentOrchestration` / `Journey` TypeScript interfaces closely
enough that most fields map 1:1 to explicit columns — see the
`custom_orchestrations` / `custom_journeys` comments in
[`db/schema.sql`](db/schema.sql) for the rationale on each.

## How pipelines execute

Pipelines are **data, not code** — `db/seed/catalog.js` is the single
source of truth for what's in each pipeline (transcribed from the
architecture matrix), loaded into `pipelines` / `pipeline_agents` /
`pipeline_steps` by `npm run db:seed`. One engine
([`src/services/pipelineRunner.js`](src/services/pipelineRunner.js))
drives all 27 — it loads a pipeline's ordered steps, and for each step
either runs the named agent or records a plain handoff (a step with no
agent named in the spec, e.g. "RM submits a request").

Every agent is a **stub adapter** today
([`src/agents/stubs.js`](src/agents/stubs.js)) — same convention as
`../../shared/ARCHITECTURE.md` §5: each returns realistic fixture data
marked `_stub: true` so the full matrix runs end-to-end before any real
registry/model/screening integration exists. Swapping one agent to a live
implementation later means editing its entry in
[`src/agents/registry.js`](src/agents/registry.js) — no pipeline or route
changes.

Every run writes an append-only `events` row per step
(`PIPELINE_RUN_STARTED` / `PIPELINE_STEP_COMPLETED` /
`PIPELINE_STEP_FAILED` / `PIPELINE_RUN_COMPLETED` /
`PIPELINE_RUN_FAILED`), same envelope shape as the rest of Nexum.

## Layout

```
src/
  server.js, app.js
  config/{index,db}.js
  agents/
    stubs.js        <- one fixture-returning function per agent_id
    registry.js      <- agent_id -> execute(context) lookup
  services/
    pipelineRunner.js <- generic engine: loads steps, calls agents, persists run/events
  routes/
    agents.js, pipelines.js, runs.js
    guardrailDomains.js, guardrails.js
    apiCatalog.js, mcpGateways.js
  middleware/errorHandler.js
db/
  schema.sql          <- registry + execution + guardrail + API catalog/MCP gateway tables
  seed/
    catalog.js              <- P-01..P-27 reference data (agents, roles, scopes, steps)
    guardrails-catalog.js    <- 13 domains + starter guardrails
    api-catalog.js            <- starter API catalog entries + MCP gateway bindings
    seed.js                    <- idempotent loader: all three catalogs -> Postgres
  migrate-design-to-execution.sh  <- ports config tables to another database, see below
```

## Porting configuration to an execution database

**Currently not needed** — the design and execution containers share one
Postgres in the present demo setup (see "Design vs execution containers"
below), so there's nothing to port; edits are already live everywhere.
This section (and the script) describes the two-separate-databases
architecture that's one config change away from being restored, and would
matter again the moment that happens.

This service is the *design-time* store — where agents, pipelines,
guardrails, the API catalog, MCP gateways, and custom
orchestrations/journeys are authored. A separate *execution* database
(same schema, different instance) is expected to actually run against that
configuration and accumulate its own `pipeline_runs`/`pipeline_run_steps`/
`events` history.

`npm run db:migrate-to-execution` (or `db/migrate-design-to-execution.sh`
directly) copies just the configuration tables — `agents`, `pipelines`,
`pipeline_agents`, `pipeline_steps`, `guardrail_domains`, `guardrails`,
`api_catalog`, `mcp_gateways`, `mcp_gateway_bindings`,
`custom_orchestrations`, `custom_journeys` — from a source database into a
target's schema, verbatim (creates the target's tables via `schema.sql`
first, then a `pg_dump --data-only --column-inserts` of just that table
list). It deliberately **excludes** `pipeline_runs`/`pipeline_run_steps`/
`events` — that's per-environment execution history, not configuration to
replicate; the target's own runs should be its own.

```bash
SOURCE_DATABASE_URL=postgresql://.../design_db \
TARGET_DATABASE_URL=postgresql://.../execution_db \
npm run db:migrate-to-execution
```

Re-running against a target that already has a prior copy fails loudly on
primary-key conflicts rather than silently duplicating rows. Add
`--truncate-target` to clear the config tables first when you want to
refresh — but read the warning in the script's header first: that
TRUNCATE CASCADEs into the target's own `pipeline_runs`/
`pipeline_run_steps`/`events` (they FK-reference `agents`/`pipelines`), so
only use it against a target with no execution history you need to keep.

Verified end-to-end while building this: ran it against a second,
freshly-created Postgres database, confirmed every table's row count
matched the source exactly and a spot-checked agent's JSONB `config`
survived byte-for-byte. Also found and fixed a real client/server
version-skew bug — a newer local `pg_dump` (18+) emits `SET
transaction_timeout = 0;` in its preamble, a GUC that only exists on
Postgres 17+, which an older target server (e.g. this project's
`postgres:16` compose service) rejects outright; the script filters that
line out.

## Design vs execution containers

Both this service and the frontend are containerized (`Dockerfile` in each),
and `../../docker-compose.design.yml` / `../../docker-compose.execution.yml`
(at the repo root) stand up two deployments — 6 containers total:

| | Design | Execution |
|---|---|---|
| frontend | `nexum_design_frontend` :3000 | `nexum_execution_frontend` :3010 |
| backend | `nexum_design_backend` :4001 | `nexum_execution_backend` :4011 |
| Postgres | *(shared — see below)* | `nexum_execution_agenticstudio_db` :55451 |
| Neo4j | — (not needed, see below) | `nexum_execution_neo4j` :7475 / :7688 |

**Current mode: demo — one shared database.** `nexum_design_backend`'s
`DATABASE_URL` points at execution's Postgres directly
(`docker-compose.design.yml`'s header comment has the exact connection
string) rather than owning its own — a deliberate simplification so
anything created in Studio is instantly visible in execution, with **no
migration step**. Verified: created a journey via design's `/custom-journeys`
POST, confirmed it was immediately readable from execution's `/custom-journeys`
GET on a different port, zero delay, no script run in between.

This trades away genuine design/execution data separation — there's
exactly one copy of `agents`/`pipelines`/`custom_journeys`/etc., so an
edit in Studio is live everywhere immediately, not staged. Fine for a demo;
not what you'd want once execution needs to run independently of
whatever's currently being edited in design.

**To revert to two separate databases**: bring the design stack down,
add back a `db` service to `docker-compose.design.yml` adopting the
`nexum-services-agenticstudio_nexum_agenticstudio_pgdata` volume (not
deleted — see `services/agenticstudio/docker-compose.yml`'s retirement
note for that exact volume name), point `backend`'s `DATABASE_URL` back at
it, and resume using `db:migrate-to-execution` (below) to sync the two on
your own schedule instead of them being permanently identical.

**The backend is the same codebase in both** — this service, extended with
`src/routes/clients.js` + `src/services/graphSync.js` (ported from
`services/clientos`, now retired as a standalone deployable — see that
service's README). Design's Platform Admin persona only ever calls the
config routes (agents/pipelines/guardrails/...); execution's
RM/Compliance/Ops/Customer personas only ever call `/clients` +
`/clients/:id/graph`, plus `/notifications` and `/sent-emails` (below).
Rather than run two separate backend+db pairs where one half of each sits
idle per deployment, one backend does both, conditionally: `NEO4J_URI` is
only set on execution's `backend` (see `src/config/neo4j.js` —
`graphSync.js` no-ops everywhere it's unset, and `/health/ready` only
checks Neo4j when configured), so design's container never even attempts
that connection.

### Notifications & sent emails

`src/routes/notifications.js` and `src/routes/sentEmails.js` — same
execution-only category as `clients` (own tables, deliberately absent from
`CONFIG_TABLES` in the migration script below): system notification
banners and the RM outreach email log, previously App.tsx-level state
persisted only to `localStorage`. Full CRUD, same conventions as
everything else here (`GET/POST /notifications`, `PUT`/`DELETE
/notifications/:id`; same shape for `/sent-emails`) — see
`frontend/src/services/agenticStudioApi.ts`'s `notificationsApi`/
`sentEmailsApi` for the frontend side, wired into `App.tsx` the same way
`clients` is (lazy fetch on persona select, `useBackendSync` debounced
watcher for ongoing edits).

Verified end-to-end: the two seeded default notifications auto-created on
the backend on first RM/Compliance/Ops session (same "local-only record
gets pushed up" behavior already proven for `clients`); a real "Send
Email" action from the RM UI created a row that then correctly tracked
through `sent -> delivered -> opened` status transitions as the frontend's
own simulation progressed it, each transition landing as a `PUT`.

`../../docker-compose.design.yml`'s `db` and
`../../docker-compose.execution.yml`'s `db`/`neo4j` are each fully
self-contained (own volume, own container) — no cross-project
`host.containers.internal` dependency, no shared instance between the two
deployments. Bring either stack up independently:

```bash
docker compose -f docker-compose.design.yml up -d --build
docker compose -f docker-compose.execution.yml up -d --build
```

Seed execution's config tables from design with `db:migrate-to-execution`
(above), `TARGET_DATABASE_URL` pointed at execution's published `55451`.
`clients` is deliberately excluded from that migration (see the schema
comment) — it's native to execution, populated directly by
RM/Compliance/Ops CRUD, never copied from design.

The frontend image is built once and reused for either deployment: Vite's
`VITE_*` env vars are baked in at *build time*, so a `VITE_AGENTICSTUDIO_URL`
alone can't vary per container. Instead both backend URLs are resolved at
container **runtime** — `server.ts` serves `/runtime-config.js`, which sets
`window.__AGENTICSTUDIO_URL__`/`window.__CLIENTOS_URL__` from the plain
`AGENTICSTUDIO_URL`/`CLIENTOS_URL` env vars, and
`src/services/agenticStudioApi.ts`/`clientOsApi.ts` read those. In
execution, `CLIENTOS_URL` is simply set to the same value as
`AGENTICSTUDIO_URL` (`http://localhost:4011`) since it's the same backend
— kept as a separate env var/runtime-config value rather than hardcoded
equal in code, so splitting back into two backends later stays a one-line
compose change, not a code change.

Verified end-to-end while restructuring this from an earlier 8-container,
4-compose-project layout (frontend+backend+db per deployment, plus a
separately-run ClientOS with its own Postgres+Neo4j shared by both,
mostly unused by design): both existing Postgres volumes and the Neo4j
volume were adopted via `external: true` into the new compose files
(`podman compose config` checked first to confirm each resolved to the
exact pre-existing volume name) rather than recreated, and ClientOS's
`clients` rows were copied over with a plain `pg_dump --data-only -t
clients | psql` into the merged backend's database — confirmed after the
swap that all data survived intact: 87 agents / 27 pipelines still in
design, and in execution the same 2 real clients plus their full 11-node,
10-relationship Neo4j graph rendering identically through the Digital
Twin Explorer's Knowledge Graph panel as before the restructure.

### Sign-in screen: which persona(s) each deployment shows

The same `DEPLOYMENT_MODE` env var (`design` | `execution`, set on the
`frontend` service in each compose file) also controls which persona
card(s) the sign-in screen offers, via
`frontend/src/config/deploymentMode.ts`:

- **`design`**: only **Platform Admin** — this is the configuration
  console; no other persona has anything to do here. The screen's
  copy/branding also switches to describe AgenticStudio itself ("Design
  and govern the agent mesh...") instead of the generic onboarding pitch.
- **`execution`**: every persona **except** Platform Admin (Relationship
  Manager, Compliance & Risk Officer, Operations Officer, Customer
  Self-Service) — this is the running onboarding platform; admin
  configuration happens in `design`, not here.
- Unset (plain local dev, no `DEPLOYMENT_MODE`): all personas, unchanged
  from before this split existed.

Verified in the browser for both modes: `execution` (the real running
compose stack) shows exactly the 4 non-admin cards; `design` (a throwaway
container built from the same image, pointed at 4011 with
`DEPLOYMENT_MODE=design`) shows only Platform Admin with the updated
headline/copy, and clicking through still lands correctly on the Platform
Admin console.

## Extending

- **Add/change a pipeline or its steps**: edit `db/seed/catalog.js`, run `npm run db:seed`. Don't hand-edit the registry tables.
- **Make an agent do real work**: replace its function body in `src/agents/stubs.js` (or point `registry.js` at a new module) — the `{input, priorOutputs, clientId, pipelineId}` call shape stays the same.
- **Run asynchronously**: `POST /pipelines/:id/runs` currently runs synchronously since stub agents resolve instantly; once agents do real I/O, swap `pipelineRunner.runPipeline` to enqueue and return the `run` row immediately with `status: 'running'`, and poll `GET /runs/:id`.
- **Register a new API or gateway**: use the CRUD endpoints directly (`POST /api-catalog`, `POST /mcp-gateways`, `POST /mcp-gateways/:id/bindings`) rather than editing `db/seed/api-catalog.js` — that file is only the starter set loaded once per empty state via `npm run db:seed`'s upsert-by-`(method, path)`/`name` logic.
