-- Nexum / AgenticStudio — DDL export (schema only), exported 2026-08-27.
-- Standalone copy of ../schema.sql — the canonical, hand-maintained schema
-- source (edit that file, not this copy, if the schema changes later).
-- Run this first, against an empty database, before 02_dml.sql:
--   createdb nexum_agenticstudio_execution
--   psql -d nexum_agenticstudio_execution -f 01_ddl.sql
--   psql -d nexum_agenticstudio_execution -f 02_dml.sql
-- Requires privileges to CREATE EXTENSION pgcrypto (used for gen_random_uuid()).
--
-- AgenticStudio schema — the Process Flow / Agent registry and execution
-- log for P-01..P-27 (see ../ARCHITECTURE.md for the full reference
-- matrix this schema is built from).
--
-- Registry tables (agents, pipelines, pipeline_agents, pipeline_steps) are
-- reference data, loaded once by db/seed/seed.js from db/seed/catalog.js —
-- do not hand-edit rows in these tables, edit the catalog and re-seed.
--
-- Execution tables (pipeline_runs, pipeline_run_steps, events) are what
-- the app writes to at runtime as pipelines are invoked.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ── Registry: agents ─────────────────────────────────────────────────────
-- One row per agent referenced anywhere in the P-01..P-27 matrix (19 total,
-- seeded — `id` is the stable slug src/agents/stubs.js keys off of), PLUS
-- any custom agents created through the frontend's Agent Studio (full CRUD
-- via src/routes/agents.js). `config` is the extensibility bag for
-- everything the frontend's richer OrchestrationAgent shape carries that
-- the 19 seeded agents don't need — description, category, model, owner,
-- risk level, MCP wiring, input/output schemas, per-agent guardrails,
-- metrics, canvas position, etc. Stored opaquely; this backend doesn't
-- interpret it.
CREATE TABLE agents (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    config      JSONB NOT NULL DEFAULT '{}',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ── Registry: pipelines ──────────────────────────────────────────────────
-- One row per Process Flow (P-01..P-27).
CREATE TABLE pipelines (
    id          TEXT PRIMARY KEY,        -- 'P-01'
    name        TEXT NOT NULL,
    stage       TEXT NOT NULL,           -- topology stage, e.g. 'Prospecting'
    role        TEXT NOT NULL,           -- "Pipeline Role" paragraph
    scope_in    TEXT NOT NULL,           -- "In-Scope" bullet text
    scope_out   TEXT NOT NULL,           -- "Out-of-Scope" bullet text
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ── Registry: which agents participate in which pipeline ────────────────
-- Captures the per-pipeline "Role" and "Scope" text for an agent, which
-- differs from that agent's generic identity in `agents` (e.g.
-- cross_validation_agent's role/scope reads differently in P-06 vs P-16).
CREATE TABLE pipeline_agents (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    pipeline_id TEXT NOT NULL REFERENCES pipelines(id),
    agent_id    TEXT NOT NULL REFERENCES agents(id),
    sequence    INTEGER NOT NULL,   -- order of appearance in "Associated Agents"
    agent_role  TEXT NOT NULL,      -- e.g. 'Front-Office Commercial Qualifier'
    agent_scope TEXT NOT NULL,
    UNIQUE (pipeline_id, agent_id)
);
CREATE INDEX ON pipeline_agents (pipeline_id, sequence);
CREATE INDEX ON pipeline_agents (agent_id);

-- ── Registry: ordered steps ("Step-by-Step Functionality") ───────────────
-- agent_id is null for a step that is a pure handoff/output description
-- rather than a specific agent action (rare — most steps name an agent).
CREATE TABLE pipeline_steps (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    pipeline_id TEXT NOT NULL REFERENCES pipelines(id),
    sequence    INTEGER NOT NULL,
    agent_id    TEXT REFERENCES agents(id),
    description TEXT NOT NULL,
    UNIQUE (pipeline_id, sequence)
);
CREATE INDEX ON pipeline_steps (pipeline_id, sequence);

-- ── Execution: one row per invocation of a pipeline ──────────────────────
CREATE TABLE pipeline_runs (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    pipeline_id  TEXT NOT NULL REFERENCES pipelines(id),
    client_id    UUID,     -- correlates to a Nexum/ClientOS client id when
                            -- known; no FK — that's a different database.
    status       TEXT NOT NULL DEFAULT 'pending',  -- pending|running|completed|failed
    input        JSONB NOT NULL DEFAULT '{}',
    output       JSONB,
    error        TEXT,
    started_at   TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON pipeline_runs (pipeline_id, created_at);
CREATE INDEX ON pipeline_runs (client_id);

-- ── Execution: per-step result within a run ──────────────────────────────
CREATE TABLE pipeline_run_steps (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    run_id       UUID NOT NULL REFERENCES pipeline_runs(id),
    -- ON DELETE SET NULL (not a hard FK): db/seed/seed.js re-seeds
    -- pipeline_steps from the catalog on every run, which can replace a
    -- step row. Run history keeps agent_id/sequence either way, so losing
    -- the link to a step definition that no longer exists is fine —
    -- letting that seed fail instead (as a NOT NULL/RESTRICT FK would)
    -- isn't.
    step_id      UUID REFERENCES pipeline_steps(id) ON DELETE SET NULL,
    agent_id     TEXT REFERENCES agents(id),
    sequence     INTEGER NOT NULL,
    status       TEXT NOT NULL DEFAULT 'pending',  -- pending|running|completed|failed
    input        JSONB,
    output        JSONB,
    error          TEXT,
    started_at      TIMESTAMPTZ,
    completed_at     TIMESTAMPTZ
);
CREATE INDEX ON pipeline_run_steps (run_id, sequence);

-- ── Execution: append-only event log ─────────────────────────────────────
-- Mirrors the event envelope convention in ../../shared/ARCHITECTURE.md §2
-- (same event_type/correlation_id/causation_id shape) so AgenticStudio's
-- execution trail stays structurally consistent with the rest of Nexum,
-- even though this is a separate database.
CREATE TABLE events (
    event_id       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_type     TEXT NOT NULL,     -- PIPELINE_RUN_STARTED | PIPELINE_STEP_COMPLETED | ...
    occurred_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    run_id         UUID REFERENCES pipeline_runs(id),
    pipeline_id    TEXT REFERENCES pipelines(id),
    agent_id       TEXT REFERENCES agents(id),
    correlation_id UUID NOT NULL,
    causation_id   UUID REFERENCES events(event_id),
    payload        JSONB NOT NULL
);
CREATE INDEX ON events (run_id);
CREATE INDEX ON events (correlation_id);
CREATE INDEX ON events (event_type, occurred_at);

-- ── Guardrails: domains ───────────────────────────────────────────────────
-- The 13 fixed guardrail domains (input, prompt, retrieval, tools, output,
-- runtime, memory, tokenomics, security, regulatory, agentic_ai,
-- observability, cost_optimization). Reference data, seeded from
-- db/seed/guardrails-catalog.js — same convention as agents/pipelines
-- above. Kept as a real table (not an enum/CHECK) so a 14th domain can be
-- added via the API without a migration.
CREATE TABLE guardrail_domains (
    id          TEXT PRIMARY KEY,        -- 'input', 'prompt', ...
    name        TEXT NOT NULL,           -- 'Input Guardrails'
    description TEXT NOT NULL,
    sequence    INTEGER NOT NULL,        -- display order 1..13
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ── Guardrails: individual rules within a domain ─────────────────────────
-- Full CRUD lives on this table (see src/routes/guardrails.js) — domains
-- are the fixed taxonomy, guardrails within them are what gets
-- created/edited/deleted day to day.
CREATE TABLE guardrails (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    domain_id   TEXT NOT NULL REFERENCES guardrail_domains(id),
    name        TEXT NOT NULL,
    description TEXT NOT NULL,
    severity    TEXT NOT NULL DEFAULT 'medium',   -- low | medium | high | critical
    enforcement TEXT NOT NULL DEFAULT 'block',    -- block | warn | log
    config      JSONB NOT NULL DEFAULT '{}',      -- domain-specific parameters (thresholds, patterns, limits...)
    enabled     BOOLEAN NOT NULL DEFAULT true,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT guardrails_severity_check CHECK (severity IN ('low', 'medium', 'high', 'critical')),
    CONSTRAINT guardrails_enforcement_check CHECK (enforcement IN ('block', 'warn', 'log'))
);
CREATE INDEX ON guardrails (domain_id);

-- ── API Catalog ───────────────────────────────────────────────────────────
-- One row per external/internal API the agent mesh can call (registries,
-- screening providers, credential verifiers, ...). Full CRUD via
-- src/routes/apiCatalog.js. `pipeline_id` optionally links an entry to the
-- P-01..P-27 process it primarily serves; `process_label` carries the
-- catalog's own display name for that association (e.g. "KYB Entity
-- Verification") when it doesn't read the same as the pipeline's stored
-- name.
CREATE TABLE api_catalog (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            TEXT NOT NULL,               -- 'ACRA Singapore Entity Profile Fetch'
    method          TEXT NOT NULL,               -- GET | POST | PUT | PATCH | DELETE
    path            TEXT NOT NULL,               -- '/api/v2/sg/acra/entity'
    description     TEXT NOT NULL,
    domain          TEXT NOT NULL,               -- 'Corporate Registry' — free-text catalog tag, a
                                                  -- different taxonomy from guardrail_domains
    pipeline_id     TEXT REFERENCES pipelines(id),
    process_label   TEXT,                        -- e.g. 'KYB Entity Verification'
    rate_limit      TEXT,                        -- '120 req/min' — display string, not parsed/enforced here
    version         TEXT NOT NULL DEFAULT 'v1',
    auth_type       TEXT NOT NULL DEFAULT 'bearer',   -- bearer | api_key | mtls | none
    sample_request  TEXT,                        -- raw HTTP request snippet, for the catalog UI
    sample_response JSONB,                        -- example 200 OK response body
    openapi_spec    JSONB,                        -- OpenAPI v3 operation object for this endpoint
    status          TEXT NOT NULL DEFAULT 'active',   -- active | beta | deprecated
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT api_catalog_method_check CHECK (method IN ('GET', 'POST', 'PUT', 'PATCH', 'DELETE')),
    CONSTRAINT api_catalog_status_check CHECK (status IN ('active', 'beta', 'deprecated')),
    UNIQUE (method, path)
);
CREATE INDEX ON api_catalog (domain);
CREATE INDEX ON api_catalog (pipeline_id);

-- ── MCP Gateways ──────────────────────────────────────────────────────────
-- A "bridge" that exposes one or more APIs (from api_catalog) and/or
-- standalone tools as MCP-callable tools for an agent. Full CRUD via
-- src/routes/mcpGateways.js.
CREATE TABLE mcp_gateways (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name        TEXT NOT NULL UNIQUE,        -- 'Corporate Registry Gateway'
    description TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'active',  -- active | inactive
    -- Extensibility bag for the frontend's transport-level fields this
    -- table doesn't have native columns for (url, protocol, authType,
    -- environment) — same pattern as agents.config.
    config      JSONB NOT NULL DEFAULT '{}',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT mcp_gateways_status_check CHECK (status IN ('active', 'inactive'))
);

-- A binding is either api-backed (api_id set, wraps an api_catalog entry)
-- or a standalone tool (api_id null, tool_name/tool_description/tool_config
-- describe it directly) — exactly one of the two, enforced below.
-- `exposed_name` is what the tool is called when the gateway serves it over
-- MCP, unique per gateway since MCP tool names must not collide within one
-- server.
CREATE TABLE mcp_gateway_bindings (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    gateway_id       UUID NOT NULL REFERENCES mcp_gateways(id) ON DELETE CASCADE,
    api_id           UUID REFERENCES api_catalog(id) ON DELETE CASCADE,
    tool_name        TEXT,
    tool_description TEXT,
    tool_config      JSONB NOT NULL DEFAULT '{}',
    exposed_name     TEXT NOT NULL,
    enabled          BOOLEAN NOT NULL DEFAULT true,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT mcp_gateway_bindings_source_check CHECK (
        (api_id IS NOT NULL AND tool_name IS NULL) OR (api_id IS NULL AND tool_name IS NOT NULL)
    ),
    UNIQUE (gateway_id, exposed_name)
);
CREATE INDEX ON mcp_gateway_bindings (gateway_id);
CREATE INDEX ON mcp_gateway_bindings (api_id);

-- ── Custom Orchestrations ─────────────────────────────────────────────────
-- User-authored agent workflows built in the frontend's visual Agent
-- Studio canvas (AgentOrchestrator.tsx) — sequential/parallel/hub-and-spoke/
-- hybrid graphs of agents wired together by the user. Deliberately a
-- separate table from `pipelines`: `pipelines` is the fixed, specced
-- P-01..P-27 KYC taxonomy (role/scope/steps transcribed from the
-- architecture doc); `custom_orchestrations` is free-form and user-owned,
-- full CRUD via src/routes/customOrchestrations.js. `id` is TEXT (not
-- UUID) because the frontend already mints its own ids client-side
-- (e.g. 'hybrid_enterprise_onboarding', 'pipeline_482913') and those are
-- preserved as-is rather than replaced.
CREATE TABLE custom_orchestrations (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    description TEXT,
    type        TEXT,               -- 'corporate' | 'funds' | 'custom'
    strategy    TEXT,               -- 'sequential' | 'parallel' | 'hub_and_spoke' | 'hybrid'
    agent_ids   JSONB NOT NULL DEFAULT '[]',   -- string[]
    connections JSONB NOT NULL DEFAULT '[]',   -- [{from, to}]
    stages      JSONB NOT NULL DEFAULT '[]',   -- HybridStage[]
    layout      JSONB NOT NULL DEFAULT '{}',   -- opaque frontend canvas state (node positions, zoom, ...)
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ── Client Journeys ───────────────────────────────────────────────────────
-- The frontend's Client Journeys builder (JourneysView, in
-- PersonaSubviews.tsx) — end-to-end onboarding journey templates: an
-- ordered set of stages, each linked to a `custom_orchestrations` pipeline
-- and a set of attached agents. Distinct from both `pipelines` (the fixed
-- P-01..P-27 spec) and `custom_orchestrations` (a single agent workflow) —
-- a journey composes multiple pipelines into one client-facing lifecycle.
-- Full CRUD via src/routes/customJourneys.js. `id` is TEXT because the
-- frontend already mints its own (e.g. 'corporate_onboarding_journey').
CREATE TABLE custom_journeys (
    id                        TEXT PRIMARY KEY,
    name                      TEXT NOT NULL,
    description               TEXT,
    expected_sla              TEXT,
    primary_anchor_id         TEXT,
    status                    TEXT NOT NULL DEFAULT 'Draft',   -- Active | Draft | Deprecated
    linked_pipeline_id        TEXT,
    intake_documents          JSONB NOT NULL DEFAULT '[]',     -- string[]
    risk_escalation_threshold NUMERIC,
    contracting_method        TEXT,
    target_entity             TEXT,
    parallel_branch_rules     TEXT,
    stages                    JSONB NOT NULL DEFAULT '[]',     -- JourneyStage[]
    phases                    JSONB NOT NULL DEFAULT '[]',     -- JourneyStage[] (frontend keeps stages/phases in sync)
    hybrid_stages             JSONB NOT NULL DEFAULT '[]',     -- HybridStage[]
    steps                     JSONB NOT NULL DEFAULT '[]',     -- JourneyStep[]
    extra                     JSONB NOT NULL DEFAULT '{}',     -- forward-compat catch-all, same convention as agents.config
    created_at                TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at                TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT custom_journeys_status_check CHECK (status IN ('Active', 'Draft', 'Deprecated'))
);

-- ── clients ──────────────────────────────────────────────────────────────
-- Ported from services/clientos (see that service's README for the
-- retirement note). The client/case record behind the frontend's RM,
-- Compliance & Risk Officer, and Operations Officer screens (My Pipeline,
-- Journey Workspace, Customer 360, Digital Twin Explorer, ...) — this is
-- execution-only data, not configuration: it's deliberately absent from
-- db/migrate-design-to-execution.sh's CONFIG_TABLES list, same category as
-- pipeline_runs/events. Matches the frontend's `ClientProfile` shape
-- (frontend/src/types.ts) closely enough that most fields round-trip
-- untouched — same JSONB-extensibility-bag convention as the tables above:
-- a handful of real columns for what's actually filtered/sorted on, JSONB
-- for everything nested/rich. src/services/graphSync.js additionally
-- mirrors the relationship-shaped fields (directors, related parties,
-- shareholders, authorized representative) into Neo4j on every write, when
-- NEO4J_URI is configured (execution only — see src/config/neo4j.js).
CREATE TABLE clients (
    id                            TEXT PRIMARY KEY,
    company_name                  TEXT NOT NULL,
    registration_number           TEXT,
    jurisdiction                  TEXT,
    industry                      TEXT,
    overall_status                TEXT NOT NULL DEFAULT 'draft',
    journey_id                    TEXT,
    journey_name                  TEXT,
    authorized_representative     JSONB NOT NULL DEFAULT '{}',
    shareholders                  JSONB NOT NULL DEFAULT '[]',
    financials                    JSONB NOT NULL DEFAULT '{}',
    documents                     JSONB NOT NULL DEFAULT '[]',
    workflow_nodes                JSONB NOT NULL DEFAULT '[]',
    directors                     JSONB NOT NULL DEFAULT '[]',
    related_parties               JSONB NOT NULL DEFAULT '[]',
    alerts                        JSONB NOT NULL DEFAULT '[]',
    govt_registry_update_requests JSONB NOT NULL DEFAULT '[]',
    internal_account_settings     JSONB NOT NULL DEFAULT '{}',
    created_at                    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at                    TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT clients_overall_status_check CHECK (overall_status IN ('draft', 'in_progress', 'approved', 'rejected'))
);

CREATE INDEX idx_clients_overall_status ON clients (overall_status);
CREATE INDEX idx_clients_journey_id ON clients (journey_id);

-- ── notifications ────────────────────────────────────────────────────────
-- System notification banners (RM/Compliance/Ops), matching the frontend's
-- `SystemNotification` shape (frontend/src/types.ts). Like `clients`, this
-- is execution-only/native data — not configuration, deliberately absent
-- from db/migrate-design-to-execution.sh's CONFIG_TABLES list. `time` is
-- the frontend's own human-readable string (e.g. "10 mins ago"), kept
-- verbatim rather than reinterpreted; `created_at` is the real timestamp
-- for ordering.
CREATE TABLE notifications (
    id                TEXT PRIMARY KEY,
    type              TEXT NOT NULL,
    title             TEXT NOT NULL,
    msg               TEXT NOT NULL,
    time              TEXT,
    node              TEXT,
    client_id         TEXT,
    client_name       TEXT,
    action_required   BOOLEAN NOT NULL DEFAULT false,
    actioned          BOOLEAN NOT NULL DEFAULT false,
    document_details  JSONB NOT NULL DEFAULT '{}',
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT notifications_type_check CHECK (type IN ('critical', 'warning', 'info', 'success'))
);

CREATE INDEX idx_notifications_client_id ON notifications (client_id);

-- ── sent_emails ──────────────────────────────────────────────────────────
-- RM outreach email log, matching App.tsx's `sentEmails` shape. Same
-- category as `notifications` above — execution-only, not configuration.
CREATE TABLE sent_emails (
    id            TEXT PRIMARY KEY,
    client_id     TEXT,
    client_name   TEXT,
    email         TEXT NOT NULL,
    subject       TEXT,
    body          TEXT,
    date          TEXT,
    status        TEXT NOT NULL DEFAULT 'sent',
    sent_at       TEXT,
    delivered_at  TEXT,
    opened_at     TEXT,
    clicked_at    TEXT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT sent_emails_status_check CHECK (status IN ('sent', 'delivered', 'opened', 'clicked'))
);

CREATE INDEX idx_sent_emails_client_id ON sent_emails (client_id);
