// Loads db/seed/catalog.js into the registry tables (agents, pipelines,
// pipeline_agents, pipeline_steps). Idempotent — safe to re-run any time
// the catalog changes; upserts by primary key and replaces each
// pipeline's agents/steps wholesale rather than trying to diff them.
//
// Usage: npm run db:seed   (reads DATABASE_URL from .env like the app does)

require('dotenv').config();
const { Pool } = require('pg');
const { AGENTS, PIPELINES } = require('./catalog');
const { DOMAINS, GUARDRAILS } = require('./guardrails-catalog');
const { APIS, GATEWAYS, openapiOperation } = require('./api-catalog');

async function seed() {
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    for (const [id, name] of Object.entries(AGENTS)) {
      await client.query(
        `INSERT INTO agents (id, name, updated_at) VALUES ($1, $2, now())
         ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, updated_at = now()`,
        [id, name],
      );
    }

    for (const pipeline of PIPELINES) {
      await client.query(
        `INSERT INTO pipelines (id, name, stage, role, scope_in, scope_out, updated_at)
         VALUES ($1, $2, $3, $4, $5, $6, now())
         ON CONFLICT (id) DO UPDATE SET
           name = EXCLUDED.name, stage = EXCLUDED.stage, role = EXCLUDED.role,
           scope_in = EXCLUDED.scope_in, scope_out = EXCLUDED.scope_out, updated_at = now()`,
        [pipeline.id, pipeline.name, pipeline.stage, pipeline.role, pipeline.scopeIn, pipeline.scopeOut],
      );

      // pipeline_agents has no incoming FK from runtime tables — safe to
      // replace wholesale.
      await client.query('DELETE FROM pipeline_agents WHERE pipeline_id = $1', [pipeline.id]);
      for (let i = 0; i < pipeline.agents.length; i += 1) {
        const a = pipeline.agents[i];
        await client.query(
          `INSERT INTO pipeline_agents (pipeline_id, agent_id, sequence, agent_role, agent_scope)
           VALUES ($1, $2, $3, $4, $5)`,
          [pipeline.id, a.agentId, i + 1, a.role, a.scope],
        );
      }

      // pipeline_steps rows can be referenced by pipeline_run_steps once a
      // pipeline has actually run, so upsert in place by (pipeline_id,
      // sequence) instead of delete+insert — existing step rows (and the
      // run history pointing at them) survive a catalog edit that keeps
      // the same step count. Only steps beyond the new count are removed
      // (harmless — the FK is ON DELETE SET NULL, see schema.sql).
      for (let i = 0; i < pipeline.steps.length; i += 1) {
        const s = pipeline.steps[i];
        await client.query(
          `INSERT INTO pipeline_steps (pipeline_id, sequence, agent_id, description)
           VALUES ($1, $2, $3, $4)
           ON CONFLICT (pipeline_id, sequence) DO UPDATE SET
             agent_id = EXCLUDED.agent_id, description = EXCLUDED.description`,
          [pipeline.id, i + 1, s.agentId, s.description],
        );
      }
      await client.query(
        'DELETE FROM pipeline_steps WHERE pipeline_id = $1 AND sequence > $2',
        [pipeline.id, pipeline.steps.length],
      );
    }

    for (let i = 0; i < DOMAINS.length; i += 1) {
      const d = DOMAINS[i];
      await client.query(
        `INSERT INTO guardrail_domains (id, name, description, sequence, updated_at)
         VALUES ($1, $2, $3, $4, now())
         ON CONFLICT (id) DO UPDATE SET
           name = EXCLUDED.name, description = EXCLUDED.description,
           sequence = EXCLUDED.sequence, updated_at = now()`,
        [d.id, d.name, d.description, i + 1],
      );
    }

    // Starter guardrails per domain are only inserted the first time (an
    // empty domain) — re-running the seed must not resurrect guardrails a
    // user has since edited or deleted via the CRUD API.
    for (const [domainId, guardrails] of Object.entries(GUARDRAILS)) {
      const { rows: [{ count }] } = await client.query(
        'SELECT count(*)::int AS count FROM guardrails WHERE domain_id = $1',
        [domainId],
      );
      if (count > 0) continue;

      for (const g of guardrails) {
        await client.query(
          `INSERT INTO guardrails (domain_id, name, description, severity, enforcement, config)
           VALUES ($1, $2, $3, $4, $5, $6)`,
          [domainId, g.name, g.description, g.severity, g.enforcement, g.config || {}],
        );
      }
    }

    for (const api of APIS) {
      const spec = openapiOperation({
        method: api.method,
        path: api.path,
        summary: api.name,
        description: api.description,
        queryParams: api.queryParams,
        responseExample: api.sampleResponse,
      });
      await client.query(
        `INSERT INTO api_catalog (
           name, method, path, description, domain, pipeline_id, process_label,
           rate_limit, version, auth_type, sample_request, sample_response, openapi_spec, updated_at
         ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, now())
         ON CONFLICT (method, path) DO UPDATE SET
           name = EXCLUDED.name, description = EXCLUDED.description, domain = EXCLUDED.domain,
           pipeline_id = EXCLUDED.pipeline_id, process_label = EXCLUDED.process_label,
           rate_limit = EXCLUDED.rate_limit, version = EXCLUDED.version, auth_type = EXCLUDED.auth_type,
           sample_request = EXCLUDED.sample_request, sample_response = EXCLUDED.sample_response,
           openapi_spec = EXCLUDED.openapi_spec, updated_at = now()`,
        [
          api.name, api.method, api.path, api.description, api.domain, api.pipelineId, api.processLabel,
          api.rateLimit, api.version, api.authType, api.sampleRequest, api.sampleResponse, spec,
        ],
      );
    }

    for (const gateway of GATEWAYS) {
      const { rows: [gw] } = await client.query(
        `INSERT INTO mcp_gateways (name, description, status, updated_at)
         VALUES ($1, $2, $3, now())
         ON CONFLICT (name) DO UPDATE SET
           description = EXCLUDED.description, status = EXCLUDED.status, updated_at = now()
         RETURNING id`,
        [gateway.name, gateway.description, gateway.status],
      );

      for (const b of gateway.bindings) {
        let apiId = null;
        if (b.apiName) {
          const { rows: [api] } = await client.query('SELECT id FROM api_catalog WHERE name = $1', [b.apiName]);
          if (!api) throw new Error(`Gateway "${gateway.name}" binds unknown API "${b.apiName}" — check api-catalog.js`);
          apiId = api.id;
        }

        await client.query(
          `INSERT INTO mcp_gateway_bindings (gateway_id, api_id, tool_name, tool_description, tool_config, exposed_name)
           VALUES ($1, $2, $3, $4, $5, $6)
           ON CONFLICT (gateway_id, exposed_name) DO UPDATE SET
             api_id = EXCLUDED.api_id, tool_name = EXCLUDED.tool_name,
             tool_description = EXCLUDED.tool_description, tool_config = EXCLUDED.tool_config`,
          [gw.id, apiId, b.toolName || null, b.toolDescription || null, b.toolConfig || {}, b.exposedName],
        );
      }
    }

    await client.query('COMMIT');
    console.log(`Seeded ${Object.keys(AGENTS).length} agents and ${PIPELINES.length} pipelines.`);
    console.log(`Seeded ${DOMAINS.length} guardrail domains (starter guardrails inserted only for empty domains).`);
    console.log(`Seeded ${APIS.length} API catalog entries and ${GATEWAYS.length} MCP gateways.`);
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
    await pool.end();
  }
}

seed().catch((err) => {
  console.error('Seed failed:', err);
  process.exit(1);
});
