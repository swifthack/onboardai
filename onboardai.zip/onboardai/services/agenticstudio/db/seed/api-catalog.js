// Reference data for the API Catalog and starter MCP Gateways. Loaded by
// db/seed/seed.js — same convention as catalog.js and
// guardrails-catalog.js: edit here, re-run `npm run db:seed`. Full CRUD
// lives on api_catalog / mcp_gateways / mcp_gateway_bindings via
// src/routes/apiCatalog.js and src/routes/mcpGateways.js, so this is a
// starter set, not the whole inventory.

// Minimal OpenAPI v3 operation object, generated per entry rather than
// hand-duplicated — enough to populate the catalog's "OpenAPI Spec" tab
// meaningfully without writing out a full spec file per API.
function openapiOperation({ method, path, summary, description, queryParams = [], responseExample }) {
  return {
    openapi: '3.0.3',
    paths: {
      [path]: {
        [method.toLowerCase()]: {
          summary,
          description,
          security: [{ bearerAuth: [] }],
          parameters: queryParams.map((p) => ({
            name: p, in: 'query', required: true, schema: { type: 'string' },
          })),
          responses: {
            200: {
              description: 'OK',
              content: { 'application/json': { example: responseExample } },
            },
          },
        },
      },
    },
  };
}

const APIS = [
  {
    name: 'ACRA Singapore Entity Profile Fetch',
    method: 'GET',
    path: '/api/v2/sg/acra/entity',
    description: 'Retrieves Singapore ACRA live corporate entity profile, incorporation date, share capital structure, and live registered address.',
    domain: 'Corporate Registry',
    pipelineId: 'P-03',
    processLabel: 'KYB Entity Verification',
    rateLimit: '120 req/min',
    version: 'v2.4',
    authType: 'bearer',
    sampleRequest: 'GET /api/v2/sg/acra/entity?uen=202112345E\nHost: gateway.internal.bank.corp\nAuthorization: Bearer <mcp_token>',
    sampleResponse: {
      uen: '202112345E',
      companyName: 'Acme Global Holdings Pte. Ltd.',
      status: 'Live Company',
      incorporationDate: '2021-06-14',
      paidUpCapital: 'USD 5,000,000',
    },
    queryParams: ['uen'],
  },
  {
    name: 'UK Companies House Entity Search',
    method: 'GET',
    path: '/api/v2/uk/companies-house/search',
    description: 'Searches UK Companies House for a company by name or number, returning registration status, SIC codes, and filing history summary.',
    domain: 'Corporate Registry',
    pipelineId: 'P-02',
    processLabel: 'Entity Resolution',
    rateLimit: '600 req/min',
    version: 'v1.0',
    authType: 'api_key',
    sampleRequest: 'GET /api/v2/uk/companies-house/search?company_number=09876543\nHost: gateway.internal.bank.corp\nAuthorization: Bearer <mcp_token>',
    sampleResponse: {
      companyNumber: '09876543',
      companyName: 'Acme UK Trading Ltd',
      companyStatus: 'active',
      sicCodes: ['64999'],
      dateOfCreation: '2015-11-02',
    },
    queryParams: ['company_number'],
  },
  {
    name: 'GLEIF LEI Lookup',
    method: 'GET',
    path: '/api/v2/global/gleif/lei',
    description: 'Resolves a Legal Entity Identifier (LEI) to its GLEIF Level 1 (who-is-who) reference data — legal name, jurisdiction, registration authority.',
    domain: 'Corporate Registry',
    pipelineId: 'P-02',
    processLabel: 'Entity Resolution',
    rateLimit: '300 req/min',
    version: 'v1.2',
    authType: 'none',
    sampleRequest: 'GET /api/v2/global/gleif/lei?lei=549300ABCDEF1234567\nHost: gateway.internal.bank.corp\nAuthorization: Bearer <mcp_token>',
    sampleResponse: {
      lei: '549300ABCDEF1234567',
      legalName: 'Acme Global Holdings Pte. Ltd.',
      jurisdiction: 'SG',
      registrationStatus: 'ISSUED',
    },
    queryParams: ['lei'],
  },
  {
    name: 'OFAC SDN Sanctions Check',
    method: 'POST',
    path: '/api/v2/screening/ofac/sdn-check',
    description: 'Screens a subject name (entity or individual) against the OFAC Specially Designated Nationals consolidated list with fuzzy/phonetic matching.',
    domain: 'Sanctions & Watchlist',
    pipelineId: 'P-10',
    processLabel: 'Sanctions & PEP Screening',
    rateLimit: '60 req/min',
    version: 'v3.1',
    authType: 'bearer',
    sampleRequest: 'POST /api/v2/screening/ofac/sdn-check\nHost: gateway.internal.bank.corp\nAuthorization: Bearer <mcp_token>\nContent-Type: application/json\n\n{ "subjectName": "Acme Global Holdings Pte. Ltd.", "subjectType": "entity" }',
    sampleResponse: {
      subjectName: 'Acme Global Holdings Pte. Ltd.',
      matches: [],
      classification: 'FALSE_POSITIVE',
      listVersion: 'OFAC-SDN-2026-08-20',
    },
    queryParams: [],
  },
  {
    name: 'Dow Jones Adverse Media Search',
    method: 'POST',
    path: '/api/v2/screening/adverse-media/search',
    description: 'Runs an NLP-classified search of global news archives and regulatory enforcement dockets for a subject, scored by FATF crime predicate.',
    domain: 'Adverse Media',
    pipelineId: 'P-11',
    processLabel: 'Adverse Media Screening',
    rateLimit: '30 req/min',
    version: 'v2.0',
    authType: 'bearer',
    sampleRequest: 'POST /api/v2/screening/adverse-media/search\nHost: gateway.internal.bank.corp\nAuthorization: Bearer <mcp_token>\nContent-Type: application/json\n\n{ "subjectName": "Acme Global Holdings Pte. Ltd.", "lookbackYears": 7 }',
    sampleResponse: {
      subjectName: 'Acme Global Holdings Pte. Ltd.',
      articlesScanned: 184,
      adverseHits: [],
      severity: 'none',
    },
    queryParams: [],
  },
  {
    name: 'GLEIF vLEI Credential Verify',
    method: 'POST',
    path: '/api/v2/credentials/vlei/verify',
    description: "Cryptographically verifies a vLEI or Official Organizational Role (OOR) credential's signature, issuer trust chain, and revocation status.",
    domain: 'Digital Identity',
    pipelineId: 'P-06',
    processLabel: 'vLEI & Cryptographic Credential Verification',
    rateLimit: '200 req/min',
    version: 'v1.0',
    authType: 'mtls',
    sampleRequest: 'POST /api/v2/credentials/vlei/verify\nHost: gateway.internal.bank.corp\nAuthorization: Bearer <mcp_token>\nContent-Type: application/json\n\n{ "credentialJwt": "<vlei_credential_jwt>" }',
    sampleResponse: {
      valid: true,
      issuerTrustChainValid: true,
      revocationStatus: 'not_revoked',
    },
    queryParams: [],
  },
  {
    name: 'IRS GIIN Registry Validate',
    method: 'GET',
    path: '/api/v2/tax/irs/giin-validate',
    description: "Validates a Global Intermediary Identification Number (GIIN) against the IRS FATCA FFI registry for FATCA/CRS tax classification.",
    domain: 'Tax Compliance',
    pipelineId: 'P-16',
    processLabel: 'FATCA / CRS Tax Domicile',
    rateLimit: '180 req/min',
    version: 'v1.1',
    authType: 'api_key',
    sampleRequest: 'GET /api/v2/tax/irs/giin-validate?giin=98Q96B.00000.LE.702\nHost: gateway.internal.bank.corp\nAuthorization: Bearer <mcp_token>',
    sampleResponse: {
      giin: '98Q96B.00000.LE.702',
      status: 'active',
      ffiName: 'Acme Global Holdings Pte. Ltd.',
    },
    queryParams: ['giin'],
  },
];

// Gateways bridge one or more catalog APIs (and/or standalone tools) as
// MCP-callable tools. `apiName` below is resolved to api_catalog.id at
// seed time by matching on name (see seed.js) since this file has no DB
// ids to reference yet.
const GATEWAYS = [
  {
    name: 'Corporate Registry Gateway',
    description: 'Bridges the corporate-registry APIs (ACRA, Companies House, GLEIF) as MCP tools for entity-resolution and research agents.',
    status: 'active',
    bindings: [
      { apiName: 'ACRA Singapore Entity Profile Fetch', exposedName: 'acra_entity_lookup' },
      { apiName: 'UK Companies House Entity Search', exposedName: 'companies_house_search' },
      { apiName: 'GLEIF LEI Lookup', exposedName: 'gleif_lei_lookup' },
    ],
  },
  {
    name: 'Compliance Screening Gateway',
    description: 'Bridges sanctions/adverse-media APIs plus an in-house fuzzy-matching tool for the screening agents (P-10/P-11/P-14).',
    status: 'active',
    bindings: [
      { apiName: 'OFAC SDN Sanctions Check', exposedName: 'ofac_sdn_check' },
      { apiName: 'Dow Jones Adverse Media Search', exposedName: 'adverse_media_search' },
      {
        // Standalone tool — not backed by an api_catalog entry (e.g. an
        // in-process library call rather than an HTTP API).
        toolName: 'internal_watchlist_fuzzy_match',
        toolDescription: 'In-house phonetic/transliteration fuzzy matcher run before external sanctions APIs to pre-filter obvious non-matches.',
        toolConfig: { algorithm: 'double_metaphone', threshold: 0.82 },
        exposedName: 'internal_fuzzy_match',
      },
    ],
  },
];

module.exports = { APIS, GATEWAYS, openapiOperation };
