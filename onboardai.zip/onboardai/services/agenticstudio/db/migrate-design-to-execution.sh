#!/usr/bin/env bash
set -euo pipefail

# Ports AgenticStudio's *configuration* tables — the design-time reference
# data (agents, pipelines + their join tables, guardrails, api_catalog,
# mcp_gateways + bindings, custom_orchestrations, custom_journeys) — from a
# source ("design") database into a target ("execution") database's
# schema, verbatim.
#
# Deliberately EXCLUDES the runtime tables (pipeline_runs, pipeline_run_steps,
# events): those are per-environment execution history, not configuration.
# The execution database is expected to generate its own as it actually
# runs pipelines — copying the design DB's run history into it would be
# meaningless (and its event/run ids would have no bearing on anything the
# execution DB itself does).
#
# Usage:
#   SOURCE_DATABASE_URL=postgresql://... \
#   TARGET_DATABASE_URL=postgresql://... \
#   ./migrate-design-to-execution.sh [--truncate-target]
#
# --truncate-target: TRUNCATE the config tables on the target first (in FK
#   order) before loading — use this to re-run the port after the target
#   already has a prior copy. Without it, re-running against a
#   non-empty target fails on primary-key conflicts rather than silently
#   overwriting or duplicating anything.
#
#   ⚠️  CASCADE WARNING: if the target is a *live* execution database that
#   has actually been running pipelines, --truncate-target's CASCADE will
#   also wipe its pipeline_runs/pipeline_run_steps/events — those tables
#   FK-reference agents/pipelines, so truncating agents/pipelines cannot
#   avoid cascading into them. Confirmed by testing: on a fresh target this
#   is a no-op; on a target with real execution history, this destroys
#   that history. Only pass --truncate-target against a target you're
#   sure has no execution history you need, or back it up first.
#
# Requires pg_dump/psql on PATH (same major Postgres client version as the
# databases involved is safest, but pg_dump's plain-text --column-inserts
# output is portable across recent Postgres versions).

SOURCE_DATABASE_URL="${SOURCE_DATABASE_URL:?Set SOURCE_DATABASE_URL — the design/configuration database to copy from}"
TARGET_DATABASE_URL="${TARGET_DATABASE_URL:?Set TARGET_DATABASE_URL — the execution database to copy into}"
TRUNCATE_TARGET=false
for arg in "$@"; do
  [ "$arg" = "--truncate-target" ] && TRUNCATE_TARGET=true
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# FK-dependency order (also the order --truncate-target reverses for the
# TRUNCATE pass): agents/pipelines have no inbound FKs from this list;
# everything else references one or more of the tables before it.
CONFIG_TABLES=(
  agents
  pipelines
  pipeline_agents
  pipeline_steps
  guardrail_domains
  guardrails
  api_catalog
  mcp_gateways
  mcp_gateway_bindings
  custom_orchestrations
  custom_journeys
)

echo "==> Ensuring full schema exists on target (safe to re-run — see schema.sql)"
SCHEMA_LOG="$(mktemp)"
psql "$TARGET_DATABASE_URL" -v ON_ERROR_STOP=0 -q -f "$SCRIPT_DIR/schema.sql" > "$SCHEMA_LOG" 2>&1 || true
echo "    (pre-existing-table errors are expected/harmless on a re-run — full log: $SCHEMA_LOG)"

if [ "$TRUNCATE_TARGET" = true ]; then
  echo "==> --truncate-target: clearing existing config rows on target first"
  echo "    WARNING: this CASCADEs into pipeline_runs/pipeline_run_steps/events on the"
  echo "    target too (they FK-reference agents/pipelines) — see the script header."
  # Reverse order so FK-referencing tables are emptied before what they reference.
  for (( idx=${#CONFIG_TABLES[@]}-1 ; idx>=0 ; idx-- )); do
    t="${CONFIG_TABLES[$idx]}"
    psql "$TARGET_DATABASE_URL" -v ON_ERROR_STOP=1 -q -c "TRUNCATE TABLE $t CASCADE;"
  done
fi

TABLE_ARGS=()
for t in "${CONFIG_TABLES[@]}"; do
  TABLE_ARGS+=(-t "$t")
done

echo "==> Copying configuration data (${#CONFIG_TABLES[@]} tables) — source -> target"
# --disable-triggers also suspends FK-check triggers during the load, so
# row order across tables in the dump doesn't have to be perfect; --column-
# inserts keeps the dump as reviewable, portable INSERT statements rather
# than binary/COPY blocks.
#
# The `grep -v transaction_timeout` guards against a real client/server
# version-skew failure hit while building this: a newer pg_dump (18+)
# emits `SET transaction_timeout = 0;` in its preamble, a GUC that only
# exists on Postgres 17+ — an older target server rejects it and the
# whole restore aborts on that one line. Harmless to drop; it's a session
# default, not something the actual data load depends on.
pg_dump "$SOURCE_DATABASE_URL" --data-only --column-inserts --disable-triggers "${TABLE_ARGS[@]}" \
  | grep -v '^SET transaction_timeout' \
  | psql "$TARGET_DATABASE_URL" -v ON_ERROR_STOP=1 -q

echo "==> Done. Row counts on target:"
for t in "${CONFIG_TABLES[@]}"; do
  count=$(psql "$TARGET_DATABASE_URL" -tAc "SELECT count(*) FROM $t")
  printf '  %-24s %s\n' "$t" "$count"
done
