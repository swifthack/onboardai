const { Router } = require('express');
const { pool } = require('../config/db');

const router = Router();

// GET /guardrail-domains — the 13 domains, in display order, with a count
// of how many guardrails each currently has.
router.get('/', async (req, res, next) => {
  try {
    const { rows } = await pool.query(
      `SELECT d.*, count(g.id)::int AS guardrail_count
       FROM guardrail_domains d
       LEFT JOIN guardrails g ON g.domain_id = d.id
       GROUP BY d.id
       ORDER BY d.sequence`,
    );
    res.json({ domains: rows });
  } catch (err) {
    next(err);
  }
});

// GET /guardrail-domains/:id — domain detail plus its full guardrail list.
router.get('/:id', async (req, res, next) => {
  try {
    const { rows: [domain] } = await pool.query('SELECT * FROM guardrail_domains WHERE id = $1', [req.params.id]);
    if (!domain) return res.status(404).json({ error: { message: 'Guardrail domain not found' } });

    const { rows: guardrails } = await pool.query(
      'SELECT * FROM guardrails WHERE domain_id = $1 ORDER BY created_at',
      [req.params.id],
    );
    res.json({ ...domain, guardrails });
  } catch (err) {
    next(err);
  }
});

// POST /guardrail-domains — add a domain beyond the seeded 13, if a new
// category is ever needed. Body: { id, name, description, sequence? }.
router.post('/', async (req, res, next) => {
  try {
    const { id, name, description, sequence } = req.body || {};
    if (!id || !name || !description) {
      return res.status(400).json({ error: { message: 'id, name, and description are required' } });
    }

    let seq = sequence;
    if (seq === undefined) {
      const { rows: [{ max }] } = await pool.query('SELECT coalesce(max(sequence), 0) AS max FROM guardrail_domains');
      seq = max + 1;
    }

    const { rows: [domain] } = await pool.query(
      `INSERT INTO guardrail_domains (id, name, description, sequence) VALUES ($1, $2, $3, $4) RETURNING *`,
      [id, name, description, seq],
    );
    res.status(201).json(domain);
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: { message: `Domain "${req.body.id}" already exists` } });
    next(err);
  }
});

// PUT /guardrail-domains/:id — update name/description/sequence.
router.put('/:id', async (req, res, next) => {
  try {
    const { name, description, sequence } = req.body || {};
    const { rows: [domain] } = await pool.query(
      `UPDATE guardrail_domains SET
         name = coalesce($2, name),
         description = coalesce($3, description),
         sequence = coalesce($4, sequence),
         updated_at = now()
       WHERE id = $1 RETURNING *`,
      [req.params.id, name, description, sequence],
    );
    if (!domain) return res.status(404).json({ error: { message: 'Guardrail domain not found' } });
    res.json(domain);
  } catch (err) {
    next(err);
  }
});

// DELETE /guardrail-domains/:id — refuses if guardrails still reference
// it; delete or reassign those first.
router.delete('/:id', async (req, res, next) => {
  try {
    const { rows: [{ count }] } = await pool.query(
      'SELECT count(*)::int AS count FROM guardrails WHERE domain_id = $1',
      [req.params.id],
    );
    if (count > 0) {
      return res.status(409).json({
        error: { message: `Cannot delete domain "${req.params.id}": ${count} guardrail(s) still reference it.` },
      });
    }

    const { rowCount } = await pool.query('DELETE FROM guardrail_domains WHERE id = $1', [req.params.id]);
    if (!rowCount) return res.status(404).json({ error: { message: 'Guardrail domain not found' } });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

module.exports = router;
