const { Router } = require('express');
const { pool } = require('../config/db');

const router = Router();

const VALID_SEVERITY = ['low', 'medium', 'high', 'critical'];
const VALID_ENFORCEMENT = ['block', 'warn', 'log'];

// GET /guardrails — all guardrails across every domain, or filtered to one
// via ?domain=input (matches guardrail_domains.id).
router.get('/', async (req, res, next) => {
  try {
    const { domain, enabled } = req.query;
    const conditions = [];
    const params = [];

    if (domain) {
      params.push(domain);
      conditions.push(`domain_id = $${params.length}`);
    }
    if (enabled !== undefined) {
      params.push(enabled === 'true');
      conditions.push(`enabled = $${params.length}`);
    }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const { rows } = await pool.query(
      `SELECT * FROM guardrails ${where} ORDER BY domain_id, created_at`,
      params,
    );
    res.json({ guardrails: rows });
  } catch (err) {
    next(err);
  }
});

// GET /guardrails/:id
router.get('/:id', async (req, res, next) => {
  try {
    const { rows: [guardrail] } = await pool.query('SELECT * FROM guardrails WHERE id = $1', [req.params.id]);
    if (!guardrail) return res.status(404).json({ error: { message: 'Guardrail not found' } });
    res.json(guardrail);
  } catch (err) {
    next(err);
  }
});

// POST /guardrails — create a guardrail within a domain.
// Body: { domain_id, name, description, severity?, enforcement?, config?, enabled? }
router.post('/', async (req, res, next) => {
  try {
    const {
      domain_id: domainId, name, description,
      severity = 'medium', enforcement = 'block', config = {}, enabled = true,
    } = req.body || {};

    if (!domainId || !name || !description) {
      return res.status(400).json({ error: { message: 'domain_id, name, and description are required' } });
    }
    if (!VALID_SEVERITY.includes(severity)) {
      return res.status(400).json({ error: { message: `severity must be one of ${VALID_SEVERITY.join(', ')}` } });
    }
    if (!VALID_ENFORCEMENT.includes(enforcement)) {
      return res.status(400).json({ error: { message: `enforcement must be one of ${VALID_ENFORCEMENT.join(', ')}` } });
    }

    const { rows: [guardrail] } = await pool.query(
      `INSERT INTO guardrails (domain_id, name, description, severity, enforcement, config, enabled)
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
      [domainId, name, description, severity, enforcement, config, enabled],
    );
    res.status(201).json(guardrail);
  } catch (err) {
    if (err.code === '23503') {
      return res.status(400).json({ error: { message: `domain_id "${req.body.domain_id}" does not match an existing guardrail domain` } });
    }
    next(err);
  }
});

// PUT /guardrails/:id — partial update; omitted fields are left unchanged.
router.put('/:id', async (req, res, next) => {
  try {
    const {
      domain_id: domainId, name, description, severity, enforcement, config, enabled,
    } = req.body || {};

    if (severity !== undefined && !VALID_SEVERITY.includes(severity)) {
      return res.status(400).json({ error: { message: `severity must be one of ${VALID_SEVERITY.join(', ')}` } });
    }
    if (enforcement !== undefined && !VALID_ENFORCEMENT.includes(enforcement)) {
      return res.status(400).json({ error: { message: `enforcement must be one of ${VALID_ENFORCEMENT.join(', ')}` } });
    }

    const { rows: [guardrail] } = await pool.query(
      `UPDATE guardrails SET
         domain_id = coalesce($2, domain_id),
         name = coalesce($3, name),
         description = coalesce($4, description),
         severity = coalesce($5, severity),
         enforcement = coalesce($6, enforcement),
         config = coalesce($7, config),
         enabled = coalesce($8, enabled),
         updated_at = now()
       WHERE id = $1 RETURNING *`,
      [req.params.id, domainId, name, description, severity, enforcement, config, enabled],
    );
    if (!guardrail) return res.status(404).json({ error: { message: 'Guardrail not found' } });
    res.json(guardrail);
  } catch (err) {
    if (err.code === '23503') {
      return res.status(400).json({ error: { message: `domain_id "${req.body.domain_id}" does not match an existing guardrail domain` } });
    }
    next(err);
  }
});

// DELETE /guardrails/:id
router.delete('/:id', async (req, res, next) => {
  try {
    const { rowCount } = await pool.query('DELETE FROM guardrails WHERE id = $1', [req.params.id]);
    if (!rowCount) return res.status(404).json({ error: { message: 'Guardrail not found' } });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

module.exports = router;
