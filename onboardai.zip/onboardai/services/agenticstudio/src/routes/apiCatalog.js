const { Router } = require('express');
const { pool } = require('../config/db');

const router = Router();

const VALID_METHODS = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'];
const VALID_STATUS = ['active', 'beta', 'deprecated'];

// GET /api-catalog — list, filterable by ?domain=, ?pipelineId=, ?status=, ?method=
router.get('/', async (req, res, next) => {
  try {
    const {
      domain, pipelineId, status, method,
    } = req.query;
    const conditions = [];
    const params = [];

    const addFilter = (column, value) => {
      if (value === undefined) return;
      params.push(value);
      conditions.push(`${column} = $${params.length}`);
    };
    addFilter('domain', domain);
    addFilter('pipeline_id', pipelineId);
    addFilter('status', status);
    addFilter('method', method && method.toUpperCase());

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const { rows } = await pool.query(
      `SELECT id, name, method, path, description, domain, pipeline_id, process_label,
              rate_limit, version, auth_type, status, created_at, updated_at
       FROM api_catalog ${where} ORDER BY domain, name`,
      params,
    );
    res.json({ apis: rows });
  } catch (err) {
    next(err);
  }
});

// GET /api-catalog/:id — full detail including sample request/response and OpenAPI spec.
router.get('/:id', async (req, res, next) => {
  try {
    const { rows: [api] } = await pool.query('SELECT * FROM api_catalog WHERE id = $1', [req.params.id]);
    if (!api) return res.status(404).json({ error: { message: 'API catalog entry not found' } });
    res.json(api);
  } catch (err) {
    next(err);
  }
});

function validate(body, { partial = false } = {}) {
  const {
    name, method, path, description, domain,
  } = body;
  if (!partial && (!name || !method || !path || !description || !domain)) {
    return 'name, method, path, description, and domain are required';
  }
  if (method !== undefined && !VALID_METHODS.includes(method.toUpperCase())) {
    return `method must be one of ${VALID_METHODS.join(', ')}`;
  }
  if (body.status !== undefined && !VALID_STATUS.includes(body.status)) {
    return `status must be one of ${VALID_STATUS.join(', ')}`;
  }
  return null;
}

// POST /api-catalog — create a catalog entry.
// Body: { name, method, path, description, domain, pipelineId?, processLabel?,
//         rateLimit?, version?, authType?, sampleRequest?, sampleResponse?, openapiSpec?, status? }
router.post('/', async (req, res, next) => {
  try {
    const err = validate(req.body || {});
    if (err) return res.status(400).json({ error: { message: err } });

    const {
      name, method, path, description, domain,
      pipelineId = null, processLabel = null, rateLimit = null,
      version = 'v1', authType = 'bearer', sampleRequest = null,
      sampleResponse = null, openapiSpec = null, status = 'active',
    } = req.body;

    const { rows: [api] } = await pool.query(
      `INSERT INTO api_catalog (
         name, method, path, description, domain, pipeline_id, process_label,
         rate_limit, version, auth_type, sample_request, sample_response, openapi_spec, status
       ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14) RETURNING *`,
      [name, method.toUpperCase(), path, description, domain, pipelineId, processLabel,
        rateLimit, version, authType, sampleRequest, sampleResponse, openapiSpec, status],
    );
    res.status(201).json(api);
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: { message: `An entry for ${req.body.method} ${req.body.path} already exists` } });
    if (err.code === '23503') return res.status(400).json({ error: { message: `pipelineId "${req.body.pipelineId}" does not match an existing pipeline` } });
    next(err);
  }
});

// PUT /api-catalog/:id — partial update.
router.put('/:id', async (req, res, next) => {
  try {
    const err = validate(req.body || {}, { partial: true });
    if (err) return res.status(400).json({ error: { message: err } });

    const {
      name, method, path, description, domain, pipelineId, processLabel,
      rateLimit, version, authType, sampleRequest, sampleResponse, openapiSpec, status,
    } = req.body || {};

    const { rows: [api] } = await pool.query(
      `UPDATE api_catalog SET
         name = coalesce($2, name), method = coalesce($3, method), path = coalesce($4, path),
         description = coalesce($5, description), domain = coalesce($6, domain),
         pipeline_id = coalesce($7, pipeline_id), process_label = coalesce($8, process_label),
         rate_limit = coalesce($9, rate_limit), version = coalesce($10, version),
         auth_type = coalesce($11, auth_type), sample_request = coalesce($12, sample_request),
         sample_response = coalesce($13, sample_response), openapi_spec = coalesce($14, openapi_spec),
         status = coalesce($15, status), updated_at = now()
       WHERE id = $1 RETURNING *`,
      [req.params.id, name, method && method.toUpperCase(), path, description, domain, pipelineId,
        processLabel, rateLimit, version, authType, sampleRequest, sampleResponse, openapiSpec, status],
    );
    if (!api) return res.status(404).json({ error: { message: 'API catalog entry not found' } });
    res.json(api);
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: { message: `An entry for ${req.body.method} ${req.body.path} already exists` } });
    if (err.code === '23503') return res.status(400).json({ error: { message: `pipelineId "${req.body.pipelineId}" does not match an existing pipeline` } });
    next(err);
  }
});

// DELETE /api-catalog/:id — cascades to any mcp_gateway_bindings that wrap it.
router.delete('/:id', async (req, res, next) => {
  try {
    const { rowCount } = await pool.query('DELETE FROM api_catalog WHERE id = $1', [req.params.id]);
    if (!rowCount) return res.status(404).json({ error: { message: 'API catalog entry not found' } });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

module.exports = router;
