const { Router } = require('express');
const { pool } = require('../config/db');

const router = Router();

const VALID_STATUS = ['active', 'inactive'];

async function loadBindings(gatewayId) {
  const { rows } = await pool.query(
    `SELECT b.*, a.name AS api_name, a.method AS api_method, a.path AS api_path
     FROM mcp_gateway_bindings b
     LEFT JOIN api_catalog a ON a.id = b.api_id
     WHERE b.gateway_id = $1
     ORDER BY b.created_at`,
    [gatewayId],
  );
  return rows;
}

// GET /mcp-gateways — list, with binding counts.
router.get('/', async (req, res, next) => {
  try {
    const { rows } = await pool.query(
      `SELECT g.*, count(b.id)::int AS binding_count
       FROM mcp_gateways g
       LEFT JOIN mcp_gateway_bindings b ON b.gateway_id = g.id
       GROUP BY g.id ORDER BY g.name`,
    );
    res.json({ gateways: rows });
  } catch (err) {
    next(err);
  }
});

// GET /mcp-gateways/:id — gateway detail plus every bound API/tool, each
// tagged with whether it's api-backed or a standalone tool.
router.get('/:id', async (req, res, next) => {
  try {
    const { rows: [gateway] } = await pool.query('SELECT * FROM mcp_gateways WHERE id = $1', [req.params.id]);
    if (!gateway) return res.status(404).json({ error: { message: 'MCP gateway not found' } });

    const bindings = await loadBindings(req.params.id);
    res.json({ ...gateway, bindings });
  } catch (err) {
    next(err);
  }
});

// POST /mcp-gateways — create a bridge.
// Body: { name, description, status?, config? } — `config` is an opaque
// bag for transport-level fields this table has no native column for
// (url, protocol, authType, environment); see schema.sql comment.
router.post('/', async (req, res, next) => {
  try {
    const { name, description, status = 'active', config = {} } = req.body || {};
    if (!name || !description) return res.status(400).json({ error: { message: 'name and description are required' } });
    if (!VALID_STATUS.includes(status)) return res.status(400).json({ error: { message: `status must be one of ${VALID_STATUS.join(', ')}` } });

    const { rows: [gateway] } = await pool.query(
      'INSERT INTO mcp_gateways (name, description, status, config) VALUES ($1, $2, $3, $4) RETURNING *',
      [name, description, status, config],
    );
    res.status(201).json({ ...gateway, bindings: [] });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: { message: `Gateway "${req.body.name}" already exists` } });
    next(err);
  }
});

// PUT /mcp-gateways/:id — update name/description/status/config. Whole
// `config` object replaces the existing one when provided.
router.put('/:id', async (req, res, next) => {
  try {
    const { name, description, status, config } = req.body || {};
    if (status !== undefined && !VALID_STATUS.includes(status)) {
      return res.status(400).json({ error: { message: `status must be one of ${VALID_STATUS.join(', ')}` } });
    }

    const { rows: [gateway] } = await pool.query(
      `UPDATE mcp_gateways SET
         name = coalesce($2, name), description = coalesce($3, description),
         status = coalesce($4, status), config = coalesce($5, config), updated_at = now()
       WHERE id = $1 RETURNING *`,
      [req.params.id, name, description, status, config],
    );
    if (!gateway) return res.status(404).json({ error: { message: 'MCP gateway not found' } });
    res.json(gateway);
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: { message: `Gateway "${req.body.name}" already exists` } });
    next(err);
  }
});

// DELETE /mcp-gateways/:id — cascades to its bindings (ON DELETE CASCADE);
// does NOT delete the api_catalog entries a binding wraps.
router.delete('/:id', async (req, res, next) => {
  try {
    const { rowCount } = await pool.query('DELETE FROM mcp_gateways WHERE id = $1', [req.params.id]);
    if (!rowCount) return res.status(404).json({ error: { message: 'MCP gateway not found' } });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

// ── Bindings — one or more APIs/tools associated with a gateway ─────────

// POST /mcp-gateways/:id/bindings — bind an existing api_catalog entry
// (apiId) OR a standalone tool (toolName + toolDescription), never both.
// Body: { exposedName, apiId? , toolName?, toolDescription?, toolConfig?, enabled? }
router.post('/:id/bindings', async (req, res, next) => {
  try {
    const {
      exposedName, apiId, toolName, toolDescription, toolConfig = {}, enabled = true,
    } = req.body || {};

    if (!exposedName) return res.status(400).json({ error: { message: 'exposedName is required' } });
    if (Boolean(apiId) === Boolean(toolName)) {
      return res.status(400).json({ error: { message: 'Provide exactly one of apiId (to bind a catalog API) or toolName (to bind a standalone tool)' } });
    }
    if (toolName && !toolDescription) {
      return res.status(400).json({ error: { message: 'toolDescription is required when binding a standalone tool' } });
    }

    const { rows: [binding] } = await pool.query(
      `INSERT INTO mcp_gateway_bindings (gateway_id, api_id, tool_name, tool_description, tool_config, exposed_name, enabled)
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
      [req.params.id, apiId || null, toolName || null, toolDescription || null, toolConfig, exposedName, enabled],
    );
    res.status(201).json(binding);
  } catch (err) {
    if (err.code === '23503') {
      if (err.constraint === 'mcp_gateway_bindings_gateway_id_fkey') return res.status(404).json({ error: { message: 'MCP gateway not found' } });
      return res.status(400).json({ error: { message: `apiId "${req.body.apiId}" does not match an existing API catalog entry` } });
    }
    if (err.code === '23505') return res.status(409).json({ error: { message: `Gateway already has a binding exposed as "${req.body.exposedName}"` } });
    if (err.code === '23514') return res.status(400).json({ error: { message: 'Provide exactly one of apiId or toolName' } });
    next(err);
  }
});

// PUT /mcp-gateways/:id/bindings/:bindingId — update exposedName/config/enabled.
router.put('/:id/bindings/:bindingId', async (req, res, next) => {
  try {
    const {
      exposedName, toolConfig, enabled,
    } = req.body || {};

    const { rows: [binding] } = await pool.query(
      `UPDATE mcp_gateway_bindings SET
         exposed_name = coalesce($3, exposed_name),
         tool_config = coalesce($4, tool_config),
         enabled = coalesce($5, enabled)
       WHERE id = $1 AND gateway_id = $2 RETURNING *`,
      [req.params.bindingId, req.params.id, exposedName, toolConfig, enabled],
    );
    if (!binding) return res.status(404).json({ error: { message: 'Binding not found on this gateway' } });
    res.json(binding);
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: { message: `Gateway already has a binding exposed as "${req.body.exposedName}"` } });
    next(err);
  }
});

// DELETE /mcp-gateways/:id/bindings/:bindingId
router.delete('/:id/bindings/:bindingId', async (req, res, next) => {
  try {
    const { rowCount } = await pool.query(
      'DELETE FROM mcp_gateway_bindings WHERE id = $1 AND gateway_id = $2',
      [req.params.bindingId, req.params.id],
    );
    if (!rowCount) return res.status(404).json({ error: { message: 'Binding not found on this gateway' } });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

module.exports = router;
