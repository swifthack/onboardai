const { Router } = require('express');
const crypto = require('crypto');
const { pool } = require('../config/db');

const router = Router();

function rowToSentEmail(row) {
  return {
    id: row.id,
    clientId: row.client_id,
    clientName: row.client_name,
    email: row.email,
    subject: row.subject,
    body: row.body,
    date: row.date,
    status: row.status,
    sentAt: row.sent_at,
    deliveredAt: row.delivered_at,
    openedAt: row.opened_at,
    clickedAt: row.clicked_at,
  };
}

// GET /sent-emails — newest first.
router.get('/', async (req, res, next) => {
  try {
    const { rows } = await pool.query('SELECT * FROM sent_emails ORDER BY created_at DESC');
    res.json({ sentEmails: rows.map(rowToSentEmail) });
  } catch (err) {
    next(err);
  }
});

// POST /sent-emails — create. Body is the full sentEmails shape (camelCase).
router.post('/', async (req, res, next) => {
  try {
    const {
      clientId = null, clientName = null, email, subject = null, body = null, date = null,
      status = 'sent', sentAt = null, deliveredAt = null, openedAt = null, clickedAt = null,
    } = req.body || {};
    if (!email) return res.status(400).json({ error: { message: 'email is required' } });

    const id = req.body.id || `email_${crypto.randomBytes(6).toString('hex')}`;

    const { rows: [row] } = await pool.query(
      `INSERT INTO sent_emails (id, client_id, client_name, email, subject, body, date, status, sent_at, delivered_at, opened_at, clicked_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
       RETURNING *`,
      [id, clientId, clientName, email, subject, body, date, status, sentAt, deliveredAt, openedAt, clickedAt],
    );
    res.status(201).json(rowToSentEmail(row));
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: { message: `Sent email "${req.body.id}" already exists` } });
    if (err.code === '23514') return res.status(400).json({ error: { message: 'status must be one of sent, delivered, opened, clicked' } });
    next(err);
  }
});

// PUT /sent-emails/:id — partial update (used mainly to progress status: sent -> delivered -> opened -> clicked).
router.put('/:id', async (req, res, next) => {
  try {
    const { clientId, clientName, email, subject, body, date, status, sentAt, deliveredAt, openedAt, clickedAt } = req.body || {};
    const { rows: [row] } = await pool.query(
      `UPDATE sent_emails SET
         client_id = coalesce($2, client_id),
         client_name = coalesce($3, client_name),
         email = coalesce($4, email),
         subject = coalesce($5, subject),
         body = coalesce($6, body),
         date = coalesce($7, date),
         status = coalesce($8, status),
         sent_at = coalesce($9, sent_at),
         delivered_at = coalesce($10, delivered_at),
         opened_at = coalesce($11, opened_at),
         clicked_at = coalesce($12, clicked_at),
         updated_at = now()
       WHERE id = $1 RETURNING *`,
      [req.params.id, clientId, clientName, email, subject, body, date, status, sentAt, deliveredAt, openedAt, clickedAt],
    );
    if (!row) return res.status(404).json({ error: { message: 'Sent email not found' } });
    res.json(rowToSentEmail(row));
  } catch (err) {
    if (err.code === '23514') return res.status(400).json({ error: { message: 'status must be one of sent, delivered, opened, clicked' } });
    next(err);
  }
});

// DELETE /sent-emails/:id
router.delete('/:id', async (req, res, next) => {
  try {
    const { rowCount } = await pool.query('DELETE FROM sent_emails WHERE id = $1', [req.params.id]);
    if (!rowCount) return res.status(404).json({ error: { message: 'Sent email not found' } });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

module.exports = router;
