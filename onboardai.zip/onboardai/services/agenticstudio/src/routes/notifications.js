const { Router } = require('express');
const crypto = require('crypto');
const { pool } = require('../config/db');

const router = Router();

const toJsonb = (value) => (value === undefined ? undefined : JSON.stringify(value));

function rowToNotification(row) {
  return {
    id: row.id,
    type: row.type,
    title: row.title,
    msg: row.msg,
    time: row.time,
    node: row.node,
    clientId: row.client_id,
    clientName: row.client_name,
    actionRequired: row.action_required,
    actioned: row.actioned,
    documentDetails: row.document_details,
  };
}

// GET /notifications — newest first.
router.get('/', async (req, res, next) => {
  try {
    const { rows } = await pool.query('SELECT * FROM notifications ORDER BY created_at DESC');
    res.json({ notifications: rows.map(rowToNotification) });
  } catch (err) {
    next(err);
  }
});

// POST /notifications — create. Body is the full SystemNotification shape
// (camelCase). `id` optional, minted if omitted.
router.post('/', async (req, res, next) => {
  try {
    const {
      type, title, msg, time = null, node = null, clientId = null, clientName = null,
      actionRequired = false, actioned = false, documentDetails = {},
    } = req.body || {};
    if (!type || !title || !msg) return res.status(400).json({ error: { message: 'type, title, and msg are required' } });

    const id = req.body.id || `notif_${crypto.randomBytes(6).toString('hex')}`;

    const { rows: [row] } = await pool.query(
      `INSERT INTO notifications (id, type, title, msg, time, node, client_id, client_name, action_required, actioned, document_details)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
       RETURNING *`,
      [id, type, title, msg, time, node, clientId, clientName, actionRequired, actioned, toJsonb(documentDetails)],
    );
    res.status(201).json(rowToNotification(row));
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: { message: `Notification "${req.body.id}" already exists` } });
    if (err.code === '23514') return res.status(400).json({ error: { message: 'type must be one of critical, warning, info, success' } });
    next(err);
  }
});

// PUT /notifications/:id — partial update (used mainly to flip actioned/actionRequired).
router.put('/:id', async (req, res, next) => {
  try {
    const { type, title, msg, time, node, clientId, clientName, actionRequired, actioned, documentDetails } = req.body || {};
    const { rows: [row] } = await pool.query(
      `UPDATE notifications SET
         type = coalesce($2, type),
         title = coalesce($3, title),
         msg = coalesce($4, msg),
         time = coalesce($5, time),
         node = coalesce($6, node),
         client_id = coalesce($7, client_id),
         client_name = coalesce($8, client_name),
         action_required = coalesce($9, action_required),
         actioned = coalesce($10, actioned),
         document_details = coalesce($11, document_details),
         updated_at = now()
       WHERE id = $1 RETURNING *`,
      [req.params.id, type, title, msg, time, node, clientId, clientName, actionRequired, actioned, toJsonb(documentDetails)],
    );
    if (!row) return res.status(404).json({ error: { message: 'Notification not found' } });
    res.json(rowToNotification(row));
  } catch (err) {
    next(err);
  }
});

// DELETE /notifications/:id
router.delete('/:id', async (req, res, next) => {
  try {
    const { rowCount } = await pool.query('DELETE FROM notifications WHERE id = $1', [req.params.id]);
    if (!rowCount) return res.status(404).json({ error: { message: 'Notification not found' } });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

module.exports = router;
