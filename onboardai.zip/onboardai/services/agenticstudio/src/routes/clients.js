// Ported from services/clientos (see that service's README for the
// retirement note) — this backend now owns both configuration (agents,
// pipelines, guardrails, ...) and client/case CRUD for the execution
// deployment, so RM/Compliance/Ops/Customer's `clients` data and
// Platform Admin's config live behind one process against one database.
const { Router } = require('express');
const crypto = require('crypto');
const { pool } = require('../config/db');
const { upsertClientGraph, deleteClientGraph, getClientGraph } = require('../services/graphSync');

const router = Router();

// node-postgres serializes a plain JS array parameter as a Postgres array
// literal ('{a,b}'), not JSON — invalid input for a jsonb column. Only
// arrays need this; plain objects are auto-JSON-serialized by pg already.
const toJsonb = (value) => (value === undefined ? undefined : JSON.stringify(value));

// Maps a `clients` row (snake_case columns) to the frontend's camelCase
// ClientProfile shape.
function rowToClient(row) {
  return {
    id: row.id,
    companyName: row.company_name,
    registrationNumber: row.registration_number,
    jurisdiction: row.jurisdiction,
    industry: row.industry,
    overallStatus: row.overall_status,
    journeyId: row.journey_id,
    journeyName: row.journey_name,
    authorizedRepresentative: row.authorized_representative,
    shareholders: row.shareholders,
    financials: row.financials,
    documents: row.documents,
    workflowNodes: row.workflow_nodes,
    directors: row.directors,
    relatedParties: row.related_parties,
    alerts: row.alerts,
    govtRegistryUpdateRequests: row.govt_registry_update_requests,
    internalAccountSettings: row.internal_account_settings,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

// GET /clients — list, newest-updated first.
router.get('/', async (req, res, next) => {
  try {
    const { rows } = await pool.query('SELECT * FROM clients ORDER BY updated_at DESC');
    res.json({ clients: rows.map(rowToClient) });
  } catch (err) {
    next(err);
  }
});

// GET /clients/:id
router.get('/:id', async (req, res, next) => {
  try {
    const { rows: [row] } = await pool.query('SELECT * FROM clients WHERE id = $1', [req.params.id]);
    if (!row) return res.status(404).json({ error: { message: 'Client not found' } });
    res.json(rowToClient(row));
  } catch (err) {
    next(err);
  }
});

// GET /clients/:id/graph — live read of this client's Neo4j knowledge
// graph (directors/shareholders/related parties/representative and their
// relationships to the client), independent of the Postgres row.
router.get('/:id/graph', async (req, res, next) => {
  try {
    const graphData = await getClientGraph(req.params.id);
    res.json(graphData);
  } catch (err) {
    next(err);
  }
});

// POST /clients — create. Body is the full ClientProfile shape (camelCase,
// matching the frontend's type) — `id` is optional, minted if omitted.
router.post('/', async (req, res, next) => {
  try {
    const {
      companyName, registrationNumber = null, jurisdiction = null, industry = null,
      overallStatus = 'draft', journeyId = null, journeyName = null,
      authorizedRepresentative = {}, shareholders = [], financials = {}, documents = [],
      workflowNodes = [], directors = [], relatedParties = [], alerts = [],
      govtRegistryUpdateRequests = [], internalAccountSettings = {},
    } = req.body || {};
    if (!companyName) return res.status(400).json({ error: { message: 'companyName is required' } });

    const id = req.body.id || `client_${crypto.randomBytes(6).toString('hex')}`;

    const { rows: [row] } = await pool.query(
      `INSERT INTO clients (
         id, company_name, registration_number, jurisdiction, industry, overall_status,
         journey_id, journey_name, authorized_representative, shareholders, financials,
         documents, workflow_nodes, directors, related_parties, alerts,
         govt_registry_update_requests, internal_account_settings
       ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18)
       RETURNING *`,
      [id, companyName, registrationNumber, jurisdiction, industry, overallStatus, journeyId, journeyName,
        authorizedRepresentative, toJsonb(shareholders), financials, toJsonb(documents), toJsonb(workflowNodes),
        toJsonb(directors), toJsonb(relatedParties), toJsonb(alerts), toJsonb(govtRegistryUpdateRequests),
        internalAccountSettings],
    );

    const client = rowToClient(row);
    try {
      await upsertClientGraph(client);
    } catch (e) {
      console.warn('[clientos] graph sync failed for', id, e.message);
    }
    res.status(201).json(client);
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: { message: `Client "${req.body.id}" already exists` } });
    if (err.code === '23514') return res.status(400).json({ error: { message: 'overallStatus must be one of draft, in_progress, approved, rejected' } });
    next(err);
  }
});

// PUT /clients/:id — partial update (full-replace semantics on JSONB
// fields when provided, matching the frontend's save-the-whole-client
// model — see useBackendSync on the frontend).
router.put('/:id', async (req, res, next) => {
  try {
    const {
      companyName, registrationNumber, jurisdiction, industry, overallStatus,
      journeyId, journeyName, authorizedRepresentative, shareholders, financials,
      documents, workflowNodes, directors, relatedParties, alerts,
      govtRegistryUpdateRequests, internalAccountSettings,
    } = req.body || {};

    const { rows: [row] } = await pool.query(
      `UPDATE clients SET
         company_name = coalesce($2, company_name),
         registration_number = coalesce($3, registration_number),
         jurisdiction = coalesce($4, jurisdiction),
         industry = coalesce($5, industry),
         overall_status = coalesce($6, overall_status),
         journey_id = coalesce($7, journey_id),
         journey_name = coalesce($8, journey_name),
         authorized_representative = coalesce($9, authorized_representative),
         shareholders = coalesce($10, shareholders),
         financials = coalesce($11, financials),
         documents = coalesce($12, documents),
         workflow_nodes = coalesce($13, workflow_nodes),
         directors = coalesce($14, directors),
         related_parties = coalesce($15, related_parties),
         alerts = coalesce($16, alerts),
         govt_registry_update_requests = coalesce($17, govt_registry_update_requests),
         internal_account_settings = coalesce($18, internal_account_settings),
         updated_at = now()
       WHERE id = $1 RETURNING *`,
      [req.params.id, companyName, registrationNumber, jurisdiction, industry, overallStatus, journeyId, journeyName,
        authorizedRepresentative, toJsonb(shareholders), financials, toJsonb(documents), toJsonb(workflowNodes),
        toJsonb(directors), toJsonb(relatedParties), toJsonb(alerts), toJsonb(govtRegistryUpdateRequests),
        internalAccountSettings],
    );
    if (!row) return res.status(404).json({ error: { message: 'Client not found' } });

    const client = rowToClient(row);
    try {
      await upsertClientGraph(client);
    } catch (e) {
      console.warn('[clientos] graph sync failed for', req.params.id, e.message);
    }
    res.json(client);
  } catch (err) {
    if (err.code === '23514') return res.status(400).json({ error: { message: 'overallStatus must be one of draft, in_progress, approved, rejected' } });
    next(err);
  }
});

// DELETE /clients/:id
router.delete('/:id', async (req, res, next) => {
  try {
    const { rowCount } = await pool.query('DELETE FROM clients WHERE id = $1', [req.params.id]);
    if (!rowCount) return res.status(404).json({ error: { message: 'Client not found' } });
    try {
      await deleteClientGraph(req.params.id);
    } catch (e) {
      console.warn('[clientos] graph delete failed for', req.params.id, e.message);
    }
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

module.exports = router;
