const { Router } = require('express');
const crypto = require('crypto');
const { pool } = require('../config/db');

const router = Router();

// GET /agents — registry listing (the 19 seeded KYC-mesh agents plus any
// custom agents created through the frontend's Agent Studio).
router.get('/', async (req, res, next) => {
  try {
    const { rows } = await pool.query(
      `SELECT a.*, count(pa.pipeline_id) AS pipeline_count
       FROM agents a
       LEFT JOIN pipeline_agents pa ON pa.agent_id = a.id
       GROUP BY a.id
       ORDER BY a.id`,
    );
    res.json({ agents: rows });
  } catch (err) {
    next(err);
  }
});

// GET /agents/:id — agent detail plus every pipeline it participates in,
// with the per-pipeline role/scope text (which differs pipeline to pipeline).
router.get('/:id', async (req, res, next) => {
  try {
    const { rows: [agent] } = await pool.query('SELECT * FROM agents WHERE id = $1', [req.params.id]);
    if (!agent) return res.status(404).json({ error: { message: 'Agent not found' } });

    const { rows: pipelines } = await pool.query(
      `SELECT p.id, p.name, p.stage, pa.agent_role, pa.agent_scope, pa.sequence
       FROM pipeline_agents pa
       JOIN pipelines p ON p.id = pa.pipeline_id
       WHERE pa.agent_id = $1
       ORDER BY p.id`,
      [req.params.id],
    );

    res.json({ ...agent, pipelines });
  } catch (err) {
    next(err);
  }
});

// POST /agents — create a custom agent (the 19 seeded agents are reference
// data from db/seed/catalog.js; this is for agents authored in the
// frontend's Agent Studio). Body: { id?, name, config? }. `config` is an
// opaque bag for whatever shape the caller wants (see schema.sql comment
// on agents.config) — this backend does not validate its contents.
router.post('/', async (req, res, next) => {
  try {
    const { name, config = {} } = req.body || {};
    if (!name) return res.status(400).json({ error: { message: 'name is required' } });

    const id = req.body.id || `agent_${crypto.randomBytes(6).toString('hex')}`;

    const { rows: [agent] } = await pool.query(
      'INSERT INTO agents (id, name, config) VALUES ($1, $2, $3) RETURNING *',
      [id, name, config],
    );
    res.status(201).json({ ...agent, pipeline_count: 0 });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: { message: `Agent "${req.body.id}" already exists` } });
    next(err);
  }
});

// PUT /agents/:id — partial update. Whole `config` object replaces the
// existing one when provided (send the merged object, not just the diff).
router.put('/:id', async (req, res, next) => {
  try {
    const { name, config } = req.body || {};
    const { rows: [agent] } = await pool.query(
      `UPDATE agents SET
         name = coalesce($2, name),
         config = coalesce($3, config),
         updated_at = now()
       WHERE id = $1 RETURNING *`,
      [req.params.id, name, config],
    );
    if (!agent) return res.status(404).json({ error: { message: 'Agent not found' } });
    res.json(agent);
  } catch (err) {
    next(err);
  }
});

// DELETE /agents/:id — refuses if the agent is still wired into a
// pipeline's step/agent list (P-01..P-27 reference data); detach it there
// first. Custom agents with no pipeline references delete cleanly.
router.delete('/:id', async (req, res, next) => {
  try {
    const { rows: [{ count }] } = await pool.query(
      'SELECT count(*)::int AS count FROM pipeline_agents WHERE agent_id = $1',
      [req.params.id],
    );
    if (count > 0) {
      return res.status(409).json({
        error: { message: `Cannot delete agent "${req.params.id}": referenced by ${count} pipeline(s).` },
      });
    }

    const { rowCount } = await pool.query('DELETE FROM agents WHERE id = $1', [req.params.id]);
    if (!rowCount) return res.status(404).json({ error: { message: 'Agent not found' } });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

module.exports = router;
