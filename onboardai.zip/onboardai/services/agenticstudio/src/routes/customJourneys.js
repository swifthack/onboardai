const { Router } = require('express');
const { pool } = require('../config/db');

const router = Router();

// node-postgres serializes a plain JS array parameter as a Postgres array
// literal ('{a,b}'), not JSON — invalid input for a jsonb column. Only
// arrays need this; plain objects are auto-JSON-serialized by pg already.
const toJsonb = (value) => (value === undefined ? undefined : JSON.stringify(value));

// GET /custom-journeys — list, newest first.
router.get('/', async (req, res, next) => {
  try {
    const { rows } = await pool.query('SELECT * FROM custom_journeys ORDER BY updated_at DESC');
    res.json({ journeys: rows });
  } catch (err) {
    next(err);
  }
});

// GET /custom-journeys/:id
router.get('/:id', async (req, res, next) => {
  try {
    const { rows: [journey] } = await pool.query('SELECT * FROM custom_journeys WHERE id = $1', [req.params.id]);
    if (!journey) return res.status(404).json({ error: { message: 'Journey not found' } });
    res.json(journey);
  } catch (err) {
    next(err);
  }
});

// POST /custom-journeys — create.
// Body: { id, name, description?, expectedSla?, primaryAnchorId?, status?,
//         linkedPipelineId?, intakeDocuments?, riskEscalationThreshold?,
//         contractingMethod?, targetEntity?, parallelBranchRules?,
//         stages?, phases?, hybridStages?, steps?, extra? }
// `id` is required — the frontend already mints its own (e.g.
// 'corporate_onboarding_journey') and this preserves it as-is.
router.post('/', async (req, res, next) => {
  try {
    const {
      id, name, description = null, expectedSla = null, primaryAnchorId = null,
      status = 'Draft', linkedPipelineId = null, intakeDocuments = [],
      riskEscalationThreshold = null, contractingMethod = null, targetEntity = null,
      parallelBranchRules = null, stages = [], phases = [], hybridStages = [], steps = [],
      extra = {},
    } = req.body || {};
    if (!id || !name) return res.status(400).json({ error: { message: 'id and name are required' } });

    const { rows: [journey] } = await pool.query(
      `INSERT INTO custom_journeys (
         id, name, description, expected_sla, primary_anchor_id, status, linked_pipeline_id,
         intake_documents, risk_escalation_threshold, contracting_method, target_entity,
         parallel_branch_rules, stages, phases, hybrid_stages, steps, extra
       ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
       RETURNING *`,
      [id, name, description, expectedSla, primaryAnchorId, status, linkedPipelineId,
        toJsonb(intakeDocuments), riskEscalationThreshold, contractingMethod, targetEntity,
        parallelBranchRules, toJsonb(stages), toJsonb(phases), toJsonb(hybridStages), toJsonb(steps), extra],
    );
    res.status(201).json(journey);
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: { message: `Journey "${req.body.id}" already exists` } });
    if (err.code === '23514') return res.status(400).json({ error: { message: 'status must be one of Active, Draft, Deprecated' } });
    next(err);
  }
});

// PUT /custom-journeys/:id — partial update (full-replace semantics on
// array/object fields when provided, matching the frontend's
// save-the-whole-journey model).
router.put('/:id', async (req, res, next) => {
  try {
    const {
      name, description, expectedSla, primaryAnchorId, status, linkedPipelineId,
      intakeDocuments, riskEscalationThreshold, contractingMethod, targetEntity,
      parallelBranchRules, stages, phases, hybridStages, steps, extra,
    } = req.body || {};

    const { rows: [journey] } = await pool.query(
      `UPDATE custom_journeys SET
         name = coalesce($2, name),
         description = coalesce($3, description),
         expected_sla = coalesce($4, expected_sla),
         primary_anchor_id = coalesce($5, primary_anchor_id),
         status = coalesce($6, status),
         linked_pipeline_id = coalesce($7, linked_pipeline_id),
         intake_documents = coalesce($8, intake_documents),
         risk_escalation_threshold = coalesce($9, risk_escalation_threshold),
         contracting_method = coalesce($10, contracting_method),
         target_entity = coalesce($11, target_entity),
         parallel_branch_rules = coalesce($12, parallel_branch_rules),
         stages = coalesce($13, stages),
         phases = coalesce($14, phases),
         hybrid_stages = coalesce($15, hybrid_stages),
         steps = coalesce($16, steps),
         extra = coalesce($17, extra),
         updated_at = now()
       WHERE id = $1 RETURNING *`,
      [req.params.id, name, description, expectedSla, primaryAnchorId, status, linkedPipelineId,
        toJsonb(intakeDocuments), riskEscalationThreshold, contractingMethod, targetEntity,
        parallelBranchRules, toJsonb(stages), toJsonb(phases), toJsonb(hybridStages), toJsonb(steps), extra],
    );
    if (!journey) return res.status(404).json({ error: { message: 'Journey not found' } });
    res.json(journey);
  } catch (err) {
    if (err.code === '23514') return res.status(400).json({ error: { message: 'status must be one of Active, Draft, Deprecated' } });
    next(err);
  }
});

// DELETE /custom-journeys/:id
router.delete('/:id', async (req, res, next) => {
  try {
    const { rowCount } = await pool.query('DELETE FROM custom_journeys WHERE id = $1', [req.params.id]);
    if (!rowCount) return res.status(404).json({ error: { message: 'Journey not found' } });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

module.exports = router;
