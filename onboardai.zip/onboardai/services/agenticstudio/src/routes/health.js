const { Router } = require('express');
const { ping } = require('../config/db');
const graph = require('../config/neo4j');

const router = Router();

// Liveness — process is up. No dependency checks.
router.get('/', (req, res) => {
  res.json({ status: 'ok', service: 'agenticstudio' });
});

// Readiness — can this instance actually serve traffic right now.
// Neo4j is only checked when configured (NEO4J_URI set) — the design
// deployment never sets it, since it never touches clients/the graph.
router.get('/ready', async (req, res) => {
  const checks = { db: 'up' };
  let ok = true;

  try {
    await ping();
  } catch (err) {
    ok = false;
    checks.db = `down: ${err.message}`;
  }

  if (graph.enabled) {
    try {
      await graph.ping();
      checks.neo4j = 'up';
    } catch (err) {
      ok = false;
      checks.neo4j = `down: ${err.message}`;
    }
  }

  res.status(ok ? 200 : 503).json({ status: ok ? 'ok' : 'error', ...checks });
});

module.exports = router;
