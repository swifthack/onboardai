const { Router } = require('express');
const health = require('./health');
const agents = require('./agents');
const pipelines = require('./pipelines');
const runs = require('./runs');
const guardrailDomains = require('./guardrailDomains');
const guardrails = require('./guardrails');
const apiCatalog = require('./apiCatalog');
const mcpGateways = require('./mcpGateways');
const customOrchestrations = require('./customOrchestrations');
const customJourneys = require('./customJourneys');
const clients = require('./clients');
const notifications = require('./notifications');
const sentEmails = require('./sentEmails');

const router = Router();

router.use('/health', health);
router.use('/agents', agents);
router.use('/pipelines', pipelines);
router.use('/runs', runs);
router.use('/guardrail-domains', guardrailDomains);
router.use('/guardrails', guardrails);
router.use('/api-catalog', apiCatalog);
router.use('/mcp-gateways', mcpGateways);
router.use('/custom-orchestrations', customOrchestrations);
router.use('/custom-journeys', customJourneys);
// Client/case CRUD (RM/Compliance/Ops/Customer) — only meaningfully used
// in the execution deployment; see routes/clients.js and services/graphSync.js.
router.use('/clients', clients);
// Notification banners + RM outreach email log (RM/Compliance/Ops) — same
// execution-only category as /clients.
router.use('/notifications', notifications);
router.use('/sent-emails', sentEmails);

module.exports = router;
