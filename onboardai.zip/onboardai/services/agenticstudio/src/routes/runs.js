const { Router } = require('express');
const runner = require('../services/pipelineRunner');

const router = Router();

// GET /runs/:id — a single run (any pipeline) plus its step results.
router.get('/:id', async (req, res, next) => {
  try {
    const result = await runner.getRun(req.params.id);
    if (!result) return res.status(404).json({ error: { message: 'Run not found' } });
    res.json(result);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
