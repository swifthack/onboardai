const { Router } = require('express');
const { pool } = require('../config/db');

const router = Router();

// node-postgres serializes a plain JS array parameter as a Postgres array
// literal ('{a,b}'), not JSON — invalid input for a jsonb column. Only
// arrays need this; plain objects are auto-JSON-serialized by pg already.
const toJsonb = (value) => (value === undefined ? undefined : JSON.stringify(value));

// GET /custom-orchestrations — list, oldest first (creation order).
// `created_at` never changes after insert (unlike `updated_at`), so the
// seeded P-01..P-27 stay in ascending numeric order regardless of how many
// times they're later edited; any custom (non-P-numbered) orchestration a
// user creates just lands at the end. Was `updated_at DESC` — flipped
// because that showed P-27 first, P-01 last on the Agentic Process Flows
// list (frontend renders array order as-is, no client-side sort).
router.get('/', async (req, res, next) => {
  try {
    const { rows } = await pool.query('SELECT * FROM custom_orchestrations ORDER BY created_at ASC');
    res.json({ orchestrations: rows });
  } catch (err) {
    next(err);
  }
});

// GET /custom-orchestrations/:id
router.get('/:id', async (req, res, next) => {
  try {
    const { rows: [orch] } = await pool.query('SELECT * FROM custom_orchestrations WHERE id = $1', [req.params.id]);
    if (!orch) return res.status(404).json({ error: { message: 'Orchestration not found' } });
    res.json(orch);
  } catch (err) {
    next(err);
  }
});

// POST /custom-orchestrations — create.
// Body: { id, name, description?, type?, strategy?, agentIds?, connections?, stages?, layout? }
// `id` is required (not generated server-side) — the frontend canvas
// already mints its own ids (e.g. 'pipeline_482913') and this preserves
// them as-is rather than swapping in a different one on save.
router.post('/', async (req, res, next) => {
  try {
    const {
      id, name, description = null, type = null, strategy = null,
      agentIds = [], connections = [], stages = [], layout = {},
    } = req.body || {};
    if (!id || !name) return res.status(400).json({ error: { message: 'id and name are required' } });

    const { rows: [orch] } = await pool.query(
      `INSERT INTO custom_orchestrations (id, name, description, type, strategy, agent_ids, connections, stages, layout)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`,
      [id, name, description, type, strategy, toJsonb(agentIds), toJsonb(connections), toJsonb(stages), toJsonb(layout)],
    );
    res.status(201).json(orch);
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: { message: `Orchestration "${req.body.id}" already exists` } });
    next(err);
  }
});

// PUT /custom-orchestrations/:id — partial update (full-replace semantics
// on array/object fields when provided, matching the frontend's
// save-the-whole-canvas-state model).
router.put('/:id', async (req, res, next) => {
  try {
    const {
      name, description, type, strategy, agentIds, connections, stages, layout,
    } = req.body || {};

    const { rows: [orch] } = await pool.query(
      `UPDATE custom_orchestrations SET
         name = coalesce($2, name),
         description = coalesce($3, description),
         type = coalesce($4, type),
         strategy = coalesce($5, strategy),
         agent_ids = coalesce($6, agent_ids),
         connections = coalesce($7, connections),
         stages = coalesce($8, stages),
         layout = coalesce($9, layout),
         updated_at = now()
       WHERE id = $1 RETURNING *`,
      [req.params.id, name, description, type, strategy, toJsonb(agentIds), toJsonb(connections), toJsonb(stages), toJsonb(layout)],
    );
    if (!orch) return res.status(404).json({ error: { message: 'Orchestration not found' } });
    res.json(orch);
  } catch (err) {
    next(err);
  }
});

// DELETE /custom-orchestrations/:id
router.delete('/:id', async (req, res, next) => {
  try {
    const { rowCount } = await pool.query('DELETE FROM custom_orchestrations WHERE id = $1', [req.params.id]);
    if (!rowCount) return res.status(404).json({ error: { message: 'Orchestration not found' } });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

module.exports = router;
