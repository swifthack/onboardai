const { Router } = require('express');
const { pool } = require('../config/db');
const runner = require('../services/pipelineRunner');

const router = Router();

// GET /pipelines — flat listing, id order (P-01..P-27).
router.get('/', async (req, res, next) => {
  try {
    const { rows } = await pool.query('SELECT id, name, stage, role FROM pipelines ORDER BY id');
    res.json({ pipelines: rows });
  } catch (err) {
    next(err);
  }
});

// GET /pipelines/topology — grouped by stage, in topology-map order. Stage
// order is derived from each stage's lowest pipeline id, matching the
// STAGE 1..9 ordering in the architecture doc without hand-maintaining a
// separate stage-order list here.
router.get('/topology', async (req, res, next) => {
  try {
    const { rows } = await pool.query('SELECT id, name, stage FROM pipelines ORDER BY id');
    const stages = new Map();
    for (const p of rows) {
      if (!stages.has(p.stage)) stages.set(p.stage, []);
      stages.get(p.stage).push(p);
    }
    res.json({ stages: [...stages.entries()].map(([stage, pipelines]) => ({ stage, pipelines })) });
  } catch (err) {
    next(err);
  }
});

// GET /pipelines/:id — full detail: role/scope, associated agents, ordered steps.
router.get('/:id', async (req, res, next) => {
  try {
    const { rows: [pipeline] } = await pool.query('SELECT * FROM pipelines WHERE id = $1', [req.params.id]);
    if (!pipeline) return res.status(404).json({ error: { message: 'Pipeline not found' } });

    const { rows: pipelineAgents } = await pool.query(
      `SELECT pa.sequence, pa.agent_id, a.name AS agent_name, pa.agent_role, pa.agent_scope
       FROM pipeline_agents pa JOIN agents a ON a.id = pa.agent_id
       WHERE pa.pipeline_id = $1 ORDER BY pa.sequence`,
      [req.params.id],
    );

    const { rows: steps } = await pool.query(
      `SELECT ps.sequence, ps.agent_id, a.name AS agent_name, ps.description
       FROM pipeline_steps ps LEFT JOIN agents a ON a.id = ps.agent_id
       WHERE ps.pipeline_id = $1 ORDER BY ps.sequence`,
      [req.params.id],
    );

    res.json({ ...pipeline, agents: pipelineAgents, steps });
  } catch (err) {
    next(err);
  }
});

// GET /pipelines/:id/runs — run history for this pipeline, newest first.
router.get('/:id/runs', async (req, res, next) => {
  try {
    const { rows } = await pool.query(
      'SELECT * FROM pipeline_runs WHERE pipeline_id = $1 ORDER BY created_at DESC LIMIT 50',
      [req.params.id],
    );
    res.json({ runs: rows });
  } catch (err) {
    next(err);
  }
});

// POST /pipelines/:id/runs — execute the pipeline now, synchronously (stub
// agents resolve instantly; swap to a queued/async model once real agents
// do real I/O). Body: { input?: object, clientId?: uuid }.
router.post('/:id/runs', async (req, res, next) => {
  try {
    const { input, clientId } = req.body || {};
    const result = await runner.runPipeline(req.params.id, { input, clientId });
    const status = result.run.status === 'failed' ? 422 : 201;
    res.status(status).json(result);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
