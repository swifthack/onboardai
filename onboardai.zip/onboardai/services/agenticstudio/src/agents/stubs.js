// Stub adapters — one function per agent_id, same spirit as the
// SourceAdapter convention in ../../../shared/ARCHITECTURE.md §5: every
// agent returns realistic, clearly-marked fixture data (`_stub: true`) so
// pipelines can be built and run end-to-end before any real model/registry
// integration exists. Swapping a stub for a live implementation later
// means replacing the function body here — the {input, priorOutputs,
// clientId} call shape doesn't change.
//
// `context` passed to every stub: { input, priorOutputs, clientId, pipelineId }
//   - input: the run's original input payload
//   - priorOutputs: array of this run's completed step outputs so far

const stub = (agentId, data) => ({
  _stub: true,
  agent_id: agentId,
  generated_at: new Date().toISOString(),
  ...data,
});

const STUBS = {
  lead_intelligence_agent: (ctx) => stub('lead_intelligence_agent', {
    entity_name: ctx.input.entity_name || 'Unknown Pty Ltd',
    estimated_revenue_tier: 'USD 10M-50M',
    industry_classification: { ssic: '6499', naics: '523900', label: 'Other financial services' },
    risk_tier_preliminary: 'MEDIUM',
    recommended_track: 'digital_fast_track',
  }),

  entity_resolution_agent: (ctx) => stub('entity_resolution_agent', {
    golden_record: {
      legal_name: ctx.input.entity_name || 'Unknown Pty Ltd',
      registration_number: 'STUB-REG-000000',
      jurisdiction: ctx.input.jurisdiction || 'SG',
      lei: null,
    },
    duplicate_check: { is_duplicate: false, matched_client_id: null },
  }),

  knowledge_graph_agent: () => stub('knowledge_graph_agent', {
    node_id: `node_${Math.random().toString(36).slice(2, 10)}`,
    node_type: 'entity',
    relationships_created: 0,
    graph_write_status: 'written',
  }),

  cross_validation_agent: () => stub('cross_validation_agent', {
    consistency_score: 0.92,
    discrepancies: [],
  }),

  ubo_ownership_agent: () => stub('ubo_ownership_agent', {
    ownership_layers: 2,
    ubos: [
      { name: 'Stub UBO One', effective_pct: 55.0, threshold_met: true },
      { name: 'Stub UBO Two', effective_pct: 20.0, threshold_met: false },
    ],
  }),

  director_verification_agent: () => stub('director_verification_agent', {
    directors: [
      { name: 'Stub Director One', appointment_status: 'active', disqualification_check: 'clear' },
    ],
  }),

  biometric_verification_agent: () => stub('biometric_verification_agent', {
    identity_confidence: 0.97,
    liveness_score: 0.95,
    document_check: 'passed',
  }),

  vlei_verification_agent: () => stub('vlei_verification_agent', {
    vlei_valid: true,
    issuer_trust_chain_valid: true,
    revocation_status: 'not_revoked',
  }),

  ocr_doc_intelligence_agent: (ctx) => stub('ocr_doc_intelligence_agent', {
    document_type: ctx.input.document_type || 'certificate_of_incorporation',
    extracted_fields: { incorporation_date: '2019-04-11', registered_address: 'Stub Address, SG' },
    forensic_authenticity_score: 0.98,
  }),

  dynamic_kyc_agent: () => stub('dynamic_kyc_agent', {
    questionnaire_id: `q_${Math.random().toString(36).slice(2, 10)}`,
    questions_generated: 12,
    declarations_captured: false,
  }),

  sanctions_pep_agent: () => stub('sanctions_pep_agent', {
    screened_subjects: 1,
    hits: [],
    overall_classification: 'FALSE_POSITIVE',
  }),

  adverse_media_agent: () => stub('adverse_media_agent', {
    articles_scanned: 240,
    adverse_hits: [],
    severity: 'none',
  }),

  risk_synthesis_agent: () => stub('risk_synthesis_agent', {
    composite_score: 42,
    risk_rating: 'MEDIUM',
    review_frequency_months: 12,
  }),

  edd_investigation_agent: () => stub('edd_investigation_agent', {
    sow_narrative_summary: 'Stub source-of-wealth narrative pending real investigation.',
    mitigation_recommendations: [],
  }),

  board_resolution_agent: () => stub('board_resolution_agent', {
    signatory_tiers: ['A', 'B'],
    signing_rules: 'joint_two_of_three',
  }),

  approval_gateway_agent: () => stub('approval_gateway_agent', {
    approval_status: 'approved',
    audit_certificate_id: `cert_${Math.random().toString(36).slice(2, 10)}`,
  }),

  credit_provisioning_agent: () => stub('credit_provisioning_agent', {
    provisioned_accounts: [{ type: 'CASA', currency: 'USD', account_ref: 'STUB-ACC-000001' }],
  }),

  rtt_validation_agent: () => stub('rtt_validation_agent', {
    handshake_results: { core_banking: 'ok', payment_rails: 'ok', transaction_monitoring: 'ok' },
    client_status: 'ACTIVE',
  }),

  perpetual_kyc_agent: () => stub('perpetual_kyc_agent', {
    event_type: 'director_resignation',
    affected_client_id: null,
    remediation_task_created: true,
  }),
};

module.exports = { STUBS };
