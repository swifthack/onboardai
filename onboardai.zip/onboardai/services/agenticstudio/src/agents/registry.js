// Executable agent registry — maps agent_id -> an execute(context) function.
// Every agent is stub-mode today (see stubs.js); a live implementation
// swaps in here per agent_id without any pipelineRunner/route changes,
// same "mode: stub|live" idea as ../../../shared/ARCHITECTURE.md §5.
const { STUBS } = require('./stubs');

function getExecutor(agentId) {
  const fn = STUBS[agentId];
  if (!fn) {
    throw new Error(`No executor registered for agent_id "${agentId}"`);
  }
  return fn;
}

async function execute(agentId, context) {
  const fn = getExecutor(agentId);
  return fn(context);
}

module.exports = { execute, getExecutor, agentIds: Object.keys(STUBS) };
