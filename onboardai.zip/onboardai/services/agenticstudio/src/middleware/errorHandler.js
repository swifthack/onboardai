// Centralized error handler — keep route handlers throwing/rejecting and
// let this shape the response, instead of each route formatting its own.
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  console.error(err);
  const status = err.status || 500;
  res.status(status).json({
    error: {
      message: status === 500 ? 'Internal server error' : err.message,
    },
  });
}

module.exports = errorHandler;
