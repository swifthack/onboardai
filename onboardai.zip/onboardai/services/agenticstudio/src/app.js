const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');

const routes = require('./routes');
const errorHandler = require('./middleware/errorHandler');
const config = require('./config');

const app = express();

app.use(helmet());
app.use(cors());
app.use(morgan(config.env === 'production' ? 'combined' : 'dev'));
app.use(express.json());

app.use('/', routes);

app.use((req, res) => {
  res.status(404).json({ error: { message: 'Not found' } });
});

app.use(errorHandler);

module.exports = app;
