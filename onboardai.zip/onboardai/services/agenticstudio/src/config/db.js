const { Pool } = require('pg');
const config = require('./index');

// Single shared pool for the process. Every query should go through this
// (or a client checked out from it) rather than opening ad-hoc connections.
const pool = new Pool({
  connectionString: config.databaseUrl,
});

pool.on('error', (err) => {
  // Postgres terminated an idle client in the pool — log and keep running,
  // don't crash the process over a background connection.
  console.error('Unexpected error on idle Postgres client', err);
});

async function ping() {
  const result = await pool.query('SELECT 1 AS ok');
  return result.rows[0].ok === 1;
}

module.exports = { pool, ping };
