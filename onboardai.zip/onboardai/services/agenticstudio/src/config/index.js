require('dotenv').config();

module.exports = {
  env: process.env.NODE_ENV || 'development',
  port: parseInt(process.env.PORT, 10) || 4001,
  databaseUrl: process.env.DATABASE_URL,
  // Optional — only the execution deployment sets these (it also owns
  // ClientOS's client/case CRUD + knowledge graph; design/Platform Admin
  // never touches either). See config/neo4j.js.
  neo4j: {
    uri: process.env.NEO4J_URI,
    user: process.env.NEO4J_USER,
    password: process.env.NEO4J_PASSWORD,
  },
};
