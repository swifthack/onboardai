const neo4j = require('neo4j-driver');
const config = require('./index');

// Optional — only set (NEO4J_URI etc.) in the execution deployment, which
// also owns ClientOS's client/case CRUD (routes/clients.js) and knowledge
// graph. The design deployment (Platform Admin / configuration only) never
// touches clients or the graph, so this stays uninitialized there rather
// than failing to connect to something that was never provisioned.
const enabled = !!config.neo4j.uri;
const driver = enabled
  ? neo4j.driver(config.neo4j.uri, neo4j.auth.basic(config.neo4j.user, config.neo4j.password))
  : null;

async function ping() {
  if (!driver) return false;
  await driver.verifyConnectivity();
  return true;
}

async function close() {
  if (driver) await driver.close();
}

module.exports = { driver, enabled, ping, close };
