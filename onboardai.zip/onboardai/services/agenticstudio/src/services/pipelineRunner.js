// Generic pipeline orchestrator — walks a pipeline's ordered steps (loaded
// from the registry tables, seeded from db/seed/catalog.js) and invokes
// each step's agent via src/agents/registry.js, persisting run/step state
// and an event trail as it goes. One engine drives all 27 pipelines; the
// pipelines themselves are data (rows), not 27 hand-written orchestrator
// files.
const { pool } = require('../config/db');
const agents = require('../agents/registry');

class PipelineNotFoundError extends Error {
  constructor(pipelineId) {
    super(`Pipeline "${pipelineId}" not found`);
    this.status = 404;
  }
}

async function loadPipeline(pipelineId) {
  const { rows: [pipeline] } = await pool.query('SELECT * FROM pipelines WHERE id = $1', [pipelineId]);
  if (!pipeline) throw new PipelineNotFoundError(pipelineId);

  const { rows: steps } = await pool.query(
    'SELECT * FROM pipeline_steps WHERE pipeline_id = $1 ORDER BY sequence ASC',
    [pipelineId],
  );
  return { pipeline, steps };
}

async function logEvent(client, { runId, pipelineId, agentId, correlationId, eventType, payload }) {
  await client.query(
    `INSERT INTO events (event_type, run_id, pipeline_id, agent_id, correlation_id, payload)
     VALUES ($1, $2, $3, $4, $5, $6)`,
    [eventType, runId, pipelineId, agentId || null, correlationId, payload],
  );
}

async function runPipeline(pipelineId, { input = {}, clientId = null } = {}) {
  const { steps } = await loadPipeline(pipelineId);

  const { rows: [run] } = await pool.query(
    `INSERT INTO pipeline_runs (pipeline_id, client_id, status, input, started_at)
     VALUES ($1, $2, 'running', $3, now()) RETURNING *`,
    [pipelineId, clientId, input],
  );
  const correlationId = run.id;

  await logEvent(pool, {
    runId: run.id, pipelineId, correlationId, eventType: 'PIPELINE_RUN_STARTED', payload: { input },
  });

  const priorOutputs = [];
  const runSteps = [];

  for (const step of steps) {
    const { rows: [runStep] } = await pool.query(
      `INSERT INTO pipeline_run_steps (run_id, step_id, agent_id, sequence, status, input, started_at)
       VALUES ($1, $2, $3, $4, 'running', $5, now()) RETURNING *`,
      [run.id, step.id, step.agent_id, step.sequence, { input, priorOutputs }],
    );

    if (!step.agent_id) {
      // Handoff/output-only step (no agent named in the spec) — record it
      // as a no-op completion so the run's step list stays complete.
      const { rows: [completed] } = await pool.query(
        `UPDATE pipeline_run_steps SET status = 'completed', output = $2, completed_at = now()
         WHERE id = $1 RETURNING *`,
        [runStep.id, { note: step.description, handoff: true }],
      );
      runSteps.push(completed);
      continue;
    }

    try {
      const output = await agents.execute(step.agent_id, {
        input, priorOutputs, clientId, pipelineId,
      });

      const { rows: [completed] } = await pool.query(
        `UPDATE pipeline_run_steps SET status = 'completed', output = $2, completed_at = now()
         WHERE id = $1 RETURNING *`,
        [runStep.id, output],
      );
      runSteps.push(completed);
      priorOutputs.push({ step: step.sequence, agentId: step.agent_id, output });

      await logEvent(pool, {
        runId: run.id, pipelineId, agentId: step.agent_id, correlationId,
        eventType: 'PIPELINE_STEP_COMPLETED', payload: { sequence: step.sequence, output },
      });
    } catch (err) {
      await pool.query(
        `UPDATE pipeline_run_steps SET status = 'failed', error = $2, completed_at = now() WHERE id = $1`,
        [runStep.id, err.message],
      );
      await logEvent(pool, {
        runId: run.id, pipelineId, agentId: step.agent_id, correlationId,
        eventType: 'PIPELINE_STEP_FAILED', payload: { sequence: step.sequence, error: err.message },
      });

      const { rows: [failedRun] } = await pool.query(
        `UPDATE pipeline_runs SET status = 'failed', error = $2, completed_at = now() WHERE id = $1 RETURNING *`,
        [run.id, `Step ${step.sequence} (${step.agent_id}) failed: ${err.message}`],
      );
      await logEvent(pool, {
        runId: run.id, pipelineId, correlationId, eventType: 'PIPELINE_RUN_FAILED',
        payload: { error: err.message },
      });

      return { run: failedRun, steps: runSteps };
    }
  }

  const finalOutput = { steps: priorOutputs };
  const { rows: [completedRun] } = await pool.query(
    `UPDATE pipeline_runs SET status = 'completed', output = $2, completed_at = now() WHERE id = $1 RETURNING *`,
    [run.id, finalOutput],
  );
  await logEvent(pool, {
    runId: run.id, pipelineId, correlationId, eventType: 'PIPELINE_RUN_COMPLETED', payload: finalOutput,
  });

  return { run: completedRun, steps: runSteps };
}

async function getRun(runId) {
  const { rows: [run] } = await pool.query('SELECT * FROM pipeline_runs WHERE id = $1', [runId]);
  if (!run) return null;
  const { rows: steps } = await pool.query(
    'SELECT * FROM pipeline_run_steps WHERE run_id = $1 ORDER BY sequence ASC',
    [runId],
  );
  return { run, steps };
}

module.exports = { loadPipeline, runPipeline, getRun, PipelineNotFoundError };
