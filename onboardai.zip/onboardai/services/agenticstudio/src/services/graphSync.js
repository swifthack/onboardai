const graph = require('../config/neo4j');

// Ported from services/clientos (see that service's README for the
// retirement note) — mirrors the relationship-shaped slice of a client
// record (directors, shareholders, related parties, the authorized
// representative) into Neo4j as an actual property graph, alongside
// Postgres owning the authoritative `clients` record. Called after every
// successful Postgres write in routes/clients.js — Postgres is the source
// of truth; this is a best-effort mirror (a failure here is logged, not
// thrown, so a graph hiccup never blocks the record itself from saving).
// A no-op when NEO4J_URI isn't set (the design deployment) — see
// config/neo4j.js.
//
// Each sync is a full replace for that client's child nodes: this matches
// the frontend's "save the whole client" model (see useBackendSync on the
// frontend) — there's no incremental diff to apply, so the simplest
// correct approach is delete-then-recreate the child nodes on every write.

async function upsertClientGraph(client) {
  if (!graph.enabled) return;
  const session = graph.driver.session();
  try {
    await session.executeWrite(async (tx) => {
      await tx.run(
        `MERGE (c:Client {id: $id})
         SET c.companyName = $companyName,
             c.registrationNumber = $registrationNumber,
             c.jurisdiction = $jurisdiction,
             c.industry = $industry,
             c.overallStatus = $overallStatus,
             c.journeyId = $journeyId`,
        {
          id: client.id,
          companyName: client.companyName || '',
          registrationNumber: client.registrationNumber || '',
          jurisdiction: client.jurisdiction || '',
          industry: client.industry || '',
          overallStatus: client.overallStatus || 'draft',
          journeyId: client.journeyId || '',
        },
      );

      // Drop this client's previously-synced child nodes before
      // recreating them from the current record — see file header.
      await tx.run(
        `MATCH (c:Client {id: $id})-[]->(n)
         WHERE n:Director OR n:Shareholder OR n:RelatedParty OR n:Representative
         DETACH DELETE n`,
        { id: client.id },
      );

      for (const d of client.directors || []) {
        await tx.run(
          `MATCH (c:Client {id: $id})
           MERGE (d:Director {clientId: $id, name: $name})
           SET d.role = $role, d.nationality = $nationality, d.appointmentDate = $appointmentDate
           MERGE (c)-[:HAS_DIRECTOR]->(d)`,
          { id: client.id, name: d.name || '', role: d.role || '', nationality: d.nationality || '', appointmentDate: d.appointmentDate || '' },
        );
      }

      for (const s of client.shareholders || []) {
        await tx.run(
          `MATCH (c:Client {id: $id})
           MERGE (s:Shareholder {clientId: $id, name: $name})
           SET s.equity = $equity, s.pepStatus = $pepStatus
           MERGE (c)-[:HAS_SHAREHOLDER]->(s)`,
          { id: client.id, name: s.name || '', equity: s.equity ?? null, pepStatus: !!s.pepStatus },
        );
      }

      for (const rp of client.relatedParties || []) {
        await tx.run(
          `MATCH (c:Client {id: $id})
           MERGE (rp:RelatedParty {clientId: $id, name: $name})
           SET rp.relationType = $relationType, rp.riskLevel = $riskLevel, rp.status = $status
           MERGE (c)-[:HAS_RELATED_PARTY]->(rp)`,
          { id: client.id, name: rp.name || '', relationType: rp.relationType || '', riskLevel: rp.riskLevel || '', status: rp.status || '' },
        );
      }

      const rep = client.authorizedRepresentative;
      if (rep && rep.name) {
        await tx.run(
          `MATCH (c:Client {id: $id})
           MERGE (r:Representative {clientId: $id, name: $name})
           SET r.role = $role, r.email = $email, r.biometricVerified = $biometricVerified
           MERGE (c)-[:HAS_REPRESENTATIVE]->(r)`,
          {
            id: client.id,
            name: rep.name,
            role: rep.role || '',
            email: rep.email || '',
            biometricVerified: !!rep.biometricVerified,
          },
        );
      }
    });
  } finally {
    await session.close();
  }
}

async function deleteClientGraph(id) {
  if (!graph.enabled) return;
  const session = graph.driver.session();
  try {
    await session.executeWrite((tx) =>
      tx.run(
        `MATCH (c:Client {id: $id})
         OPTIONAL MATCH (c)-[]->(n)
         DETACH DELETE c, n`,
        { id },
      ),
    );
  } finally {
    await session.close();
  }
}

// Returns { nodes: [{id, label, type, properties}], edges: [{id, from, to, type}] }
// for GET /clients/:id/graph — a live read of exactly what's in Neo4j for
// this client right now (not derived from the Postgres row). Empty result
// when Neo4j isn't configured, rather than throwing.
async function getClientGraph(id) {
  if (!graph.enabled) return { nodes: [], edges: [] };
  const session = graph.driver.session();
  try {
    const result = await session.executeRead((tx) =>
      tx.run(
        `MATCH (c:Client {id: $id})
         OPTIONAL MATCH (c)-[rel]->(n)
         RETURN c, collect({relType: type(rel), node: n}) AS related`,
        { id },
      ),
    );
    if (result.records.length === 0) return { nodes: [], edges: [] };

    const record = result.records[0];
    const centerNode = record.get('c');
    const related = record.get('related');

    const nodes = [
      {
        id: centerNode.elementId,
        label: centerNode.properties.companyName,
        type: 'Client',
        properties: centerNode.properties,
      },
    ];
    const edges = [];

    for (const { relType, node } of related) {
      if (!node) continue; // client with no relationships yields one null entry
      nodes.push({
        id: node.elementId,
        label: node.properties.name || node.properties.companyName || '',
        type: node.labels ? node.labels[0] : 'Unknown',
        properties: node.properties,
      });
      edges.push({
        id: `${centerNode.elementId}-${relType}-${node.elementId}`,
        from: centerNode.elementId,
        to: node.elementId,
        type: relType,
      });
    }

    return { nodes, edges };
  } finally {
    await session.close();
  }
}

module.exports = { upsertClientGraph, deleteClientGraph, getClientGraph };
