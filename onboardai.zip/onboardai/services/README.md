# Nexum Services

Deployable platform services, as opposed to `../agents` (the 54-agent mesh
specs/code) and `../pipelines` (MLP pipeline builds).

| Service | Purpose | Data stores |
|---|---|---|
| [`agenticstudio/`](agenticstudio) | Backend for the Process Flow matrix (P-01..P-27) — 19-agent registry, pipeline definitions, a generic run engine, **and** client/case CRUD + knowledge graph for the execution deployment (ported from `clientos/`, below) | Postgres (+ Neo4j, execution only) |
| [`clientos/`](clientos) | *Retired* — its routes and Neo4j sync now live in `agenticstudio/` | — |

See [`agenticstudio/README.md`](agenticstudio/README.md) for local dev
setup and the full API surface, including its "Design vs execution
containers" section for why one backend now covers both roles.

## Deployments

6 containers total — **demo mode: design and execution share one
Postgres** (execution's), so anything created in Studio is instantly
visible in execution with no migration step:

```
design:    frontend :3000 → backend :4001 ─┐
execution: frontend :3010 → backend :4011 ─┴→ Postgres :55451
                                            → Neo4j :7475/:7688 (execution only)
```

- `../docker-compose.design.yml` — where agents/pipelines/guardrails/etc.
  are authored (Platform Admin only).
- `../docker-compose.execution.yml` — owns the shared Postgres and Neo4j;
  also serves `clients` (RM/Compliance/Ops/Customer CRUD + Neo4j graph).

One backend codebase serves both — see
[`agenticstudio/README.md#design-vs-execution-containers`](agenticstudio/README.md#design-vs-execution-containers)
for the full reasoning, ports, how to revert to two separate databases
(and resume using `db:migrate-to-execution` on your own schedule), and how
one frontend image serves both deployments via runtime config.
