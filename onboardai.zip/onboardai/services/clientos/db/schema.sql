-- ClientOS Postgres schema — the client/case record behind the RM,
-- Compliance & Risk Officer, and Operations Officer screens (My Pipeline,
-- Journey Workspace, Customer 360, Digital Twin Explorer, Review Queue,
-- Ops Review Queue, ...). See ../../shared/schema.sql and
-- ../../shared/ARCHITECTURE.md for the longer-term agent-mesh Digital Twin
-- concept this is a pragmatic, ClientOS-owned stand-in for today — same
-- JSONB-extensibility-bag convention AgenticStudio's schema uses (see
-- ../agenticstudio/db/schema.sql), not a competing copy of that schema.
--
-- One row per client/case, matching the frontend's `ClientProfile` shape
-- (frontend/src/types.ts) closely enough that most fields round-trip
-- untouched: a handful of real columns for what's actually filtered/sorted
-- on (id, company_name, overall_status, journey_id), JSONB for everything
-- else nested/rich. `src/services/graphSync.js` additionally mirrors the
-- relationship-shaped fields (directors, related parties, shareholders,
-- authorized representative) into Neo4j on every write — see that file.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS clients (
  id                            TEXT PRIMARY KEY,
  company_name                  TEXT NOT NULL,
  registration_number           TEXT,
  jurisdiction                  TEXT,
  industry                      TEXT,
  overall_status                TEXT NOT NULL DEFAULT 'draft'
                                   CHECK (overall_status IN ('draft', 'in_progress', 'approved', 'rejected')),
  journey_id                    TEXT,
  journey_name                  TEXT,

  -- Rich/nested fields — opaque bags, shaped like the matching
  -- ClientProfile field of the same name (minus camelCase -> snake_case).
  authorized_representative     JSONB NOT NULL DEFAULT '{}',
  shareholders                  JSONB NOT NULL DEFAULT '[]',
  financials                    JSONB NOT NULL DEFAULT '{}',
  documents                     JSONB NOT NULL DEFAULT '[]',
  workflow_nodes                JSONB NOT NULL DEFAULT '[]',
  directors                     JSONB NOT NULL DEFAULT '[]',
  related_parties               JSONB NOT NULL DEFAULT '[]',
  alerts                        JSONB NOT NULL DEFAULT '[]',
  govt_registry_update_requests JSONB NOT NULL DEFAULT '[]',
  internal_account_settings     JSONB NOT NULL DEFAULT '{}',

  created_at                    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at                    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_clients_overall_status ON clients (overall_status);
CREATE INDEX IF NOT EXISTS idx_clients_journey_id ON clients (journey_id);
