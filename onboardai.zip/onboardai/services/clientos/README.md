# ClientOS — retired as a standalone service

This service's routes and Neo4j sync were ported into
[`../agenticstudio`](../agenticstudio) (`src/routes/clients.js` +
`src/services/graphSync.js`), which now owns client/case CRUD + the
knowledge graph for the execution deployment alongside its original
config CRUD — see that service's README's "Design vs execution
containers" section for the full reasoning and current architecture.

Nothing in this directory runs anymore (`docker-compose.yml` here is a
retirement notice, not a working stack) — this README and the source
files remain only as a record of where the `clients` domain model and the
Neo4j sync logic originally came from, in case that history is useful.
Real data (the `clients` rows, and the Neo4j graph) was migrated over,
not lost — see `../agenticstudio/README.md`'s verification note.

## Why it existed

Built as a genuinely separate Node/Express + Postgres + Neo4j service
before the design/execution split existed, when "RM/Compliance/Ops
screens" and "Platform Admin screens" weren't yet understood to need
completely disjoint backends per deployment. Once that split landed
(`docker-compose.design.yml` / `docker-compose.execution.yml`), it became
clear nothing in execution's frontend ever called AgenticStudio's config
routes, and nothing in design's frontend ever called ClientOS's routes —
so running two separate backend+db pairs, each with an idle half, was
unnecessary. One backend serving both, gated by which env vars are set
(`NEO4J_URI` only in execution), removes that duplication.

## Original data model (for reference)

`db/schema.sql` here still describes the `clients` table shape as
originally designed (now living in `../agenticstudio/db/schema.sql`
instead) and `src/services/graphSync.js` / `src/routes/clients.js`
describe the Postgres-to-Neo4j mirror (now
`../agenticstudio/src/services/graphSync.js` /
`../agenticstudio/src/routes/clients.js`, byte-for-byte the same logic).
