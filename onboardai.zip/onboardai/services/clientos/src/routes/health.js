const { Router } = require('express');
const db = require('../config/db');
const graph = require('../config/neo4j');

const router = Router();

// Liveness — process is up. No dependency checks.
router.get('/', (req, res) => {
  res.json({ status: 'ok', service: 'clientos' });
});

// Readiness — can this instance actually serve traffic right now.
router.get('/ready', async (req, res) => {
  const checks = {};
  let ok = true;

  try {
    await db.ping();
    checks.postgres = 'up';
  } catch (err) {
    ok = false;
    checks.postgres = `down: ${err.message}`;
  }

  try {
    await graph.ping();
    checks.neo4j = 'up';
  } catch (err) {
    ok = false;
    checks.neo4j = `down: ${err.message}`;
  }

  res.status(ok ? 200 : 503).json({ status: ok ? 'ok' : 'error', checks });
});

module.exports = router;
