const { Router } = require('express');
const health = require('./health');
const clients = require('./clients');

const router = Router();

router.use('/health', health);
router.use('/clients', clients);

module.exports = router;
