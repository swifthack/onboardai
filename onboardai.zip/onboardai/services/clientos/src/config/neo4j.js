const neo4j = require('neo4j-driver');
const config = require('./index');

// Single shared driver for the process — driver instances pool their own
// connections internally, so this should not be re-created per request.
const driver = neo4j.driver(
  config.neo4j.uri,
  neo4j.auth.basic(config.neo4j.user, config.neo4j.password),
);

async function ping() {
  await driver.verifyConnectivity();
  return true;
}

async function close() {
  await driver.close();
}

module.exports = { driver, ping, close };
