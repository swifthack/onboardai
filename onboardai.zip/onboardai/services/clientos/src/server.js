const app = require('./app');
const config = require('./config');
const graph = require('./config/neo4j');

const server = app.listen(config.port, () => {
  console.log(`[clientos] listening on :${config.port} (${config.env})`);
});

function shutdown(signal) {
  console.log(`[clientos] received ${signal}, shutting down`);
  server.close(async () => {
    await graph.close();
    process.exit(0);
  });
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
