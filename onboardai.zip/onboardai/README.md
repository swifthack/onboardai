# Nexum

An agent mesh for bank client onboarding and lifecycle KYC/AML — 54 single-
responsibility agents across 8 layers, each subscribing to specific events
and publishing structured output back to a shared **Digital Twin** (the
live state of one client) built up incrementally as a **Knowledge Graph**
of entities, individuals, and their relationships.

Sibling project: [`../adversemedia/mlp`](../adversemedia/mlp) is a working,
narrower precedent for this pattern — a single agent (Adverse Media
screening) built end-to-end against Postgres with a real ingest source, an
LLM reasoning chain, and honestly-documented v1 limitations. Nexum's shared
schema and stub-adapter convention (below) generalize that pattern to a
whole mesh.

## Status

Design/spec pass, **Agents 1–10** (Layer 1 in full, plus the first two
Layer 2 agents). Being built one agent at a time, in order — each
`SPEC.md` is reviewed before the next agent starts, so the template set by
Agent 1 has a chance to be corrected before it's copied nine more times.
Code (the actual runnable MLP per agent, matching `adversemedia/mlp`'s
depth) is a separate, later pass.

| # | Agent | Status |
|---|---|---|
| 1 | [Lead Discovery](agents/01-lead-discovery/SPEC.md) | ✅ spec |
| 2 | Entity Resolution | ⏳ next |
| 3 | Corporate Registry | queued |
| 4 | Regulatory Status | queued |
| 5 | Sanctions Screening | queued |
| 6 | PEP Screening | queued |
| 7 | Adverse Media | queued — see also [`adversemedia/`](../adversemedia) for a deeper existing build of this exact agent |
| 8 | Ownership Structure | queued |
| 9 | Dynamic KYC Engine | queued |
| 10 | Document Intelligence | queued |

## Read first

[`shared/ARCHITECTURE.md`](shared/ARCHITECTURE.md) — the event envelope,
the Digital Twin schema (`shared/schema.sql`), the field-provenance
convention, and the stub-adapter convention every agent spec assumes.
Read this before any individual agent spec; they don't repeat it.

## Folder layout

```
Nexum/
  README.md                 <- this file
  shared/
    ARCHITECTURE.md          <- shared conventions, read first
    schema.sql               <- Digital Twin schema, grows as agents are built
  agents/
    01-lead-discovery/SPEC.md
    02-entity-resolution/SPEC.md
    ...
  services/                 <- deployable platform services (see services/README.md)
    agenticstudio/            <- Node/Express, Postgres
    clientos/                  <- Node/Express, Postgres + Neo4j
```

## Beyond Agent 10

The full 54-agent inventory and build priority (Phase 1: 1–10, 16–20,
24–26, 50 · Phase 2: 11–15, 21–23, 34–40 · Phase 3: 27–33 · Phase 4: 41–49,
51–54) is tracked in conversation/source material, not duplicated here yet
— this README's table will grow as later phases are specced.
