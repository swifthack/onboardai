-- Nexum shared Digital Twin / Knowledge Graph schema.
-- Executable form of ARCHITECTURE.md §3-4. Grows as each agent is built —
-- do not fork this per agent; extend it here so the schema stays one source
-- of truth. See ARCHITECTURE.md for the rationale behind each table.

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ── Event store ──────────────────────────────────────────────────────────
CREATE TABLE events (
    event_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_type      TEXT NOT NULL,
    occurred_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    client_id       UUID,
    correlation_id  UUID NOT NULL,
    causation_id    UUID REFERENCES events(event_id),
    producer_agent  TEXT NOT NULL,
    payload         JSONB NOT NULL,
    confidence      NUMERIC(4,3)
);
CREATE INDEX ON events (client_id, occurred_at);
CREATE INDEX ON events (event_type, occurred_at);
CREATE INDEX ON events (correlation_id);

-- ── Clients ──────────────────────────────────────────────────────────────
CREATE TABLE clients (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    stage               TEXT NOT NULL DEFAULT 'lead',
    primary_entity_id   UUID,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ── Entities ─────────────────────────────────────────────────────────────
CREATE TABLE entities (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id                   UUID NOT NULL REFERENCES clients(id),
    entity_type                 TEXT,
    legal_name                  TEXT,
    trading_name                TEXT,
    registration_number         TEXT,
    incorporation_date          DATE,
    incorporation_jurisdiction  TEXT,
    registered_address          JSONB,
    status                      TEXT,
    lei                         TEXT,
    is_primary                  BOOLEAN NOT NULL DEFAULT true,
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON entities (client_id);
CREATE INDEX ON entities (lei) WHERE lei IS NOT NULL;
CREATE INDEX entities_legal_name_trgm ON entities USING gin (legal_name gin_trgm_ops);

ALTER TABLE clients
    ADD CONSTRAINT clients_primary_entity_fk
    FOREIGN KEY (primary_entity_id) REFERENCES entities(id);

CREATE TABLE entity_aliases (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entity_id       UUID NOT NULL REFERENCES entities(id),
    alias           TEXT NOT NULL,
    alias_type      TEXT,
    source_agent    TEXT NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX entity_aliases_alias_trgm ON entity_aliases USING gin (alias gin_trgm_ops);

-- ── Individuals ──────────────────────────────────────────────────────────
CREATE TABLE individuals (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id           UUID NOT NULL REFERENCES clients(id),
    full_name           TEXT,
    date_of_birth       DATE,
    nationality         TEXT,
    id_document_type    TEXT,
    id_document_number  TEXT,
    residential_address JSONB,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON individuals (client_id);

-- ── Relationships (the graph) ───────────────────────────────────────────
CREATE TABLE relationships (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id                   UUID NOT NULL REFERENCES clients(id),
    from_type                   TEXT NOT NULL CHECK (from_type IN ('entity','individual')),
    from_id                     UUID NOT NULL,
    to_type                     TEXT NOT NULL CHECK (to_type IN ('entity','individual')),
    to_id                       UUID NOT NULL,
    relationship_type           TEXT NOT NULL,
    ownership_pct               NUMERIC(5,2),
    role                        TEXT,
    is_look_through_required    BOOLEAN NOT NULL DEFAULT false,
    valid_from                  DATE,
    valid_to                    DATE,
    source_agent                TEXT NOT NULL,
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON relationships (client_id);
CREATE INDEX ON relationships (from_type, from_id);
CREATE INDEX ON relationships (to_type, to_id);

-- ── Documents ────────────────────────────────────────────────────────────
CREATE TABLE documents (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id           UUID NOT NULL REFERENCES clients(id),
    document_type       TEXT,
    storage_uri         TEXT NOT NULL,
    uploaded_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    expiry_date          DATE,
    extraction_status    TEXT NOT NULL DEFAULT 'pending'
        CHECK (extraction_status IN ('pending','validated','discrepancy','failed')),
    extracted_data        JSONB,
    ocr_language          TEXT
);
CREATE INDEX ON documents (client_id);
CREATE INDEX ON documents (expiry_date) WHERE expiry_date IS NOT NULL;

-- ── Screening results (sanctions / PEP / adverse media / regulatory) ────
CREATE TABLE screening_results (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id               UUID NOT NULL REFERENCES clients(id),
    subject_type            TEXT NOT NULL CHECK (subject_type IN ('entity','individual')),
    subject_id               UUID NOT NULL,
    screening_type            TEXT NOT NULL CHECK (screening_type IN ('sanctions','pep','adverse_media','regulatory_status')),
    result                    TEXT NOT NULL CHECK (result IN ('clear','hit','unknown')),
    severity                  TEXT CHECK (severity IN ('low','medium','high','critical')),
    detail                    JSONB NOT NULL,
    source_agent              TEXT NOT NULL,
    list_or_source_version    TEXT,
    screened_at                TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON screening_results (client_id, screening_type);
CREATE INDEX ON screening_results (subject_type, subject_id);

-- ── Field provenance (source/confidence/timestamp on every fact) ───────
CREATE TABLE field_provenance (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id       UUID NOT NULL REFERENCES clients(id),
    subject_table   TEXT NOT NULL,
    subject_id      UUID NOT NULL,
    field_name      TEXT NOT NULL,
    field_value     JSONB NOT NULL,
    source_agent    TEXT NOT NULL,
    source_system   TEXT NOT NULL,
    confidence      NUMERIC(4,3) NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    observed_at     TIMESTAMPTZ NOT NULL,
    superseded_by   UUID REFERENCES field_provenance(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON field_provenance (client_id, subject_table, subject_id, field_name);

-- ── KYC requirements (Dynamic KYC Engine output, Layer 2) ───────────────
CREATE TABLE kyc_requirements (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id               UUID NOT NULL REFERENCES clients(id),
    requirement_key          TEXT NOT NULL,
    regulatory_basis          TEXT NOT NULL,
    subject_type              TEXT CHECK (subject_type IN ('entity','individual')),
    subject_id                 UUID,
    acceptable_methods         JSONB NOT NULL,
    status                     TEXT NOT NULL DEFAULT 'outstanding'
        CHECK (status IN ('outstanding','satisfied','waived')),
    satisfied_by_event_id      UUID REFERENCES events(event_id),
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON kyc_requirements (client_id, status);

-- ── Lightweight pub/sub for the MLP transport (ARCHITECTURE.md §2) ──────
CREATE OR REPLACE FUNCTION notify_new_event() RETURNS trigger AS $$
BEGIN
    PERFORM pg_notify('nexum_events', json_build_object(
        'event_id', NEW.event_id,
        'event_type', NEW.event_type,
        'client_id', NEW.client_id,
        'correlation_id', NEW.correlation_id
    )::text);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER events_notify AFTER INSERT ON events
    FOR EACH ROW EXECUTE FUNCTION notify_new_event();
