# Nexum — Shared Architecture

This document is the source of truth for everything agent specs assume but
don't re-explain: the event envelope, the Digital Twin / Knowledge Graph
schema, the field-provenance convention, and the stub-adapter convention for
data sources we don't have credentials for yet. Every agent spec in
`agents/NN-*/SPEC.md` links back here instead of restating this.

Scope of this pass: **Agents 1–10** (Layer 1: Discovery & Intelligence, plus
the first two Layer 2 agents — Dynamic KYC Engine and Document Intelligence
— since they're the natural close of the "research a lead into a
risk-ready entity" arc). Later layers (risk synthesis, provisioning,
lifecycle, governance) will extend this schema, not replace it — tables here
are deliberately named/shaped so Layer 3+ agents can add to them rather than
forcing a migration.

## 1. What the Digital Twin actually is

Not a separate system —  "Digital Twin" is the
product name for *the current, continuously-updated state of one client*;
"Knowledge Graph" is the product name for the entity/individual/relationship
subset of that state once you view it as a graph rather than rows. Every
agent reads state by querying these tables and writes state by (a) inserting
into `events` (always) and (b) upserting the specific table its output
belongs in (usually, not always — pure scoring/routing agents may only emit
events).

This mirrors the pattern already established in
[`adversemedia/mlp`](../../adversemedia/mlp) (Postgres, `schema.sql`, a
`registry.py`-style lookup layer) — same spirit, wider schema, because Nexum
agents collaborate on one client record instead of one screening run.

## 2. Event envelope

Every event any agent publishes or subscribes to has this shape. This *is*
the mesh — agents don't call each other directly, they publish events and
subscribe to event types.

```json
{
  "event_id": "uuid",
  "event_type": "ENTITY_CREATED",
  "occurred_at": "2026-08-24T10:15:00Z",
  "client_id": "uuid",
  "correlation_id": "uuid",
  "causation_id": "uuid | null",
  "producer_agent": "lead-discovery-agent",
  "payload": { "...": "event-type-specific" },
  "confidence": 0.0
}
```

- `client_id` — the Digital Twin this event belongs to. Present on every
  event from `ENTITY_CREATED` onward. `LEAD_SUBMITTED` is the one event that
  precedes a `client_id` existing — see Agent 1.
- `correlation_id` — shared by every event in one onboarding/review
  "episode," so the full causal chain for one case is one SQL filter away.
  This is what the Audit Trail Agent (51) and Regulatory Examination Pack
  Agent (53) key off later — not built in this pass, but the column exists
  from day one so nothing needs backfilling.
- `causation_id` — the specific `event_id` that caused this one to fire.
  Null for root events (e.g. `LEAD_SUBMITTED`).
- `confidence` — 0–1 float. Present on every event even when the payload
  itself carries per-field confidence (§3) — this is the event-level
  headline number; field-level confidence is finer-grained.

**MLP transport**: Postgres `events` table (append-only, §4) plus `LISTEN
nexum_events` / `NOTIFY` for same-process pub/sub. No Kafka/message broker in
this pass — the adversemedia precedent is single-node Postgres too, and a
broker is a swap-in later, not a day-one requirement. Each agent's spec
lists what it subscribes to and what it publishes; wiring those into an
actual dispatcher is a Phase-1 build task, not a schema decision.

## 3. Field-provenance convention

The spec text repeatedly says things like *"each field tagged with source,
confidence, and timestamp"* (Agent 3) or *"government-verified confidence
0.99"* (Agent 12). That's not per-agent bookkeeping — it's one mechanism,
used everywhere: **no fact lives only as a bare column value.** Every fact
that came from an agent (as opposed to being a primary key or a
system-generated id) is stored as a row in `field_provenance`, and the
"current" column on the entity/individual table is a materialized view of
the highest-confidence, most-recent row for that field.

```sql
CREATE TABLE field_provenance (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id       UUID NOT NULL REFERENCES clients(id),
    subject_table   TEXT NOT NULL,     -- 'entities' | 'individuals' | 'entity_relationships' | ...
    subject_id      UUID NOT NULL,     -- PK of the row in subject_table
    field_name      TEXT NOT NULL,     -- 'legal_name', 'incorporation_date', ...
    field_value     JSONB NOT NULL,
    source_agent    TEXT NOT NULL,     -- 'corporate-registry-agent'
    source_system   TEXT NOT NULL,     -- 'ACRA Bizfile+', 'Companies House API', ...
    confidence      NUMERIC(4,3) NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    observed_at     TIMESTAMPTZ NOT NULL,
    superseded_by   UUID REFERENCES field_provenance(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON field_provenance (client_id, subject_table, subject_id, field_name);
```

Rule of thumb for confidence values (agents should stay inside these bands
unless a spec says otherwise, so scores are comparable across agents):

| Band | Meaning | Example |
|---|---|---|
| 0.95–1.00 | Cryptographic or government-authenticated verification | vLEI signature check, Singpass MyInfo, Aadhaar eKYC |
| 0.80–0.94 | Official registry / regulator source, machine-read | ACRA, Companies House, MAS FI Directory |
| 0.60–0.79 | Reputable third-party aggregator, not primary-source | Crunchbase, Pitchbook, LinkedIn |
| 0.40–0.59 | Inferred / fuzzy-matched / LLM-extracted from unstructured text | OCR'd document field, adverse-media NLP classification |
| < 0.40 | Should not be written to `field_provenance` as fact — route to human review instead | — |

`DOCUMENT_DISCREPANCY_DETECTED` (Agent 10) is exactly what happens when a
new `field_provenance` row would conflict with the current highest-confidence
row for the same field — that comparison is the trigger, not a separate rule.

## 4. Core schema

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Append-only event store. Source of truth for the mesh and for audit.
CREATE TABLE events (
    event_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_type      TEXT NOT NULL,
    occurred_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    client_id       UUID,                      -- null only for LEAD_SUBMITTED
    correlation_id  UUID NOT NULL,
    causation_id    UUID REFERENCES events(event_id),
    producer_agent  TEXT NOT NULL,
    payload         JSONB NOT NULL,
    confidence      NUMERIC(4,3)
);
CREATE INDEX ON events (client_id, occurred_at);
CREATE INDEX ON events (event_type, occurred_at);
CREATE INDEX ON events (correlation_id);

-- One row per prospective/onboarded client (legal entity, top-level).
CREATE TABLE clients (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    stage               TEXT NOT NULL DEFAULT 'lead',   -- lead | researching | kyc_gathering | risk_assessment | approved | active | offboarded
    primary_entity_id   UUID,                            -- FK to entities, set once ENTITY_CONFIRMED_NEW/MERGED resolves
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Legal entities (companies, funds, foundations, VASPs...).
CREATE TABLE entities (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id           UUID NOT NULL REFERENCES clients(id),
    entity_type         TEXT,               -- company | fund | foundation | trust | sole_prop | vasp
    legal_name          TEXT,
    trading_name         TEXT,
    registration_number TEXT,
    incorporation_date  DATE,
    incorporation_jurisdiction TEXT,          -- ISO 3166-1 alpha-2
    registered_address  JSONB,
    status              TEXT,               -- active | dissolved | struck_off | in_liquidation
    lei                 TEXT,               -- GLEIF LEI if resolved
    is_primary          BOOLEAN NOT NULL DEFAULT true,   -- false for related entities pulled in via ownership chain
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON entities (client_id);
CREATE INDEX ON entities (lei) WHERE lei IS NOT NULL;
-- Trigram index for fuzzy name matching (Agent 2 entity resolution)
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE INDEX entities_legal_name_trgm ON entities USING gin (legal_name gin_trgm_ops);

-- Known aliases / prior names / trading names for an entity — what Agent 2 merges onto.
CREATE TABLE entity_aliases (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entity_id       UUID NOT NULL REFERENCES entities(id),
    alias           TEXT NOT NULL,
    alias_type      TEXT,               -- former_legal_name | trading_name | transliteration | typo_variant
    source_agent    TEXT NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Natural persons — directors, UBOs, signatories, PEP subjects.
CREATE TABLE individuals (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id           UUID NOT NULL REFERENCES clients(id),
    full_name           TEXT,
    date_of_birth       DATE,
    nationality          TEXT,               -- ISO 3166-1 alpha-2
    id_document_type    TEXT,
    id_document_number  TEXT,
    residential_address JSONB,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON individuals (client_id);

-- Relationships: entity-to-entity (ownership, subsidiary) and
-- individual-to-entity (director, UBO, signatory). One table, typed edges —
-- this IS the "knowledge graph" when you traverse it.
CREATE TABLE relationships (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id           UUID NOT NULL REFERENCES clients(id),
    from_type           TEXT NOT NULL,      -- 'entity' | 'individual'
    from_id             UUID NOT NULL,
    to_type             TEXT NOT NULL,      -- 'entity' | 'individual'
    to_id               UUID NOT NULL,
    relationship_type   TEXT NOT NULL,      -- owns | director_of | ubo_of | signatory_of | subsidiary_of
    ownership_pct       NUMERIC(5,2),       -- populated for 'owns'
    role                TEXT,               -- populated for director_of/signatory_of
    is_look_through_required BOOLEAN NOT NULL DEFAULT false,
    valid_from          DATE,
    valid_to            DATE,               -- null = current
    source_agent        TEXT NOT NULL,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON relationships (client_id);
CREATE INDEX ON relationships (from_type, from_id);
CREATE INDEX ON relationships (to_type, to_id);

-- Uploaded/collected documents and what Document Intelligence extracted.
CREATE TABLE documents (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id           UUID NOT NULL REFERENCES clients(id),
    document_type       TEXT,               -- passport | board_resolution | poa | cert_of_incorp | ...
    storage_uri          TEXT NOT NULL,
    uploaded_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    expiry_date          DATE,
    extraction_status    TEXT NOT NULL DEFAULT 'pending',  -- pending | validated | discrepancy | failed
    extracted_data       JSONB,
    ocr_language          TEXT
);
CREATE INDEX ON documents (client_id);
CREATE INDEX ON documents (expiry_date) WHERE expiry_date IS NOT NULL;

-- Generic screening result — sanctions, PEP, adverse media, regulatory
-- status all write here with a discriminator, instead of one table each.
-- Keeps Layer 1 agents structurally identical and makes cross-screen
-- queries ("show me every hit of any kind for this client") a single table.
CREATE TABLE screening_results (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id           UUID NOT NULL REFERENCES clients(id),
    subject_type        TEXT NOT NULL,      -- 'entity' | 'individual'
    subject_id           UUID NOT NULL,
    screening_type       TEXT NOT NULL,      -- sanctions | pep | adverse_media | regulatory_status
    result               TEXT NOT NULL,      -- clear | hit | unknown
    severity             TEXT,               -- for adverse_media: low|medium|high|critical
    detail                JSONB NOT NULL,     -- classification-specific payload (list name, licence number, article ref...)
    source_agent          TEXT NOT NULL,
    list_or_source_version TEXT,             -- e.g. OFAC SDN list version/date — required for regulatory defensibility
    screened_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON screening_results (client_id, screening_type);
CREATE INDEX ON screening_results (subject_type, subject_id);

-- Required-information gaps the Dynamic KYC Engine computes and Client
-- Outreach works off of.
CREATE TABLE kyc_requirements (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id           UUID NOT NULL REFERENCES clients(id),
    requirement_key     TEXT NOT NULL,      -- e.g. 'ubo_id_document', 'source_of_wealth_declaration'
    regulatory_basis     TEXT NOT NULL,      -- cites the specific rule
    subject_type         TEXT,               -- 'entity' | 'individual' | null (client-level)
    subject_id            UUID,
    acceptable_methods    JSONB NOT NULL,     -- ['document_upload', 'vlei', 'singpass_myinfo']
    status                TEXT NOT NULL DEFAULT 'outstanding',  -- outstanding | satisfied | waived
    satisfied_by_event_id UUID REFERENCES events(event_id),
    created_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON kyc_requirements (client_id, status);
```

Layer 3+ will add `risk_assessments`, `approvals`, `product_provisioning`,
etc. — deliberately not designed here; they belong to the agents that own
them.

## 5. Stub-adapter convention

Per the build decision, every external data source (LinkedIn, Crunchbase,
Pitchbook, Bloomberg, ACRA, MAS, GLEIF, OFAC, Dow Jones, ...) is wrapped
behind a small adapter interface, not called directly from agent logic. This
is the same shape as `ingest_gdelt.py` / `ingest_gnews_rss.py` in
`adversemedia/mlp` — swappable ingest modules behind a common call shape.

```python
class SourceAdapter(Protocol):
    name: str                 # 'acra_bizfile' | 'companies_house' | ...
    mode: Literal["live", "stub"]

    def query(self, params: dict) -> AdapterResult: ...

@dataclass
class AdapterResult:
    found: bool
    data: dict | None
    confidence: float          # per §3 bands
    source_system: str
    observed_at: datetime
    raw_response: dict | None  # kept for audit even in stub mode
```

- **Stub mode** returns realistic, clearly-marked fixture data (`raw_response
  = {"_stub": true, ...}`) so downstream agents, prompts, and the schema
  itself can be built and tested end-to-end before any paid credential
  exists. Fixtures live in each agent's `fixtures/` folder.
- **Live mode** is a drop-in swap once a credential exists — same
  `AdapterResult` shape, so no downstream agent code changes when a source
  goes live. `.env.example` in each agent folder lists the credential name
  even while stubbed, so wiring a real key later is a one-line change.
- A small number of sources are free/keyless today (GLEIF LEI-lookup API,
  most national company registries' basic search, OFAC/UN/EU consolidated
  sanctions lists, UK Companies House free tier, UK PSC register) — those
  can go live from day one in the actual build pass; they're still specced
  with the adapter interface so the agent code doesn't care which mode it's
  in.

## 6. Naming & folder convention

```
Nexum/
  shared/
    ARCHITECTURE.md        <- this file
    schema.sql              <- executable form of §4, grows as agents are built
  agents/
    01-lead-discovery/
      SPEC.md
      fixtures/             <- stub adapter fixtures (added when code is built)
    02-entity-resolution/
      SPEC.md
    ...
```

Each `SPEC.md` follows one fixed section order (see
[`agents/01-lead-discovery/SPEC.md`](../agents/01-lead-discovery/SPEC.md) for
the template in use): Purpose · Position in the mesh · Trigger & subscribed
events · Data sources & adapters · Processing pipeline · Output & published
events · Digital Twin writes · Scoring/reasoning logic · Confidence &
data-quality rules · Known v1 limitations · Open questions.
