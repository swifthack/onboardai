# P-02 — Entity Resolution & Knowledge Base Pipeline

Read [`../README.md`](../README.md) first for how this track relates to
[`../../agents/`](../../agents).

## Pipeline role & scope

Authoritative master data resolution and canonical Knowledge Graph
persistence.

**In scope**: querying official multi-jurisdictional government registers
(ACRA, Companies House, Delaware, OpenCorporates), resolving company
identity, creating the immutable Golden Entity Record, instantiating graph
nodes.

**Out of scope**: in-depth document OCR (P-07), natural person identity
checks (P-05/P-06).

**Implementation note**: the code build ([`../mlp`](../mlp)) backs the
Knowledge Graph with Neo4j — `entities`/`relationships` in Postgres were
never the right fit for graph traversal, and this spec's "graph nodes" and
"anchor edges" language was written storage-agnostic on purpose. Postgres
remains the store of record for the Golden Entity Record itself (below);
Neo4j holds only the graph. See [`../mlp/README.md`](../mlp/README.md).

**Note on overlap with the `agents/` track**: this pipeline's job spans
what that track splits across two agents — Agent 2 (Entity Resolution,
internal KG dedup) and Agent 3 (Corporate Registry, external registry
pull). Here it's one agent (`entity_resolution_agent`, in its P-02 mode)
doing both the external lookup and the disambiguation. Flagging this as an
observation for whenever the two tracks get compared, not acting on it —
per decision, the tracks stay separate.

## Position in the topology

```
P-01 output (enriched opportunity card, no_match dedup result)
      │
      ▼
entity_resolution_agent (P-02 mode)
      │  queries ACRA / Companies House / Delaware / OpenCorporates
      │  resolves discrepancies across filings
      ▼
        Golden Entity Record
      │
      ▼
knowledge_graph_agent
      │  writes root entity node + parent/subsidiary/affiliate anchors
      ▼
[STAGE 2: Entity Graph] ──► P-03: Autonomous Research
                        ──► P-04: Ownership & UBO Mapping
```

## Agents in this pipeline

### `entity_resolution_agent` (P-02 mode) — Corporate Identity Disambiguator

Same agent as P-01's, different scope — see the cross-pipeline agent index
in [`../README.md`](../README.md). This mode is registry-grade and
external-facing; the P-01 mode never leaves internal systems.

**Scope**: executes deterministic LEI/UEN/Tax ID matching and fuzzy string
distance matching across corporate registries; eliminates corporate alias
confusion.

**Inputs**: `entity_name`, `jurisdiction` (from P-01's opportunity card, or
RM-supplied), any registration number already known.

**Processing**:
1. **Deterministic match first**: if a registration number, LEI, or UEN is
   already known, query the specific jurisdiction's registry directly by
   ID — this is the high-confidence path and should always be tried
   before falling back to name matching.
2. **Fuzzy fallback**: where only a name is known, query the relevant
   registry/registries by name and score candidates by string distance
   (and, for cross-border entities, GLEIF as a jurisdiction-agnostic
   anchor — free, keyless, worth querying in parallel regardless of which
   national registry is primary).
3. **Cross-registry reconciliation**: where an entity has filings across
   multiple sources (e.g. a Delaware-incorporated entity with a
   Singapore-registered branch), reconcile conflicting attributes
   (address, status, officer list) rather than picking one source
   silently — see § Conflict-resolution policy.
4. Emit the **Golden Entity Record** (schema below).

**Output**: one Golden Entity Record per resolved entity, plus a
`resolution_method` tag (`deterministic_id_match` | `fuzzy_string_match`)
and a confidence score.

### `knowledge_graph_agent` — Knowledge Base Graph Constructor

**Scope**: takes resolved corporate attributes and persists them as the
root entity node in the bank's canonical Knowledge Graph, establishing
parent, subsidiary, and affiliate relationship anchors.

**Inputs**: Golden Entity Record from `entity_resolution_agent`.

**Processing**: writes a node for the entity (attributes = the Golden
Record fields) and, where the registry data itself surfaces
parent/subsidiary/affiliate relationships (common in Companies House and
Delaware filings, which often list a parent or registered agent), creates
the corresponding edges as **anchors only** — i.e. it records that a
relationship exists and to what entity, without yet computing ownership
percentages or beneficial-ownership chains. That computation is P-04's job
(`ubo_ownership_agent`); this agent's edges are what P-04 traverses and
enriches, not a duplicate of what P-04 produces.

**Output**: `entity_node_id` (root node), any `PARENT_OF` / `SUBSIDIARY_OF`
/ `AFFILIATE_OF` anchor edges created.

## Step-by-step data flow

1. `entity_resolution_agent` queries external registry APIs using raw
   registration numbers and corporate names.
2. Resolves discrepancies across multiple filings and outputs the verified
   Golden Record.
3. `knowledge_graph_agent` ingests the Golden Record and writes the
   canonical entity node into the institutional Knowledge Graph.

## Golden Entity Record — schema

```json
{
  "golden_record_id": "uuid",
  "legal_name": "string",
  "registration_number": "string",
  "lei": "string | null",
  "uen_or_tax_id": "string | null",
  "incorporation_date": "date",
  "incorporation_jurisdiction": "ISO 3166-1 alpha-2",
  "registered_address": {"...": "..."},
  "status": "active | dissolved | struck_off | in_liquidation",
  "source_registries": [
    {"registry": "acra_bizfile | companies_house | delaware_sos | opencorporates",
     "matched_field": "registration_number | lei | name",
     "retrieved_at": "timestamp"}
  ],
  "conflicting_filings": [
    {"field": "string", "values": [{"value": "string", "source_registry": "string"}],
     "resolution": "string — which value won and why"}
  ],
  "resolution_method": "deterministic_id_match | fuzzy_string_match",
  "confidence": 0.0
}
```

`conflicting_filings` is populated only when sources actually disagree —
most resolutions will have an empty array here, and that's the expected
case, not a gap.

## Conflict-resolution policy (proposed — needs sign-off, see open questions)

When two registries disagree on a field (e.g. registered address current
in Companies House but stale in an OpenCorporates cache):

1. **Primary national registry beats aggregator** — ACRA/Companies
   House/Delaware SoS (direct government sources) always outrank
   OpenCorporates (a secondary aggregator) for any field both report.
2. **Most-recent filing date wins** among sources of equal standing.
3. **Never silently drop the losing value** — record it in
   `conflicting_filings` even after resolution, since an examiner may need
   to see what was reconciled and why.

## Confidence scoring

| Path | Confidence |
|---|---|
| Deterministic match on LEI/UEN/registration number | 0.90+ |
| GLEIF LEI cross-reference confirms a fuzzy match | 0.85–0.90 |
| Fuzzy string match alone, single registry, no corroboration | 0.60–0.75 — should not be treated as onboarding-final without a human glance, consistent with the 0.85 onboarding threshold noted in P-01 |
| OpenCorporates-only match (aggregator, no primary registry hit) | Cap at 0.60 regardless of string-match closeness — it's a secondary source by design (see conflict-resolution policy) |

## Known v1 limitations

- Registry API coverage is jurisdiction-uneven by nature — ACRA and
  Companies House have solid programmatic APIs; many jurisdictions don't,
  and OpenCorporates as a fallback aggregator is explicitly lower-trust
  (see conflict-resolution policy), not a substitute for real coverage.
- No jurisdiction priority list defined yet — which registries are
  must-have from day one vs. added later is a coverage/roadmap decision
  this spec doesn't make.
- `knowledge_graph_agent`'s anchor edges depend on the registry filing
  actually surfacing parent/subsidiary data — many registries don't; in
  that common case P-04 starts its ownership traversal with no anchor at
  all, from shareholder registers/filings directly, not from this
  pipeline's output.

## Open questions

1. **Jurisdiction coverage priority** — which registries beyond
   ACRA/Companies House/Delaware/OpenCorporates are must-have for the
   bank's actual target markets? The source list is a starting four, not
   necessarily complete (UAE/DIFC/ADGM, Cayman, BVI, Hong Kong, India
   equivalents all appear in the other track's Agent 3 and aren't
   mentioned here — worth reconciling which list is authoritative for
   this track).
2. **Conflict-resolution policy sign-off** — the policy above is proposed
   by inference from "resolves discrepancies... outputs the verified
   Golden Record," not stated explicitly in the source. Needs confirmation
   before it's treated as settled, especially the "primary beats
   aggregator" ranking.
3. **Golden Record immutability** — the pipeline description calls it "the
   immutable Golden Entity Record." Immutable in the sense of
   append-only/versioned (new resolution creates a new record, old one
   retained), or literally never re-resolved once created? The former is
   almost certainly intended (entities change registered address, status,
   etc. over time) but the exact re-resolution trigger (schedule? event-
   driven off registry webhooks, as P-27 implies exists later?) isn't
   defined at this pipeline's scope.
