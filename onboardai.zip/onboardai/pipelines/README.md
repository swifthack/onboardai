# Nexum Pipelines — "Agent Studio" track (P-01–P-27)

A second, independent design track for the same domain (bank client
onboarding / KYC-AML) as [`../agents/`](../agents), organized around **27
process flows** instead of 54 single-purpose agents. Kept deliberately
separate from the `agents/` track by decision — not merged, not reconciled,
not treated as a superset or subset of it. Differences worth being aware of
when reading both:

- **Fewer, broader agents, reused across pipelines.** `entity_resolution_agent`
  does internal-CRM dedup in P-01 and external-registry disambiguation in
  P-02 — one agent, two scopes, rather than the `agents/` track's one-job-
  per-agent split (there, Agent 2 = dedup only, Agent 3 = registry pull
  only). Where an agent's scope actually differs by pipeline, its `SPEC.md`
  entry in that pipeline says so explicitly rather than assuming a single
  fixed contract carries across every pipeline it appears in.
- **A dedicated `knowledge_graph_agent`** owns writing to the graph. In the
  `agents/` track, every agent writes directly to shared tables — there is
  no single writer. This track's graph-write ownership model is a real
  difference, not a naming variation, and this doc doesn't paper over it.
- **No shared Postgres schema yet.** `agents/shared/schema.sql` is that
  track's schema, not this one's. Each pipeline spec here defines the
  minimal data shape it needs (e.g. the "Golden Record" in P-02); a
  consolidated schema for this track can follow once enough pipelines are
  specced to see the real shape needed — premature here the same way it
  would have been premature to design `agents/shared/schema.sql` before
  Agent 1.

## Status

| Pipeline | Name | Agents | Status |
|---|---|---|---|
| P-01 | [Lead Intelligence](P-01-lead-intelligence/SPEC.md) | `lead_intelligence_agent`, `entity_resolution_agent` | ✅ spec + [code](mlp) |
| P-02 | [Entity Resolution & Knowledge Base](P-02-entity-resolution/SPEC.md) | `entity_resolution_agent`, `knowledge_graph_agent` | ✅ spec + [code](mlp) |
| P-03–P-27 | *(see source topology)* | — | not yet specced |

Code for P-01/P-02 lives in one shared MLP — [`mlp/`](mlp) — rather than per
pipeline, since `entity_resolution_agent` spans both and shares no state
between its two modes worth splitting into separate services yet. See
[`mlp/README.md`](mlp/README.md) for the pipeline diagram, setup/run
instructions, and known v1 limitations (all external sources — internal
CRM, ACRA/Companies House/Delaware/OpenCorporates, GLEIF — are fixtures in
this pass, not live credentials, per the stub-first build decision).

## Cross-pipeline agent index

Tracked here because layout is pipeline-centric (per decision) — this is
the one place that shows an agent's full footprint across pipelines, so a
later pipeline spec doesn't accidentally redefine an earlier one's scope
for an agent instead of adding to it.

| Agent | Appears in | Role summary (grows as more pipelines are specced) |
|---|---|---|
| `lead_intelligence_agent` | P-01 | Front-office commercial qualifier — industry classification, track selection, opportunity enrichment |
| `entity_resolution_agent` | P-01, P-02 | P-01: pre-flight dedup guard (internal CRM fuzzy match). P-02: corporate identity disambiguator (external registry deterministic + fuzzy match) |
| `knowledge_graph_agent` | P-02 *(also P-03, P-04, P-10, P-14, P-27 per the source topology — not yet specced)* | Graph node/edge constructor and the sole writer to the canonical Knowledge Graph |

## Topology (source reference)

Full P-01–P-27 stage map and the complete reference matrix (all 27
pipelines, their agents, primary role, and scope boundary) were supplied in
conversation and aren't duplicated here in full — this table will be
filled in as each pipeline gets specced, in the same order as the source
topology (Stage 1 → Stage 9).
