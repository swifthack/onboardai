# P-01 — Lead Intelligence Pipeline

Read [`../README.md`](../README.md) first for how this track relates to
[`../../agents/`](../../agents) — kept separate by decision, don't assume
shared schema or conventions with that track.

## Pipeline role & scope

Top-of-funnel prospect intake, commercial viability triage, and opportunity
enrichment.

**In scope**: unstructured prospect signal ingestion (web domain, declared
revenue, requested products), automated industry classification
(SSIC/NACE/NAICS), pre-onboarding track selection (Digital Fast-Track vs.
High-Touch RM-Assisted), preliminary deduplication check.

**Out of scope**: legal identity resolution, official registry document
parsing, binding sanctions clearance. All three are explicitly P-02+
territory — P-01 never blocks or clears a lead, it only classifies and
routes it.

## Position in the topology

```
[STAGE 1: Prospecting]
LEAD INTAKE
      │
      ▼
lead_intelligence_agent  ──►  entity_resolution_agent (P-01 mode)
      │                              │
      │  business sector +           │  dedup confidence vs.
      │  product viability           │  internal CRM / customer DB
      ▼                              ▼
              Enriched Opportunity Card
                      │
                      ▼
                  RM review  ──►  P-02: Entity Resolution & Knowledge Base
```

## Agents in this pipeline

### `lead_intelligence_agent` — Front-Office Commercial Qualifier

**Scope**: ingests basic entity name, URL, and target products; queries
public signals to estimate operational scale, revenue tier, and high-level
risk classification.

**Inputs**: `entity_name` (required), `url` (optional), `target_products`
(list, optional), `declared_revenue` (optional, self-reported).

**Processing**:
1. Resolve `url` (if given) to a live domain — pull basic public signals:
   domain age (WHOIS), site content (for industry-classification text),
   any public "About/Company" page data.
2. Classify industry sector against SSIC (Singapore), NACE (EU), and NAICS
   (US) taxonomies — pick the scheme(s) relevant to the entity's apparent
   jurisdiction, output all applicable codes rather than forcing one
   scheme when the jurisdiction is ambiguous.
3. Estimate operational scale and revenue tier from available signals
   (domain traffic/age as weak proxies, declared revenue if given,
   employee-count signals if the site or public sources surface any) —
   output a **band**, not a point figure, and say plainly when signal is
   too thin to band at all (`"insufficient_signal"` rather than a
   guessed band).
4. Assign a high-level risk classification — this is a coarse screen (not
   the Composite Risk Score, which is P-12's job, far downstream and
   dependent on data this pipeline doesn't have yet): jurisdiction on a
   bank-excluded or FATF-blacklist list is the main thing that can flip
   this at P-01, since little else is knowable yet.
5. Select the onboarding track — see § Track selection logic.

**Output**: partial opportunity card (sector, scale/revenue band, risk
classification, track recommendation) — handed to `entity_resolution_agent`
for the dedup pass before the full card is assembled.

### `entity_resolution_agent` (P-01 mode) — Pre-Flight Deduplication Guard

Same agent as P-02's `entity_resolution_agent`, different scope in this
pipeline — see the cross-pipeline agent index in
[`../README.md`](../README.md). Here it does **not** touch external
registries at all; that's exclusively the P-02 mode.

**Scope**: performs a fast string and alias match against internal CRM and
existing bank customer databases to prevent duplicate lead creation or
cross-team conflict of interest.

**Inputs**: `entity_name`, any known aliases/trading names surfaced by
`lead_intelligence_agent`'s domain scan.

**Processing**: fuzzy string match (trigram/edit-distance) + phonetic match
against two internal repositories — the CRM (prospects, leads in flight)
and the core client system of record (active/former banked clients). This
is a narrower, faster version of what P-02's registry-grade resolution
does — internal data only, no external API calls, designed to return
inside the RM-facing turnaround time this pipeline targets (seconds, not
minutes).

**Output**: `dedup_result` — one of `no_match` (proceed), `matches_existing_
client` (surface to RM — may be a conflict-of-interest or cross-sell
signal depending on which internal team owns the existing relationship),
`matches_existing_lead` (another RM or channel already has this prospect —
surfaces the owning RM so the new submission doesn't silently fork the
relationship).

## Step-by-step data flow

1. `lead_intelligence_agent` processes inbound lead attributes and predicts
   business sector and product viability.
2. Output payload is handed off to `entity_resolution_agent` to query
   internal client repositories.
3. Returns an **enriched opportunity card** to the Relationship Manager
   with preliminary risk tier and deduplication confirmation.

## Output contract — Enriched Opportunity Card

```json
{
  "entity_name": "string",
  "industry_classification": {
    "ssic": "string | null",
    "nace": "string | null",
    "naics": "string | null",
    "basis": "string — what text/signal drove the classification"
  },
  "operational_scale": {
    "revenue_band": "string | 'insufficient_signal'",
    "basis": "string"
  },
  "preliminary_risk_classification": "standard | elevated | excluded_jurisdiction",
  "recommended_track": "digital_fast_track | high_touch_rm_assisted",
  "track_rationale": ["string", "..."],
  "dedup_result": {
    "status": "no_match | matches_existing_client | matches_existing_lead",
    "matched_record_id": "string | null",
    "owning_rm_or_team": "string | null",
    "confidence": 0.0
  }
}
```

## Track selection logic

A rubric, for the same reason the `agents/` track's propensity score is a
rubric and not an opaque number — an RM needs to see *why* a lead was
routed digital-only vs. flagged for high-touch handling:

| Signal | Pushes toward Digital Fast-Track | Pushes toward High-Touch RM-Assisted |
|---|---|---|
| Requested products | Single simple product (e.g. CASA only) | Multiple products, or any of trade finance / custody / lending / complex treasury |
| Entity structural signal | Single operating company, no fund/holding-company language detected | Fund/GP/LP/trust/foundation/holding-structure language on site or in declared name |
| Revenue/scale band | Small/early-stage | Large or `insufficient_signal` (can't safely fast-track what can't be sized) |
| Preliminary risk classification | `standard` | `elevated` or `excluded_jurisdiction` (the latter should really be a decline, not a track choice — see open questions) |
| Dedup result | `no_match` (clean intake) | `matches_existing_client`/`matches_existing_lead` (needs human handling regardless of the above, to resolve relationship ownership) |

Any single "High-Touch" trigger wins — this is not a weighted score like
the propensity rubric in the other track, because track selection is a
routing decision (binary-ish, low stakes to over-trigger toward the safer
high-touch path) rather than a prioritization ranking.

## Confidence & data-quality notes

- Industry classification confidence depends entirely on how much public
  text is available (a URL with a real "About" page vs. a bare domain).
  Report classification confidence per scheme, not just a single number —
  SSIC might resolve confidently while NAICS doesn't, if the entity's
  apparent nexus is Singapore.
- `entity_resolution_agent`'s internal match confidence should use the
  same disambiguation-threshold discipline established in
  `adversemedia/mlp`'s README (0.70 as a loose exploratory threshold vs.
  0.85 for anything onboarding-consequential) — since a false
  `matches_existing_client` here can misroute a genuinely new lead to the
  wrong RM, lean toward the tighter (0.85) threshold for anything that
  changes routing, and only use the looser threshold for a soft
  "possible match, human should glance at this" flag.

## Known v1 limitations

- No real data-source integration specified yet for `lead_intelligence_agent`'s
  public-signal scan (WHOIS lookup, site scraping, revenue-band
  inference) — this pipeline doc describes the *logic*, not a chosen
  vendor/adapter; unlike the `agents/` track, this track hasn't yet
  defined a stub-adapter convention of its own (see open questions).
- SSIC/NACE/NAICS classification from thin public signal (a domain and
  maybe a homepage) is inherently approximate — should be treated as a
  routing aid, never as the industry classification of record (P-02/P-03
  and official filings are the real source of truth once the entity is
  registry-resolved).
- The "preliminary risk classification" here is deliberately shallow
  (jurisdiction-list check, nothing else) — it must not be confused with
  or substituted for P-12's Composite Risk Score downstream.

## Open questions

1. **Data sources for the public-signal scan** — what's actually available
   (WHOIS API, a scraping/enrichment vendor, an LLM web-search tool)?
   This pipeline's quality depends entirely on this choice and it isn't
   specified in the source material.
2. **Should `excluded_jurisdiction` be a decline, not a track choice?**
   The rubric above currently treats it as just another High-Touch
   trigger, but arguably a lead from a bank-excluded jurisdiction
   shouldn't proceed to *any* track — worth a hard stop here rather than
   waiting for P-12 to catch it much later.
3. **Internal CRM/customer-DB access** — what system(s) does
   `entity_resolution_agent`'s P-01 mode actually query, and is there one
   unified internal client repository or several per business line (which
   would explain the `owning_rm_or_team` field's need to disambiguate)?
4. **Digital Fast-Track definition** — this spec assumes it means a
   lighter-touch, more automated onboarding journey downstream, but the
   source material doesn't define what's actually different about it
   operationally (which pipelines it skips or automates further, if any).
