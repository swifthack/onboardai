# Nexum Pipelines MLP — P-01 + P-02

The "most lovable product" slice of the Agent Studio track: `lead_intelligence_agent`,
`entity_resolution_agent` (both modes), and `knowledge_graph_agent`, wired
end-to-end against **Postgres** (leads, opportunity cards, Golden Records —
the relational/structured data) and **Neo4j** (the Knowledge Graph itself —
entity nodes and parent/subsidiary anchor edges), with a small fixture data
set standing in for the internal CRM and external registries, and Claude
doing the industry-classification/track-rationale reasoning for P-01.

This is a stripped-down, single-node implementation of the design in
[`../P-01-lead-intelligence/SPEC.md`](../P-01-lead-intelligence/SPEC.md) and
[`../P-02-entity-resolution/SPEC.md`](../P-02-entity-resolution/SPEC.md) —
read those first if picking this up cold. Same pattern as
[`adversemedia/mlp`](../../../adversemedia/mlp): real Postgres, real LLM
calls, external data sources stubbed with clearly-marked fixtures instead of
live credentials.

## Pipeline

```
entity_name, url?, products?, revenue?, jurisdiction?
        │
        ▼
P-01 ── entity_resolution_agent (dedup_guard mode) ──► internal CRM fixture match
     └─ lead_intelligence_agent ──► Claude (industry classification, scale band)
                                 ──► track selection rubric (rule-based)
                                 ──► Claude (track rationale bullets)
        │
        ▼
   Enriched Opportunity Card  (Postgres: opportunity_cards)
        │
        ▼
P-02 ── entity_resolution_agent (resolve mode) ──► registry fixture lookup
     │                                              (ACRA / Companies House /
     │                                              Delaware / OpenCorporates)
     │                                              + GLEIF
     │                                           ──► conflict reconciliation
     │                                              (rule-based)
     ▼
   Golden Entity Record  (Postgres: golden_records)
        │
        ▼
   knowledge_graph_agent ──► Neo4j: (:Entity {golden_record_id, ...})
                              -[:SUBSIDIARY_OF {source}]-> (:Entity | :Unresolved)
```

`:Unresolved` is a placeholder node — created when a registry filing names
a parent/affiliate that hasn't itself been through P-02 yet. If that name
later resolves for real, `write_entity_node` upgrades the placeholder in
place (same node, label swapped, `golden_record_id` attached) rather than
creating a duplicate — verified by resolving `Vantage Global Holdings PLC`
after `Vantage Fintech Solutions Ltd` in a test run: node count stayed at 4,
the existing `SUBSIDIARY_OF` edge automatically pointed at the upgraded node.

## Setup

1. **Start Postgres + Neo4j:**
   ```bash
   docker compose up -d
   ```
   This project is pinned to `name: nexum-pipelines-mlp` in
   `docker-compose.yml` — without that, Compose defaults the project name
   to the directory basename (`mlp`), which collides with
   `../../../adversemedia/mlp` (same basename, also a Compose project) and
   Compose will recreate/destroy whichever one ran last. Hit this for real
   while building this file — the explicit `name:` is required, not
   cosmetic.
2. **Python env:**
   ```bash
   python3 -m venv .venv && source .venv/bin/activate
   pip install -r requirements.txt
   ```
3. **Credentials:**
   ```bash
   cp .env.example .env
   # edit .env and set ANTHROPIC_API_KEY (required — P-01's classification call)
   ```

## Run

```bash
cd src
python run_pipeline.py "Vantage Fintech Solutions Ltd" --products casa,trade_finance --jurisdiction GB
```

Demo entities chosen to exercise specific paths in the fixture data
(`src/fixtures/internal_crm.py`, `src/fixtures/registries.py`):

| Entity name | Exercises |
|---|---|
| `Meridian Trade Holdings Pte Ltd` | Dedup hit — existing client; single-source clean registry match (ACRA) |
| `Northbridge Capital Partners LLC` | Dedup hit — existing lead (not client); two registries agree; GLEIF LEI cross-reference |
| `Vantage Fintech Solutions Ltd` | Clean dedup (no internal match), but registry conflict — Companies House vs. OpenCorporates disagree on address *and* incorporation date — plus a parent-company anchor edge |
| any other name | No dedup match, no registry filing — unresolved Golden Record (`status: "unresolved"`), proving the pipeline degrades gracefully instead of erroring or fabricating |

Each run prints both JSON payloads to stdout and writes
`output/pipeline_report_*.md`.

## Browsing the graph

Neo4j Browser: [http://localhost:7474](http://localhost:7474) — sign in
with `neo4j` / `nexum_local_dev` (or whatever `.env` sets). Useful queries:

```cypher
// Everything
MATCH (n) RETURN n;

// A specific entity and one hop out
MATCH (e:Entity {legal_name: "Vantage Fintech Solutions Ltd"})-[r]-(n)
RETURN e, r, n;

// Unresolved placeholders — parent/affiliate hints from registry filings
// that haven't themselves been through P-02 yet
MATCH (u:Unresolved) RETURN u;
```

## What's a known v1 limitation (by design, not oversight)

- **All external sources are hardcoded fixtures**, not live APIs — per the
  build decision (stub everything, wire live credentials later). GLEIF and
  the bank's own internal CRM are the two worth wiring live first (same call
  made in both P-01 and P-02 SPEC.md).
- **P-01's public-signal scan is unimplemented** — `classify_lead()` reasons
  only from `entity_name` / `url` / `declared_revenue` / `target_products`
  text, with no actual WHOIS lookup or site scraping behind `url`. This is
  P-01 SPEC.md's open question #1, left open on purpose — the classification
  prompt is honest about `"insufficient_signal"` rather than hallucinating
  around the gap.
- **Registry name matching is exact-normalized lookup** against the fixture
  dict, not real fuzzy matching against a live registry search API — fine
  for 3 demo entities, not a substitute for the fuzzy-match step P-02
  SPEC.md describes once live registries are wired in.
- **`entity_resolution_agent`'s two modes live in one file**
  (`dedup_guard` vs. `resolve_entity`) rather than being split into separate
  services — reasonable at MLP scale since they share no state; worth
  revisiting if this ever needs independent scaling/deployment.
- **No event bus.** This is a synchronous CLI pipeline (P-01 then P-02 in
  one process), not the event-driven mesh the wider Nexum design implies.
  Fine for proving the agent logic; a real deployment needs event contracts
  this MLP doesn't define (see [`../README.md`](../README.md)).
- **Neo4j is a single unclustered dev instance, no plugins** (no APOC, no
  Graph Data Science) — fine for the anchor-edge writes P-02 does today.
  P-04 (ownership/UBO traversal, out of scope here) will want recursive
  Cypher or APOC path-finding once it's built against this same graph.
- **The upgrade-in-place logic (`:Unresolved` → `:Entity`) matches on exact
  `legal_name` string equality** — a registry filing that names the parent
  slightly differently than that parent's own Golden Record (punctuation,
  "Ltd" vs "Limited", as already seen between Companies House and
  OpenCorporates in the Vantage fixture) won't upgrade the placeholder and
  will instead leave two nodes for the same real company. P-02's own
  fuzzy-matching logic isn't reused here; it should be once this graph
  write path handles more than 3 demo entities.

## Next widenings, roughly in order of leverage

1. Swap `fixtures/internal_crm.py` for a real internal CRM/core-banking read
   API — highest leverage since it needs no external licensing.
2. Wire GLEIF live (free, keyless) — replaces `fixtures/registries.py`'s
   `GLEIF_FIXTURES` dict with the real LEI search API.
3. Add a real public-signal source for P-01 (WHOIS + a scraping/enrichment
   vendor, or an LLM web-search tool) to resolve open question #1.
4. Replace exact-normalized registry lookup with real fuzzy matching against
   live ACRA / Companies House / Delaware SoS / OpenCorporates APIs.
5. Reuse `entity_resolution_agent`'s fuzzy-matching logic (or GLEIF) for the
   `:Unresolved` → `:Entity` upgrade match in `graph_db.py`, instead of
   exact `legal_name` equality.
