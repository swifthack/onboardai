"""
knowledge_graph_agent — P-02, Knowledge Base Graph Constructor.
Sole writer to the graph (see ../README.md for how this differs from the
agents/ track, where every agent writes directly to shared tables). The
graph itself lives in Neo4j (graph_db.py) — Postgres (db.py) remains the
store of record for leads/opportunity_cards/golden_records. See
P-02-entity-resolution/SPEC.md for the full contract.
"""

import graph_db


def write_entity_node(golden_record: dict) -> str:
    """Returns golden_record_id, used as the node's identifier everywhere
    else in this codebase (there's no separate node_id anymore — the
    business key doubles as the graph key, see graph_db.py)."""
    return graph_db.write_entity_node(golden_record)


def write_anchor_edges(from_node_id: str, golden_record: dict) -> list[dict]:
    """Anchors only — records that a parent/subsidiary/affiliate relationship
    exists and to what entity, WITHOUT computing ownership percentages or
    beneficial-ownership chains (that's P-04's ubo_ownership_agent, out of
    scope here). See P-02 SPEC.md § knowledge_graph_agent.

    Most registry filings don't surface this at all — an empty return here
    is the common case, not a gap (P-02 SPEC.md known limitations)."""
    parent_hint = golden_record.get("_parent_company_hint")
    if not parent_hint:
        return []

    edge = graph_db.write_anchor_edge(
        from_golden_record_id=from_node_id,
        to_legal_name_hint=parent_hint,
        edge_type="SUBSIDIARY_OF",
        source="registry_filing",
    )
    return [edge]
