"""
Neo4j writer for knowledge_graph_agent — the real graph store for P-02's
output, replacing the earlier Postgres JSONB stand-in (see schema.sql's
note). Postgres stays the store of record for leads/opportunity_cards/
golden_records (db.py); this module is the only thing that touches the
graph itself.

Model:
  (:Entity {golden_record_id, legal_name, registration_number, lei,
            uen_or_tax_id, incorporation_date, incorporation_jurisdiction,
            status, resolution_method, confidence})
  -[:PARENT_OF | :SUBSIDIARY_OF | :AFFILIATE_OF {source}]->
  (:Entity)                      -- resolved anchor target, or --
  (:Entity:Unresolved {legal_name})  -- name-only hint, no Golden Record yet

`golden_record_id` is the MERGE key for resolved nodes — idempotent by
design, since a re-run of P-02 for the same entity should update the node
in place, not duplicate it. An :Unresolved node is MERGEd by legal_name
alone (no golden_record_id yet) and upgraded in place — label swapped,
golden_record_id attached — the moment that same name resolves through
P-02 for real. That upgrade is what write_entity_node does below; it's the
graph-native equivalent of db.find_node_by_legal_name's lookup in the old
Postgres version.
"""

import os

from dotenv import load_dotenv
from neo4j import GraphDatabase

load_dotenv()

NEO4J_URI = os.environ.get("NEO4J_URI", "bolt://localhost:7687")
NEO4J_USER = os.environ.get("NEO4J_USER", "neo4j")
NEO4J_PASSWORD = os.environ.get("NEO4J_PASSWORD", "nexum_local_dev")

_driver = None


def get_driver():
    global _driver
    if _driver is None:
        _driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))
    return _driver


def close_driver():
    global _driver
    if _driver is not None:
        _driver.close()
        _driver = None


def ensure_constraints():
    """Run once (idempotent) — uniqueness on the two keys nodes are MERGEd
    on. Call this after the container is up and before the first write;
    run_pipeline.py does this on startup."""
    with get_driver().session() as session:
        session.run(
            "CREATE CONSTRAINT entity_golden_record_id IF NOT EXISTS "
            "FOR (e:Entity) REQUIRE e.golden_record_id IS UNIQUE"
        )
        session.run(
            "CREATE CONSTRAINT unresolved_legal_name IF NOT EXISTS "
            "FOR (e:Unresolved) REQUIRE e.legal_name IS UNIQUE"
        )


def write_entity_node(golden_record: dict) -> str:
    """MERGE the resolved entity node. If an :Unresolved placeholder already
    exists under this legal_name (created earlier as someone else's anchor
    target), upgrade it in place rather than leaving two nodes for the same
    company — this is the one case where write order across pipeline runs
    matters, and it's handled here rather than assumed away.

    Returns golden_record_id — the node's business key, used as the "node
    id" everywhere else in this codebase (run_pipeline.py's report, the
    return value of write_anchor_edges)."""
    props = {
        "golden_record_id": golden_record["golden_record_id"],
        "legal_name": golden_record["legal_name"],
        "registration_number": golden_record.get("registration_number"),
        "lei": golden_record.get("lei"),
        "uen_or_tax_id": golden_record.get("uen_or_tax_id"),
        "incorporation_date": golden_record.get("incorporation_date"),
        "incorporation_jurisdiction": golden_record.get("incorporation_jurisdiction"),
        "status": golden_record.get("status"),
        "resolution_method": golden_record.get("resolution_method"),
        "confidence": golden_record.get("confidence"),
    }
    with get_driver().session() as session:
        # Step 1: if an :Unresolved placeholder exists under this exact
        # legal_name, upgrade it in place rather than leaving two nodes for
        # the same company. MERGE can't take a WHERE filter on its own
        # pattern, so this is a plain MATCH — it does nothing if no such
        # placeholder exists, which is the common case.
        session.run(
            """
            MATCH (existing:Unresolved {legal_name: $legal_name})
            SET existing:Entity
            REMOVE existing:Unresolved
            SET existing += $props
            """,
            legal_name=props["legal_name"], props=props,
        )
        # Step 2: MERGE by the real business key — creates the node if step 1
        # found nothing to upgrade, and idempotently re-applies props if
        # P-02 re-runs for an entity that's already resolved (including the
        # node step 1 just upgraded, matched here by its new golden_record_id).
        session.run(
            "MERGE (e:Entity {golden_record_id: $golden_record_id}) SET e += $props",
            golden_record_id=props["golden_record_id"], props=props,
        )
    return golden_record["golden_record_id"]


def find_resolved_node_by_legal_name(legal_name: str):
    """Graph-native equivalent of the old db.find_node_by_legal_name — only
    matches an already-resolved (:Entity) node, never an :Unresolved
    placeholder, so an anchor edge doesn't accidentally point at another
    edge's placeholder instead of a real Golden Record."""
    with get_driver().session() as session:
        result = session.run(
            "MATCH (e:Entity) WHERE toLower(e.legal_name) = toLower($legal_name) "
            "RETURN e.golden_record_id AS golden_record_id LIMIT 1",
            legal_name=legal_name,
        )
        record = result.single()
        return record["golden_record_id"] if record else None


def write_anchor_edge(from_golden_record_id: str, to_legal_name_hint: str, edge_type: str, source: str) -> dict:
    """Anchor edge only — see knowledge_graph_agent.py. If `to_legal_name_hint`
    already resolved to a real Golden Record elsewhere, the edge points at
    that :Entity node; otherwise it points at a fresh :Unresolved
    placeholder that a later P-02 run on that name will upgrade in place."""
    resolved_id = find_resolved_node_by_legal_name(to_legal_name_hint)
    with get_driver().session() as session:
        if resolved_id:
            session.run(
                f"""
                MATCH (from:Entity {{golden_record_id: $from_id}})
                MATCH (to:Entity {{golden_record_id: $to_id}})
                MERGE (from)-[r:{edge_type} {{source: $source}}]->(to)
                """,
                from_id=from_golden_record_id, to_id=resolved_id, source=source,
            )
            target_ref = resolved_id
        else:
            session.run(
                f"""
                MATCH (from:Entity {{golden_record_id: $from_id}})
                MERGE (to:Unresolved {{legal_name: $legal_name}})
                MERGE (from)-[r:{edge_type} {{source: $source}}]->(to)
                """,
                from_id=from_golden_record_id, legal_name=to_legal_name_hint, source=source,
            )
            target_ref = f"(unresolved: {to_legal_name_hint})"
    return {
        "from_node_id": from_golden_record_id,
        "to_node_id": resolved_id,
        "to_entity_name_hint": None if resolved_id else to_legal_name_hint,
        "edge_type": edge_type,
        "source": source,
        "_target_display": target_ref,
    }
