"""
End-to-end CLI orchestrator for P-01 -> P-02.

Run:
    python run_pipeline.py "Vantage Fintech Solutions Ltd" \
        --products casa,trade_finance --jurisdiction GB

Demo entities chosen to exercise specific paths against the fixture data in
fixtures/internal_crm.py and fixtures/registries.py — see mlp/README.md for
the full table of what each one proves.
"""

import argparse
import json
import os
import uuid
from datetime import datetime, timezone

import graph_db
from db import insert_lead, insert_opportunity_card, insert_golden_record
from entity_resolution_agent import dedup_guard, resolve_entity
from lead_intelligence_agent import build_opportunity_card
from knowledge_graph_agent import write_entity_node, write_anchor_edges

OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "..", "output")


def run_p01(entity_name, url, declared_revenue, target_products, jurisdiction_hint):
    lead_id = f"lead-{uuid.uuid4().hex[:10]}"
    insert_lead(lead_id, entity_name, url, target_products, declared_revenue, jurisdiction_hint)

    dedup_result = dedup_guard(entity_name)
    card = build_opportunity_card(
        entity_name, url, declared_revenue, target_products, jurisdiction_hint, dedup_result,
    )
    insert_opportunity_card(lead_id, card)
    return lead_id, card


def run_p02(entity_name, lead_id):
    golden_record = resolve_entity(entity_name, lead_id=lead_id)
    insert_golden_record(golden_record)

    node_id = write_entity_node(golden_record)
    edges = write_anchor_edges(node_id, golden_record)
    return golden_record, node_id, edges


def write_report(entity_name, card, golden_record, node_id, edges):
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H%MZ")
    path = os.path.join(OUTPUT_DIR, f"pipeline_report_{ts}.md")

    lines = [f"# P-01/P-02 Pipeline Report — {entity_name} — {ts}\n"]
    lines.append("## P-01 — Enriched Opportunity Card\n")
    lines.append("```json\n" + json.dumps(card, indent=2, default=str) + "\n```\n")
    lines.append("## P-02 — Golden Entity Record\n")
    lines.append("```json\n" + json.dumps(golden_record, indent=2, default=str) + "\n```\n")
    lines.append(f"**Knowledge Graph node (Neo4j, `golden_record_id`):** `{node_id}`\n")
    if edges:
        lines.append("**Anchor edges:**")
        for e in edges:
            lines.append(f"- {e['edge_type']} -> {e['_target_display']} (source: {e['source']})")
    else:
        lines.append("**Anchor edges:** none surfaced by registry filings for this entity.")

    with open(path, "w") as f:
        f.write("\n".join(lines))
    print(f"\nReport written to {path}")
    return path


def main():
    parser = argparse.ArgumentParser(
        description="Run P-01 (Lead Intelligence) then P-02 (Entity Resolution) for one lead.",
    )
    parser.add_argument("entity_name")
    parser.add_argument("--url", default=None)
    parser.add_argument("--revenue", dest="declared_revenue", default=None)
    parser.add_argument("--products", default="", help="comma-separated, e.g. casa,trade_finance")
    parser.add_argument("--jurisdiction", dest="jurisdiction_hint", default=None)
    args = parser.parse_args()

    target_products = [p.strip() for p in args.products.split(",") if p.strip()]

    graph_db.ensure_constraints()

    print(f"=== P-01: Lead Intelligence — {args.entity_name} ===")
    lead_id, card = run_p01(
        args.entity_name, args.url, args.declared_revenue, target_products, args.jurisdiction_hint,
    )
    print(json.dumps(card, indent=2, default=str))

    print(f"\n=== P-02: Entity Resolution & Knowledge Base — {args.entity_name} ===")
    golden_record, node_id, edges = run_p02(args.entity_name, lead_id)
    print(json.dumps(golden_record, indent=2, default=str))
    print(f"Knowledge Graph node: {node_id}")
    for e in edges:
        print(f"  edge: {e}")

    write_report(args.entity_name, card, golden_record, node_id, edges)
    graph_db.close_driver()


if __name__ == "__main__":
    main()
