import os
import json
from contextlib import contextmanager

import psycopg2
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.environ.get(
    "DATABASE_URL", "postgresql://nexum:nexum_local_dev@localhost:55433/nexum_pipelines_mlp"
)


@contextmanager
def get_conn():
    conn = psycopg2.connect(DATABASE_URL)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def insert_lead(lead_id: str, entity_name: str, url, target_products, declared_revenue, jurisdiction_hint):
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO leads (lead_id, entity_name, url, target_products, declared_revenue, jurisdiction_hint)
            VALUES (%s, %s, %s, %s, %s, %s)
            ON CONFLICT (lead_id) DO NOTHING
            """,
            (lead_id, entity_name, url, json.dumps(target_products or []), declared_revenue, jurisdiction_hint),
        )


def insert_opportunity_card(lead_id: str, card: dict):
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO opportunity_cards
                (lead_id, industry_classification, operational_scale, preliminary_risk_classification,
                 recommended_track, track_rationale, dedup_result)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """,
            (
                lead_id,
                json.dumps(card["industry_classification"]),
                json.dumps(card["operational_scale"]),
                card["preliminary_risk_classification"],
                card["recommended_track"],
                json.dumps(card["track_rationale"]),
                json.dumps(card["dedup_result"]),
            ),
        )


def insert_golden_record(gr: dict):
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO golden_records
                (golden_record_id, lead_id, legal_name, registration_number, lei, uen_or_tax_id,
                 incorporation_date, incorporation_jurisdiction, registered_address, status,
                 source_registries, conflicting_filings, resolution_method, confidence)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (golden_record_id) DO NOTHING
            """,
            (
                gr["golden_record_id"],
                gr.get("lead_id"),
                gr["legal_name"],
                gr.get("registration_number"),
                gr.get("lei"),
                gr.get("uen_or_tax_id"),
                gr.get("incorporation_date"),
                gr.get("incorporation_jurisdiction"),
                json.dumps(gr.get("registered_address")),
                gr.get("status"),
                json.dumps(gr.get("source_registries", [])),
                json.dumps(gr.get("conflicting_filings", [])),
                gr["resolution_method"],
                gr["confidence"],
            ),
        )



# Graph writes (entity nodes + anchor edges) moved to Neo4j — see
# graph_db.py — this module now only ever writes the three Postgres tables
# above (leads, opportunity_cards, golden_records).
