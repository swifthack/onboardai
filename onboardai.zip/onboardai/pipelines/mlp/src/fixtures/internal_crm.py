"""
Stand-in for the bank's internal CRM + core client system of record, used by
entity_resolution_agent's P-01 (dedup-guard) mode. Real build swaps this for
actual CRM/core-banking read APIs — see P-01-lead-intelligence/SPEC.md open
question #3.

Hardcoded, small, deliberately fictitious companies — same spirit as
adversemedia/mlp's src/registry.py watchlist: enough to prove the matching
logic works end-to-end, not a real customer extract.
"""

EXISTING_CLIENTS = [
    {
        "record_id": "client-0001",
        "legal_name": "Meridian Trade Holdings Pte Ltd",
        "aliases": ["Meridian Trade Holdings"],
        "status": "active_client",
        "owning_rm_or_team": "RM: Priya Nair, Corporate Banking SG",
    },
]

EXISTING_LEADS = [
    {
        "record_id": "lead-0091",
        "legal_name": "Northbridge Capital Partners LLC",
        "aliases": ["Northbridge Capital"],
        "status": "prospect_in_flight",
        "owning_rm_or_team": "RM: Wei Chen, Digital Assets Coverage",
    },
]
