"""
Stand-in for external registry APIs (ACRA Bizfile+, Companies House,
Delaware SoS, OpenCorporates) and GLEIF, used by entity_resolution_agent's
P-02 (registry-disambiguator) mode. Real build swaps each of these for the
actual registry API — see P-02-entity-resolution/SPEC.md open question #1
(jurisdiction coverage priority).

Keyed by lowercased legal_name for this MLP's exact-normalized lookup (P-02
SPEC.md's real fuzzy-match step is a v1 limitation, not implemented here —
see mlp/README.md). Fixture set deliberately includes one entity with a
genuine cross-registry conflict (registered address AND incorporation date
differ between Companies House and OpenCorporates) so the reconciliation
policy in P-02's spec has something real to exercise, plus a
parent-company hint so knowledge_graph_agent's anchor-edge logic has
something to write.
"""

REGISTRY_FIXTURES = {
    "meridian trade holdings pte ltd": [
        {
            "registry": "acra_bizfile",
            "legal_name": "Meridian Trade Holdings Pte. Ltd.",
            "registration_number": "201812345K",
            "uen_or_tax_id": "201812345K",
            "lei": None,
            "incorporation_date": "2018-03-14",
            "incorporation_jurisdiction": "SG",
            "registered_address": {"line1": "1 Raffles Place", "city": "Singapore", "postal_code": "048616"},
            "status": "active",
        },
    ],
    "northbridge capital partners llc": [
        {
            "registry": "delaware_sos",
            "legal_name": "Northbridge Capital Partners LLC",
            "registration_number": "DE-6541827",
            "uen_or_tax_id": None,
            "lei": "549300ABCDEF1234GH56",
            "incorporation_date": "2016-09-02",
            "incorporation_jurisdiction": "US-DE",
            "registered_address": {"line1": "251 Little Falls Drive", "city": "Wilmington, DE", "postal_code": "19808"},
            "status": "active",
        },
        {
            "registry": "opencorporates",
            "legal_name": "Northbridge Capital Partners, LLC",
            "registration_number": "DE-6541827",
            "uen_or_tax_id": None,
            "lei": None,
            "incorporation_date": "2016-09-02",
            "incorporation_jurisdiction": "US-DE",
            "registered_address": {"line1": "251 Little Falls Drive", "city": "Wilmington, DE", "postal_code": "19808"},
            "status": "active",
        },
    ],
    "vantage fintech solutions ltd": [
        {
            "registry": "companies_house",
            "legal_name": "VANTAGE FINTECH SOLUTIONS LTD",
            "registration_number": "09876543",
            "uen_or_tax_id": None,
            "lei": None,
            "incorporation_date": "2015-11-20",
            "incorporation_jurisdiction": "GB",
            "registered_address": {"line1": "20 Fenchurch Street", "city": "London", "postal_code": "EC3M 3BY"},
            "status": "active",
            "parent_company_hint": "Vantage Global Holdings PLC",
        },
        {
            "registry": "opencorporates",
            "legal_name": "Vantage Fintech Solutions Limited",
            "registration_number": "09876543",
            "uen_or_tax_id": None,
            "lei": None,
            "incorporation_date": "2015-11-19",
            "incorporation_jurisdiction": "GB",
            "registered_address": {"line1": "1 Fenchurch Avenue", "city": "London", "postal_code": "EC3M 5BA"},
            "status": "active",
        },
    ],
}

# Free/keyless in reality (see P-02 SPEC.md) — fixture here only because
# live wiring isn't in scope for this pass.
GLEIF_FIXTURES = {
    "northbridge capital partners llc": "549300ABCDEF1234GH56",
}
