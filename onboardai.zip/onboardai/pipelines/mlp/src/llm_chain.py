"""
LLM reasoning layer for P-01 (industry classification, operational-scale
banding, track rationale) — mirrors the grounding discipline of
adversemedia/mlp/src/llm_chain.py (strict JSON out, retry-then-human-review
on parse failure) even though this pipeline's stakes are lower (routing a
lead, not asserting adverse facts about a named individual).

P-02's conflict resolution is deliberately rule-based, not LLM-driven — see
entity_resolution_agent.py — so there's no LLM call in that path; the
conflict-resolution policy in P-02's SPEC.md is meant to be deterministic
and auditable, not a model judgment call.
"""

import os
import json
import re

from anthropic import Anthropic
from dotenv import load_dotenv

load_dotenv()

client = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])

MODEL_CLASSIFY = os.environ.get("MODEL_CLASSIFY", "claude-haiku-4-5-20251001")

PROMPT_VERSION = "p01-mlp-v1.0.0"


def _call_json(system: str, user: str, max_tokens: int = 700):
    """One retry with a stricter instruction on parse failure, then give up —
    caller must treat a None return as 'route to human'."""
    for attempt in (1, 2):
        sys_msg = system
        if attempt == 2:
            sys_msg += (
                "\n\nIMPORTANT: your previous response was not valid JSON. "
                "Output ONLY the JSON value. No prose, no markdown fences, "
                "no explanation before or after."
            )
        resp = client.messages.create(
            model=MODEL_CLASSIFY,
            max_tokens=max_tokens,
            system=sys_msg,
            messages=[{"role": "user", "content": user}],
        )
        text = "".join(block.text for block in resp.content if block.type == "text")
        cleaned = text.strip()
        fence_match = re.search(r"```(?:json)?\s*(.*?)\s*```", cleaned, re.DOTALL)
        if fence_match:
            cleaned = fence_match.group(1)
        try:
            return json.loads(cleaned)
        except (json.JSONDecodeError, ValueError):
            continue
    return None


# ---------------------------------------------------------------------------
# Industry classification + operational-scale banding
# ---------------------------------------------------------------------------

CLASSIFY_SYSTEM = """You are a front-office commercial-banking analyst assistant \
classifying a prospective corporate client from limited public signal. Given \
only an entity name, an optional website URL/domain, an optionally declared \
revenue figure, and the products the prospect is interested in, do two things:

1. Propose industry classification codes under any of SSIC (Singapore), \
NACE (EU), or NAICS (US) that plausibly apply given the entity's apparent \
jurisdiction/name/domain — it is fine and expected to leave a scheme null \
if there is no real basis to guess it. Do not force a guess for schemes \
the input gives no jurisdictional signal for.
2. Estimate an operational-scale/revenue BAND (never a point figure) only if \
the signal genuinely supports one — if the signal is too thin (bare name, \
no URL, no declared revenue), return "insufficient_signal" rather than \
guessing a band.

State the specific input text each claim is based on. Do NOT use outside \
knowledge about any real company that might share this name — reason only \
from what's given below. Output strict JSON and nothing else:
{"industry_classification": {"ssic": "code or null", "nace": "code or null", \
"naics": "code or null", "basis": "..."}, \
"operational_scale": {"revenue_band": "string or 'insufficient_signal'", "basis": "..."}, \
"confidence": 0.0-1.0}"""


def classify_lead(entity_name: str, url: str | None, declared_revenue: str | None,
                   target_products: list[str]) -> dict:
    user = (
        f"Entity name: {entity_name}\n"
        f"Website/domain: {url or '(not provided)'}\n"
        f"Declared revenue: {declared_revenue or '(not provided)'}\n"
        f"Target products: {', '.join(target_products) if target_products else '(not provided)'}\n"
    )
    result = _call_json(CLASSIFY_SYSTEM, user)
    if result is None:
        return {
            "industry_classification": {
                "ssic": None, "nace": None, "naics": None,
                "basis": "LLM classification failed after retry — routed for human review.",
            },
            "operational_scale": {
                "revenue_band": "insufficient_signal",
                "basis": "LLM classification failed after retry — routed for human review.",
            },
            "confidence": 0.0,
            "_needs_human_review": True,
        }
    return result


# ---------------------------------------------------------------------------
# Track-selection rationale (the rubric's decision is rule-based — see
# lead_intelligence_agent.select_track — this call only explains it in
# RM-readable prose, grounded in the actual trigger signals passed in)
# ---------------------------------------------------------------------------

TRACK_RATIONALE_SYSTEM = """You are explaining, in 2-4 short bullet points, \
why a prospective corporate banking client was routed to a specific \
onboarding track (digital_fast_track or high_touch_rm_assisted), for an RM \
to read. The routing decision itself was already made by rule, not by you — \
your only job is to explain it clearly. Ground every bullet in the specific \
trigger signals provided below — do not invent a reason that isn't present \
in the input. Output a strict JSON array of strings and nothing else."""


def track_rationale(track: str, signals: dict) -> list[str]:
    user = f"Recommended track: {track}\n\nSignals:\n{json.dumps(signals, indent=2, default=str)}"
    result = _call_json(TRACK_RATIONALE_SYSTEM, user, max_tokens=400)
    if isinstance(result, list) and result:
        return result
    return [f"Routed to {track} based on rule evaluation (LLM rationale generation failed after retry)."]
