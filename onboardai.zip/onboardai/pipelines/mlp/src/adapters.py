"""
Stub adapters for P-01/P-02. Each returns a result shaped consistently
(found / data / confidence / source / raw) regardless of which "wire"
(internal CRM, external registry, GLEIF) backs it — same spirit as the
SourceAdapter convention in ../../shared/ARCHITECTURE.md (the agents/
track), reimplemented standalone here since this track is kept separate
(see ../README.md). Swap the fixture lookups for real API calls later
without changing any caller.
"""

from dataclasses import dataclass, field
from typing import Any

from rapidfuzz import fuzz

from fixtures.internal_crm import EXISTING_CLIENTS, EXISTING_LEADS
from fixtures.registries import REGISTRY_FIXTURES, GLEIF_FIXTURES


@dataclass
class AdapterResult:
    found: bool
    data: Any = None
    confidence: float = 0.0
    source: str = ""
    raw: dict = field(default_factory=dict)


def _best_fuzzy_match(name: str, candidates: list[dict], threshold: int = 70):
    name_norm = name.strip().lower()
    best, best_score = None, 0
    for c in candidates:
        for candidate_name in [c["legal_name"]] + c.get("aliases", []):
            score = fuzz.token_sort_ratio(name_norm, candidate_name.strip().lower())
            if score > best_score:
                best_score, best = score, c
    if best and best_score >= threshold:
        return best, best_score / 100.0
    return None, 0.0


def internal_crm_lookup(entity_name: str) -> AdapterResult:
    """P-01 mode: fuzzy match against existing clients first, then existing
    leads — an active-client hit matters more than an in-flight-lead hit,
    so clients are checked first even though both are surfaced identically
    downstream (P-01 SPEC.md's dedup_result just tags which)."""
    match, score = _best_fuzzy_match(entity_name, EXISTING_CLIENTS)
    if match:
        return AdapterResult(
            found=True, data={**match, "match_type": "existing_client"},
            confidence=score, source="internal_crm_stub", raw=match,
        )
    match, score = _best_fuzzy_match(entity_name, EXISTING_LEADS)
    if match:
        return AdapterResult(
            found=True, data={**match, "match_type": "existing_lead"},
            confidence=score, source="internal_crm_stub", raw=match,
        )
    return AdapterResult(found=False, confidence=1.0, source="internal_crm_stub")


def registry_lookup(entity_name: str) -> list[AdapterResult]:
    """P-02 mode: one AdapterResult per registry filing found for this name.
    Exact-normalized lookup in this fixture set (see mlp/README.md's known
    v1 limitations) — real build queries each registry's search API and
    fuzzy-matches candidates the way P-01's internal lookup already does."""
    filings = REGISTRY_FIXTURES.get(entity_name.strip().lower(), [])
    return [
        AdapterResult(
            found=True,
            data=filing,
            confidence=0.90 if filing["registry"] != "opencorporates" else 0.60,
            source=filing["registry"],
            raw=filing,
        )
        for filing in filings
    ]


def gleif_lookup(entity_name: str) -> AdapterResult:
    lei = GLEIF_FIXTURES.get(entity_name.strip().lower())
    if lei:
        return AdapterResult(found=True, data={"lei": lei}, confidence=0.95, source="gleif_stub")
    return AdapterResult(found=False, confidence=1.0, source="gleif_stub")
