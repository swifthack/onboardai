"""
entity_resolution_agent — two modes, per ../README.md's cross-pipeline
agent index:

  - dedup_guard()   — P-01 mode (Pre-Flight Deduplication Guard): fast
    internal-CRM fuzzy match, no external calls. See
    P-01-lead-intelligence/SPEC.md.
  - resolve_entity() — P-02 mode (Corporate Identity Disambiguator):
    external registry lookup + deterministic/fuzzy matching + cross-
    registry conflict reconciliation -> Golden Entity Record. See
    P-02-entity-resolution/SPEC.md.

Same agent, two scopes — kept in one module because they share no state
and splitting them would just be ceremony at this scale (see mlp/README.md
known limitations for when that stops being true).
"""

import json
import uuid

from adapters import internal_crm_lookup, registry_lookup, gleif_lookup

# P-01 SPEC.md § Confidence & data-quality notes: 0.85 for anything that
# actually changes routing (tighter than the 0.70 exploratory threshold
# used elsewhere, e.g. adversemedia/mlp's research-tool disambiguation).
DEDUP_ROUTING_THRESHOLD = 0.85


def dedup_guard(entity_name: str) -> dict:
    """P-01 mode. Returns the `dedup_result` block of the Enriched Opportunity Card."""
    result = internal_crm_lookup(entity_name)

    if not result.found:
        return {
            "status": "no_match",
            "matched_record_id": None,
            "owning_rm_or_team": None,
            "confidence": result.confidence,
        }

    if result.confidence < DEDUP_ROUTING_THRESHOLD:
        # Below the routing-consequential threshold — surface as a soft
        # flag, not a routing decision (P-01 SPEC.md).
        return {
            "status": "no_match",
            "matched_record_id": result.data["record_id"],
            "owning_rm_or_team": None,
            "confidence": result.confidence,
            "_soft_flag": f"possible match below {DEDUP_ROUTING_THRESHOLD} routing threshold — human should glance at this",
        }

    status = "matches_existing_client" if result.data["match_type"] == "existing_client" else "matches_existing_lead"
    return {
        "status": status,
        "matched_record_id": result.data["record_id"],
        "owning_rm_or_team": result.data["owning_rm_or_team"],
        "confidence": result.confidence,
    }


# ---------------------------------------------------------------------------
# P-02 mode
# ---------------------------------------------------------------------------

# P-02 SPEC.md § Conflict-resolution policy: primary national registries
# outrank the OpenCorporates aggregator for any field both report.
REGISTRY_PRIORITY = {
    "acra_bizfile": 0,
    "companies_house": 0,
    "delaware_sos": 0,
    "opencorporates": 1,
}

RECONCILED_FIELDS = [
    "legal_name", "registration_number", "incorporation_date",
    "incorporation_jurisdiction", "registered_address", "status",
]


def _hashable(value):
    return json.dumps(value, sort_keys=True) if isinstance(value, dict) else value


def _reconcile_field(field_name: str, filings: list[dict]):
    """Returns (winning_value, [conflict_record_or_empty]) for one field
    across all filings that reported it. No conflict record when every
    filing agrees — the expected, common case."""
    values = [(f.get(field_name), f["registry"]) for f in filings if f.get(field_name) is not None]
    if not values:
        return None, []

    distinct = {_hashable(v) for v, _ in values}
    if len(distinct) <= 1:
        return values[0][0], []

    ranked = sorted(values, key=lambda vs: REGISTRY_PRIORITY.get(vs[1], 99))
    winner, winning_registry = ranked[0]
    conflict = {
        "field": field_name,
        "values": [{"value": v, "source_registry": r} for v, r in values],
        "resolution": f"{winning_registry} wins (registry priority)",
    }
    return winner, [conflict]


def resolve_entity(entity_name: str, lead_id: str | None = None) -> dict:
    """P-02 mode. Returns a Golden Entity Record dict matching
    P-02-entity-resolution/SPEC.md's schema."""
    filings_results = registry_lookup(entity_name)
    gleif = gleif_lookup(entity_name)

    if not filings_results:
        # Degrades gracefully rather than erroring — P-02 SPEC.md doesn't
        # explicitly spec this path, but silently failing or fabricating a
        # record would violate the same grounding discipline the rest of
        # Nexum holds to.
        return {
            "golden_record_id": f"gr-{uuid.uuid4().hex[:10]}",
            "lead_id": lead_id,
            "legal_name": entity_name,
            "registration_number": None,
            "lei": gleif.data["lei"] if gleif.found else None,
            "uen_or_tax_id": None,
            "incorporation_date": None,
            "incorporation_jurisdiction": None,
            "registered_address": None,
            "status": "unresolved",
            "source_registries": [],
            "conflicting_filings": [],
            "resolution_method": "fuzzy_string_match",
            "confidence": 0.0,
            "_note": "No registry filing found in fixture set — real build falls back to a live registry query (see P-02 SPEC.md open question #1).",
        }

    filings = [r.data for r in filings_results]
    parent_hint = next((f.get("parent_company_hint") for f in filings if f.get("parent_company_hint")), None)

    conflicts = []
    reconciled = {}
    for field_name in RECONCILED_FIELDS:
        value, field_conflicts = _reconcile_field(field_name, filings)
        reconciled[field_name] = value
        conflicts.extend(field_conflicts)

    uen_or_tax_id = next((f["uen_or_tax_id"] for f in filings if f.get("uen_or_tax_id")), None)
    lei = next((f["lei"] for f in filings if f.get("lei")), gleif.data["lei"] if gleif.found else None)

    has_deterministic_id = bool(uen_or_tax_id or lei or reconciled.get("registration_number"))
    resolution_method = "deterministic_id_match" if has_deterministic_id else "fuzzy_string_match"

    primary_sources = [f["registry"] for f in filings if f["registry"] != "opencorporates"]
    confidence = 0.90 if primary_sources else 0.60
    if gleif.found:
        confidence = max(confidence, 0.85)

    return {
        "golden_record_id": f"gr-{uuid.uuid4().hex[:10]}",
        "lead_id": lead_id,
        "legal_name": reconciled["legal_name"],
        "registration_number": reconciled["registration_number"],
        "lei": lei,
        "uen_or_tax_id": uen_or_tax_id,
        "incorporation_date": reconciled["incorporation_date"],
        "incorporation_jurisdiction": reconciled["incorporation_jurisdiction"],
        "registered_address": reconciled["registered_address"],
        "status": reconciled["status"],
        "source_registries": [
            {"registry": f["registry"], "matched_field": "name", "retrieved_at": "stub"} for f in filings
        ],
        "conflicting_filings": conflicts,
        "resolution_method": resolution_method,
        "confidence": confidence,
        "_parent_company_hint": parent_hint,
    }
