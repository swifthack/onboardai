"""
lead_intelligence_agent — P-01, Front-Office Commercial Qualifier.
See P-01-lead-intelligence/SPEC.md for the full contract.
"""

from llm_chain import classify_lead, track_rationale

# Placeholders — P-01 SPEC.md open question #2 flags that excluded_jurisdiction
# arguably shouldn't be "just another high-touch trigger" but a hard stop.
# Real build reads live bank-excluded-countries and FATF lists; these are
# small fixed sets purely so the routing logic has something real to branch on.
EXCLUDED_JURISDICTIONS = {"KP", "IR", "SY"}
FATF_BLACKLIST = {"KP", "IR", "MM"}

HIGH_TOUCH_PRODUCTS = {"trade_finance", "custody", "lending", "treasury"}


def assess_risk_classification(jurisdiction_hint: str | None) -> str:
    if jurisdiction_hint in EXCLUDED_JURISDICTIONS:
        return "excluded_jurisdiction"
    if jurisdiction_hint in FATF_BLACKLIST:
        return "elevated"
    return "standard"


def select_track(target_products: list[str], operational_scale: dict,
                  risk_classification: str, dedup_result: dict) -> tuple[str, list[str]]:
    """P-01 SPEC.md § Track selection logic: any single high-touch trigger
    wins — this is a routing decision, not a weighted score."""
    triggers = []

    if len(target_products or []) > 1:
        triggers.append(f"multiple products requested ({', '.join(target_products)})")
    high_touch_hit = [p for p in (target_products or []) if p in HIGH_TOUCH_PRODUCTS]
    if high_touch_hit:
        triggers.append(f"requested product requires high-touch handling ({', '.join(high_touch_hit)})")
    if operational_scale.get("revenue_band") == "insufficient_signal":
        triggers.append("operational scale could not be sized from available signal")
    if risk_classification != "standard":
        triggers.append(f"preliminary risk classification is '{risk_classification}'")
    if dedup_result["status"] != "no_match":
        triggers.append(f"dedup check returned '{dedup_result['status']}' — needs human relationship-ownership resolution")

    if triggers:
        return "high_touch_rm_assisted", triggers
    return "digital_fast_track", ["single simple product, standard risk, clean dedup, operational scale sized"]


def build_opportunity_card(entity_name: str, url: str | None, declared_revenue: str | None,
                            target_products: list[str], jurisdiction_hint: str | None,
                            dedup_result: dict) -> dict:
    classification = classify_lead(entity_name, url, declared_revenue, target_products)
    risk_classification = assess_risk_classification(jurisdiction_hint)
    track, trigger_signals = select_track(
        target_products, classification["operational_scale"], risk_classification, dedup_result,
    )
    rationale = track_rationale(track, {
        "target_products": target_products,
        "operational_scale": classification["operational_scale"],
        "risk_classification": risk_classification,
        "dedup_result": dedup_result,
        "trigger_signals": trigger_signals,
    })

    return {
        "entity_name": entity_name,
        "industry_classification": classification["industry_classification"],
        "operational_scale": classification["operational_scale"],
        "preliminary_risk_classification": risk_classification,
        "recommended_track": track,
        "track_rationale": rationale,
        "dedup_result": dedup_result,
    }
