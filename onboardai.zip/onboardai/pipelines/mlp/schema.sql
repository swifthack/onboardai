-- Nexum "Agent Studio" track — P-01 & P-02 MLP schema.
-- Independent from ../../shared/schema.sql (the agents/ track) by decision
-- — see ../README.md. Mirrors adversemedia/mlp's schema style: plain
-- Postgres, JSONB for nested/variable-shape data, no event bus at MLP scale.

CREATE TABLE leads (
    lead_id             TEXT PRIMARY KEY,
    entity_name         TEXT NOT NULL,
    url                 TEXT,
    target_products     JSONB NOT NULL DEFAULT '[]',
    declared_revenue    TEXT,
    jurisdiction_hint   TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- P-01 output — the Enriched Opportunity Card (P-01 SPEC.md § Output contract).
CREATE TABLE opportunity_cards (
    id                                SERIAL PRIMARY KEY,
    lead_id                           TEXT NOT NULL REFERENCES leads(lead_id),
    industry_classification           JSONB NOT NULL,
    operational_scale                 JSONB NOT NULL,
    preliminary_risk_classification   TEXT NOT NULL,
    recommended_track                 TEXT NOT NULL,
    track_rationale                   JSONB NOT NULL DEFAULT '[]',
    dedup_result                      JSONB NOT NULL,
    created_at                        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON opportunity_cards (lead_id);

-- P-02 output — the Golden Entity Record (P-02 SPEC.md § Golden Entity Record schema).
CREATE TABLE golden_records (
    golden_record_id            TEXT PRIMARY KEY,
    lead_id                     TEXT REFERENCES leads(lead_id),
    legal_name                  TEXT NOT NULL,
    registration_number         TEXT,
    lei                         TEXT,
    uen_or_tax_id                TEXT,
    incorporation_date           DATE,
    incorporation_jurisdiction   TEXT,
    registered_address            JSONB,
    status                        TEXT,
    source_registries              JSONB NOT NULL DEFAULT '[]',
    conflicting_filings            JSONB NOT NULL DEFAULT '[]',
    resolution_method              TEXT NOT NULL,
    confidence                     NUMERIC(4,3) NOT NULL,
    created_at                      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON golden_records (lead_id);

-- knowledge_graph_agent's output (entity nodes + PARENT_OF/SUBSIDIARY_OF/
-- AFFILIATE_OF anchor edges) now lives in Neo4j, not here — see
-- src/graph_db.py and docker-compose.yml's `neo4j` service. Postgres
-- remains the store of record for everything relational (leads,
-- opportunity_cards, golden_records above); Neo4j is only for the graph
-- itself, keyed off golden_record_id. This table pair used to hold the
-- graph as JSONB and was removed once the real graph store existed —
-- flagging the removal here rather than leaving a silently-stale table
-- pair for someone to find later.
