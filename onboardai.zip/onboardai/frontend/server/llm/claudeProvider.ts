import Anthropic from '@anthropic-ai/sdk';
import { LlmProvider, LlmMessage, JsonSchema } from './types';

function toClaudeMessages(messages: LlmMessage[]) {
  return messages.map((m) => ({ role: m.role, content: m.content }));
}

export function createClaudeProvider(apiKey: string, model = 'claude-sonnet-5'): LlmProvider {
  const client = new Anthropic({ apiKey });

  return {
    name: 'anthropic',

    async chat({ messages, systemInstruction, temperature = 0.7 }) {
      const response = await client.messages.create({
        model,
        max_tokens: 1024,
        system: systemInstruction,
        temperature,
        messages: toClaudeMessages(messages),
      });
      const textBlock = response.content.find((b) => b.type === 'text');
      return textBlock ? textBlock.text : "I apologize, but I couldn't generate a response.";
    },

    async generateJSON<T>({ messages, systemInstruction, schema, temperature = 0.2 }: {
      messages: LlmMessage[]; systemInstruction: string; schema: JsonSchema; temperature?: number;
    }): Promise<T> {
      // Structured output via forced tool-use — the reliable pattern for
      // guaranteed-shape JSON from Claude (a bare "reply in JSON" prompt
      // isn't safe to parse blind; JsonSchema already *is* the input_schema
      // Claude's tool-use wants, so no translation needed here).
      const response = await client.messages.create({
        model,
        max_tokens: 1024,
        system: systemInstruction,
        temperature,
        messages: toClaudeMessages(messages),
        tools: [{ name: 'respond', description: 'Provide the structured response.', input_schema: schema as any }],
        tool_choice: { type: 'tool', name: 'respond' },
      });
      const toolUse = response.content.find((b) => b.type === 'tool_use');
      if (!toolUse) throw new Error('Empty structured response from Claude');
      return toolUse.input as T;
    },
  };
}
