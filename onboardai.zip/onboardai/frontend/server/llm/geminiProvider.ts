import { GoogleGenAI, Type } from '@google/genai';
import { LlmProvider, LlmMessage, JsonSchema } from './types';

function toGeminiType(t: JsonSchema['type']) {
  switch (t) {
    case 'object': return Type.OBJECT;
    case 'array': return Type.ARRAY;
    case 'number': return Type.NUMBER;
    case 'boolean': return Type.BOOLEAN;
    case 'integer': return Type.INTEGER;
    case 'string':
    default:
      return Type.STRING;
  }
}

// Translates the provider-agnostic JsonSchema into Gemini's Type-enum
// schema shape — kept local to this file so nothing outside ever needs to
// know Gemini's schema dialect exists.
function toGeminiSchema(schema: JsonSchema): any {
  const out: any = { type: toGeminiType(schema.type) };
  if (schema.description) out.description = schema.description;
  if (schema.properties) {
    out.properties = Object.fromEntries(
      Object.entries(schema.properties).map(([key, value]) => [key, toGeminiSchema(value)]),
    );
  }
  if (schema.items) out.items = toGeminiSchema(schema.items);
  if (schema.required) out.required = schema.required;
  if (schema.enum) out.enum = schema.enum;
  return out;
}

function toGeminiContents(messages: LlmMessage[]) {
  return messages.map((m) => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: m.content }],
  }));
}

export function createGeminiProvider(ai: GoogleGenAI, model = 'gemini-3.6-flash'): LlmProvider {
  return {
    name: 'gemini',

    async chat({ messages, systemInstruction, temperature = 0.7 }) {
      const response = await ai.models.generateContent({
        model,
        contents: toGeminiContents(messages),
        config: { systemInstruction, temperature },
      });
      return response.text || "I apologize, but I couldn't generate a response.";
    },

    async generateJSON<T>({ messages, systemInstruction, schema, temperature = 0.2 }: {
      messages: LlmMessage[]; systemInstruction: string; schema: JsonSchema; temperature?: number;
    }): Promise<T> {
      const response = await ai.models.generateContent({
        model,
        contents: toGeminiContents(messages),
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: toGeminiSchema(schema),
          temperature,
        },
      });
      const text = response.text;
      if (!text) throw new Error('Empty response from Gemini');
      return JSON.parse(text.trim()) as T;
    },
  };
}
