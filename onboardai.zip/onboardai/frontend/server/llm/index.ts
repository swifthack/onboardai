import { GoogleGenAI } from '@google/genai';
import { LlmProvider } from './types';
import { createGeminiProvider } from './geminiProvider';
import { createClaudeProvider } from './claudeProvider';

export * from './types';

// Picks the Copilot's LLM provider from COPILOT_LLM_PROVIDER (default:
// anthropic, per the Copilot routes' actual requirement). Only the Copilot
// routes go through this — onboarding.ts/admin.ts still call the Gemini
// SDK directly and are unaffected by this env var.
export function createCopilotLlmProvider(ai: GoogleGenAI): LlmProvider {
  const choice = (process.env.COPILOT_LLM_PROVIDER || 'anthropic').toLowerCase();

  if (choice === 'anthropic' || choice === 'claude') {
    if (!process.env.ANTHROPIC_API_KEY) {
      console.warn('[llm] COPILOT_LLM_PROVIDER=anthropic but ANTHROPIC_API_KEY is not set — falling back to Gemini for the Copilot.');
      return createGeminiProvider(ai);
    }
    return createClaudeProvider(process.env.ANTHROPIC_API_KEY, process.env.COPILOT_LLM_MODEL || undefined);
  }

  return createGeminiProvider(ai, process.env.COPILOT_LLM_MODEL || undefined);
}
