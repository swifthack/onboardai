// Thin, provider-agnostic interface for everything the Copilot routes
// actually need — a plain chat reply, and a JSON reply matching a schema.
// Not a full passthrough of either SDK's surface (that would just move the
// coupling around); scoped to these two call shapes on purpose. Same
// stub-adapter spirit as ../../../shared/ARCHITECTURE.md §5: routes call
// this interface, never a specific provider's SDK directly.

export interface LlmMessage {
  role: 'user' | 'assistant';
  content: string;
}

// Plain JSON Schema (the standard shape) — not Gemini's `Type.OBJECT` enum
// form. Each provider implementation translates this into whatever wire
// format its own SDK needs (see geminiProvider.ts's toGeminiSchema).
export interface JsonSchema {
  type: 'object' | 'string' | 'array' | 'number' | 'boolean' | 'integer';
  description?: string;
  properties?: Record<string, JsonSchema>;
  items?: JsonSchema;
  required?: string[];
  enum?: string[];
}

export interface LlmProvider {
  readonly name: string;

  chat(params: {
    messages: LlmMessage[];
    systemInstruction: string;
    temperature?: number;
  }): Promise<string>;

  generateJSON<T = any>(params: {
    messages: LlmMessage[];
    systemInstruction: string;
    schema: JsonSchema;
    temperature?: number;
  }): Promise<T>;
}
