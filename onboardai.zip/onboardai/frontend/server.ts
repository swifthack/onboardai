import express from 'express';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

import { createOnboardingRouter } from './server/routes/onboarding';
import { createCopilotRouter } from './server/routes/copilots';
import { createAdminRouter } from './server/routes/admin';
import { createBlockchainRouter } from './server/routes/blockchain';
import { createRegistryRouter } from './server/routes/registry';
import { createSanctionsRouter } from './server/routes/sanctions';
import { createCopilotLlmProvider } from './server/llm';

// Load environment variables
dotenv.config();

// Initialize the modern GenAI SDK
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
    timeout: 30000 // 30 seconds timeout to prevent long gateway stalls
  }
});

const app = express();
const PORT = parseInt(process.env.PORT, 10) || 3000;

app.use(express.json({ limit: '10mb' }));

// Runtime (not build-time) config for the client bundle — lets one built
// image be pointed at different backends per deployment (e.g. "design" vs
// "execution") via plain server-side env vars. Vite's VITE_* vars are
// baked into the bundle at build time and can't vary per running
// container; this route is read at page-load time instead. See
// index.html's <script src="/runtime-config.js">,
// src/services/agenticStudioApi.ts's and src/services/clientOsApi.ts's
// BASE_URL resolution.
//
// DEPLOYMENT_MODE ('design' | 'execution', unset for plain local dev) is
// the same idea applied to which persona(s) the sign-in screen offers —
// see src/config/deploymentMode.ts.
app.get('/runtime-config.js', (req, res) => {
  res.type('application/javascript');
  res.send(
    `window.__AGENTICSTUDIO_URL__ = ${JSON.stringify(process.env.AGENTICSTUDIO_URL || '')};\n` +
    `window.__CLIENTOS_URL__ = ${JSON.stringify(process.env.CLIENTOS_URL || '')};\n` +
    `window.__DEPLOYMENT_MODE__ = ${JSON.stringify(process.env.DEPLOYMENT_MODE || '')};`
  );
});

// Copilot's LLM is chosen independently of the other routes (which stay on
// Gemini directly) — see server/llm/index.ts. Default: Anthropic/Claude.
const copilotLlm = createCopilotLlmProvider(ai);
console.log(`[llm] Copilot provider: ${copilotLlm.name}`);

// Mount Modular API Routers
app.use('/api/onboarding', createOnboardingRouter(ai));
app.use('/api', createCopilotRouter(copilotLlm));
app.use('/api/admin', createAdminRouter(ai));
app.use('/api/blockchain', createBlockchainRouter());
app.use('/api/registry', createRegistryRouter());
app.use('/api/sanctions', createSanctionsRouter());

// Serve health route
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date() });
});

// Vite Middleware Configuration for Dev / Static Asset Server for Production
async function setupServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
    console.log('Dev server initialized with Vite middleware.');
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
    console.log('Production server initialized serving /dist folder.');
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Express custom server running on http://localhost:${PORT}`);
  });
}

setupServer().catch((err) => {
  console.error('Failed to initialize server:', err);
});
