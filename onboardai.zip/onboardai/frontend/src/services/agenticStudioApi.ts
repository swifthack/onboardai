/**
 * Typed client for the AgenticStudio backend (Nexum/services/agenticstudio
 * — Node/Express + Postgres, see its README for the full API surface).
 * Every function here is a thin fetch wrapper; no caching or state lives
 * here — callers own their own React state.
 */

// Resolution order: runtime config (set by server.ts's /runtime-config.js,
// read at page load — lets one built image be re-pointed per deployment,
// e.g. "design" vs "execution") > Vite build-time env var (local dev,
// `npm run dev`) > localhost default.
const BASE_URL =
  (typeof window !== 'undefined' && (window as any).__AGENTICSTUDIO_URL__) ||
  (import.meta as any).env?.VITE_AGENTICSTUDIO_URL ||
  'http://localhost:4001';

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...(init?.headers || {}) },
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.error?.message || `HTTP ${res.status} on ${path}`);
  }
  if (res.status === 204) return undefined as T;
  return res.json();
}

// ── Agents ────────────────────────────────────────────────────────────────
export interface BackendAgent {
  id: string;
  name: string;
  config: Record<string, any>;
  pipeline_count?: number;
  created_at: string;
  updated_at: string;
}

export const agentsApi = {
  list: () => request<{ agents: BackendAgent[] }>('/agents').then((r) => r.agents),
  get: (id: string) => request<BackendAgent & { pipelines: any[] }>(`/agents/${encodeURIComponent(id)}`),
  create: (body: { id?: string; name: string; config?: Record<string, any> }) =>
    request<BackendAgent>('/agents', { method: 'POST', body: JSON.stringify(body) }),
  update: (id: string, body: { name?: string; config?: Record<string, any> }) =>
    request<BackendAgent>(`/agents/${encodeURIComponent(id)}`, { method: 'PUT', body: JSON.stringify(body) }),
  remove: (id: string) => request<void>(`/agents/${encodeURIComponent(id)}`, { method: 'DELETE' }),
};

// ── Pipelines (P-01..P-27) & runs ─────────────────────────────────────────
export const pipelinesApi = {
  list: () => request<{ pipelines: any[] }>('/pipelines').then((r) => r.pipelines),
  topology: () => request<{ stages: any[] }>('/pipelines/topology').then((r) => r.stages),
  get: (id: string) => request<any>(`/pipelines/${encodeURIComponent(id)}`),
  runs: (id: string) => request<{ runs: any[] }>(`/pipelines/${encodeURIComponent(id)}/runs`).then((r) => r.runs),
  run: (id: string, body?: { input?: Record<string, any>; clientId?: string }) =>
    request<any>(`/pipelines/${encodeURIComponent(id)}/runs`, { method: 'POST', body: JSON.stringify(body || {}) }),
  getRun: (runId: string) => request<any>(`/runs/${encodeURIComponent(runId)}`),
};

// ── Guardrails ─────────────────────────────────────────────────────────────
export interface BackendGuardrailDomain {
  id: string;
  name: string;
  description: string;
  sequence: number;
  guardrail_count?: number;
}

export interface BackendGuardrail {
  id: string;
  domain_id: string;
  name: string;
  description: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  enforcement: 'block' | 'warn' | 'log';
  config: Record<string, any>;
  enabled: boolean;
  created_at: string;
  updated_at: string;
}

export const guardrailDomainsApi = {
  list: () => request<{ domains: BackendGuardrailDomain[] }>('/guardrail-domains').then((r) => r.domains),
  get: (id: string) => request<BackendGuardrailDomain & { guardrails: BackendGuardrail[] }>(`/guardrail-domains/${encodeURIComponent(id)}`),
};

export const guardrailsApi = {
  list: (params?: { domain?: string; enabled?: boolean }) => {
    const qs = new URLSearchParams();
    if (params?.domain) qs.set('domain', params.domain);
    if (params?.enabled !== undefined) qs.set('enabled', String(params.enabled));
    const suffix = qs.toString() ? `?${qs.toString()}` : '';
    return request<{ guardrails: BackendGuardrail[] }>(`/guardrails${suffix}`).then((r) => r.guardrails);
  },
  create: (body: Partial<BackendGuardrail> & { domain_id: string; name: string; description: string }) =>
    request<BackendGuardrail>('/guardrails', { method: 'POST', body: JSON.stringify(body) }),
  update: (id: string, body: Partial<BackendGuardrail>) =>
    request<BackendGuardrail>(`/guardrails/${encodeURIComponent(id)}`, { method: 'PUT', body: JSON.stringify(body) }),
  remove: (id: string) => request<void>(`/guardrails/${encodeURIComponent(id)}`, { method: 'DELETE' }),
};

// ── API Catalog ──────────────────────────────────────────────────────────
export interface BackendApiCatalogEntry {
  id: string;
  name: string;
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  description: string;
  domain: string;
  pipeline_id: string | null;
  process_label: string | null;
  rate_limit: string | null;
  version: string;
  auth_type: string;
  sample_request: string | null;
  sample_response: any;
  openapi_spec: any;
  status: 'active' | 'beta' | 'deprecated';
  created_at: string;
  updated_at: string;
}

// Wire-format body for create/update — the route reads camelCase fields
// off req.body (pipelineId, processLabel, ...), distinct from the
// snake_case shape GET responses come back as (BackendApiCatalogEntry).
export interface ApiCatalogInput {
  name: string;
  method: string;
  path: string;
  description: string;
  domain: string;
  pipelineId?: string;
  processLabel?: string;
  rateLimit?: string;
  version?: string;
  authType?: string;
  sampleRequest?: string;
  sampleResponse?: any;
  openapiSpec?: any;
  status?: string;
}

export const apiCatalogApi = {
  list: (params?: { domain?: string; pipelineId?: string; status?: string; method?: string }) => {
    const qs = new URLSearchParams();
    if (params?.domain) qs.set('domain', params.domain);
    if (params?.pipelineId) qs.set('pipelineId', params.pipelineId);
    if (params?.status) qs.set('status', params.status);
    if (params?.method) qs.set('method', params.method);
    const suffix = qs.toString() ? `?${qs.toString()}` : '';
    return request<{ apis: BackendApiCatalogEntry[] }>(`/api-catalog${suffix}`).then((r) => r.apis);
  },
  get: (id: string) => request<BackendApiCatalogEntry>(`/api-catalog/${encodeURIComponent(id)}`),
  create: (body: ApiCatalogInput) =>
    request<BackendApiCatalogEntry>('/api-catalog', { method: 'POST', body: JSON.stringify(body) }),
  update: (id: string, body: Partial<ApiCatalogInput>) =>
    request<BackendApiCatalogEntry>(`/api-catalog/${encodeURIComponent(id)}`, { method: 'PUT', body: JSON.stringify(body) }),
  remove: (id: string) => request<void>(`/api-catalog/${encodeURIComponent(id)}`, { method: 'DELETE' }),
};

// ── MCP Gateways ───────────────────────────────────────────────────────────
export interface BackendMcpBinding {
  id: string;
  gateway_id: string;
  api_id: string | null;
  tool_name: string | null;
  tool_description: string | null;
  tool_config: Record<string, any>;
  exposed_name: string;
  enabled: boolean;
  api_name?: string | null;
  api_method?: string | null;
  api_path?: string | null;
}

export interface BackendMcpGateway {
  id: string;
  name: string;
  description: string;
  status: 'active' | 'inactive';
  config: Record<string, any>;
  binding_count?: number;
  bindings?: BackendMcpBinding[];
  created_at: string;
  updated_at: string;
}

export const mcpGatewaysApi = {
  list: () => request<{ gateways: BackendMcpGateway[] }>('/mcp-gateways').then((r) => r.gateways),
  get: (id: string) => request<BackendMcpGateway>(`/mcp-gateways/${encodeURIComponent(id)}`),
  create: (body: { name: string; description: string; status?: string; config?: Record<string, any> }) =>
    request<BackendMcpGateway>('/mcp-gateways', { method: 'POST', body: JSON.stringify(body) }),
  update: (id: string, body: Partial<{ name: string; description: string; status: string; config: Record<string, any> }>) =>
    request<BackendMcpGateway>(`/mcp-gateways/${encodeURIComponent(id)}`, { method: 'PUT', body: JSON.stringify(body) }),
  remove: (id: string) => request<void>(`/mcp-gateways/${encodeURIComponent(id)}`, { method: 'DELETE' }),
  addBinding: (gatewayId: string, body: { exposedName: string; apiId?: string; toolName?: string; toolDescription?: string; toolConfig?: Record<string, any>; enabled?: boolean }) =>
    request<BackendMcpBinding>(`/mcp-gateways/${encodeURIComponent(gatewayId)}/bindings`, { method: 'POST', body: JSON.stringify(body) }),
  updateBinding: (gatewayId: string, bindingId: string, body: Partial<{ exposedName: string; toolConfig: Record<string, any>; enabled: boolean }>) =>
    request<BackendMcpBinding>(`/mcp-gateways/${encodeURIComponent(gatewayId)}/bindings/${encodeURIComponent(bindingId)}`, { method: 'PUT', body: JSON.stringify(body) }),
  removeBinding: (gatewayId: string, bindingId: string) =>
    request<void>(`/mcp-gateways/${encodeURIComponent(gatewayId)}/bindings/${encodeURIComponent(bindingId)}`, { method: 'DELETE' }),
};

// ── Custom Orchestrations (Agent Studio canvas) ───────────────────────────
export interface BackendCustomOrchestration {
  id: string;
  name: string;
  description: string | null;
  type: string | null;
  strategy: string | null;
  agent_ids: string[];
  connections: { from: string; to: string }[];
  stages: any[];
  layout: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export const customOrchestrationsApi = {
  list: () => request<{ orchestrations: BackendCustomOrchestration[] }>('/custom-orchestrations').then((r) => r.orchestrations),
  get: (id: string) => request<BackendCustomOrchestration>(`/custom-orchestrations/${encodeURIComponent(id)}`),
  create: (body: { id: string; name: string; description?: string; type?: string; strategy?: string; agentIds?: string[]; connections?: any[]; stages?: any[]; layout?: Record<string, any> }) =>
    request<BackendCustomOrchestration>('/custom-orchestrations', { method: 'POST', body: JSON.stringify(body) }),
  update: (id: string, body: Partial<{ name: string; description: string; type: string; strategy: string; agentIds: string[]; connections: any[]; stages: any[]; layout: Record<string, any> }>) =>
    request<BackendCustomOrchestration>(`/custom-orchestrations/${encodeURIComponent(id)}`, { method: 'PUT', body: JSON.stringify(body) }),
  remove: (id: string) => request<void>(`/custom-orchestrations/${encodeURIComponent(id)}`, { method: 'DELETE' }),
};

// ── Client Journeys ────────────────────────────────────────────────────────
export interface BackendCustomJourney {
  id: string;
  name: string;
  description: string | null;
  expected_sla: string | null;
  primary_anchor_id: string | null;
  status: 'Active' | 'Draft' | 'Deprecated';
  linked_pipeline_id: string | null;
  intake_documents: string[];
  risk_escalation_threshold: number | null;
  contracting_method: string | null;
  target_entity: string | null;
  parallel_branch_rules: string | null;
  stages: any[];
  phases: any[];
  hybrid_stages: any[];
  steps: any[];
  extra: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export interface CustomJourneyInput {
  id: string;
  name: string;
  description?: string | null;
  expectedSla?: string | null;
  primaryAnchorId?: string | null;
  status?: 'Active' | 'Draft' | 'Deprecated';
  linkedPipelineId?: string | null;
  intakeDocuments?: string[];
  riskEscalationThreshold?: number | null;
  contractingMethod?: string | null;
  targetEntity?: string | null;
  parallelBranchRules?: string | null;
  stages?: any[];
  phases?: any[];
  hybridStages?: any[];
  steps?: any[];
  extra?: Record<string, any>;
}

export const customJourneysApi = {
  list: () => request<{ journeys: BackendCustomJourney[] }>('/custom-journeys').then((r) => r.journeys),
  get: (id: string) => request<BackendCustomJourney>(`/custom-journeys/${encodeURIComponent(id)}`),
  create: (body: CustomJourneyInput) =>
    request<BackendCustomJourney>('/custom-journeys', { method: 'POST', body: JSON.stringify(body) }),
  update: (id: string, body: Partial<CustomJourneyInput>) =>
    request<BackendCustomJourney>(`/custom-journeys/${encodeURIComponent(id)}`, { method: 'PUT', body: JSON.stringify(body) }),
  remove: (id: string) => request<void>(`/custom-journeys/${encodeURIComponent(id)}`, { method: 'DELETE' }),
};

// ── System Notifications ────────────────────────────────────────────────
// Wire shape is already camelCase (routes/notifications.js maps snake_case
// Postgres columns before responding) — matches frontend/src/types.ts's
// SystemNotification field-for-field.
export interface BackendNotification {
  id: string;
  type: 'critical' | 'warning' | 'info' | 'success';
  title: string;
  msg: string;
  time: string | null;
  node: string | null;
  clientId: string | null;
  clientName: string | null;
  actionRequired: boolean;
  actioned: boolean;
  documentDetails: Record<string, any>;
}

export const notificationsApi = {
  list: () => request<{ notifications: BackendNotification[] }>('/notifications').then((r) => r.notifications),
  create: (body: Partial<BackendNotification> & { id?: string; type: string; title: string; msg: string }) =>
    request<BackendNotification>('/notifications', { method: 'POST', body: JSON.stringify(body) }),
  update: (id: string, body: Partial<BackendNotification>) =>
    request<BackendNotification>(`/notifications/${encodeURIComponent(id)}`, { method: 'PUT', body: JSON.stringify(body) }),
  remove: (id: string) => request<void>(`/notifications/${encodeURIComponent(id)}`, { method: 'DELETE' }),
};

// ── Sent Emails (RM outreach log) ─────────────────────────────────────────
export interface BackendSentEmail {
  id: string;
  clientId: string | null;
  clientName: string | null;
  email: string;
  subject: string | null;
  body: string | null;
  date: string | null;
  status: 'sent' | 'delivered' | 'opened' | 'clicked';
  sentAt: string | null;
  deliveredAt: string | null;
  openedAt: string | null;
  clickedAt: string | null;
}

export const sentEmailsApi = {
  list: () => request<{ sentEmails: BackendSentEmail[] }>('/sent-emails').then((r) => r.sentEmails),
  create: (body: Partial<BackendSentEmail> & { id?: string; email: string }) =>
    request<BackendSentEmail>('/sent-emails', { method: 'POST', body: JSON.stringify(body) }),
  update: (id: string, body: Partial<BackendSentEmail>) =>
    request<BackendSentEmail>(`/sent-emails/${encodeURIComponent(id)}`, { method: 'PUT', body: JSON.stringify(body) }),
  remove: (id: string) => request<void>(`/sent-emails/${encodeURIComponent(id)}`, { method: 'DELETE' }),
};
