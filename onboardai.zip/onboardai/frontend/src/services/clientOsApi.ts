/**
 * Typed client for the ClientOS backend (Nexum/services/clientos —
 * Node/Express + Postgres + Neo4j). Every function here is a thin fetch
 * wrapper; no caching or state lives here — callers own their own React
 * state. Mirrors agenticStudioApi.ts's shape/conventions exactly, pointed
 * at a different backend.
 */

// Same resolution order as agenticStudioApi.ts: runtime config (set by
// server.ts's /runtime-config.js, read at page load) > Vite build-time env
// var (local dev) > localhost default (ClientOS's own port, 4002 — not
// AgenticStudio's 4001).
const BASE_URL =
  (typeof window !== 'undefined' && (window as any).__CLIENTOS_URL__) ||
  (import.meta as any).env?.VITE_CLIENTOS_URL ||
  'http://localhost:4002';

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...(init?.headers || {}) },
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.error?.message || `HTTP ${res.status} on ${path}`);
  }
  if (res.status === 204) return undefined as T;
  return res.json();
}

// ── Clients ──────────────────────────────────────────────────────────────
// Wire shape is already camelCase (routes/clients.js maps snake_case
// Postgres columns to this before responding) — matches
// frontend/src/types.ts's ClientProfile field-for-field, plus
// createdAt/updatedAt.
export interface BackendClient {
  id: string;
  companyName: string;
  registrationNumber: string | null;
  jurisdiction: string | null;
  industry: string | null;
  overallStatus: 'draft' | 'in_progress' | 'approved' | 'rejected';
  journeyId: string | null;
  journeyName: string | null;
  authorizedRepresentative: Record<string, any>;
  shareholders: any[];
  financials: Record<string, any>;
  documents: any[];
  workflowNodes: any[];
  directors: any[];
  relatedParties: any[];
  alerts: any[];
  govtRegistryUpdateRequests: any[];
  internalAccountSettings: Record<string, any>;
  createdAt: string;
  updatedAt: string;
}

export interface ClientGraphNode {
  id: string;
  label: string;
  type: string;
  properties: Record<string, any>;
}

export interface ClientGraphEdge {
  id: string;
  from: string;
  to: string;
  type: string;
}

export const clientsApi = {
  list: () => request<{ clients: BackendClient[] }>('/clients').then((r) => r.clients),
  get: (id: string) => request<BackendClient>(`/clients/${encodeURIComponent(id)}`),
  create: (body: Partial<BackendClient> & { id?: string; companyName: string }) =>
    request<BackendClient>('/clients', { method: 'POST', body: JSON.stringify(body) }),
  update: (id: string, body: Partial<BackendClient>) =>
    request<BackendClient>(`/clients/${encodeURIComponent(id)}`, { method: 'PUT', body: JSON.stringify(body) }),
  remove: (id: string) => request<void>(`/clients/${encodeURIComponent(id)}`, { method: 'DELETE' }),
  // Live Neo4j read — the knowledge graph as it actually is right now, not
  // derived from the Postgres row. See DigitalTwinExplorer's "Knowledge
  // Graph (Neo4j)" panel.
  graph: (id: string) => request<{ nodes: ClientGraphNode[]; edges: ClientGraphEdge[] }>(`/clients/${encodeURIComponent(id)}/graph`),
};
