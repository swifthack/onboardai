export type NodeStatus = 'pending' | 'running' | 'completed' | 'flagged' | 'awaiting_approval';

// Human-in-the-loop clarification thread on a stage node. `awaiting_approval`
// (see NodeStatus above — previously declared but never set anywhere in the
// app) is the node status used while a clarification is open; every existing
// render path (stepper, DAG, review queues, NodeDetail's approval banner)
// already treats it as a real "blocked, needs a human" state.
export type ClarificationAction = 'raised' | 'forwarded' | 'outreach_sent' | 'customer_response' | 'resolved';

export interface ClarificationThreadEntry {
  persona: AppPersona;
  action: ClarificationAction;
  message: string;
  timestamp: string;
}

export interface NodeClarification {
  id: string;
  raisedBy: AppPersona;
  targetPersona: AppPersona; // whose turn it is right now
  status: 'open' | 'resolved';
  history: ClarificationThreadEntry[];
  createdAt: string;
  resolvedAt?: string;
}

export interface WorkflowNode {
  id: string;
  name: string;
  agentType: 'data_aggregator' | 'name_screening' | 'aml' | 'client_risk' | 'credit_risk' | 'legal_compliance';
  team: string; // e.g., 'Internal/External Module', 'Compliance Team', 'Credit Risk Team', etc.
  description: string;
  status: NodeStatus;
  dependsOn: string[];
  logs: string[];
  lastUpdated?: string;
  assignedAgentId?: string;
  attachedAgentIds?: string[];
  executionMode?: 'sequential' | 'parallel';
  pipelines?: string[];
  results?: {
    summary: string;
    metrics: Record<string, string | number | boolean>;
    findings: string[];
    aiAnalysis?: string;
  };
  clarification?: NodeClarification;
  // Design-time stage-gate config, copied from the originating JourneyStage
  // by JourneyInitiator's computeCalculatedWorkflow when a journey is
  // initiated for a client. Undefined on nodes created before this feature
  // existed (kept permissive — see NodeDetail.tsx's canDirectNode/gates).
  transitionRule?: 'auto' | 'approval_gate' | 'risk_check';
  reviewerRole?: 'rm' | 'operations_officer' | 'compliance_officer';
}

export interface UploadedDocument {
  id: string;
  name: string;
  type: string;
  size: string;
  uploadedAt: string;
  status: 'verified' | 'pending' | 'pending_review' | 'rejected';
  ocrData?: Record<string, string>;
  source?: 'customer_provided' | 'externally_sourced';
  sourceDetails?: string;
}

export interface InternalRepresentative {
  id: string;
  name: string;
  role: string;
  email: string;
  phone: string;
  isPrimary: boolean;
}

export interface InternalSignatory {
  id: string;
  name: string;
  role: string;
  signingPower: string;
  email: string;
  status: 'Active' | 'Pending Verification';
}

export interface InternalOperator {
  id: string;
  name: string;
  role: string;
  accessLevel: 'Full Admin' | 'Payment Drafter (Maker)' | 'Payment Approver (Checker)' | 'View Only';
  email: string;
}

export interface TaxSelfCertEntry {
  id: string;
  taxResidencyCountry: string;
  tinReferenceNumber: string;
  tinReasonCode?: string;
  fatcaClassification: string;
  crsStatus: string;
  isPrimary: boolean;
}

export interface GovtRegistryUpdateRequest {
  id: string;
  mismatchCategory: string;
  commentary: string;
  filingReferenceNo?: string;
  submittedAt: string;
  status: 'pending_review' | 'acknowledged' | 'updated';
}

export interface ClientProfile {
  id: string;
  companyName: string;
  registrationNumber: string;
  jurisdiction: string;
  industry: string;
  authorizedRepresentative: {
    name: string;
    role: string;
    email: string;
    phone?: string;
    biometricVerified: boolean;
    biometricMatchScore?: number;
    biometricSelfieUrl?: string;
  };
  shareholders: { name: string; equity: number; pepStatus: boolean }[];
  financials: {
    revenue: string;
    assets: string;
    debtRatio: string;
    rating: string;
  };
  documents: UploadedDocument[];
  workflowNodes: WorkflowNode[];
  overallStatus: 'draft' | 'in_progress' | 'approved' | 'rejected';
  journeyId?: string;
  journeyName?: string;
  directors?: { name: string; role: string; appointmentDate: string; nationality: string }[];
  relatedParties?: { name: string; relationType: string; status: string; riskLevel: 'Low' | 'Medium' | 'High' }[];
  alerts?: { id: string; type: string; title: string; severity: string; description: string; date: string; status: 'active' | 'resolved' }[];
  govtRegistryUpdateRequests?: GovtRegistryUpdateRequest[];
  internalAccountSettings?: {
    representatives?: InternalRepresentative[];
    signatories?: InternalSignatory[];
    operators?: InternalOperator[];
    taxCertifications?: TaxSelfCertEntry[];
    phoneContact?: string;
    secondaryEmail?: string;
    primaryCurrency?: string;
    accountType?: string;
    estMonthlyVolume?: string;
    statementDelivery?: string;
    operatingMandate?: string;
    fatcaClassification?: string;
    taxResidencyCountry?: string;
    tinReferenceNumber?: string;
    lastUpdatedByCustomer?: string;
  };
}

export type AppPersona = 'platform_admin' | 'rm' | 'operations_officer' | 'compliance_officer' | 'customer';

export interface SystemNotification {
  id: string;
  type: 'critical' | 'warning' | 'info' | 'success';
  title: string;
  msg: string;
  time: string;
  node: string;
  clientId: string;
  clientName: string;
  actionRequired?: boolean;
  actioned?: boolean;
  documentDetails?: {
    docId: string;
    docName: string;
    docType: string;
    ocrData: Record<string, string>;
  };
}

export interface PersonaConfig {
  id: AppPersona;
  name: string;
  role: string;
  badgeColor: string;
  description: string;
}

export * from './agents/types';

