import React from 'react';
import { 
  Bot, 
  Sliders, 
  Server, 
  ShoppingBag, 
  ShieldCheck, 
  GitBranch, 
  Layers, 
  LayoutDashboard, 
  Compass, 
  Users, 
  Activity, 
  Bell, 
  ListTodo, 
  AlertTriangle,
  FileText,
  ClipboardList,
  Database,
  Network
} from 'lucide-react';
import { AppPersona } from '../types';

export const PERSONA_TABS: Record<AppPersona, { id: string; label: string; icon: React.ComponentType<any> }[]> = {
  platform_admin: [
    { id: 'agent_registry', label: 'Agent Registry', icon: Bot },
    { id: 'agentic_process_flows', label: 'Agentic Process Flows', icon: Network },
    { id: 'guardrails', label: 'Guardrails', icon: ShieldCheck },
    { id: 'mcp_gateway', label: 'MCP Gateway', icon: Server },
    { id: 'api_catalog', label: 'API Catalog', icon: Database },
    { id: 'agent_generator', label: 'Agent Generator (A2A/MCP)', icon: Sliders },
    { id: 'journeys', label: 'Client Journeys', icon: GitBranch },
    { id: 'governance', label: 'Governance & Audit', icon: Layers }
  ],
  rm: [
    { id: 'my_pipeline', label: 'My Pipeline', icon: LayoutDashboard },
    { id: 'journey_workspace', label: 'Journey Workspace', icon: Compass },
    { id: 'customer_360', label: 'Customer 360', icon: Users },
    { id: 'digital_twin', label: 'Digital Twin Explorer', icon: Activity }
  ],
  compliance_officer: [
    { id: 'review_queue', label: 'Review Queue', icon: ListTodo },
    { id: 'journey_workspace', label: 'Compliance Workspace', icon: Compass },
    { id: 'digital_twin', label: 'Digital Twin Explorer', icon: Activity },
    { id: 'screening_results', label: 'Screening Results', icon: ShieldCheck },
    { id: 'escalations', label: 'Escalations', icon: AlertTriangle }
  ],
  operations_officer: [
    { id: 'ops_queue', label: 'Ops Review Queue', icon: ClipboardList },
    { id: 'journey_workspace', label: 'Operations Workspace', icon: Compass },
    { id: 'doc_verification', label: 'Document Review Hub', icon: FileText },
    { id: 'digital_twin', label: 'Digital Twin Explorer', icon: Activity }
  ],
  customer: [
    { id: 'self_service_dashboard', label: 'My Dashboard', icon: LayoutDashboard }
  ]
};

export const TAB_ICON_COLORS: Record<string, string> = {
  agent_registry: 'bg-[#0474C4]',
  agent_generator: 'bg-[#00A3E0]',
  agent_studio: 'bg-[#5379AE]',
  mcp_servers: 'bg-[#2C444C]',
  marketplace: 'bg-[#06457F]',
  governance: 'bg-[#262B40]',
  journeys: 'bg-[#0474C4]',
  policy_engine: 'bg-[#5379AE]',
  agent_blocks: 'bg-[#2C444C]',
  
  // RM tabs
  my_pipeline: 'bg-[#0474C4]',
  journey_workspace: 'bg-[#06457F]',
  customer_360: 'bg-[#5379AE]',
  digital_twin: 'bg-[#2C444C]',
  notifications: 'bg-[#0474C4]',
  
  // Compliance tabs
  review_queue: 'bg-[#06457F]',
  screening_results: 'bg-[#0474C4]',
  escalations: 'bg-[#2C444C]',

  // Operations tabs
  ops_queue: 'bg-[#06457F]',
  doc_verification: 'bg-[#0474C4]',

  // Customer tabs
  self_service_dashboard: 'bg-[#0474C4]',
};
