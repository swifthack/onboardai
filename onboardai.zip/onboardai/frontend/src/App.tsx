import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  ClientProfile,
  WorkflowNode,
  AppPersona,
  NodeStatus,
  NodeClarification,
  OrchestrationAgent,
  AgentOrchestration,
  SystemNotification,
  UploadedDocument
} from './types';
import { 
  MOCK_CLIENTS, 
  PERSONAS, 
  createInitialWorkflowNodes,
  INITIAL_AGENTS,
  INITIAL_ORCHESTRATIONS
} from './mockData';
import { PERSONA_TABS } from './constants/personaTabs';
import {
  Sidebar,
  HeaderNavbar,
  JourneyWorkspace,
  PersonaSelector,
  AdminDashboard,
  AgentOrchestrator,
  AgentManager,
  McpServersView, 
  MarketplaceView, 
  GovernanceView, 
  NotificationsView, 
  ReviewQueueView, 
  OperationsQueueView,
  DocVerificationHubView,
  ScreeningResultsView, 
  EscalationsView, 
  JourneysView, 
  PolicyEngineView, 
  Customer360View,
  DigitalTwinExplorer,
  CopilotChatPanel,
  CustomerDashboard,
  CustomerLoginGate,
  ClientCreator,
  JourneyInitiator,
  AgentGeneratorView,
  GuardrailsView,
  McpGatewayView,
  ApiCatalogView,
  Journey,
  DEFAULT_JOURNEYS,
  mergeJourneysWithBackend,
  journeyToBackendPayload
} from './components';
import { OutreachDraftModal } from './components/common/OutreachDraftModal';
import { GateHandoffAlertModal } from './components/common/GateHandoffAlertModal';
import { agentsApi, customOrchestrationsApi, customJourneysApi, notificationsApi, sentEmailsApi, BackendAgent, BackendCustomOrchestration, BackendNotification, BackendSentEmail } from './services/agenticStudioApi';
import { clientsApi, BackendClient } from './services/clientOsApi';
import { useBackendSync } from './hooks/useBackendSync';

import {
  Mail,
  Bot
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// ── AgenticStudio backend <-> frontend shape bridging ──────────────────────
// The backend's `agents`/`custom_orchestrations` tables only own identity
// (id/name) plus an opaque `config`/layout JSONB bag — everything else in
// OrchestrationAgent/AgentOrchestration (description, category, MCP
// wiring, canvas positions, ...) round-trips through that bag untouched.
// See Nexum/services/agenticstudio/db/schema.sql for the rationale.

function agentFromBackend(row: BackendAgent, fallback?: OrchestrationAgent): OrchestrationAgent {
  const base: OrchestrationAgent = fallback || {
    id: row.id,
    name: row.name,
    description: '',
    category: 'Operations',
    isEnabled: true,
    agentClass: 'normal',
    usesGoogleProtocol: true,
  };
  return { ...base, ...(row.config || {}), id: row.id, name: row.name };
}

function agentToBackendConfig(agent: OrchestrationAgent): Record<string, any> {
  const { id, name, ...config } = agent;
  return config;
}

function mergeAgentsWithBackend(backendRows: BackendAgent[], initial: OrchestrationAgent[]): OrchestrationAgent[] {
  const initialById = new Map(initial.map((a) => [a.id, a]));
  const merged = backendRows.map((row) => agentFromBackend(row, initialById.get(row.id)));
  const backendIds = new Set(backendRows.map((r) => r.id));
  const missing = initial.filter((a) => !backendIds.has(a.id));
  return [...merged, ...missing];
}

function orchestrationFromBackend(row: BackendCustomOrchestration): AgentOrchestration {
  return {
    id: row.id,
    name: row.name,
    description: row.description || '',
    type: (row.type as any) || 'custom',
    strategy: (row.strategy as any) || 'sequential',
    agentIds: row.agent_ids || [],
    connections: row.connections || [],
    stages: (row.stages as any) || [],
    hybridStages: (row.stages as any) || [],
  };
}

function orchestrationToBackendPayload(o: AgentOrchestration) {
  return {
    id: o.id,
    name: o.name,
    description: o.description,
    type: o.type,
    strategy: o.strategy,
    agentIds: o.agentIds || [],
    connections: o.connections || [],
    stages: (o.stages || o.hybridStages || []) as any[],
  };
}

function mergeOrchestrationsWithBackend(backendRows: BackendCustomOrchestration[], initial: AgentOrchestration[]): AgentOrchestration[] {
  const merged = backendRows.map(orchestrationFromBackend);
  const backendIds = new Set(backendRows.map((r) => r.id));
  const missing = initial.filter((o) => !backendIds.has(o.id));
  return [...merged, ...missing];
}

// ── ClientOS backend <-> frontend shape bridging ───────────────────────────
// ClientOS's `clients` table maps to ClientProfile close to field-for-field
// (see Nexum/services/clientos/db/schema.sql) — unlike agents/journeys
// there's no opaque config bag here, just camelCase <-> snake_case at the
// route layer (already undone server-side, so BackendClient is already
// camelCase). `fallback` only covers a client the backend returned with an
// empty JSONB default for a field mock data had already populated (first
// merge only; every real write round-trips the full object).
function clientFromBackend(row: BackendClient, fallback?: ClientProfile): ClientProfile {
  return {
    id: row.id,
    companyName: row.companyName,
    registrationNumber: row.registrationNumber || fallback?.registrationNumber || '',
    jurisdiction: row.jurisdiction || fallback?.jurisdiction || '',
    industry: row.industry || fallback?.industry || '',
    authorizedRepresentative: ((row.authorizedRepresentative && Object.keys(row.authorizedRepresentative).length
      ? row.authorizedRepresentative
      : fallback?.authorizedRepresentative) || { name: '', role: '', email: '', biometricVerified: false }) as ClientProfile['authorizedRepresentative'],
    shareholders: row.shareholders?.length ? row.shareholders : (fallback?.shareholders || []),
    financials: ((row.financials && Object.keys(row.financials).length ? row.financials : fallback?.financials)
      || { revenue: '', assets: '', debtRatio: '', rating: '' }) as ClientProfile['financials'],
    documents: row.documents?.length ? row.documents : (fallback?.documents || []),
    workflowNodes: row.workflowNodes?.length ? row.workflowNodes : (fallback?.workflowNodes || createInitialWorkflowNodes()),
    overallStatus: row.overallStatus,
    journeyId: row.journeyId || fallback?.journeyId,
    journeyName: row.journeyName || fallback?.journeyName,
    directors: row.directors?.length ? row.directors : fallback?.directors,
    relatedParties: row.relatedParties?.length ? row.relatedParties : fallback?.relatedParties,
    alerts: row.alerts?.length ? row.alerts : fallback?.alerts,
    govtRegistryUpdateRequests: row.govtRegistryUpdateRequests?.length ? row.govtRegistryUpdateRequests : fallback?.govtRegistryUpdateRequests,
    internalAccountSettings: (row.internalAccountSettings && Object.keys(row.internalAccountSettings).length)
      ? row.internalAccountSettings
      : fallback?.internalAccountSettings,
  };
}

function clientToBackendPayload(c: ClientProfile) {
  return {
    id: c.id,
    companyName: c.companyName,
    registrationNumber: c.registrationNumber,
    jurisdiction: c.jurisdiction,
    industry: c.industry,
    overallStatus: c.overallStatus,
    journeyId: c.journeyId || null,
    journeyName: c.journeyName || null,
    authorizedRepresentative: c.authorizedRepresentative,
    shareholders: c.shareholders,
    financials: c.financials,
    documents: c.documents,
    workflowNodes: c.workflowNodes,
    directors: c.directors || [],
    relatedParties: c.relatedParties || [],
    alerts: c.alerts || [],
    govtRegistryUpdateRequests: c.govtRegistryUpdateRequests || [],
    internalAccountSettings: c.internalAccountSettings || {},
  };
}

function mergeClientsWithBackend(backendRows: BackendClient[], initial: ClientProfile[]): ClientProfile[] {
  const initialById = new Map(initial.map((c) => [c.id, c]));
  const merged = backendRows.map((row) => clientFromBackend(row, initialById.get(row.id)));
  const backendIds = new Set(backendRows.map((r) => r.id));
  const missing = initial.filter((c) => !backendIds.has(c.id));
  return [...merged, ...missing];
}

// ── Notifications & Sent Emails backend bridging ───────────────────────────
// Same execution-only category as `clients` (see
// Nexum/services/agenticstudio/db/schema.sql) — notification banners and
// the RM outreach email log, backed by their own tables on the same
// database, wired the same way.
export interface SentEmailRecord {
  id: string;
  clientName: string;
  email: string;
  subject: string;
  body: string;
  date: string;
  clientId: string;
  status: 'sent' | 'delivered' | 'opened' | 'clicked';
  sentAt?: string;
  deliveredAt?: string;
  openedAt?: string;
  clickedAt?: string;
}

function notificationFromBackend(row: BackendNotification): SystemNotification {
  return {
    id: row.id,
    type: row.type,
    title: row.title,
    msg: row.msg,
    time: row.time || '',
    node: row.node || '',
    clientId: row.clientId || '',
    clientName: row.clientName || '',
    actionRequired: row.actionRequired,
    actioned: row.actioned,
    documentDetails: row.documentDetails && Object.keys(row.documentDetails).length ? (row.documentDetails as any) : undefined,
  };
}

function notificationToBackendPayload(n: SystemNotification) {
  return {
    id: n.id,
    type: n.type,
    title: n.title,
    msg: n.msg,
    time: n.time,
    node: n.node,
    clientId: n.clientId,
    clientName: n.clientName,
    actionRequired: !!n.actionRequired,
    actioned: !!n.actioned,
    documentDetails: n.documentDetails || {},
  };
}

function mergeNotificationsWithBackend(backendRows: BackendNotification[], initial: SystemNotification[]): SystemNotification[] {
  const merged = backendRows.map(notificationFromBackend);
  const backendIds = new Set(backendRows.map((r) => r.id));
  const missing = initial.filter((n) => !backendIds.has(n.id));
  return [...merged, ...missing];
}

function sentEmailFromBackend(row: BackendSentEmail): SentEmailRecord {
  return {
    id: row.id,
    clientName: row.clientName || '',
    email: row.email,
    subject: row.subject || '',
    body: row.body || '',
    date: row.date || '',
    clientId: row.clientId || '',
    status: row.status,
    sentAt: row.sentAt || undefined,
    deliveredAt: row.deliveredAt || undefined,
    openedAt: row.openedAt || undefined,
    clickedAt: row.clickedAt || undefined,
  };
}

function sentEmailToBackendPayload(e: SentEmailRecord) {
  return {
    id: e.id,
    clientId: e.clientId,
    clientName: e.clientName,
    email: e.email,
    subject: e.subject,
    body: e.body,
    date: e.date,
    status: e.status,
    sentAt: e.sentAt,
    deliveredAt: e.deliveredAt,
    openedAt: e.openedAt,
    clickedAt: e.clickedAt,
  };
}

function mergeSentEmailsWithBackend(backendRows: BackendSentEmail[], initial: SentEmailRecord[]): SentEmailRecord[] {
  const merged = backendRows.map(sentEmailFromBackend);
  const backendIds = new Set(backendRows.map((r) => r.id));
  const missing = initial.filter((e) => !backendIds.has(e.id));
  return [...merged, ...missing];
}

export default function App() {
  // No frontend caching: these seed only the brief pre-fetch placeholder
  // shown before the backend responds. The navigation-driven fetch effects
  // below (gated on activeTab/activePersona) are the sole source of real
  // data from here on, refetched fresh on every relevant navigation rather
  // than once per session — see the effects further down this file.
  const [clients, setClients] = useState<ClientProfile[]>(MOCK_CLIENTS);
  const [agents, setAgents] = useState<OrchestrationAgent[]>(INITIAL_AGENTS);
  const [orchestrations, setOrchestrations] = useState<AgentOrchestration[]>(INITIAL_ORCHESTRATIONS);

  // ── AgenticStudio backend sync ──────────────────────────────────────────
  // Reconciles against the real Postgres-backed registry on every
  // navigation to a Studio tab that needs it (see the effect below, gated
  // on activeTab — refetched fresh each visit, not cached), then a
  // debounced watcher pushes local edits back.
  const [agentsBackendReady, setAgentsBackendReady] = useState(false);
  const [orchestrationsBackendReady, setOrchestrationsBackendReady] = useState(false);
  const agentsSync = useBackendSync<OrchestrationAgent>(
    agents,
    agentsBackendReady,
    {
      getId: (a) => a.id,
      snapshot: (a) => JSON.stringify(agentToBackendConfig(a)),
      create: (a) => agentsApi.create({ id: a.id, name: a.name, config: agentToBackendConfig(a) }),
      update: (id, a) => agentsApi.update(id, { name: a.name, config: agentToBackendConfig(a) }),
      remove: (id) => agentsApi.remove(id),
    },
  );
  const orchestrationsSync = useBackendSync<AgentOrchestration>(
    orchestrations,
    orchestrationsBackendReady,
    {
      getId: (o) => o.id,
      snapshot: (o) => JSON.stringify(orchestrationToBackendPayload(o)),
      create: (o) => customOrchestrationsApi.create(orchestrationToBackendPayload(o)),
      update: (id, o) => customOrchestrationsApi.update(id, orchestrationToBackendPayload(o)),
      remove: (id) => customOrchestrationsApi.remove(id),
    },
  );

  // `journeys` (custom_journeys) lives here rather than inside JourneysView
  // so AgentOrchestrator's delete-guard (checkPipelineJourneyTag) can read
  // the live list too — the two are mutually-exclusive sibling tabs with no
  // other path to share it. Fetched on the same navigation-driven effect as
  // agents/orchestrations below (TABS_NEEDING_ORCHESTRATIONS already covers
  // every tab that needs it).
  const [journeys, setJourneys] = useState<Journey[]>(DEFAULT_JOURNEYS);
  const [journeysBackendReady, setJourneysBackendReady] = useState(false);
  const journeysSync = useBackendSync<Journey>(
    journeys,
    journeysBackendReady,
    {
      getId: (j) => j.id,
      snapshot: (j) => JSON.stringify(journeyToBackendPayload(j)),
      create: (j) => customJourneysApi.create(journeyToBackendPayload(j)),
      update: (id, j) => customJourneysApi.update(id, journeyToBackendPayload(j)),
      remove: (id) => customJourneysApi.remove(id),
    },
  );

  // ── ClientOS backend sync ────────────────────────────────────────────────
  // Same shape as the AgenticStudio sync above, pointed at ClientOS instead
  // — see the lazy-fetch effect below (gated on persona, not tab: RM/
  // Compliance/Ops's very first screen already needs `clients`).
  const [clientsBackendReady, setClientsBackendReady] = useState(false);
  const clientsSync = useBackendSync<ClientProfile>(
    clients,
    clientsBackendReady,
    {
      getId: (c) => c.id,
      snapshot: (c) => JSON.stringify(clientToBackendPayload(c)),
      create: (c) => clientsApi.create(clientToBackendPayload(c)),
      update: (id, c) => clientsApi.update(id, clientToBackendPayload(c)),
      remove: (id) => clientsApi.remove(id),
    },
  );

  const [selectedClientId, setSelectedClientId] = useState<string>(() => clients[0]?.id || 'client_1');
  const [selectedNodeId, setSelectedNodeId] = useState<string>('data_aggregator');
  const [activePersona, setActivePersona] = useState<AppPersona | null>(null);
  const [isCustomerVerified, setIsCustomerVerified] = useState<boolean>(false);
  const [isViewingAgentGenerator, setIsViewingAgentGenerator] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>('my_pipeline');

  // Fetch agents/orchestrations/journeys from the AgenticStudio backend on
  // every navigation to a tab that needs them — not once per session. The
  // refs below are an IN-FLIGHT guard only (reset in both .then() and
  // .catch()), never a permanent "already fetched" flag, so revisiting the
  // same tab always re-pulls fresh backend state; the `cancelled` flag
  // discards a response from an abandoned earlier fetch if the user
  // navigates again before it resolves. Ongoing local->backend sync after
  // each fetch is handled by useBackendSync (agentsSync/orchestrationsSync/
  // journeysSync).
  const agentsFetchInFlightRef = useRef(false);
  const orchestrationsFetchInFlightRef = useRef(false);
  const journeysFetchInFlightRef = useRef(false);
  const TABS_NEEDING_AGENTS = useMemo(() => new Set([
    'agent_registry', 'agentic_process_flows', 'agent_studio', 'mcp_gateway', 'mcp_servers', 'journeys',
  ]), []);
  const TABS_NEEDING_ORCHESTRATIONS = useMemo(() => new Set([
    'agentic_process_flows', 'agent_studio', 'journeys',
  ]), []);

  useEffect(() => {
    if (activePersona !== 'platform_admin') return;
    let cancelled = false;

    if (!agentsFetchInFlightRef.current && TABS_NEEDING_AGENTS.has(activeTab)) {
      agentsFetchInFlightRef.current = true;
      agentsApi.list()
        .then((rows) => {
          agentsFetchInFlightRef.current = false;
          if (cancelled) return;
          setAgents((prev) => {
            const merged = mergeAgentsWithBackend(rows, prev);
            rows.forEach((row) => {
              const found = merged.find((a) => a.id === row.id);
              if (found) agentsSync.markSynced(found);
            });
            return merged;
          });
          setAgentsBackendReady(true);
        })
        .catch((e) => {
          agentsFetchInFlightRef.current = false;
          if (cancelled) return;
          console.warn('[AgenticStudio] failed to load agents from backend, using local only:', e.message);
        });
    }

    if (!orchestrationsFetchInFlightRef.current && TABS_NEEDING_ORCHESTRATIONS.has(activeTab)) {
      orchestrationsFetchInFlightRef.current = true;
      customOrchestrationsApi.list()
        .then((rows) => {
          orchestrationsFetchInFlightRef.current = false;
          if (cancelled) return;
          setOrchestrations((prev) => {
            const merged = mergeOrchestrationsWithBackend(rows, prev);
            rows.forEach((row) => {
              const found = merged.find((o) => o.id === row.id);
              if (found) orchestrationsSync.markSynced(found);
            });
            return merged;
          });
          setOrchestrationsBackendReady(true);
        })
        .catch((e) => {
          orchestrationsFetchInFlightRef.current = false;
          if (cancelled) return;
          console.warn('[AgenticStudio] failed to load orchestrations from backend, using local only:', e.message);
        });
    }

    if (!journeysFetchInFlightRef.current && TABS_NEEDING_ORCHESTRATIONS.has(activeTab)) {
      journeysFetchInFlightRef.current = true;
      customJourneysApi.list()
        .then((rows) => {
          journeysFetchInFlightRef.current = false;
          if (cancelled) return;
          setJourneys((prev) => {
            const merged = mergeJourneysWithBackend(rows, prev);
            rows.forEach((row) => {
              const found = merged.find((j) => j.id === row.id);
              if (found) journeysSync.markSynced(found);
            });
            return merged;
          });
          setJourneysBackendReady(true);
        })
        .catch((e) => {
          journeysFetchInFlightRef.current = false;
          if (cancelled) return;
          console.warn('[AgenticStudio] failed to load journeys from backend, using local only:', e.message);
        });
    }

    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab, activePersona]);

  // Fetch `clients` from the ClientOS backend on every navigation — RM,
  // Compliance & Risk Officer, Operations Officer, or Customer persona
  // selection, AND every tab switch within that persona (not gated
  // per-tab: every tab these personas land on — My Pipeline, Review Queue,
  // Ops Review Queue, Journey Workspace, Customer 360, Digital Twin
  // Explorer, My Dashboard, ... — reads the same `clients` array, so
  // there's no tab where deferring or skipping the fetch would actually
  // help). `clientsFetchInFlightRef` is an in-flight guard only (see the
  // agents/orchestrations/journeys effect above for the same pattern) —
  // it never permanently blocks a later refetch. Customer was originally
  // left out of PERSONAS_NEEDING_CLIENTS — a real bug: without it,
  // `clientsBackendReady` never becomes true in a customer-only session,
  // so useBackendSync's debounced push silently never fires — any edit a
  // customer makes (document upload, responding to a clarification, ...)
  // would apply locally but never reach the backend. Found while testing
  // the clarification workflow's customer response step.
  const clientsFetchInFlightRef = useRef(false);
  const PERSONAS_NEEDING_CLIENTS = useMemo(() => new Set(['rm', 'compliance_officer', 'operations_officer', 'customer']), []);

  useEffect(() => {
    if (!activePersona || !PERSONAS_NEEDING_CLIENTS.has(activePersona)) return;
    if (clientsFetchInFlightRef.current) return;
    clientsFetchInFlightRef.current = true;
    let cancelled = false;

    clientsApi.list()
      .then((rows) => {
        clientsFetchInFlightRef.current = false;
        if (cancelled) return;
        setClients((prev) => {
          const merged = mergeClientsWithBackend(rows, prev);
          rows.forEach((row) => {
            const found = merged.find((c) => c.id === row.id);
            if (found) clientsSync.markSynced(found);
          });
          return merged;
        });
        setClientsBackendReady(true);
      })
      .catch((e) => {
        clientsFetchInFlightRef.current = false;
        if (cancelled) return;
        console.warn('[ClientOS] failed to load clients from backend, using local only:', e.message);
      });

    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab, activePersona]);

  const [isCreatingClient, setIsCreatingClient] = useState(false);
  const [isInitiatingJourney, setIsInitiatingJourney] = useState(false);
  const [isAutoProcessing, setIsAutoProcessing] = useState(false);
  const isAutoProcessingRef = useRef(false);

  const setAutoProcessing = (val: boolean) => {
    isAutoProcessingRef.current = val;
    setIsAutoProcessing(val);
  };

  const [activeRunningNodeId, setActiveRunningNodeId] = useState<string | undefined>(undefined);
  const clientsRef = useRef<ClientProfile[]>(clients);

  useEffect(() => {
    clientsRef.current = clients;
  }, [clients]);

  const [sentEmails, setSentEmails] = useState<SentEmailRecord[]>([]);

  const [sentEmailsBackendReady, setSentEmailsBackendReady] = useState(false);
  const sentEmailsSync = useBackendSync<SentEmailRecord>(
    sentEmails,
    sentEmailsBackendReady,
    {
      getId: (e) => e.id,
      snapshot: (e) => JSON.stringify(sentEmailToBackendPayload(e)),
      create: (e) => sentEmailsApi.create(sentEmailToBackendPayload(e)),
      update: (id, e) => sentEmailsApi.update(id, sentEmailToBackendPayload(e)),
      remove: (id) => sentEmailsApi.remove(id),
    },
  );

  const [systemNotifications, setSystemNotifications] = useState<SystemNotification[]>([
    {
      id: 'notif-1',
      type: 'critical',
      title: 'PEP Screening Alert',
      msg: 'AML PEP Alert: Shareholder detected in sanctions adverse registers.',
      time: '10 mins ago',
      node: 'aml',
      clientId: 'client_1',
      clientName: 'Nexus Tech Solutions',
      actionRequired: false,
      actioned: false
    },
    {
      id: 'notif-2',
      type: 'info',
      title: 'Biometrics Verification Passed',
      msg: 'Biometric FaceID Passed: Representative Dr. Evelyn Chen facial matches completed successfully.',
      time: '1 hour ago',
      node: 'biometric_verification',
      clientId: 'client_1',
      clientName: 'Nexus Tech Solutions',
      actionRequired: false,
      actioned: false
    }
  ]);

  const [notificationsBackendReady, setNotificationsBackendReady] = useState(false);
  const notificationsSync = useBackendSync<SystemNotification>(
    systemNotifications,
    notificationsBackendReady,
    {
      getId: (n) => n.id,
      snapshot: (n) => JSON.stringify(notificationToBackendPayload(n)),
      create: (n) => notificationsApi.create(notificationToBackendPayload(n)),
      update: (id, n) => notificationsApi.update(id, notificationToBackendPayload(n)),
      remove: (id) => notificationsApi.remove(id),
    },
  );

  // Lazy fetch — same persona gating as `clients` (PERSONAS_NEEDING_CLIENTS,
  // declared above): notifications and the RM outreach email log are the
  // same execution-only category, just their own tables.
  const notificationsFetchStartedRef = useRef(false);
  const sentEmailsFetchStartedRef = useRef(false);

  useEffect(() => {
    if (!activePersona || !PERSONAS_NEEDING_CLIENTS.has(activePersona)) return;

    if (!notificationsFetchStartedRef.current) {
      notificationsFetchStartedRef.current = true;
      notificationsApi.list()
        .then((rows) => {
          setSystemNotifications((prev) => {
            const merged = mergeNotificationsWithBackend(rows, prev);
            rows.forEach((row) => {
              const found = merged.find((n) => n.id === row.id);
              if (found) notificationsSync.markSynced(found);
            });
            return merged;
          });
          setNotificationsBackendReady(true);
        })
        .catch((e) => {
          notificationsFetchStartedRef.current = false;
          console.warn('[AgenticStudio] failed to load notifications from backend, using local only:', e.message);
        });
    }

    if (!sentEmailsFetchStartedRef.current) {
      sentEmailsFetchStartedRef.current = true;
      sentEmailsApi.list()
        .then((rows) => {
          setSentEmails((prev) => {
            const merged = mergeSentEmailsWithBackend(rows, prev);
            rows.forEach((row) => {
              const found = merged.find((e) => e.id === row.id);
              if (found) sentEmailsSync.markSynced(found);
            });
            return merged;
          });
          setSentEmailsBackendReady(true);
        })
        .catch((e) => {
          sentEmailsFetchStartedRef.current = false;
          console.warn('[AgenticStudio] failed to load sent emails from backend, using local only:', e.message);
        });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activePersona]);

  const handleAddNotification = (notif: SystemNotification) => {
    setSystemNotifications(prev => [notif, ...prev]);
  };

  const handleActionNotification = (notifId: string, action: 'approve' | 'reject') => {
    setSystemNotifications(prev => prev.map(n => {
      if (n.id === notifId) {
        return { ...n, actioned: true, actionRequired: false };
      }
      return n;
    }));

    const targetNotif = systemNotifications.find(n => n.id === notifId);
    if (!targetNotif) return;

    if (action === 'approve') {
      setClients(prevClients => prevClients.map(client => {
        if (client.id === targetNotif.clientId) {
          const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
          
          const targetNodeIdx = client.workflowNodes.findIndex(n => n.id === targetNotif.node || n.id === 'doc_verification');

          const updatedNodes = client.workflowNodes.map((node, idx) => {
            if (node.id === 'doc_verification' || node.id === targetNotif.node) {
              return {
                ...node,
                status: 'completed' as NodeStatus,
                logs: [
                  ...node.logs,
                  `[${timeStr}] 👨‍💼 RM ACTION TAKEN: Relationship Manager reviewed & approved document verification notification.`,
                  `[${timeStr}] 🟢 Node status transitioned to COMPLETED.`
                ]
              };
            }
            if (targetNodeIdx !== -1 && idx === targetNodeIdx + 1 && node.status === 'pending') {
              return {
                ...node,
                status: 'completed' as NodeStatus,
                logs: [
                  ...node.logs,
                  `[${timeStr}] ⚡ AUTONOMOUS STEP ADVANCED: Proceeding to next step (${node.name}) following RM approval.`,
                  `[${timeStr}] 🟢 Node completed successfully.`
                ]
              };
            }
            return node;
          });

          const allNodesDone = updatedNodes.every(n => n.status === 'completed');

          return {
            ...client,
            workflowNodes: updatedNodes,
            overallStatus: allNodesDone ? 'approved' : 'in_progress'
          };
        }
        return client;
      }));
    }
  };

  const [showSimulatedMailbox, setShowSimulatedMailbox] = useState(false);
  const [showRmCopilot, setShowRmCopilot] = useState(false);
  const [showPersonaDropdown, setShowPersonaDropdown] = useState(false);

  const [draftClient, setDraftClient] = useState<ClientProfile | null>(null);
  const [isDraftModalOpen, setIsDraftModalOpen] = useState(false);
  // Set only when the outreach draft modal was opened from a clarification's
  // "Initiate Client Outreach" action (handleInitiateClarificationOutreach)
  // — lets handleConfirmSendEmail know which node's clarification to advance
  // to the customer once the email is actually sent.
  const [draftClarificationNodeId, setDraftClarificationNodeId] = useState<string | null>(null);

  // Demo-facing handoff alert — see announceGateHandoff, set whenever the
  // autonomous engine pauses a node at a review gate for a different persona.
  const [gateHandoffAlert, setGateHandoffAlert] = useState<{ clientName: string; nodeName: string; reviewerLabel: string } | null>(null);

  const mainContentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (mainContentRef.current) {
      mainContentRef.current.scrollTop = 0;
    }
    if (activePersona === 'platform_admin') {
      setShowRmCopilot(false);
    }
  }, [activePersona, activeTab]);

  const activeClient = useMemo(() => {
    return clients.find(c => c.id === selectedClientId) || clients[0];
  }, [clients, selectedClientId]);

  const updateActiveClient = (updatedFields: Partial<ClientProfile>, targetClientId?: string) => {
    const targetId = targetClientId || selectedClientId;
    const next = clientsRef.current.map(c => c.id === targetId ? { ...c, ...updatedFields } : c);
    clientsRef.current = next;
    setClients(next);
  };

  const handleAddDirector = (clientId: string, name: string, role: string, nationality: string) => {
    setClients(prev => prev.map(c => {
      if (c.id === clientId) {
        const directors = c.directors || [];
        return {
          ...c,
          directors: [...directors, { name, role, nationality, appointmentDate: new Date().toISOString().split('T')[0] }]
        };
      }
      return c;
    }));
  };

  const handleAddRelatedParty = (clientId: string, name: string, relationType: string, riskLevel: 'Low' | 'Medium' | 'High') => {
    setClients(prev => prev.map(c => {
      if (c.id === clientId) {
        const relatedParties = c.relatedParties || [];
        return { ...c, relatedParties: [...relatedParties, { name, relationType, riskLevel }] };
      }
      return c;
    }));
  };

  const handleTriggerKycReview = (clientId: string, alert: { type: string; title: string; severity: string; details: string }) => {
    setClients(prev => prev.map(c => {
      if (c.id === clientId) {
        const existingAlerts = c.alerts || [];
        const newAlert = {
          id: `alert_${Date.now()}`,
          type: alert.type,
          title: alert.title,
          severity: alert.severity,
          description: alert.details,
          date: new Date().toISOString().replace('T', ' ').substring(0, 19),
          status: 'active' as const
        };

        const updatedNodes = c.workflowNodes.map(node => {
          if (alert.severity === 'critical' && (node.id === 'name_screening' || node.id === 'aml' || node.id === 'client_risk')) {
            return {
              ...node,
              status: 'flagged' as const,
              logs: [
                ...node.logs,
                `[Urgent KYC Review Triggered] Category: ${alert.type.toUpperCase()}`,
                `Alert: "${alert.title}"`,
                `Evidence details: "${alert.details}"`,
                `Action taken: Locked node and raised compliance escalations queue.`
              ],
              results: {
                summary: `Adverse media or payment anomaly flagged: ${alert.title}`,
                metrics: { 'Vibe Score': '35/100', 'Threat Category': alert.type === 'adverse_media' ? 'ADVERSE_MEDIA_LEAK' : 'TRANSACTION_ANOMALY', 'Audit Status': 'URGENT REVIEW' },
                findings: [`Triggered dynamically by operational agent: "${alert.details}"`, 'Lock status: Active restriction. Requires supervisor sign-off to override.']
              }
            };
          }
          return node;
        });

        return {
          ...c,
          alerts: [newAlert, ...existingAlerts],
          workflowNodes: updatedNodes,
          overallStatus: alert.severity === 'critical' ? 'in_progress' as const : c.overallStatus
        };
      }
      return c;
    }));
  };

  const handleUpdateNode = (nodeId: string, updatedFields: Partial<WorkflowNode>, targetClientId?: string) => {
    const cId = targetClientId || selectedClientId;
    const isManualCompletion = updatedFields.status === 'completed' && !isAutoProcessingRef.current;

    const nextClients = clientsRef.current.map(c => {
      if (c.id === cId) {
        const updatedNodes = c.workflowNodes.map(node => {
          if (node.id === nodeId) {
            return { ...node, ...updatedFields, lastUpdated: new Date().toISOString().replace('T', ' ').substring(0, 16) };
          }
          return node;
        });

        const allCompleted = updatedNodes.every(n => n.status === 'completed');
        const anyFlagged = updatedNodes.some(n => n.status === 'flagged');

        return {
          ...c,
          workflowNodes: updatedNodes,
          overallStatus: allCompleted ? 'approved' as const : anyFlagged ? 'in_progress' as const : 'in_progress' as const
        };
      }
      return c;
    });

    clientsRef.current = nextClients;
    setClients(nextClients);

    if (isManualCompletion) {
      setTimeout(() => {
        const targetClient = clientsRef.current.find(c => c.id === cId);
        if (targetClient) handleTriggerAutonomousFlow(targetClient);
      }, 100);
    }
  };

  // ── Human-in-the-loop clarification workflow ────────────────────────────
  // Compliance can raise a clarification, which Ops must review before
  // optionally forwarding to RM; Ops can also raise directly to RM. RM can
  // resolve it directly or initiate client outreach (an email); the
  // customer's response routes back to RM. Rides entirely on the existing
  // `clients.workflow_nodes` JSONB column (already backend-synced via
  // handleUpdateNode above) — no new backend routes needed. `awaiting_approval`
  // (declared in NodeStatus but never set anywhere before this) is the node
  // status while a clarification is open; every existing render path
  // (stepper, DAG, review queues, NodeDetail's approval banner) already
  // treats it as "blocked, needs a human".
  const nextClarificationTarget = (fromPersona: AppPersona, action: 'raise' | 'forward' | 'outreach'): AppPersona => {
    if (action === 'raise') return fromPersona === 'compliance_officer' ? 'operations_officer' : 'rm';
    if (action === 'forward') return 'rm';
    return 'customer'; // action === 'outreach'
  };

  const handleRaiseClarification = (clientId: string, nodeId: string, message: string) => {
    if (!activePersona) return;
    const client = clientsRef.current.find(c => c.id === clientId);
    const node = client?.workflowNodes.find(n => n.id === nodeId);
    if (!client || !node) return;

    // Prefer the stage's design-time reviewerRole (set on the JourneyStage
    // when the journey was designed, copied onto this node by
    // JourneyInitiator) over the fixed convention — e.g. this lets a stage
    // designed with reviewerRole: 'rm' route straight to RM, skipping Ops,
    // when Compliance raises a clarification on it. Falls back to the
    // fixed chain when unset (nodes predating this feature) or when the
    // configured reviewer is the same persona doing the raising.
    const target = (node.reviewerRole && node.reviewerRole !== activePersona)
      ? node.reviewerRole
      : nextClarificationTarget(activePersona, 'raise');
    const clarification: NodeClarification = {
      id: `clar_${Date.now()}`,
      raisedBy: activePersona,
      targetPersona: target,
      status: 'open',
      history: [{ persona: activePersona, action: 'raised', message, timestamp: new Date().toISOString() }],
      createdAt: new Date().toISOString(),
    };

    handleUpdateNode(nodeId, { status: 'awaiting_approval', clarification }, clientId);
    handleAddNotification({
      id: `notif_${Date.now()}`,
      type: 'warning',
      title: 'Clarification Requested',
      msg: `${activePersona} raised a clarification on "${node.name}" for ${client.companyName}: "${message}"`,
      time: 'just now',
      node: nodeId,
      clientId,
      clientName: client.companyName,
      actionRequired: true,
      actioned: false,
    });
  };

  const handleForwardClarification = (clientId: string, nodeId: string, message: string) => {
    if (activePersona !== 'operations_officer') return;
    const client = clientsRef.current.find(c => c.id === clientId);
    const node = client?.workflowNodes.find(n => n.id === nodeId);
    if (!client || !node?.clarification) return;

    const clarification: NodeClarification = {
      ...node.clarification,
      targetPersona: 'rm',
      history: [...node.clarification.history, { persona: activePersona, action: 'forwarded' as const, message, timestamp: new Date().toISOString() }],
    };

    handleUpdateNode(nodeId, { clarification }, clientId);
    handleAddNotification({
      id: `notif_${Date.now()}`,
      type: 'warning',
      title: 'Clarification Forwarded to RM',
      msg: `Operations forwarded a clarification on "${node.name}" for ${client.companyName} to RM: "${message}"`,
      time: 'just now',
      node: nodeId,
      clientId,
      clientName: client.companyName,
      actionRequired: true,
      actioned: false,
    });
  };

  const handleResolveClarification = (clientId: string, nodeId: string, message: string) => {
    if (!activePersona) return;
    const client = clientsRef.current.find(c => c.id === clientId);
    const node = client?.workflowNodes.find(n => n.id === nodeId);
    if (!client || !node?.clarification) return;

    const clarification: NodeClarification = {
      ...node.clarification,
      status: 'resolved',
      resolvedAt: new Date().toISOString(),
      history: [...node.clarification.history, { persona: activePersona, action: 'resolved' as const, message, timestamp: new Date().toISOString() }],
    };

    // Revert to 'pending' so the node re-enters the normal review/autonomous
    // flow — unlike a revert-to-'completed', handleUpdateNode doesn't
    // auto-trigger the autonomous flow for this case, so do it explicitly.
    handleUpdateNode(nodeId, { status: 'pending', clarification }, clientId);
    setTimeout(() => {
      const targetClient = clientsRef.current.find(c => c.id === clientId);
      if (targetClient) handleTriggerAutonomousFlow(targetClient);
    }, 100);
  };

  const handleInitiateClarificationOutreach = (clientId: string, nodeId: string) => {
    const client = clientsRef.current.find(c => c.id === clientId);
    if (!client) return;
    setDraftClarificationNodeId(nodeId);
    setDraftClient(client);
    setIsDraftModalOpen(true);
  };

  const handleCustomerRespondToClarification = (clientId: string, nodeId: string, message: string) => {
    const client = clientsRef.current.find(c => c.id === clientId);
    const node = client?.workflowNodes.find(n => n.id === nodeId);
    if (!client || !node?.clarification) return;

    const clarification: NodeClarification = {
      ...node.clarification,
      targetPersona: 'rm',
      history: [...node.clarification.history, { persona: 'customer' as const, action: 'customer_response' as const, message, timestamp: new Date().toISOString() }],
    };

    handleUpdateNode(nodeId, { clarification }, clientId);
    handleAddNotification({
      id: `notif_${Date.now()}`,
      type: 'info',
      title: 'Customer Responded',
      msg: `${client.companyName} responded to the clarification on "${node.name}": "${message}"`,
      time: 'just now',
      node: nodeId,
      clientId,
      clientName: client.companyName,
      actionRequired: true,
      actioned: false,
    });
  };

  const handleReorderNodes = (reorderedNodes: WorkflowNode[], targetClientId?: string) => {
    const cId = targetClientId || selectedClientId;
    const nextClients = clientsRef.current.map(c => {
      if (c.id === cId) {
        return { ...c, workflowNodes: reorderedNodes };
      }
      return c;
    });
    clientsRef.current = nextClients;
    setClients(nextClients);
  };

  const handleAddDocument = (newDoc: any, targetClientId?: string) => {
    const cId = targetClientId || selectedClientId;
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    const completeDoc: UploadedDocument = {
      id: newDoc.id || `doc_${Date.now()}`,
      name: newDoc.name || 'Document.pdf',
      type: newDoc.type || 'Institutional Corporate Record',
      size: newDoc.size || '1.2 MB',
      uploadedAt: newDoc.uploadedAt || new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: newDoc.status || 'verified',
      ocrData: newDoc.ocrData || {},
      source: newDoc.source || 'customer_provided',
      sourceDetails: newDoc.sourceDetails || 'Uploaded via Copilot Assistant'
    };

    setClients(prev => prev.map(c => {
      if (c.id === cId) {
        const updatedDocs = [...c.documents, completeDoc];
        const updatedNodes = c.workflowNodes.map(n => {
          if (n.id === 'doc_verification' || n.agentType === 'doc_verification') {
            return {
              ...n,
              status: 'completed' as const,
              logs: [...n.logs, `[${timeStr}] 📂 Upload Received via Copilot: "${completeDoc.name}" (${completeDoc.source === 'externally_sourced' ? 'Externally Sourced' : 'Customer Provided'}). Executing OCR models...`],
              results: {
                summary: `OCR extraction and authenticity checks completed for ${completeDoc.name}.`,
                metrics: { 'OCR Trust Score': '99.4%', 'Digital Signature Vetted': 'Valid' },
                findings: [`Parsed fields matched government registry records.`, `Document digital signature verified.`]
              }
            };
          }
          return n;
        });

        return { ...c, documents: updatedDocs, workflowNodes: updatedNodes, overallStatus: updatedNodes.every(n => n.status === 'completed') ? 'approved' : 'in_progress' };
      }
      return c;
    }));
  };

  const handleDeleteDocument = (docId: string) => {
    updateActiveClient({ documents: activeClient.documents.filter(d => d.id !== docId) });
  };

  const handleBiometricComplete = (score: number, photoUrl: string) => {
    updateActiveClient({
      authorizedRepresentative: {
        ...activeClient.authorizedRepresentative,
        biometricVerified: true,
        biometricMatchScore: score,
        biometricSelfieUrl: photoUrl
      }
    });

    const bioNode = activeClient.workflowNodes.find(n => n.id === 'biometric_verification');
    if (bioNode) {
      handleUpdateNode('biometric_verification', {
        status: 'completed',
        logs: [...bioNode.logs, 'Biometric camera session successfully established.', `Liveness verification: PASSED.`, `Match confidence metric scored: ${score}%`],
        results: {
          summary: 'Facial identity confirmed with absolute compliance clearance.',
          metrics: { 'Facial Landmarks Plotted': 68, 'Liveness Confidence': '100%', 'Identity Score Match': `${score}%` },
          findings: [`Verified authorized signee matches register records.`]
        }
      });
    }
  };

  const handleResetWorkflow = () => {
    setAutoProcessing(false);
    setActiveRunningNodeId(undefined);

    const resetNodes = activeClient.id.startsWith('client_journey_')
      ? activeClient.workflowNodes.map(node => ({
          ...node,
          status: 'pending' as NodeStatus,
          logs: [`[Journey Orchestrator] Workflow reset by Relationship Manager. Re-enqueued step.`],
          results: undefined
        }))
      : createInitialWorkflowNodes();

    updateActiveClient({
      workflowNodes: resetNodes,
      overallStatus: 'draft',
      authorizedRepresentative: { ...activeClient.authorizedRepresentative, biometricVerified: false, biometricMatchScore: 0, biometricSelfieUrl: '' }
    });

    setSelectedNodeId(resetNodes[0]?.id || 'data_aggregator');
    setTimeout(() => {
      const target = clientsRef.current.find(c => c.id === activeClient.id) || activeClient;
      handleTriggerAutonomousFlow(target);
    }, 250);
  };

  const handleCleanupRMWorkspace = () => {
    setAutoProcessing(false);
    setActiveRunningNodeId(undefined);

    const freshClients = MOCK_CLIENTS.map(c => ({
      ...c,
      overallStatus: 'draft' as const,
      workflowNodes: createInitialWorkflowNodes(),
      authorizedRepresentative: {
        ...c.authorizedRepresentative,
        biometricVerified: false,
        biometricMatchScore: 0,
        biometricSelfieUrl: ''
      }
    }));

    clientsRef.current = freshClients;
    setClients(freshClients);

    setSentEmails([]);

    const cleanNotif: SystemNotification = {
      id: `notif-cleanup-${Date.now()}`,
      type: 'info',
      title: 'RM Workspace Cleaned Up',
      msg: 'RM workspace reset. Ready to initiate fresh new onboarding journeys across all jurisdictions.',
      time: 'Just now',
      node: 'data_aggregator',
      clientId: freshClients[0]?.id || 'client_1',
      clientName: freshClients[0]?.companyName || 'Nexus Tech Solutions',
      actionRequired: false,
      actioned: true
    };
    setSystemNotifications([cleanNotif]);

    if (freshClients.length > 0) {
      setSelectedClientId(freshClients[0].id);
      setSelectedNodeId(freshClients[0].workflowNodes[0]?.id || 'data_aggregator');
    }

    setIsInitiatingJourney(true);
  };

  const STAGE_SEQUENCE = [
    'data_aggregator',
    'doc_verification',
    'biometric_verification',
    'name_screening',
    'aml',
    'client_risk',
    'credit_risk',
    'legal_compliance'
  ];

  // Demo-facing "handoff" alert: whenever the autonomous engine pauses a
  // node at a design-time review gate (transitionRule 'risk_check' /
  // 'approval_gate' — see handleRunAutonomousNode below), pop a modal
  // telling whoever is currently looking exactly which stage is now
  // waiting and which persona has to approve it next. Purely informational
  // — the real gate is already enforced by isApproveDisabled/canDirectNode
  // in NodeDetail.tsx; this just makes the handoff visible in a live demo.
  const announceGateHandoff = (clientName: string, node: WorkflowNode) => {
    const reviewerLabel = PERSONAS.find(p => p.id === node.reviewerRole)?.name || node.reviewerRole || 'the assigned reviewer';
    setGateHandoffAlert({ clientName, nodeName: node.name, reviewerLabel });
  };

  const handleRunAutonomousNode = async (nodeId: string, customClientId?: string): Promise<boolean> => {
    const targetId = customClientId || selectedClientId;
    const current = clientsRef.current.find(c => c.id === targetId) || clientsRef.current[0];
    if (!current) return false;

    const runningNode = current.workflowNodes.find(n => n.id === nodeId);
    const nodeLabel = runningNode?.name || 'This stage';

    handleUpdateNode(nodeId, { status: 'running', logs: [] }, targetId);
    setSelectedNodeId(nodeId);
    setActiveRunningNodeId(nodeId);

    // Visible "agent reviewing" step: reveal a few interim log lines with a
    // natural pause between each, instead of jumping straight from
    // 'running' to a finished result in well under a second — that reads
    // as fake for a live demo, especially right before a review-gate
    // handoff alert. Purely cosmetic pacing: the real analysis/result still
    // comes from the API call or local fallback right after this.
    const interimLogLines = [
      `Initializing ${nodeLabel} module...`,
      'Pulling latest client & registry context...',
      'Running compliance / risk evaluation...',
    ];
    const progressLogs: string[] = [];
    for (const line of interimLogLines) {
      await new Promise(resolve => setTimeout(resolve, 650 + Math.random() * 350));
      progressLogs.push(line);
      handleUpdateNode(nodeId, { logs: [...progressLogs] }, targetId);
    }
    await new Promise(resolve => setTimeout(resolve, 500 + Math.random() * 300));

    const updatedTarget = clientsRef.current.find(c => c.id === targetId) || current;

    // Design-time stage gate (see JourneyStage.transitionRule / WorkflowNode
    // in types.ts): a node whose stage was designed as 'risk_check' or
    // 'approval_gate' must not sail through to 'completed' on its own —
    // the autonomous engine finishes its analysis but then PAUSES the node
    // at 'awaiting_approval' instead, and handleTriggerAutonomousFlow's loop
    // stops there (mirroring the 'flagged' path below) until the assigned
    // reviewer explicitly approves via NodeDetail's sign-off controls
    // (handleManualSignoff, which already resumes the flow on approve).
    // Nodes with no transitionRule (pre-existing clients) are unaffected.
    const gatedNode = updatedTarget.workflowNodes.find(n => n.id === nodeId);
    const requiresGate = !!gatedNode?.transitionRule && gatedNode.transitionRule !== 'auto';

    try {
      const response = await fetch('/api/onboarding/analyze-node', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ client: updatedTarget, nodeId, userPrompt: 'Autonomous check trigger.' })
      });

      if (response.ok) {
        const data = await response.json();
        const rawStatus = (data.status || '').toString().toLowerCase();
        const isFlagged = rawStatus === 'flagged' || rawStatus === 'failed' || rawStatus === 'rejected';
        const normStatus: NodeStatus = isFlagged ? 'flagged' : (requiresGate ? 'awaiting_approval' : 'completed');

        handleUpdateNode(nodeId, {
          status: normStatus,
          logs: [
            'Triggering autonomous module sequence...',
            ...(data.logs || []),
            ...(requiresGate ? [`[Stage Gate] transitionRule '${gatedNode!.transitionRule}' — paused for ${gatedNode!.reviewerRole || 'reviewer'} sign-off.`] : [])
          ],
          results: {
            summary: data.summary || `Autonomous evaluation completed for node '${nodeId}'.`,
            metrics: data.metrics || { 'Trust Score': '98%', 'Status': 'VERIFIED' },
            findings: data.findings || ['Verified compliance parameters.']
          }
        }, targetId);
        setActiveRunningNodeId(undefined);
        if (requiresGate && !isFlagged) announceGateHandoff(updatedTarget.companyName, gatedNode!);
        return normStatus === 'completed';
      }
    } catch (e) {
      console.error('API call failed, running local fallback', e);
    }

    handleUpdateNode(nodeId, {
      status: requiresGate ? 'awaiting_approval' : 'completed',
      logs: [
        'Executing high-precision local verification engine...',
        'Compliance checks passed.',
        ...(requiresGate ? [`[Stage Gate] transitionRule '${gatedNode!.transitionRule}' — paused for ${gatedNode!.reviewerRole || 'reviewer'} sign-off.`] : [])
      ],
      results: {
        summary: `Autonomous evaluation finished for node '${nodeId}'.`,
        metrics: { 'Trust Score': '99%', 'Status': 'VERIFIED' },
        findings: ['No regulatory blockers or sanctions matches detected.']
      }
    }, targetId);
    setActiveRunningNodeId(undefined);
    if (requiresGate) announceGateHandoff(updatedTarget.companyName, gatedNode!);
    return !requiresGate;
  };

  const handleTriggerAutonomousFlow = async (targetClient?: ClientProfile) => {
    if (isAutoProcessingRef.current) {
      return;
    }
    setAutoProcessing(true);

    const targetId = targetClient?.id || selectedClientId;

    while (isAutoProcessingRef.current) {
      const currentClientState = clientsRef.current.find(c => c.id === targetId);
      if (!currentClientState) break;

      const nodes = currentClientState.workflowNodes;
      
      // Find pending nodes whose dependencies are satisfied (completed or approved)
      const readyNodes = nodes.filter(node => {
        if (node.status !== 'pending') return false;
        if (!node.dependsOn || node.dependsOn.length === 0) return true;
        return node.dependsOn.every(depId => {
          const depNode = nodes.find(n => n.id === depId || n.agentType === depId || n.assignedAgentId === depId);
          return depNode && (depNode.status === 'completed' || depNode.status === 'approved');
        });
      });

      if (readyNodes.length === 0) break;

      // Sort ready nodes deterministically by STAGE_SEQUENCE index to guarantee sequence execution
      readyNodes.sort((a, b) => {
        const idxA = STAGE_SEQUENCE.indexOf(a.id);
        const idxB = STAGE_SEQUENCE.indexOf(b.id);
        return (idxA !== -1 ? idxA : 99) - (idxB !== -1 ? idxB : 99);
      });

      // Execute the single next ready node sequentially to prevent race conditions & out-of-order skipping
      const nextNode = readyNodes[0];

      const success = await handleRunAutonomousNode(nextNode.id, targetId);
      await new Promise(resolve => setTimeout(resolve, 500));

      // If node is flagged/rejected or failed, pause auto-processing so user can inspect and manually approve
      if (!success) {
        break;
      }
    }

    setAutoProcessing(false);
  };

  const handleSendOutreachEmail = (customClient?: ClientProfile) => {
    const target = customClient || activeClient;
    if (!target) return;
    setDraftClient(target);
    setIsDraftModalOpen(true);
  };

  const handleConfirmSendEmail = (emailData: {
    clientId: string;
    clientName: string;
    email: string;
    subject: string;
    body: string;
  }) => {
    const emailId = 'email_' + Date.now();
    const nowTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    const newEmail = {
      id: emailId,
      clientName: emailData.clientName,
      email: emailData.email,
      subject: emailData.subject,
      body: emailData.body,
      date: new Date().toLocaleString(),
      clientId: emailData.clientId,
      status: 'sent' as const,
      sentAt: nowTime
    };

    setSentEmails(prev => [newEmail, ...prev.filter(e => e.clientId !== emailData.clientId)]);

    setTimeout(() => {
      setSentEmails(prev => prev.map(e => e.id === emailId ? { ...e, status: 'delivered', deliveredAt: new Date().toLocaleTimeString() } : e));
    }, 2000);
    setTimeout(() => {
      setSentEmails(prev => prev.map(e => e.id === emailId ? { ...e, status: 'opened', openedAt: new Date().toLocaleTimeString() } : e));
    }, 4500);
    setTimeout(() => {
      setSentEmails(prev => prev.map(e => e.id === emailId ? { ...e, status: 'clicked', clickedAt: new Date().toLocaleTimeString() } : e));
    }, 7500);

    // If this outreach was initiated from a clarification thread
    // (handleInitiateClarificationOutreach), advance that clarification to
    // the customer now that the email is actually sent.
    if (draftClarificationNodeId) {
      const nodeId = draftClarificationNodeId;
      const client = clientsRef.current.find(c => c.id === emailData.clientId);
      const node = client?.workflowNodes.find(n => n.id === nodeId);
      if (client && node?.clarification) {
        const clarification: NodeClarification = {
          ...node.clarification,
          targetPersona: 'customer',
          history: [...node.clarification.history, { persona: 'rm' as const, action: 'outreach_sent' as const, message: emailData.body, timestamp: new Date().toISOString() }],
        };
        handleUpdateNode(nodeId, { clarification }, emailData.clientId);
      }
      setDraftClarificationNodeId(null);
    }
  };

  const handleSelectPersona = (p: AppPersona) => {
    setActivePersona(p);
    setIsCustomerVerified(false);
    // Copilot starts closed for every persona (RM/Compliance/Ops included) —
    // it's still reachable via the floating "Open Copilot" button, just not
    // shown automatically on login/persona switch.
    setShowRmCopilot(false);
    const tabs = PERSONA_TABS[p];
    if (tabs && tabs.length > 0) setActiveTab(tabs[0].id);
  };

  const handleSelectClient = (clientId: string) => {
    setSelectedClientId(clientId);
    const target = clientsRef.current.find(c => c.id === clientId) || clients.find(c => c.id === clientId);
    if (target && target.workflowNodes && target.workflowNodes.length > 0) {
      const activeOrPending = target.workflowNodes.find(n => n.status === 'running' || n.status === 'pending');
      setSelectedNodeId(activeOrPending ? activeOrPending.id : target.workflowNodes[0].id);
    }
  };

  const handleClientCreated = (newClient: ClientProfile) => {
    const initializedClient: ClientProfile = {
      ...newClient,
      workflowNodes: newClient.workflowNodes && newClient.workflowNodes.length > 0 ? newClient.workflowNodes : createInitialWorkflowNodes()
    };

    const filteredRef = clientsRef.current.filter(c => c.id !== initializedClient.id);
    clientsRef.current = [initializedClient, ...filteredRef];
    setClients(prev => [initializedClient, ...prev.filter(c => c.id !== initializedClient.id)]);
    setSelectedClientId(initializedClient.id);
    setSelectedNodeId(initializedClient.workflowNodes[0]?.id || 'data_aggregator');

    handleSendOutreachEmail(initializedClient);
    setIsInitiatingJourney(false);
    setIsCreatingClient(false);
    setActivePersona('rm');
    setActiveTab('journey_workspace');

    setTimeout(() => handleTriggerAutonomousFlow(initializedClient), 200);
  };

  const currentPersonaInfo = useMemo(() => {
    return PERSONAS.find(p => p.id === activePersona) || PERSONAS[0];
  }, [activePersona]);

  const activeTabLabel = useMemo(() => {
    if (!activePersona) return 'Dashboard';
    const list = PERSONA_TABS[activePersona] || [];
    return list.find(t => t.id === activeTab)?.label || 'Dashboard';
  }, [activePersona, activeTab]);

  if (isViewingAgentGenerator) {
    return (
      <AgentGeneratorView 
        onBackToLanding={() => setIsViewingAgentGenerator(false)} 
        onSelectPersona={(persona) => {
          setIsViewingAgentGenerator(false);
          handleSelectPersona(persona);
        }}
      />
    );
  }

  if (!activePersona) {
    return (
      <PersonaSelector 
        onSelect={handleSelectPersona} 
        activePersona={activePersona} 
        onOpenAgentGenerator={() => setIsViewingAgentGenerator(true)}
      />
    );
  }

  if (activePersona === 'customer' && !isCustomerVerified) {
    return (
      <CustomerLoginGate
        clients={clients}
        initialClientId={selectedClientId}
        onLoginSuccess={(clientId) => {
          setSelectedClientId(clientId);
          setIsCustomerVerified(true);
        }}
        onBackToPersonas={() => {
          setActivePersona(null);
          setIsCustomerVerified(false);
        }}
      />
    );
  }

  return (
    <div className="min-h-screen font-sans flex flex-col md:flex-row antialiased transition-colors duration-200 bg-[#0B2545] text-[#1C1C1C]">
      
      {/* Persistent Left Sidebar Navigation - Platform Admin Only */}
      {activePersona === 'platform_admin' && (
        <Sidebar
          activePersona={activePersona}
          currentPersonaInfo={currentPersonaInfo}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          onSwitchPersona={() => {
            setActivePersona(null);
            setIsCustomerVerified(false);
          }}
        />
      )}

      {/* Main Content Area */}
      <div ref={mainContentRef} className="flex-1 flex flex-col min-w-0 overflow-y-auto bg-[#0B2545]">
        
        {/* Top Header Navbar */}
        <HeaderNavbar
          activeTabLabel={activeTabLabel}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          sentEmails={sentEmails}
          showSimulatedMailbox={showSimulatedMailbox}
          setShowSimulatedMailbox={setShowSimulatedMailbox}
          setSentEmails={setSentEmails}
          activePersona={activePersona}
          currentPersonaInfo={currentPersonaInfo}
          showRmCopilot={showRmCopilot}
          setShowRmCopilot={setShowRmCopilot}
          onLogout={() => {
            setActivePersona(null);
            setIsCustomerVerified(false);
          }}
          onSelectPersona={handleSelectPersona}
          setSelectedClientId={setSelectedClientId}
          systemNotifications={systemNotifications}
          activeClient={activeClient}
          clients={clients}
          onSelectClient={handleSelectClient}
        />

        {/* Dynamic Subview Body Panel */}
        <div className="px-6 py-6 pb-8 flex-1 z-10">
          <div className="bg-white rounded-3xl p-6 md:p-8 border border-[#A8C4EC]/60 shadow-2xl min-h-[800px]">
            
            {/* Platform Admin Subviews */}
            {activePersona === 'platform_admin' && (
              <>
                {activeTab === 'agent_registry' && <AgentManager agents={agents} setAgents={setAgents} />}
                {(activeTab === 'agentic_process_flows' || activeTab === 'agent_studio') && (
                  <AgentOrchestrator
                    agents={agents}
                    setAgents={setAgents}
                    orchestrations={orchestrations}
                    setOrchestrations={setOrchestrations}
                    journeys={journeys}
                  />
                )}
                {activeTab === 'guardrails' && <GuardrailsView />}
                {activeTab === 'mcp_gateway' && <McpGatewayView agents={agents} />}
                {activeTab === 'api_catalog' && <ApiCatalogView />}
                {activeTab === 'agent_generator' && <AgentGeneratorView />}
                {activeTab === 'mcp_servers' && <McpGatewayView agents={agents} />}
                {activeTab === 'marketplace' && <MarketplaceView />}
                {activeTab === 'governance' && <GovernanceView />}
                {activeTab === 'journeys' && (
                  <JourneysView
                    agents={agents}
                    orchestrations={orchestrations}
                    journeys={journeys}
                    setJourneys={setJourneys}
                    onJourneySaved={journeysSync.markSynced}
                    onNavigateToStudio={() => setActiveTab('agentic_process_flows')}
                  />
                )}
                {activeTab === 'policy_engine' && <GuardrailsView />}
              </>
            )}

            {/* RM, Operations & Compliance Subviews */}
            {(activePersona === 'rm' || activePersona === 'compliance_officer' || activePersona === 'operations_officer') && (
              <>
                {activePersona === 'rm' && activeTab === 'my_pipeline' && (
                  <AdminDashboard 
                    clients={clients} 
                    onNavigateToOrchestrator={() => setActiveTab('journey_workspace')} 
                    onSelectClient={(id) => {
                      handleSelectClient(id);
                      setActiveTab('journey_workspace');
                    }}
                    persona={activePersona || undefined}
                    onInitiateJourney={() => setIsInitiatingJourney(true)}
                    onCleanupWorkspace={handleCleanupRMWorkspace}
                    sentEmails={sentEmails}
                    onSendOutreachEmail={handleSendOutreachEmail}
                  />
                )}

                {activePersona === 'compliance_officer' && activeTab === 'review_queue' && (
                  <ReviewQueueView 
                    clients={clients} 
                    onSelectClient={handleSelectClient} 
                    onNavigateToWorkspace={() => setActiveTab('journey_workspace')}
                  />
                )}

                {activePersona === 'compliance_officer' && activeTab === 'screening_results' && (
                  <ScreeningResultsView activeClient={activeClient} />
                )}

                {activePersona === 'compliance_officer' && activeTab === 'escalations' && (
                  <EscalationsView />
                )}

                {activePersona === 'operations_officer' && activeTab === 'ops_queue' && (
                  // OperationsHub was a rich but entirely mocked exception-management
                  // UI — its `clients` prop was never actually read anywhere in that
                  // file, so the queue never reflected real cases. OperationsQueueView
                  // is the already-built, live-data equivalent (same pattern as
                  // Compliance's ReviewQueueView): it filters the real `clients` array
                  // by workflowNodes status (flagged/awaiting_approval/pending/running).
                  <OperationsQueueView
                    clients={clients}
                    onSelectClient={handleSelectClient}
                    onNavigateToWorkspace={() => setActiveTab('journey_workspace')}
                  />
                )}

                {activePersona === 'operations_officer' && activeTab === 'doc_verification' && (
                  <DocVerificationHubView 
                    activeClient={activeClient}
                    onApproveDocument={(docId) => {
                      handleAddDocument(
                        activeClient.documents.find(d => d.id === docId)
                          ? { ...activeClient.documents.find(d => d.id === docId)!, status: 'verified' }
                          : null,
                        activeClient.id
                      );
                    }}
                    onRejectDocument={(docId) => {
                      handleDeleteDocument(docId);
                    }}
                  />
                )}

                {activeTab === 'journey_workspace' && (
                  <JourneyWorkspace
                    activeClient={activeClient}
                    clients={clients}
                    selectedClientId={selectedClientId}
                    selectedNodeId={selectedNodeId}
                    activeRunningNodeId={activeRunningNodeId}
                    isAutoProcessing={isAutoProcessing}
                    activePersona={activePersona}
                    agents={agents}
                    handleSelectClient={handleSelectClient}
                    setIsInitiatingJourney={setIsInitiatingJourney}
                    handleSendOutreachEmail={handleSendOutreachEmail}
                    handleTriggerAutonomousFlow={handleTriggerAutonomousFlow}
                    handleResetWorkflow={handleResetWorkflow}
                    handleCleanupRMWorkspace={handleCleanupRMWorkspace}
                    setSelectedNodeId={setSelectedNodeId}
                    handleAddDocument={handleAddDocument}
                    handleDeleteDocument={handleDeleteDocument}
                    handleBiometricComplete={handleBiometricComplete}
                    handleUpdateNode={handleUpdateNode}
                    handleRunAutonomousNode={handleRunAutonomousNode}
                    handleReorderNodes={handleReorderNodes}
                    handleRaiseClarification={handleRaiseClarification}
                    handleForwardClarification={handleForwardClarification}
                    handleResolveClarification={handleResolveClarification}
                    handleInitiateClarificationOutreach={handleInitiateClarificationOutreach}
                  />
                )}

                {activeTab === 'customer_360' && (
                  <Customer360View 
                    clients={clients} 
                    activeClientId={selectedClientId}
                    onSelectClient={setSelectedClientId}
                    onAddDirector={handleAddDirector} 
                    onAddRelatedParty={handleAddRelatedParty} 
                    onTriggerKycReview={handleTriggerKycReview}
                  />
                )}
                {activeTab === 'digital_twin' && (
                  <DigitalTwinExplorer 
                    clients={clients}
                    activeClient={activeClient}
                    selectedClientId={selectedClientId}
                    onSelectClient={handleSelectClient}
                    onAddDocument={handleAddDocument}
                    onUpdateClient={updateActiveClient}
                  />
                )}
                {activeTab === 'notifications' && (
                  <NotificationsView 
                    notifications={systemNotifications}
                    onActionNotification={handleActionNotification}
                    onSelectClient={setSelectedClientId}
                  />
                )}
              </>
            )}

            {/* Customer Portal Subview */}
            {activePersona === 'customer' && (
              <CustomerDashboard
                clients={clients}
                activeClient={activeClient || null}
                onUpdateClient={(updated) => setClients(prev => prev.map(c => c.id === updated.id ? updated : c))}
                onClientCreated={handleClientCreated}
                onSelectClient={setSelectedClientId}
                isDarkMode={false}
                onAddNotification={handleAddNotification}
                onRespondToClarification={handleCustomerRespondToClarification}
              />
            )}

          </div>
        </div>

        {/* Modal Dialogs */}
        <AnimatePresence>
          {isCreatingClient && (
            <motion.div
              key="modal-create-client"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50"
            >
              <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} className="w-full max-w-xl">
                <ClientCreator onClientCreated={handleClientCreated} onClose={() => setIsCreatingClient(false)} />
              </motion.div>
            </motion.div>
          )}

          {isInitiatingJourney && (
            <motion.div
              key="modal-initiate-journey"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto"
            >
              <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} className="w-full max-w-3xl my-auto">
                <JourneyInitiator
                  onClientCreated={handleClientCreated}
                  onClose={() => setIsInitiatingJourney(false)}
                  agents={agents}
                  orchestrations={orchestrations}
                />
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Prompt-Driven Copilot Right Panel for Personas (including RM and Customer when toggled) */}
      {showRmCopilot && activePersona !== 'platform_admin' && (
        <div className="w-full md:w-[580px] lg:w-[700px] xl:w-[780px] shrink-0 h-screen sticky top-0 z-30 shadow-2xl border-l border-[#00A3E0]/20 bg-slate-950">
          <CopilotChatPanel 
            activePersona={activePersona}
            activeClient={activeClient} 
            clients={clients}
            onSelectClient={handleSelectClient}
            activeTab={activeTab}
            onNavigateTab={(tabId) => setActiveTab(tabId)}
            onAddDocument={handleAddDocument}
            onExecuteCommand={(command, args) => {
              if (command === 'trigger_check') handleTriggerAutonomousFlow();
              if (command === 'navigate' && args?.tabId) setActiveTab(args.tabId);
              if (command === 'onboard_agent') {
                setActiveTab('agent_registry');
                window.dispatchEvent(new CustomEvent('open_onboard_agent_form', { detail: args }));
              }
            }}
            onClose={() => setShowRmCopilot(false)}
          />
        </div>
      )}

      {/* Floating Copilot Button for Personas */}
      {!showRmCopilot && activePersona !== 'platform_admin' && (
        <button
          onClick={() => setShowRmCopilot(true)}
          className="fixed bottom-6 right-6 z-40 bg-[#008752] hover:bg-[#006e42] text-white px-4 py-3 rounded-full shadow-2xl flex items-center gap-2.5 font-bold text-sm cursor-pointer border border-emerald-400/40 transition-all hover:scale-105"
          title={activePersona === 'customer' ? 'Open Customer Copilot' : 'Open RM Copilot'}
        >
          <Bot className="w-5 h-5" />
          <span className="font-sans">{activePersona === 'customer' ? 'Customer Copilot' : 'Copilot'}</span>
        </button>
      )}

      {/* Outreach Email Verification Draft Modal */}
      <OutreachDraftModal
        isOpen={isDraftModalOpen}
        client={draftClient}
        activePersona={activePersona}
        onClose={() => setIsDraftModalOpen(false)}
        onSend={handleConfirmSendEmail}
      />

      <GateHandoffAlertModal
        alert={gateHandoffAlert}
        onClose={() => setGateHandoffAlert(null)}
      />
    </div>
  );
}
