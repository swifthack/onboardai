import React, { useState } from 'react';
import { 
  Building2, 
  Play, 
  Bot, 
  Mail, 
  Compass, 
  Users, 
  ShieldAlert, 
  TrendingUp, 
  Award,
  Lock,
  FileText,
  Eye,
  Plus
} from 'lucide-react';
import { ClientProfile, WorkflowNode, AppPersona, OrchestrationAgent, UploadedDocument } from '../../types';
import WorkflowGraph from './WorkflowGraph';
import NodeDetail from './NodeDetail';
import JourneyStepper from './JourneyStepper';
import { DocumentViewerModal } from '../common/DocumentViewerModal';

interface JourneyWorkspaceProps {
  activeClient: ClientProfile;
  clients: ClientProfile[];
  selectedClientId: string;
  selectedNodeId: string;
  activeRunningNodeId?: string;
  isAutoProcessing: boolean;
  activePersona: AppPersona;
  agents: OrchestrationAgent[];
  handleSelectClient: (clientId: string) => void;
  setIsInitiatingJourney: (val: boolean) => void;
  handleSendOutreachEmail: (customClient?: ClientProfile) => void;
  handleTriggerAutonomousFlow: () => void;
  handleResetWorkflow: () => void;
  handleCleanupRMWorkspace?: () => void;
  setSelectedNodeId: (id: string) => void;
  handleAddDocument: (doc: any, targetClientId?: string) => void;
  handleDeleteDocument: (docId: string) => void;
  handleBiometricComplete: (score: number, photoUrl: string) => void;
  handleUpdateNode: (nodeId: string, updatedFields: Partial<WorkflowNode>, targetClientId?: string) => void;
  handleRunAutonomousNode: (nodeId: string, customClientId?: string) => Promise<boolean>;
  handleReorderNodes?: (reorderedNodes: WorkflowNode[], targetClientId?: string) => void;
  handleRaiseClarification?: (clientId: string, nodeId: string, message: string) => void;
  handleForwardClarification?: (clientId: string, nodeId: string, message: string) => void;
  handleResolveClarification?: (clientId: string, nodeId: string, message: string) => void;
  handleInitiateClarificationOutreach?: (clientId: string, nodeId: string) => void;
}

export const JourneyWorkspace: React.FC<JourneyWorkspaceProps> = ({
  activeClient,
  clients,
  selectedClientId,
  selectedNodeId,
  activeRunningNodeId,
  isAutoProcessing,
  activePersona,
  agents,
  handleSelectClient,
  setIsInitiatingJourney,
  handleSendOutreachEmail,
  handleTriggerAutonomousFlow,
  handleResetWorkflow,
  handleCleanupRMWorkspace,
  setSelectedNodeId,
  handleAddDocument,
  handleDeleteDocument,
  handleBiometricComplete,
  handleUpdateNode,
  handleRunAutonomousNode,
  handleReorderNodes,
  handleRaiseClarification,
  handleForwardClarification,
  handleResolveClarification,
  handleInitiateClarificationOutreach
}) => {
  const activeNode = activeClient.workflowNodes.find(n => n.id === selectedNodeId) || activeClient.workflowNodes[0];
  const isComplianceOfficer = activePersona === 'compliance_officer';
  const [viewingDocument, setViewingDocument] = useState<UploadedDocument | null>(null);

  return (
    <>
      <header className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/80 rounded-xl px-6 py-4 mb-6 flex flex-col lg:flex-row items-center justify-between gap-4 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="p-2.5 bg-indigo-600 text-white rounded-lg shadow-sm shrink-0">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-slate-900 dark:text-white flex flex-wrap items-center gap-2">
              Client Onboarding Journey: <span className="text-indigo-600 dark:text-indigo-400">{activeClient.companyName}</span>
            </h1>
            <div className="flex flex-wrap items-center gap-2 mt-0.5">
              <p className="text-[10px] text-slate-400 dark:text-slate-500 uppercase tracking-wider font-mono">Ref: #{activeClient.registrationNumber}</p>
              <span className="text-slate-300 dark:text-slate-700 text-xs">•</span>
              <span className="text-[10px] bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 font-mono px-2 py-0.5 rounded font-bold">
                {activeClient.journeyName || 'Corporate Entity Onboarding Journey'} ({activeClient.workflowNodes.length} Stages)
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="hidden md:flex flex-col items-end mr-2">
            <span className="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider font-mono">Overall Completion</span>
            <div className="flex items-center gap-3 mt-1">
              <div className="w-36 h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden border border-slate-200/50 dark:border-slate-700/50">
                <div 
                  className="h-full bg-emerald-500 transition-all duration-500" 
                  style={{ width: `${(activeClient.workflowNodes.filter(n => n.status === 'completed').length / activeClient.workflowNodes.length) * 100}%` }}
                />
              </div>
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                {Math.round((activeClient.workflowNodes.filter(n => n.status === 'completed').length / activeClient.workflowNodes.length) * 100)}%
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex flex-col">
              <span className="text-[9px] font-mono font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wide">ACTIVE JOURNEY PROFILE:</span>
              <select
                value={selectedClientId}
                onChange={(e) => handleSelectClient(e.target.value)}
                className="border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-md px-3 py-1.5 text-xs font-semibold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 cursor-pointer min-w-[200px]"
              >
                {clients.map((c, idx) => (
                  <option key={`${c.id}_${idx}`} value={c.id}>
                    {c.companyName} ({c.jurisdiction})
                  </option>
                ))}
              </select>
            </div>

            {!isComplianceOfficer && (
              <div className="flex items-center gap-2 mt-3.5">
                <button
                  onClick={() => setIsInitiatingJourney(true)}
                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-md text-xs transition flex items-center gap-1 cursor-pointer shadow-sm shadow-indigo-600/10"
                >
                  <Play className="w-3.5 h-3.5" /> Initiate Fresh Journey
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Visual Onboarding Stage & Progress Stepper */}
      <JourneyStepper 
        nodes={activeClient.workflowNodes}
        selectedNodeId={selectedNodeId}
        onSelectNode={setSelectedNodeId}
        activeRunningNodeId={activeRunningNodeId}
        onReorderNodes={(newNodes) => handleReorderNodes?.(newNodes, activeClient.id)}
      />

      {isComplianceOfficer ? (
        /* COMPLIANCE & RISK OFFICER REARRANGED LAYOUT */
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
          {/* LEFT COLUMN: Corporate Registry, Financial Disclosures & Outreach Agent Banner (xl:col-span-7) */}
          <div className="xl:col-span-7 flex flex-col gap-6">
            
            {/* Corporate Registry & Financial Disclosures */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
              <h3 className="font-bold text-slate-900 dark:text-white text-xs uppercase tracking-wider font-mono border-b border-slate-100 dark:border-slate-800/60 pb-3 mb-4 flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-indigo-500" />
                Corporate Registry & Financial Disclosures
              </h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 mb-5">
                <div className="bg-slate-50 dark:bg-slate-950/40 p-3 rounded-lg border border-slate-100 dark:border-slate-800/40">
                  <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500 uppercase">REGISTRATION NUMBER</span>
                  <strong className="text-sm text-slate-800 dark:text-slate-100 font-semibold block mt-0.5">{activeClient.registrationNumber}</strong>
                </div>
                <div className="bg-slate-50 dark:bg-slate-950/40 p-3 rounded-lg border border-slate-100 dark:border-slate-800/40">
                  <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500 uppercase">JURISDICTION</span>
                  <strong className="text-sm text-slate-800 dark:text-slate-100 font-semibold block mt-0.5">{activeClient.jurisdiction}</strong>
                </div>
                <div className="bg-slate-50 dark:bg-slate-950/40 p-3 rounded-lg border border-slate-100 dark:border-slate-800/40">
                  <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500 uppercase">INDUSTRY SEGMENT</span>
                  <strong className="text-sm text-slate-800 dark:text-slate-100 font-semibold block mt-0.5 truncate">{activeClient.industry}</strong>
                </div>
                <div className="bg-slate-50 dark:bg-slate-950/40 p-3 rounded-lg border border-slate-100 dark:border-slate-800/40">
                  <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500 uppercase">OVERALL COMPLIANCE</span>
                  <span className={`inline-flex items-center gap-1 text-[11px] font-mono font-bold uppercase mt-1 px-2.5 py-0.5 rounded-full ${
                    activeClient.overallStatus === 'approved' ? 'bg-emerald-100 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-400 border border-emerald-200' :
                    activeClient.overallStatus === 'rejected' ? 'bg-rose-100 dark:bg-rose-950/20 text-rose-800 dark:text-rose-400 border border-rose-200' :
                    'bg-amber-100 dark:bg-amber-950/20 text-amber-800 dark:text-amber-400 border border-amber-200'
                  }`}>
                    {activeClient.overallStatus}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="border border-slate-100 dark:border-slate-800 rounded-xl p-4 bg-slate-50/20">
                  <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 tracking-wider font-mono uppercase mb-2.5 flex items-center justify-between">
                    <span>Shareholding Registers (UBO Vetting)</span>
                    <Users className="w-4 h-4 text-slate-400" />
                  </h4>
                  <div className="space-y-2">
                    {activeClient.shareholders.map((sh, idx) => (
                      <div key={idx} className="flex items-center justify-between p-2 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/60 rounded-lg">
                        <div className="overflow-hidden mr-2">
                          <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">{sh.name}</p>
                          <p className="text-[10px] text-slate-400 dark:text-slate-500 font-mono">Direct Shareholder Equity</p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          {sh.pepStatus && (
                            <span className="px-1.5 py-0.5 bg-rose-100 dark:bg-rose-950/30 text-rose-800 dark:text-rose-400 font-mono text-[9px] font-extrabold rounded-md uppercase animate-pulse flex items-center gap-0.5">
                              <ShieldAlert className="w-2.5 h-2.5" /> PEP ALERT
                            </span>
                          )}
                          <span className="text-xs font-bold font-mono text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">
                            {sh.equity}%
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="border border-slate-100 dark:border-slate-800 rounded-xl p-4 bg-slate-50/20">
                  <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 tracking-wider font-mono uppercase mb-2.5 flex items-center justify-between">
                    <span>Balance Sheet Ratios (Underwriting)</span>
                    <TrendingUp className="w-4 h-4 text-slate-400" />
                  </h4>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/60 rounded-lg p-2.5">
                      <span className="text-[9px] font-mono text-slate-400 dark:text-slate-500 block uppercase">ANNUAL REVENUE</span>
                      <strong className="text-xs font-semibold text-slate-800 dark:text-slate-200 block mt-0.5">{activeClient.financials.revenue}</strong>
                    </div>
                    <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/60 rounded-lg p-2.5">
                      <span className="text-[9px] font-mono text-slate-400 dark:text-slate-500 block uppercase">BALANCED ASSETS</span>
                      <strong className="text-xs font-semibold text-slate-800 dark:text-slate-200 block mt-0.5">{activeClient.financials.assets}</strong>
                    </div>
                    <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/60 rounded-lg p-2.5">
                      <span className="text-[9px] font-mono text-slate-400 dark:text-slate-500 block uppercase">DEBT LEVERAGE RATIO</span>
                      <strong className="text-xs font-semibold text-slate-800 dark:text-slate-200 block mt-0.5">{activeClient.financials.debtRatio}</strong>
                    </div>
                    <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/60 rounded-lg p-2.5">
                      <span className="text-[9px] font-mono text-slate-400 dark:text-slate-500 block uppercase">INTERNAL CREDIT RATIO</span>
                      <span className="inline-flex items-center gap-0.5 text-xs font-bold font-mono text-blue-700 bg-blue-50 dark:text-indigo-400 dark:bg-indigo-950/30 px-1.5 py-0.5 rounded">
                        <Award className="w-3 h-3" /> {activeClient.financials.rating}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Compliance Query to RM Banner */}
            <div className="bg-gradient-to-r from-amber-50/80 via-indigo-50/40 to-slate-50/10 dark:from-slate-900/40 dark:via-amber-950/20 dark:to-slate-950/20 border border-amber-200/60 dark:border-slate-800 rounded-xl p-4.5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded-lg shrink-0 mt-0.5">
                  <Mail className="w-4.5 h-4.5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">Compliance Query & RM Escalation Dispatch</h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 leading-normal max-w-xl">
                    Initiate formal compliance query, document escalation, or risk review notice directly to the assigned Relationship Manager for <strong className="text-slate-700 dark:text-slate-200">{activeClient.companyName}</strong>.
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => handleSendOutreachEmail()}
                  className="w-full sm:w-auto px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold tracking-wider transition shadow-sm cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Mail className="w-3.5 h-3.5" /> Initiate Email to RM
                </button>
              </div>
            </div>

            {/* Ingested Document Vault Panel (Compliance View) */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
              <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100 dark:border-slate-800/60">
                <h3 className="font-bold text-slate-900 dark:text-white text-xs uppercase tracking-wider font-mono flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-indigo-500" />
                  Ingested Verification Documents ({activeClient.documents?.length || 0})
                </h3>
                <span className="text-[10px] font-mono text-slate-400">CLICK TO INSPECT FILE CONTENTS</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {activeClient.documents && activeClient.documents.length > 0 ? (
                  activeClient.documents.map((doc) => (
                    <div 
                      key={doc.id}
                      onClick={() => setViewingDocument(doc)}
                      className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40 hover:border-indigo-400 dark:hover:border-indigo-600 hover:bg-slate-50 transition-all cursor-pointer group flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="p-2 rounded-lg bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 group-hover:bg-indigo-600 group-hover:text-white transition-colors shrink-0">
                          <FileText className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <h5 className="text-xs font-bold text-slate-900 dark:text-white truncate group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                            {doc.name}
                          </h5>
                          <span className="text-[10px] text-slate-400 font-mono block truncate">
                            {doc.type} • {doc.size}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-bold uppercase ${
                          doc.status === 'verified' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' :
                          doc.status === 'rejected' ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300' :
                          'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                        }`}>
                          {doc.status}
                        </span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setViewingDocument(doc);
                          }}
                          className="px-2 py-1 rounded bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-bold transition flex items-center gap-1 cursor-pointer"
                        >
                          <Eye className="w-3 h-3" />
                          <span>View</span>
                        </button>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="col-span-2 text-xs text-slate-400 italic text-center py-4">No documents submitted yet.</p>
                )}
              </div>
            </div>

          </div>

          {/* RIGHT COLUMN: Node Detail & Compliance Sign-off Panel (xl:col-span-5) */}
          <div className="xl:col-span-5 h-full sticky top-24">
            {activeNode ? (
              <NodeDetail
                node={activeNode}
                client={activeClient}
                activePersona={activePersona}
                onUpdateNode={handleUpdateNode}
                onRunAutonomousNode={handleRunAutonomousNode}
                onTriggerAutonomousFlow={handleTriggerAutonomousFlow}
                isProcessing={activeRunningNodeId === activeNode.id}
                agents={agents}
                onRaiseClarification={handleRaiseClarification}
                onForwardClarification={handleForwardClarification}
                onResolveClarification={handleResolveClarification}
                onInitiateClarificationOutreach={handleInitiateClarificationOutreach}
              />
            ) : (
              <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-6 text-center text-slate-400 italic">
                Select a stage in the onboarding stepper above to inspect compliance logs and perform supervisor sign-offs.
              </div>
            )}
          </div>
        </div>
      ) : (
        /* STANDARD LAYOUT FOR OTHER PERSONAS */
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
          <div className="xl:col-span-8 flex flex-col gap-6">
            {/* Client Outreach Agent Simulation Banner */}
            <div className="bg-gradient-to-r from-indigo-50/80 via-blue-50/40 to-slate-50/10 dark:from-slate-900/40 dark:via-indigo-950/20 dark:to-slate-950/20 border border-indigo-100/60 dark:border-slate-800 rounded-xl p-4.5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-indigo-600/10 text-indigo-600 dark:text-indigo-400 rounded-lg shrink-0 mt-0.5">
                  <Bot className="w-4.5 h-4.5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">Autonomous Client Outreach Agent (Active)</h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 leading-normal max-w-xl">
                    Dispatches secure email invitations with onboarding gateway credentials, allowing representatives to perform self-service registration and Singpass/Aadhaar profile matching.
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => handleSendOutreachEmail()}
                  className="w-full sm:w-auto px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold tracking-wider transition shadow-sm cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Mail className="w-3.5 h-3.5" /> Trigger Outreach Email
                </button>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800/60 mb-4">
                <div className="flex items-center gap-2">
                  <Compass className="w-5 h-5 text-[#002D62] dark:text-[#00A3E0]" />
                  <div>
                    <h2 className="font-bold text-slate-900 dark:text-white text-sm">Visual Dependency Graph & Processing Flow</h2>
                    <p className="text-[10px] font-mono text-slate-400">CONNECTED WORKFLOW DAG • DYNAMIC SEQUENCE DEPENDENCIES</p>
                  </div>
                </div>
              </div>

              <WorkflowGraph
                nodes={activeClient.workflowNodes}
                selectedNodeId={selectedNodeId}
                onSelectNode={(id) => setSelectedNodeId(id)}
                activeNodeId={activeRunningNodeId}
              />
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
              <h3 className="font-bold text-slate-900 dark:text-white text-xs uppercase tracking-wider font-mono border-b border-slate-100 dark:border-slate-800/60 pb-3 mb-4 flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-slate-500" />
                Corporate Registry & Financial Disclosures
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                <div className="bg-slate-50 dark:bg-slate-950/40 p-3 rounded-lg border border-slate-100 dark:border-slate-800/40">
                  <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500 uppercase">REGISTRATION NUMBER</span>
                  <strong className="text-sm text-slate-800 dark:text-slate-100 font-semibold block mt-0.5">{activeClient.registrationNumber}</strong>
                </div>
                <div className="bg-slate-50 dark:bg-slate-950/40 p-3 rounded-lg border border-slate-100 dark:border-slate-800/40">
                  <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500 uppercase">JURISDICTION</span>
                  <strong className="text-sm text-slate-800 dark:text-slate-100 font-semibold block mt-0.5">{activeClient.jurisdiction}</strong>
                </div>
                <div className="bg-slate-50 dark:bg-slate-950/40 p-3 rounded-lg border border-slate-100 dark:border-slate-800/40">
                  <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500 uppercase">INDUSTRY SEGMENT</span>
                  <strong className="text-sm text-slate-800 dark:text-slate-100 font-semibold block mt-0.5 truncate">{activeClient.industry}</strong>
                </div>
                <div className="bg-slate-50 dark:bg-slate-950/40 p-3 rounded-lg border border-slate-100 dark:border-slate-800/40">
                  <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500 uppercase">OVERALL COMPLIANCE</span>
                  <span className={`inline-flex items-center gap-1 text-[11px] font-mono font-bold uppercase mt-1 px-2.5 py-0.5 rounded-full ${
                    activeClient.overallStatus === 'approved' ? 'bg-emerald-100 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-400 border border-emerald-200' :
                    activeClient.overallStatus === 'rejected' ? 'bg-rose-100 dark:bg-rose-950/20 text-rose-800 dark:text-rose-400 border border-rose-200' :
                    'bg-amber-100 dark:bg-amber-950/20 text-amber-800 dark:text-amber-400 border border-amber-200'
                  }`}>
                    {activeClient.overallStatus}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="border border-slate-100 dark:border-slate-800 rounded-xl p-4 bg-slate-50/20">
                  <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 tracking-wider font-mono uppercase mb-2.5 flex items-center justify-between">
                    <span>Shareholding Registers (UBO Vetting)</span>
                    <Users className="w-4 h-4 text-slate-400" />
                  </h4>
                  <div className="space-y-2">
                    {activeClient.shareholders.map((sh, idx) => (
                      <div key={idx} className="flex items-center justify-between p-2 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/60 rounded-lg">
                        <div className="overflow-hidden mr-2">
                          <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">{sh.name}</p>
                          <p className="text-[10px] text-slate-400 dark:text-slate-500 font-mono">Direct Shareholder Equity</p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          {sh.pepStatus && (
                            <span className="px-1.5 py-0.5 bg-rose-100 dark:bg-rose-950/30 text-rose-800 dark:text-rose-400 font-mono text-[9px] font-extrabold rounded-md uppercase animate-pulse flex items-center gap-0.5">
                              <ShieldAlert className="w-2.5 h-2.5" /> PEP ALERT
                            </span>
                          )}
                          <span className="text-xs font-bold font-mono text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">
                            {sh.equity}%
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="border border-slate-100 dark:border-slate-800 rounded-xl p-4 bg-slate-50/20">
                  <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 tracking-wider font-mono uppercase mb-2.5 flex items-center justify-between">
                    <span>Balance Sheet Ratios (Underwriting)</span>
                    <TrendingUp className="w-4 h-4 text-slate-400" />
                  </h4>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/60 rounded-lg p-2.5">
                      <span className="text-[9px] font-mono text-slate-400 dark:text-slate-500 block uppercase">ANNUAL REVENUE</span>
                      <strong className="text-xs font-semibold text-slate-800 dark:text-slate-200 block mt-0.5">{activeClient.financials.revenue}</strong>
                    </div>
                    <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/60 rounded-lg p-2.5">
                      <span className="text-[9px] font-mono text-slate-400 dark:text-slate-500 block uppercase">BALANCED ASSETS</span>
                      <strong className="text-xs font-semibold text-slate-800 dark:text-slate-200 block mt-0.5">{activeClient.financials.assets}</strong>
                    </div>
                    <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/60 rounded-lg p-2.5">
                      <span className="text-[9px] font-mono text-slate-400 dark:text-slate-500 block uppercase">DEBT LEVERAGE RATIO</span>
                      <strong className="text-xs font-semibold text-slate-800 dark:text-slate-200 block mt-0.5">{activeClient.financials.debtRatio}</strong>
                    </div>
                    <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/60 rounded-lg p-2.5">
                      <span className="text-[9px] font-mono text-slate-400 dark:text-slate-500 block uppercase">INTERNAL CREDIT RATIO</span>
                      <span className="inline-flex items-center gap-0.5 text-xs font-bold font-mono text-blue-700 bg-blue-50 dark:text-indigo-400 dark:bg-indigo-950/30 px-1.5 py-0.5 rounded">
                        <Award className="w-3 h-3" /> {activeClient.financials.rating}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Ingested Document Vault Panel (RM / Platform Admin / Operations View) */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
              <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100 dark:border-slate-800/60">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-indigo-500" />
                  <h3 className="font-bold text-slate-900 dark:text-white text-xs uppercase tracking-wider font-mono">
                    Ingested Verification Documents ({activeClient.documents?.length || 0})
                  </h3>
                </div>
                <span className="text-[10px] font-mono text-slate-400">READ-ONLY SECURE VIEWER</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {activeClient.documents && activeClient.documents.length > 0 ? (
                  activeClient.documents.map((doc) => (
                    <div 
                      key={doc.id}
                      onClick={() => setViewingDocument(doc)}
                      className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40 hover:border-indigo-400 dark:hover:border-indigo-600 hover:bg-slate-50 transition-all cursor-pointer group flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="p-2 rounded-lg bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 group-hover:bg-indigo-600 group-hover:text-white transition-colors shrink-0">
                          <FileText className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <h5 className="text-xs font-bold text-slate-900 dark:text-white truncate group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                              {doc.name}
                            </h5>
                            <span className={`px-1.5 py-0.5 rounded text-[8px] font-mono font-bold uppercase tracking-wider ${
                              doc.source === 'externally_sourced' 
                                ? 'bg-purple-100 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 border border-purple-200 dark:border-purple-800' 
                                : 'bg-blue-100 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200 dark:border-blue-800'
                            }`}>
                              {doc.source === 'externally_sourced' ? '🌐 Externally Sourced' : '👤 Customer Provided'}
                            </span>
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono block truncate mt-0.5">
                            {doc.type} • {doc.size} {doc.sourceDetails ? `• ${doc.sourceDetails}` : ''}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-center">
                        <span className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-bold uppercase ${
                          doc.status === 'verified' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' :
                          doc.status === 'rejected' ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300' :
                          'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                        }`}>
                          {doc.status}
                        </span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setViewingDocument(doc);
                          }}
                          className="px-2.5 py-1 rounded bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-bold transition flex items-center gap-1 cursor-pointer shadow-xs"
                        >
                          <Eye className="w-3 h-3" />
                          <span>View</span>
                        </button>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="col-span-2 text-xs text-slate-400 italic text-center py-4">No documents submitted yet.</p>
                )}
              </div>
            </div>
          </div>

          <div className="xl:col-span-4 h-full sticky top-24">
            {activeNode ? (
              <NodeDetail
                node={activeNode}
                client={activeClient}
                activePersona={activePersona}
                onUpdateNode={handleUpdateNode}
                onRunAutonomousNode={handleRunAutonomousNode}
                onTriggerAutonomousFlow={handleTriggerAutonomousFlow}
                isProcessing={activeRunningNodeId === activeNode.id}
                agents={agents}
                onRaiseClarification={handleRaiseClarification}
                onForwardClarification={handleForwardClarification}
                onResolveClarification={handleResolveClarification}
                onInitiateClarificationOutreach={handleInitiateClarificationOutreach}
              />
            ) : (
              <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-6 text-center text-slate-400 italic">
                Select a node in the workflow graph to inspect logs and perform compliance sign-offs.
              </div>
            )}
          </div>
        </div>
      )}

      {/* CENTRAL REACT DOCUMENT VIEWER MODAL (READ ONLY, NO DOWNLOAD) */}
      <DocumentViewerModal
        document={viewingDocument}
        isOpen={Boolean(viewingDocument)}
        onClose={() => setViewingDocument(null)}
        readOnly={false}
        userRole={isComplianceOfficer ? 'compliance' : 'rm'}
        onApprove={(docId) => {
          handleAddDocument?.(
            activeClient.documents.find(d => d.id === docId)
              ? { ...activeClient.documents.find(d => d.id === docId)!, status: 'verified' }
              : null,
            activeClient.id
          );
          setViewingDocument(null);
        }}
        onReject={(docId) => {
          handleDeleteDocument?.(docId);
          setViewingDocument(null);
        }}
      />
    </>
  );
};

export default JourneyWorkspace;
