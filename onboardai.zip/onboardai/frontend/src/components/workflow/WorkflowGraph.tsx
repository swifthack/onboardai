import React, { useState, useMemo } from 'react';
import { WorkflowNode, NodeStatus } from '../../types';
import { 
  Database, 
  FileText, 
  Fingerprint, 
  ShieldAlert, 
  Shield, 
  Activity, 
  TrendingUp, 
  Scale, 
  CheckCircle2, 
  AlertTriangle, 
  Loader2, 
  Circle,
  GitFork,
  Layers,
  Table,
  ArrowRight,
  Sparkles,
  Lock,
  Unlock,
  Check,
  ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface WorkflowGraphProps {
  nodes: WorkflowNode[];
  selectedNodeId: string;
  onSelectNode: (nodeId: string) => void;
  activeNodeId?: string;
}

// Stage configuration mapping for sequential DAG flowchart layout
const NODE_STAGE_META: Record<string, { stageNum: string; stageName: string; position: { x: number; y: number } }> = {
  // Legacy Node IDs
  data_aggregator: { stageNum: '#1', stageName: 'Data Ingestion', position: { x: 500, y: 70 } },
  name_screening: { stageNum: '#2', stageName: 'Sanctions Screening', position: { x: 500, y: 210 } },
  aml: { stageNum: '#3', stageName: 'AML Deep Scan', position: { x: 500, y: 350 } },
  client_risk: { stageNum: '#4', stageName: 'Composite Risk Synthesis', position: { x: 500, y: 490 } },
  credit_risk: { stageNum: '#5', stageName: 'Credit Underwriting', position: { x: 500, y: 630 } },
  legal_compliance: { stageNum: '#6', stageName: 'Legal Sign-off', position: { x: 500, y: 770 } },

  // Standard 11 Journey Stages
  stage_1: { stageNum: '#1', stageName: 'Prospect Qualification', position: { x: 500, y: 70 } },
  stage_2: { stageNum: '#2a', stageName: 'Entity Research', position: { x: 280, y: 190 } },
  stage_3: { stageNum: '#2b', stageName: 'Individual Verification', position: { x: 720, y: 190 } },
  stage_4: { stageNum: '#3', stageName: 'Dynamic KYC', position: { x: 500, y: 310 } },
  stage_5: { stageNum: '#4a', stageName: 'Compliance Data Collection', position: { x: 280, y: 430 } },
  stage_6: { stageNum: '#4b', stageName: 'Sanctions & PEP Screening', position: { x: 720, y: 430 } },
  stage_7: { stageNum: '#5', stageName: 'Risk Assessment', position: { x: 500, y: 550 } },
  stage_8: { stageNum: '#6', stageName: 'Approval Gateway', position: { x: 500, y: 670 } },
  stage_9: { stageNum: '#7', stageName: 'Product Provisioning', position: { x: 500, y: 790 } },
  stage_10: { stageNum: '#8', stageName: 'Ready to Trade', position: { x: 500, y: 910 } },
  stage_11: { stageNum: '#9', stageName: 'Perpetual KYC', position: { x: 500, y: 1030 } },

  // Fund Journey Stages
  fund_stage_1: { stageNum: '#1', stageName: 'Prospect Qualification', position: { x: 500, y: 70 } },
  fund_stage_2: { stageNum: '#2a', stageName: 'Entity Research', position: { x: 280, y: 190 } },
  fund_stage_3: { stageNum: '#2b', stageName: 'Individual Verification', position: { x: 720, y: 190 } },
  fund_stage_4: { stageNum: '#3', stageName: 'Dynamic KYC', position: { x: 500, y: 310 } },
  fund_stage_5: { stageNum: '#4a', stageName: 'Compliance Data Collection', position: { x: 280, y: 430 } },
  fund_stage_6: { stageNum: '#4b', stageName: 'Sanctions & PEP Screening', position: { x: 720, y: 430 } },
  fund_stage_7: { stageNum: '#5', stageName: 'Risk Assessment', position: { x: 500, y: 550 } },
  fund_stage_8: { stageNum: '#6', stageName: 'Approval Gateway', position: { x: 500, y: 670 } },
  fund_stage_9: { stageNum: '#7', stageName: 'Product Provisioning', position: { x: 500, y: 790 } },
  fund_stage_10: { stageNum: '#8', stageName: 'Ready to Trade', position: { x: 500, y: 910 } },
  fund_stage_11: { stageNum: '#9', stageName: 'Perpetual KYC', position: { x: 500, y: 1030 } },
};

const NODE_ICONS: Record<string, React.ReactNode> = {
  data_aggregator: <Database className="w-4.5 h-4.5" />,
  name_screening: <ShieldAlert className="w-4.5 h-4.5" />,
  aml: <Shield className="w-4.5 h-4.5" />,
  client_risk: <Activity className="w-4.5 h-4.5" />,
  credit_risk: <TrendingUp className="w-4.5 h-4.5" />,
  legal_compliance: <Scale className="w-4.5 h-4.5" />,

  stage_1: <Sparkles className="w-4.5 h-4.5" />,
  stage_2: <Database className="w-4.5 h-4.5" />,
  stage_3: <Shield className="w-4.5 h-4.5" />,
  stage_4: <Layers className="w-4.5 h-4.5" />,
  stage_5: <Scale className="w-4.5 h-4.5" />,
  stage_6: <ShieldAlert className="w-4.5 h-4.5" />,
  stage_7: <Activity className="w-4.5 h-4.5" />,
  stage_8: <CheckCircle2 className="w-4.5 h-4.5" />,
  stage_9: <TrendingUp className="w-4.5 h-4.5" />,
  stage_10: <Unlock className="w-4.5 h-4.5" />,
  stage_11: <Shield className="w-4.5 h-4.5" />,

  fund_stage_1: <Sparkles className="w-4.5 h-4.5" />,
  fund_stage_2: <Database className="w-4.5 h-4.5" />,
  fund_stage_3: <Shield className="w-4.5 h-4.5" />,
  fund_stage_4: <Layers className="w-4.5 h-4.5" />,
  fund_stage_5: <Scale className="w-4.5 h-4.5" />,
  fund_stage_6: <ShieldAlert className="w-4.5 h-4.5" />,
  fund_stage_7: <Activity className="w-4.5 h-4.5" />,
  fund_stage_8: <CheckCircle2 className="w-4.5 h-4.5" />,
  fund_stage_9: <TrendingUp className="w-4.5 h-4.5" />,
  fund_stage_10: <Unlock className="w-4.5 h-4.5" />,
  fund_stage_11: <Shield className="w-4.5 h-4.5" />,
};

export default function WorkflowGraph({ 
  nodes, 
  selectedNodeId, 
  onSelectNode,
  activeNodeId
}: WorkflowGraphProps) {
  const [viewMode, setViewMode] = useState<'flowchart' | 'matrix'>('flowchart');
  const [hoveredNodeId, setHoveredNodeId] = useState<string | null>(null);

  const getStatusStyle = (status: NodeStatus, isSelected: boolean, isHovered: boolean) => {
    const base = "border-2 transition-all duration-300 relative ";
    const selectedRing = isSelected 
      ? "ring-4 ring-offset-2 ring-[#008752] dark:ring-offset-slate-900 scale-105 shadow-lg z-10" 
      : isHovered 
      ? "shadow-md scale-[1.02] border-[#00A3E0]" 
      : "shadow-sm hover:shadow-md";
    
    switch (status) {
      case 'completed':
        return `${base} border-emerald-500 bg-emerald-50/90 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 ${selectedRing}`;
      case 'flagged':
      case 'awaiting_approval':
        return `${base} border-amber-500 bg-amber-50/90 dark:bg-amber-950/40 text-amber-950 dark:text-amber-200 ring-2 ring-amber-300/80 ${selectedRing}`;
      case 'running':
        return `${base} border-[#00A3E0] bg-white dark:bg-slate-900 text-[#002D62] dark:text-sky-200 ring-4 ring-[#00A3E0]/20 animate-pulse ${selectedRing}`;
      case 'pending':
      default:
        return `${base} border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 ${selectedRing}`;
    }
  };

  const getStatusIcon = (status: NodeStatus) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />;
      case 'flagged':
      case 'awaiting_approval':
        return <AlertTriangle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 animate-pulse" />;
      case 'running':
        return <Loader2 className="w-3.5 h-3.5 text-[#00A3E0] animate-spin" />;
      case 'pending':
      default:
        return <Circle className="w-3.5 h-3.5 text-slate-300 dark:text-slate-600" />;
    }
  };

  // Compute node positions dynamically or use predefined DAG positions
  const { resolvedPositions, stageHeight } = useMemo(() => {
    const positions: Record<string, { x: number; y: number }> = {};
    const isStandard = nodes.every(n => n.id in NODE_STAGE_META);
    
    if (isStandard) {
      let maxY = 850;
      nodes.forEach(n => {
        positions[n.id] = NODE_STAGE_META[n.id].position;
        if (NODE_STAGE_META[n.id].position.y > maxY) {
          maxY = NODE_STAGE_META[n.id].position.y;
        }
      });
      return { resolvedPositions: positions, stageHeight: Math.max(850, maxY + 120) };
    }

    // Dynamic layer-based positioning for non-standard or custom node structures
    const layers: string[][] = [];
    const visited = new Set<string>();
    let remaining = [...nodes];
    
    let iterations = 0;
    while (remaining.length > 0 && iterations < 30) {
      iterations++;
      const currentLayer: string[] = [];
      const nextRemaining: typeof remaining = [];
      
      for (const node of remaining) {
        const depsSatisfied = !node.dependsOn || node.dependsOn.length === 0 || 
          node.dependsOn.every(depId => visited.has(depId) || !nodes.some(n => n.id === depId));
        
        if (depsSatisfied) {
          currentLayer.push(node.id);
        } else {
          nextRemaining.push(node);
        }
      }
      
      if (currentLayer.length === 0) {
        currentLayer.push(...remaining.map(r => r.id));
        remaining = [];
      } else {
        remaining = nextRemaining;
      }
      
      currentLayer.forEach(id => visited.add(id));
      layers.push(currentLayer);
    }
    
    const totalLayersCount = layers.length;
    const calculatedStageHeight = Math.max(850, totalLayersCount * 135 + 80);
    
    layers.forEach((layerIds, layerIndex) => {
      const y = totalLayersCount > 1 
        ? 70 + (layerIndex / (totalLayersCount - 1)) * (calculatedStageHeight - 140) 
        : calculatedStageHeight / 2;
      
      const count = layerIds.length;
      layerIds.forEach((nodeId, nodeIndex) => {
        const x = count > 1
          ? 260 + (nodeIndex / (count - 1)) * 480
          : 500;
        positions[nodeId] = { x, y };
      });
    });
    
    return { resolvedPositions: positions, stageHeight: calculatedStageHeight };
  }, [nodes]);

  // Compute directed dependency edges
  const EDGES = useMemo(() => {
    const list: { from: string; to: string }[] = [];
    nodes.forEach(node => {
      if (node.dependsOn && node.dependsOn.length > 0) {
        node.dependsOn.forEach(depId => {
          if (nodes.some(n => n.id === depId)) {
            list.push({ from: depId, to: node.id });
          }
        });
      }
    });
    
    if (list.length === 0 && nodes.every(n => n.id in NODE_STAGE_META)) {
      return [
        { from: 'data_aggregator', to: 'name_screening' },
        { from: 'name_screening', to: 'aml' },
        { from: 'aml', to: 'client_risk' },
        { from: 'client_risk', to: 'credit_risk' },
        { from: 'credit_risk', to: 'legal_compliance' }
      ];
    }
    
    return list;
  }, [nodes]);

  // Check dependency readiness status for a given node
  const checkDependenciesSatisfied = (node: WorkflowNode) => {
    if (!node.dependsOn || node.dependsOn.length === 0) return { satisfied: true, total: 0, completed: 0, pending: [] };
    const depNodes = nodes.filter(n => node.dependsOn.includes(n.id));
    const completedNodes = depNodes.filter(n => n.status === 'completed');
    const pendingNodes = depNodes.filter(n => n.status !== 'completed');
    return {
      satisfied: pendingNodes.length === 0,
      total: depNodes.length,
      completed: completedNodes.length,
      pending: pendingNodes
    };
  };

  const activeFocusNodeId = hoveredNodeId || selectedNodeId;

  return (
    <div className="relative w-full rounded-2xl bg-[#F4F6F8] dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-4 sm:p-6 flex flex-col items-center select-none shadow-sm transition-colors">
      
      {/* Top Controls Bar: View Switcher & Graph Status Legend */}
      <div className="w-full flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-200/80 dark:border-slate-800">
        
        {/* View Mode Tabs */}
        <div className="flex items-center p-1 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm self-start">
          <button
            onClick={() => setViewMode('flowchart')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              viewMode === 'flowchart'
                ? 'bg-[#002D62] text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <GitFork className="w-3.5 h-3.5 text-[#00A3E0]" />
            <span>2D Flowchart</span>
          </button>

          <button
            onClick={() => setViewMode('matrix')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              viewMode === 'matrix'
                ? 'bg-[#002D62] text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Table className="w-3.5 h-3.5 text-[#00A3E0]" />
            <span>Dependency Matrix</span>
          </button>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center gap-3 bg-white/90 dark:bg-slate-900/90 backdrop-blur px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-[10px] font-mono text-slate-600 dark:text-slate-400">
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-slate-300 dark:bg-slate-600 inline-block"></span> Pending
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-[#00A3E0] inline-block animate-pulse"></span> Running
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-[#008752] inline-block"></span> Verified
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-amber-500 inline-block animate-ping"></span> Action Needed
          </span>
        </div>
      </div>

      {/* VIEW 1: 2D CONNECTED FLOWCHART DAG */}
      {viewMode === 'flowchart' && (
        <div className="w-full overflow-x-auto flex justify-center pb-4">
          <div className="relative w-[850px]" style={{ height: `${stageHeight}px` }} id="graph-stage">
            
            {/* Horizontal Stage Guidelines Background */}
            <div className="absolute inset-0 pointer-events-none space-y-0">
              {[
                { stageNum: 'Stage 01', y: 70, name: 'Data Ingestion' },
                { stageNum: 'Stage 02', y: 210, name: 'Identity & Screening (Parallel)' },
                { stageNum: 'Stage 03', y: 350, name: 'Biometric & AML Verification (Parallel)' },
                { stageNum: 'Stage 04', y: 490, name: 'Composite Risk Synthesis' },
                { stageNum: 'Stage 05', y: 630, name: 'Underwriting & Ratios' },
                { stageNum: 'Stage 06', y: 770, name: 'Legal Sign-off' },
              ].map((stg, i) => (
                <div 
                  key={i} 
                  className="absolute w-full border-b border-dashed border-slate-200/80 dark:border-slate-800/80 flex items-center justify-between px-2 text-[9px] font-mono text-slate-400/60 dark:text-slate-600/60"
                  style={{ top: `${stg.y}px` }}
                >
                  <span className="bg-[#F4F6F8] dark:bg-slate-950 px-1 font-bold text-[#002D62] dark:text-[#00A3E0]">{stg.stageNum}: {stg.name}</span>
                </div>
              ))}
            </div>

            {/* SVG Connectors Canvas */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
              <defs>
                <marker
                  id="arrow-default"
                  viewBox="0 0 10 10"
                  refX="9"
                  refY="5"
                  markerWidth="6"
                  markerHeight="6"
                  orient="auto-start-reverse"
                >
                  <path d="M 0 0 L 10 5 L 0 10 z" fill="#cbd5e1" />
                </marker>
                <marker
                  id="arrow-[#00A3E0]"
                  viewBox="0 0 10 10"
                  refX="9"
                  refY="5"
                  markerWidth="6"
                  markerHeight="6"
                  orient="auto-start-reverse"
                >
                  <path d="M 0 0 L 10 5 L 0 10 z" fill="#00A3E0" />
                </marker>
                <marker
                  id="arrow-completed"
                  viewBox="0 0 10 10"
                  refX="9"
                  refY="5"
                  markerWidth="6"
                  markerHeight="6"
                  orient="auto-start-reverse"
                >
                  <path d="M 0 0 L 10 5 L 0 10 z" fill="#008752" />
                </marker>
                <marker
                  id="arrow-flagged"
                  viewBox="0 0 10 10"
                  refX="9"
                  refY="5"
                  markerWidth="6"
                  markerHeight="6"
                  orient="auto-start-reverse"
                >
                  <path d="M 0 0 L 10 5 L 0 10 z" fill="#f59e0b" />
                </marker>
              </defs>

              {EDGES.map((edge, index) => {
                const start = resolvedPositions[edge.from];
                const end = resolvedPositions[edge.to];
                if (!start || !end) return null;

                const dx = end.x - start.x;
                const dy = end.y - start.y;
                const len = Math.sqrt(dx * dx + dy * dy);

                let startX = start.x;
                let startY = start.y;
                let endX = end.x;
                let endY = end.y;

                if (len > 0) {
                  const ux = dx / len;
                  const uy = dy / len;
                  const W = 115; // half width of node (230px)
                  const H = 40;  // half height of node (80px)

                  const txStart = ux !== 0 ? W / Math.abs(ux) : Infinity;
                  const tyStart = uy !== 0 ? H / Math.abs(uy) : Infinity;
                  const tStart = Math.min(txStart, tyStart);

                  const txEnd = ux !== 0 ? W / Math.abs(ux) : Infinity;
                  const tyEnd = uy !== 0 ? H / Math.abs(uy) : Infinity;
                  const tEnd = Math.min(txEnd, tyEnd);

                  startX = start.x + ux * (tStart + 4);
                  startY = start.y + uy * (tStart + 4);
                  endX = end.x - ux * (tEnd + 8);
                  endY = end.y - uy * (tEnd + 8);
                }
                
                const fromNode = nodes.find(n => n.id === edge.from);
                const toNode = nodes.find(n => n.id === edge.to);

                // Highlight status relative to focus/selection
                const isIncomingEdge = activeFocusNodeId === edge.to;
                const isOutgoingEdge = activeFocusNodeId === edge.from;
                const isEdgeHighlighted = isIncomingEdge || isOutgoingEdge;

                let strokeColor = '#cbd5e1'; // slate-300
                let marker = 'url(#arrow-default)';
                let dashArray = 'none';
                let strokeWidth = 2;
                let strokeOpacity = activeFocusNodeId && !isEdgeHighlighted ? 0.25 : 1;

                if (isIncomingEdge) {
                  strokeColor = '#00A3E0'; // Cyan for incoming dependencies
                  marker = 'url(#arrow-[#00A3E0])';
                  strokeWidth = 3;
                  dashArray = '6,4';
                } else if (isOutgoingEdge) {
                  strokeColor = '#008752'; // Green for outgoing unblocked
                  marker = 'url(#arrow-completed)';
                  strokeWidth = 3;
                } else if (fromNode?.status === 'completed' && toNode?.status === 'running') {
                  strokeColor = '#00A3E0';
                  marker = 'url(#arrow-[#00A3E0])';
                  dashArray = '5,5';
                  strokeWidth = 2.5;
                } else if (fromNode?.status === 'completed' && toNode?.status === 'completed') {
                  strokeColor = '#008752';
                  marker = 'url(#arrow-completed)';
                  strokeWidth = 2;
                } else if (fromNode?.status === 'flagged' || toNode?.status === 'flagged' || fromNode?.status === 'awaiting_approval' || toNode?.status === 'awaiting_approval') {
                  strokeColor = '#f59e0b';
                  marker = 'url(#arrow-flagged)';
                  strokeWidth = 2;
                }

                return (
                  <g key={`edge-${index}`}>
                    <path
                      d={`M ${startX} ${startY} L ${endX} ${endY}`}
                      fill="none"
                      stroke={strokeColor}
                      strokeWidth={strokeWidth}
                      strokeDasharray={dashArray}
                      strokeOpacity={strokeOpacity}
                      markerEnd={marker}
                      className="transition-all duration-300"
                    />
                    {/* Animated pulse dot for running path */}
                    {(isIncomingEdge || (fromNode?.status === 'completed' && toNode?.status === 'running')) && (
                      <circle r="4" fill="#00A3E0">
                        <animateMotion
                          dur="1.5s"
                          repeatCount="indefinite"
                          path={`M ${startX} ${startY} L ${endX} ${endY}`}
                        />
                      </circle>
                    )}
                  </g>
                );
              })}
            </svg>

            {/* Nodes Layer */}
            {nodes.map((node) => {
              const pos = resolvedPositions[node.id] || { x: 500, y: 300 };
              const isSelected = selectedNodeId === node.id;
              const isHovered = hoveredNodeId === node.id;
              const isWaitingApproval = node.status === 'flagged' || node.status === 'awaiting_approval';
              const depStatus = checkDependenciesSatisfied(node);
              const stageMeta = NODE_STAGE_META[node.id];

              return (
                <motion.div
                  key={node.id}
                  style={{
                    position: 'absolute',
                    left: pos.x - 115,
                    top: pos.y - 40,
                    width: '230px',
                    height: '80px',
                  }}
                  whileHover={{ y: -4 }}
                  onMouseEnter={() => setHoveredNodeId(node.id)}
                  onMouseLeave={() => setHoveredNodeId(null)}
                  transition={{ type: "spring", stiffness: 400, damping: 25 }}
                  id={`node-${node.id}`}
                  className="z-10"
                >
                  {/* Action Banner for flagged / awaiting approval */}
                  {isWaitingApproval && (
                    <div className="absolute -top-7 left-1/2 -translate-x-1/2 whitespace-nowrap bg-amber-500 text-white text-[9px] font-extrabold px-2.5 py-0.5 rounded-full shadow-lg flex items-center gap-1 border border-amber-300 z-20 animate-bounce">
                      <AlertTriangle className="w-2.5 h-2.5 text-white" />
                      <span>Action Required</span>
                    </div>
                  )}

                  <button
                    onClick={() => onSelectNode(node.id)}
                    className={`w-full h-full flex flex-col justify-between p-3 rounded-xl cursor-pointer text-left focus:outline-none ${getStatusStyle(
                      node.status,
                      isSelected,
                      isHovered
                    )}`}
                  >
                    {/* Node Header Row */}
                    <div className="flex items-center justify-between w-full">
                      <div className="flex items-center gap-1.5 overflow-hidden">
                        <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-[#002D62] text-white shrink-0">
                          {stageMeta?.stageNum || `#${nodes.findIndex(n => n.id === node.id) + 1}`}
                        </span>
                        <div className={`p-1 rounded-md shrink-0 ${
                          node.status === 'completed' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' :
                          isWaitingApproval ? 'bg-amber-100 text-amber-900 border border-amber-300' :
                          node.status === 'running' ? 'bg-[#00A3E0]/20 text-[#00A3E0]' :
                          'bg-slate-100 dark:bg-slate-800 text-slate-500'
                        }`}>
                          {NODE_ICONS[node.id] || NODE_ICONS[node.agentType] || <Circle className="w-4 h-4" />}
                        </div>
                      </div>

                      {/* Right Status Icon & Dependency Pill */}
                      <div className="flex items-center gap-1 text-[10px] font-mono tracking-wide">
                        {!depStatus.satisfied && node.status === 'pending' && (
                          <span className="text-[8px] font-bold px-1 py-0.2 rounded bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300" title={`Waiting on: ${depStatus.pending.map(p => p.name).join(', ')}`}>
                            <Lock className="w-2.5 h-2.5 inline mr-0.5" />
                            Blocked
                          </span>
                        )}
                        {getStatusIcon(node.status)}
                      </div>
                    </div>

                    {/* Node Title & Subtitle */}
                    <div className="mt-1">
                      <h4 className="text-[11px] font-bold tracking-tight text-slate-900 dark:text-white truncate">
                        {node.name}
                      </h4>
                      <div className="flex items-center justify-between text-[9px] text-slate-500 dark:text-slate-400 font-mono mt-0.5">
                        <span className="truncate">{node.team}</span>
                        {node.dependsOn && node.dependsOn.length > 0 && (
                          <span className="text-[8px] text-[#00A3E0] shrink-0 font-sans">
                            {depStatus.completed}/{depStatus.total} deps
                          </span>
                        )}
                      </div>
                    </div>
                  </button>
                </motion.div>
              );
            })}
          </div>
        </div>
      )}

      {/* VIEW 2: DEPENDENCY MATRIX */}
      {viewMode === 'matrix' && (
        <div className="w-full overflow-x-auto text-left">
          <table className="w-full text-left text-xs bg-white dark:bg-slate-900 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-sm">
            <thead className="bg-[#002D62] text-white font-mono uppercase text-[10px] tracking-wider">
              <tr>
                <th className="p-3">Sequence</th>
                <th className="p-3">Processing Node</th>
                <th className="p-3">Assigned Team</th>
                <th className="p-3">Prerequisites (dependsOn)</th>
                <th className="p-3">Dependency Health</th>
                <th className="p-3">Current Status</th>
                <th className="p-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {nodes.map((node) => {
                const stageMeta = NODE_STAGE_META[node.id];
                const isSelected = selectedNodeId === node.id;
                const depStatus = checkDependenciesSatisfied(node);
                const isWaitingApproval = node.status === 'flagged' || node.status === 'awaiting_approval';

                return (
                  <tr 
                    key={node.id} 
                    onClick={() => onSelectNode(node.id)}
                    className={`hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer transition ${
                      isSelected ? 'bg-emerald-50/50 dark:bg-emerald-950/20 font-semibold' : ''
                    }`}
                  >
                    <td className="p-3 font-mono font-bold text-[#002D62] dark:text-[#00A3E0]">
                      {stageMeta?.stageNum || '#'}
                    </td>
                    <td className="p-3 font-bold text-slate-900 dark:text-white flex items-center gap-2">
                      <div className="p-1.5 rounded bg-slate-100 dark:bg-slate-800 text-[#002D62] dark:text-[#00A3E0]">
                        {NODE_ICONS[node.id] || <Circle className="w-4 h-4" />}
                      </div>
                      <div>
                        <div>{node.name}</div>
                        <div className="text-[10px] font-normal text-slate-400">{node.id}</div>
                      </div>
                    </td>
                    <td className="p-3 text-slate-600 dark:text-slate-400 font-mono text-[11px]">
                      {node.team}
                    </td>
                    <td className="p-3">
                      {node.dependsOn && node.dependsOn.length > 0 ? (
                        <div className="flex flex-wrap gap-1">
                          {node.dependsOn.map(depId => {
                            const depNode = nodes.find(n => n.id === depId);
                            const isDone = depNode?.status === 'completed';
                            return (
                              <span key={depId} className={`px-1.5 py-0.5 rounded text-[9px] font-mono ${
                                isDone ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                              }`}>
                                {depNode?.name || depId}
                              </span>
                            );
                          })}
                        </div>
                      ) : (
                        <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-bold">Root Node</span>
                      )}
                    </td>
                    <td className="p-3 font-mono text-[11px]">
                      {depStatus.satisfied ? (
                        <span className="text-[#008752] dark:text-emerald-400 font-bold flex items-center gap-1">
                          <Unlock className="w-3 h-3" /> All Satisfied
                        </span>
                      ) : (
                        <span className="text-amber-600 dark:text-amber-400 font-bold flex items-center gap-1">
                          <Lock className="w-3 h-3" /> Waiting on {depStatus.pending.length} node(s)
                        </span>
                      )}
                    </td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase inline-flex items-center gap-1 ${
                        node.status === 'completed' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' :
                        isWaitingApproval ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 animate-pulse' :
                        node.status === 'running' ? 'bg-sky-100 text-[#00A3E0]' :
                        'bg-slate-100 dark:bg-slate-800 text-slate-500'
                      }`}>
                        {getStatusIcon(node.status)}
                        {node.status}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <button className="px-2.5 py-1 bg-[#008752] text-white rounded text-[10px] font-bold hover:bg-[#006e42] transition">
                        Select Node
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

    </div>
  );
}
