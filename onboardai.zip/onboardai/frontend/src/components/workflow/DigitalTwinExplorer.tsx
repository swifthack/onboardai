import React, { useState, useMemo } from 'react';
import {
  Flag,
  ShieldCheck,
  Building2,
  Wallet,
  Landmark,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Activity,
  ChevronDown,
  Sparkles,
  Database,
  User,
  FileText,
  FileCheck,
  Bot
} from 'lucide-react';
import { ClientProfile } from '../../types';
import { MOCK_CLIENTS } from '../../mockData';
import { clientsApi, ClientGraphNode, ClientGraphEdge } from '../../services/clientOsApi';

// Types
export type NodeVerificationStatus = 'verified' | 'pending' | 'flagged' | 'amber';
export type NodeType = 'entity' | 'individual' | 'wallet' | 'regulatory' | 'account' | 'tax';

export interface DataField {
  name: string;
  value: string;
  confidence: number; // 0.0 to 1.0
  source?: string;
  stagePopulated?: string;
}

export interface NodeDocumentRequirement {
  id: string;
  name: string;
  category: string;
  status: 'verified' | 'uploaded' | 'pending' | 'missing';
  uploadedDocId?: string;
  mandatory: boolean;
}

export interface GraphNode {
  id: string;
  label: string;
  subLabel: string;
  type: NodeType;
  status: NodeVerificationStatus;
  x: number;
  y: number;
  radius?: number;
  stageOrigin: string;
  stageCode: string;
  details: {
    legalName: string;
    registration: string;
    jurisdiction: string;
    statusText: string;
    directorsCount?: number;
    directorsList?: string[];
    source: string;
    lastUpdated: string;
    confidence: number;
    dataFields: DataField[];
    documents: NodeDocumentRequirement[];
  };
}

export interface GraphEdge {
  id: string;
  from: string;
  to: string;
  label: string;
  tooltip: string;
  type?: string;
}

export interface EventTimelineItem {
  id: string;
  eventType: string;
  timestamp: string;
  description: string;
  stageName: string;
  nodeId?: string;
  badgeColor: string;
}

export interface DigitalTwinExplorerProps {
  clients?: ClientProfile[];
  activeClient?: ClientProfile;
  selectedClientId?: string;
  onSelectClient?: (clientId: string) => void;
  onAddDocument?: (newDoc: any, targetClientId?: string) => void;
  onUpdateClient?: (clientUpdates: Partial<ClientProfile>) => void;
}

// Helper to construct dynamic Knowledge Graph for selected customer
function buildCustomerGraphData(client: ClientProfile) {
  const isApproved = client.overallStatus === 'approved';
  const isRejected = client.overallStatus === 'rejected';
  const centerStatus: NodeVerificationStatus = isApproved ? 'verified' : isRejected ? 'flagged' : 'amber';

  const centerNodeId = client.id;
  const docs = client.documents || [];

  // Match existing client docs
  const hasIncorpDoc = docs.some(d => d.name.toLowerCase().includes('incorporation') || d.type?.toLowerCase().includes('registry'));
  const hasFinancials = docs.some(d => d.name.toLowerCase().includes('financial') || d.name.toLowerCase().includes('statement'));
  const hasBoardRes = docs.some(d => d.name.toLowerCase().includes('resolution') || d.name.toLowerCase().includes('mandate'));
  const hasProofAddr = docs.some(d => d.name.toLowerCase().includes('address') || d.name.toLowerCase().includes('bill'));
  const hasTaxDoc = docs.some(d => d.name.toLowerCase().includes('tax') || d.name.toLowerCase().includes('w-8') || d.name.toLowerCase().includes('crs'));

  // 1. Center Customer Node (Stage 1 & 2)
  const centerNode: GraphNode = {
    id: centerNodeId,
    label: client.companyName,
    subLabel: `${client.industry} • ${client.jurisdiction}`,
    type: 'entity',
    status: centerStatus,
    x: 350,
    y: 250,
    radius: 52,
    stageOrigin: 'Stage #1 (Prospect Intake) & Stage #2 (Entity Resolution)',
    stageCode: 'STAGE_01_02',
    details: {
      legalName: client.companyName,
      registration: client.registrationNumber,
      jurisdiction: client.jurisdiction,
      statusText: `ONBOARDING: ${client.overallStatus.toUpperCase()}`,
      directorsCount: client.directors?.length || 1,
      directorsList: client.directors?.map(d => `${d.name} (${d.role})`) || [client.authorizedRepresentative.name],
      source: `${client.jurisdiction} Official Business Registry (ACRA)`,
      lastUpdated: 'Knowledge base synced',
      confidence: 0.98,
      dataFields: [
        { name: 'Legal Company Name', value: client.companyName, confidence: 1.0, source: 'Business Registry', stagePopulated: 'Stage #2: Entity Resolution' },
        { name: 'Registration UEN/ID', value: client.registrationNumber, confidence: 0.99, source: 'Govt Registry Extract', stagePopulated: 'Stage #2: Entity Resolution' },
        { name: 'Incorporation Country', value: client.jurisdiction, confidence: 1.0, source: 'ACRA BizProfile', stagePopulated: 'Stage #2: Entity Resolution' },
        { name: 'Industry Category', value: client.industry, confidence: 0.97, source: 'SSIC / NAICS DB', stagePopulated: 'Stage #1: Prospect Intake' },
        { name: 'Authorized Signatory', value: `${client.authorizedRepresentative.name} (${client.authorizedRepresentative.role})`, confidence: 0.99, source: 'Board Resolution', stagePopulated: 'Stage #3: Dynamic KYC' },
        { name: 'Biometric Face Liveness', value: client.authorizedRepresentative.biometricVerified ? `${client.authorizedRepresentative.biometricMatchScore || 98.6}% Match` : 'Pending Liveness Check', confidence: client.authorizedRepresentative.biometricVerified ? 0.99 : 0.6, source: 'Facial AI Engine', stagePopulated: 'Stage #3: Dynamic KYC' },
        { name: 'Annual Revenue', value: client.financials?.revenue || 'Audited $14.2M', confidence: 0.95, source: 'PwC Financial Audit', stagePopulated: 'Stage #4: Risk Assessment' },
        { name: 'Credit Score Rating', value: client.financials?.rating || 'AA-', confidence: 0.96, source: 'Internal Risk Engine', stagePopulated: 'Stage #4: Risk Assessment' }
      ],
      documents: [
        { id: 'doc_incorp', name: 'Certificate of Incorporation', category: 'Entity Legal Records', status: hasIncorpDoc ? 'verified' : 'verified', mandatory: true },
        { id: 'doc_const', name: 'Company Constitution / Memorandum & Articles', category: 'Entity Legal Records', status: 'verified', mandatory: true },
        { id: 'doc_audit', name: 'Audited Annual Financials (2025/2026)', category: 'Financial Proof', status: hasFinancials ? 'verified' : 'uploaded', mandatory: false }
      ]
    }
  };

  const nodes: GraphNode[] = [centerNode];
  const edges: GraphEdge[] = [];

  // 2. Authorized Representative Node (Stage 3)
  const repNodeId = `${centerNodeId}_rep`;
  nodes.push({
    id: repNodeId,
    label: client.authorizedRepresentative.name,
    subLabel: `${client.authorizedRepresentative.role} (Auth Rep)`,
    type: 'individual',
    status: client.authorizedRepresentative.biometricVerified ? 'verified' : 'amber',
    x: 170,
    y: 120,
    radius: 36,
    stageOrigin: 'Stage #3 • Dynamic KYC & Individual Biometric Verification',
    stageCode: 'STAGE_03',
    details: {
      legalName: client.authorizedRepresentative.name,
      registration: `Email: ${client.authorizedRepresentative.email}`,
      jurisdiction: client.jurisdiction,
      statusText: client.authorizedRepresentative.biometricVerified ? 'Identity Liveness Verified' : 'Pending Liveness Check',
      source: 'SingPass / Passport MyInfo API',
      lastUpdated: 'Indexed via Stage #3',
      confidence: client.authorizedRepresentative.biometricVerified ? 0.99 : 0.75,
      dataFields: [
        { name: 'Full Legal Name', value: client.authorizedRepresentative.name, confidence: 1.0, source: 'Singpass / Passport', stagePopulated: 'Stage #3: Dynamic KYC' },
        { name: 'Corporate Role', value: client.authorizedRepresentative.role, confidence: 0.99, source: 'Board Resolution', stagePopulated: 'Stage #3: Dynamic KYC' },
        { name: 'Email Address', value: client.authorizedRepresentative.email, confidence: 0.98, source: 'Corporate Domain Verification', stagePopulated: 'Stage #1: Prospect Intake' },
        { name: 'Biometric Liveness Match', value: client.authorizedRepresentative.biometricVerified ? `${client.authorizedRepresentative.biometricMatchScore || 98.6}% Match` : 'Unverified', confidence: 0.99, source: 'Facial Recognition SDK', stagePopulated: 'Stage #3: Dynamic KYC' }
      ],
      documents: [
        { id: 'doc_passport', name: 'Passport / National Identity Document', category: 'Identity Proof', status: 'verified', mandatory: true },
        { id: 'doc_liveness', name: 'Facial Biometric Liveness Certificate', category: 'Biometrics', status: client.authorizedRepresentative.biometricVerified ? 'verified' : 'pending', mandatory: true },
        { id: 'doc_rep_poa', name: 'Proof of Residential Address', category: 'Address Proof', status: hasProofAddr ? 'verified' : 'pending', mandatory: false }
      ]
    }
  });
  edges.push({
    id: `e_rep`,
    from: centerNodeId,
    to: repNodeId,
    label: 'AUTHORIZED_SIGNATORY',
    tooltip: 'AUTHORIZED_SIGNATORY | Legally binding corporate representative'
  });

  // 3. Shareholders / UBO Nodes (Stage 2 & 4)
  (client.shareholders || []).forEach((sh, idx) => {
    const shNodeId = `${centerNodeId}_sh_${idx}`;
    const isPep = sh.pepStatus;
    nodes.push({
      id: shNodeId,
      label: sh.name,
      subLabel: `UBO (${sh.equity}% Equity)`,
      type: 'individual',
      status: isPep ? 'flagged' : 'verified',
      x: 530,
      y: 110 + idx * 100,
      radius: 36,
      stageOrigin: 'Stage #2 (Ownership Mapping) & Stage #4 (Sanctions & PEP Screening)',
      stageCode: 'STAGE_02_04',
      details: {
        legalName: sh.name,
        registration: `Equity: ${sh.equity}%`,
        jurisdiction: client.jurisdiction,
        statusText: isPep ? 'PEP Screening Alert' : 'Cleared & Verified UBO',
        source: 'ACRA Shareholder Register & World-Check Engine',
        lastUpdated: 'Indexed via Stage #2 / #4',
        confidence: 0.97,
        dataFields: [
          { name: 'Shareholder Name', value: sh.name, confidence: 1.0, source: 'ACRA Registry', stagePopulated: 'Stage #2: Ownership Mapping' },
          { name: 'Equity Stake', value: `${sh.equity}%`, confidence: 0.99, source: 'Share Registry', stagePopulated: 'Stage #2: Ownership Mapping' },
          { name: 'PEP / Sanctions Hit', value: isPep ? 'PEP Hit - High Risk Watchlist' : 'Negative (Passed Clearance)', confidence: 0.99, source: 'World-Check', stagePopulated: 'Stage #4: Sanctions & PEP' }
        ],
        documents: [
          { id: `doc_sh_reg_${idx}`, name: 'Certified Register of Members', category: 'Shareholding Proof', status: 'verified', mandatory: true },
          { id: `doc_sh_sow_${idx}`, name: 'Source of Wealth / Funds Declaration', category: 'Enhanced Due Diligence', status: isPep ? 'pending' : 'verified', mandatory: isPep }
        ]
      }
    });
    edges.push({
      id: `e_sh_${idx}`,
      from: centerNodeId,
      to: shNodeId,
      label: `BENEFICIAL_OWNER (${sh.equity}%)`,
      tooltip: `BENEFICIAL_OWNER | Direct equity shareholder holding ${sh.equity}%`
    });
  });

  // 4. Government Business Registry Node (Stage 2)
  const regNodeId = `${centerNodeId}_registry`;
  nodes.push({
    id: regNodeId,
    label: `${client.jurisdiction} Business Registry`,
    subLabel: `ACRA / Legal Reg: ${client.registrationNumber}`,
    type: 'regulatory',
    status: 'verified',
    x: 530,
    y: 390,
    radius: 38,
    stageOrigin: 'Stage #2 • Entity Resolution & Live Registry Ingestion',
    stageCode: 'STAGE_02',
    details: {
      legalName: `${client.jurisdiction} Accounting & Corporate Regulatory Authority`,
      registration: client.registrationNumber,
      jurisdiction: client.jurisdiction,
      statusText: 'Active Registration Confirmed',
      source: 'Government BizProfile Live Registry Feed',
      lastUpdated: 'Indexed via Stage #2',
      confidence: 0.99,
      dataFields: [
        { name: 'Registry Name', value: `${client.jurisdiction} Registry (ACRA)`, confidence: 1.0, source: 'Official Govt API', stagePopulated: 'Stage #2: Entity Resolution' },
        { name: 'Registration Number', value: client.registrationNumber, confidence: 0.99, source: 'Live Registry Extract', stagePopulated: 'Stage #2: Entity Resolution' },
        { name: 'Good Standing Status', value: 'Live, Active & Compliant', confidence: 0.99, source: 'ACRA Registry Feed', stagePopulated: 'Stage #2: Entity Resolution' }
      ],
      documents: [
        { id: 'doc_acra_profile', name: 'Certified BizProfile Electronic Extract', category: 'Government Record', status: 'verified', mandatory: true }
      ]
    }
  });
  edges.push({
    id: `e_reg`,
    from: centerNodeId,
    to: regNodeId,
    label: 'REGISTRAR_VERIFIED',
    tooltip: 'REGISTRAR_VERIFIED | Officially registered with government authority'
  });

  // 5. Primary Corporate Operating Bank Account Node (Stage 6)
  const bankNodeId = `${centerNodeId}_bank`;
  nodes.push({
    id: bankNodeId,
    label: 'DBS Corporate CASA Account',
    subLabel: 'Primary Operating Account',
    type: 'account',
    status: 'verified',
    x: 350,
    y: 430,
    radius: 38,
    stageOrigin: 'Stage #6 • CASA Account & FX Limits Provisioning',
    stageCode: 'STAGE_06',
    details: {
      legalName: 'DBS Commercial Banking Singapore',
      registration: `Acc No: SGD-78234-8912 (${client.companyName})`,
      jurisdiction: 'Singapore',
      statusText: 'CASA Account Provisioned',
      source: 'DBS Core Banking Provisioning Engine',
      lastUpdated: 'Indexed via Stage #6',
      confidence: 0.99,
      dataFields: [
        { name: 'Bank Name', value: 'DBS Bank Ltd', confidence: 1.0, source: 'DBS Core Banking', stagePopulated: 'Stage #6: CASA Provisioning' },
        { name: 'Account Type', value: 'Corporate Operating CASA', confidence: 0.99, source: 'DBS Core', stagePopulated: 'Stage #6: CASA Provisioning' },
        { name: 'Escrow Status', value: 'Active & Linked', confidence: 0.99, source: 'Treasury Gateway', stagePopulated: 'Stage #6: CASA Provisioning' }
      ],
      documents: [
        { id: 'doc_casa_mandate', name: 'Board Resolution for Bank Account Opening', category: 'Banking Mandate', status: hasBoardRes ? 'verified' : 'verified', mandatory: true },
        { id: 'doc_sig_specimen', name: 'Authorized Signatory Signature Specimen', category: 'Banking Mandate', status: 'verified', mandatory: true }
      ]
    }
  });
  edges.push({
    id: `e_bank`,
    from: centerNodeId,
    to: bankNodeId,
    label: 'OPERATING_ACCOUNT',
    tooltip: 'OPERATING_ACCOUNT | Primary corporate account tied to onboarding'
  });

  // 6. Digital Asset Treasury Vault Node (Stage 8)
  const vaultNodeId = `${centerNodeId}_vault`;
  nodes.push({
    id: vaultNodeId,
    label: 'Fireblocks MPC Treasury Vault',
    subLabel: 'Institutional Multi-Sig Escrow',
    type: 'wallet',
    status: 'verified',
    x: 170,
    y: 380,
    radius: 36,
    stageOrigin: 'Stage #8 • Digital Asset & MPC Custody Provisioning',
    stageCode: 'STAGE_08',
    details: {
      legalName: 'Fireblocks Institutional Treasury Custody',
      registration: 'Vault ID: 0x1a2b...4f5e',
      jurisdiction: 'Global Institutional',
      statusText: 'Risk Score: 12 (Low Risk)',
      source: 'Fireblocks Engine & Chainalysis KYT',
      lastUpdated: 'Indexed via Stage #8',
      confidence: 0.98,
      dataFields: [
        { name: 'Custody Provider', value: 'Fireblocks Vault', confidence: 1.0, source: 'MPC Infrastructure', stagePopulated: 'Stage #8: Digital Assets' },
        { name: 'Wallet Risk Rating', value: '12 / 100 (Clean Low Risk)', confidence: 0.98, source: 'Chainalysis KYT', stagePopulated: 'Stage #8: Digital Assets' },
        { name: 'Multi-Sig Signers', value: '3-of-5 Governance Threshold Met', confidence: 0.99, source: 'Smart Contract Audit', stagePopulated: 'Stage #8: Digital Assets' }
      ],
      documents: [
        { id: 'doc_mpc_agreement', name: 'Institutional MPC Custody Agreement', category: 'Custody Mandate', status: 'verified', mandatory: true }
      ]
    }
  });
  edges.push({
    id: `e_vault`,
    from: centerNodeId,
    to: vaultNodeId,
    label: 'TREASURY_CUSTODY',
    tooltip: 'TREASURY_CUSTODY | Multi-Sig institutional crypto custody'
  });

  // 7. Tax & FATCA/CRS Classification Node (Stage 5)
  const taxNodeId = `${centerNodeId}_tax`;
  nodes.push({
    id: taxNodeId,
    label: 'FATCA / CRS Tax Classification',
    subLabel: 'Tax Residence: Singapore',
    type: 'tax',
    status: hasTaxDoc ? 'verified' : 'verified',
    x: 170,
    y: 250,
    radius: 36,
    stageOrigin: 'Stage #5 • FATCA / CRS Classification & Tax Due Diligence',
    stageCode: 'STAGE_05',
    details: {
      legalName: 'Inland Revenue Authority of Singapore (IRAS) / US IRS',
      registration: 'Tax ID: T26LL0981X',
      jurisdiction: 'Singapore',
      statusText: 'Active NFFE Tax Classification',
      source: 'Tax Classification Engine & Form W-8BEN-E',
      lastUpdated: 'Indexed via Stage #5',
      confidence: 0.98,
      dataFields: [
        { name: 'Entity Tax Classification', value: 'Active Non-Financial Foreign Entity (Active NFFE)', confidence: 0.99, source: 'W-8BEN-E Tax Rules', stagePopulated: 'Stage #5: Tax Intelligence' },
        { name: 'US Indicia Status', value: 'No US Indicia Detected', confidence: 1.0, source: 'Automated Indicia Rules', stagePopulated: 'Stage #5: Tax Intelligence' },
        { name: 'GIIN Number / Exemption', value: 'Exempt Active NFFE', confidence: 0.98, source: 'IRS Classification Table', stagePopulated: 'Stage #5: Tax Intelligence' }
      ],
      documents: [
        { id: 'doc_w8_form', name: 'Form W-8BEN-E / CRS Entity Declaration', category: 'Tax Classification', status: hasTaxDoc ? 'verified' : 'verified', mandatory: true }
      ]
    }
  });
  edges.push({
    id: `e_tax`,
    from: centerNodeId,
    to: taxNodeId,
    label: 'TAX_CLASSIFICATION',
    tooltip: 'TAX_CLASSIFICATION | FATCA & Common Reporting Standard (CRS) profile'
  });

  // Stage-by-Stage Knowledge Base Audit Timeline
  const events: EventTimelineItem[] = [
    {
      id: 'ev1',
      eventType: 'PROSPECT_INTAKE',
      stageName: 'Stage #1: Prospect Qualification',
      timestamp: 'Today 09:00',
      description: `Ingested ${client.companyName} basic registration attributes & domain records.`,
      nodeId: centerNodeId,
      badgeColor: 'bg-blue-900/60 text-blue-300 border border-blue-700'
    },
    {
      id: 'ev2',
      eventType: 'ENTITY_RESOLVED',
      stageName: 'Stage #2: Entity Resolution',
      timestamp: 'Today 09:12',
      description: `Live ACRA BizProfile data populated corporate structure, registration (${client.registrationNumber}), and ownership lines.`,
      nodeId: regNodeId,
      badgeColor: 'bg-indigo-900/60 text-indigo-300 border border-indigo-700'
    },
    {
      id: 'ev3',
      eventType: 'DYNAMIC_KYC_INDEXED',
      stageName: 'Stage #3: Dynamic KYC',
      timestamp: 'Today 09:25',
      description: `Biometric liveness data and identity documentation indexed for ${client.authorizedRepresentative.name}.`,
      nodeId: repNodeId,
      badgeColor: 'bg-emerald-900/60 text-emerald-300 border border-emerald-700'
    },
    {
      id: 'ev4',
      eventType: 'SANCTIONS_CLEARED',
      stageName: 'Stage #4: Sanctions & PEP',
      timestamp: 'Today 09:38',
      description: 'World-Check & adverse media screening findings indexed into knowledge graph.',
      nodeId: centerNodeId,
      badgeColor: 'bg-amber-900/60 text-amber-300 border border-amber-700'
    },
    {
      id: 'ev5',
      eventType: 'TAX_CLASSIFIED',
      stageName: 'Stage #5: Tax Intelligence',
      timestamp: 'Today 09:44',
      description: 'FATCA/CRS Active NFFE status computed and stored in knowledge graph.',
      nodeId: taxNodeId,
      badgeColor: 'bg-teal-900/60 text-teal-300 border border-teal-700'
    },
    {
      id: 'ev6',
      eventType: 'CASA_PROVISIONED',
      stageName: 'Stage #6: CASA Provisioning',
      timestamp: 'Today 10:00',
      description: 'Core banking operating CASA account (SGD-78234-8912) linked to entity.',
      nodeId: bankNodeId,
      badgeColor: 'bg-purple-900/60 text-purple-300 border border-purple-700'
    }
  ];

  return { nodes, edges, events };
}

export default function DigitalTwinExplorer({
  clients = MOCK_CLIENTS,
  activeClient,
  selectedClientId,
  onSelectClient,
}: DigitalTwinExplorerProps) {
  // Determine current active client
  const currentClient = useMemo(() => {
    if (activeClient) return activeClient;
    if (selectedClientId) {
      const found = clients.find(c => c.id === selectedClientId);
      if (found) return found;
    }
    return clients[0] || MOCK_CLIENTS[0];
  }, [activeClient, selectedClientId, clients]);

  // Construct Knowledge Graph data dynamically for current customer
  const { nodes, edges, events } = useMemo(() => {
    return buildCustomerGraphData(currentClient);
  }, [currentClient]);

  // Selected Node State inside the graph inspector
  const [selectedNodeId, setSelectedNodeId] = useState<string>(currentClient.id);

  // Sync selectedNodeId when currentClient changes
  React.useEffect(() => {
    setSelectedNodeId(currentClient.id);
  }, [currentClient.id]);

  // Zoom and Filter Controls
  const [zoomLevel, setZoomLevel] = useState<number>(1.0);
  const [showPersons, setShowPersons] = useState<boolean>(true);
  const [showAccounts, setShowAccounts] = useState<boolean>(true);
  const [showWallets, setShowWallets] = useState<boolean>(true);
  const [showRegulatory, setShowRegulatory] = useState<boolean>(true);

  // Feedback State
  const [isFlagged, setIsFlagged] = useState<Record<string, boolean>>({});
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Live Neo4j knowledge graph panel — a real Cypher-query read from
  // ClientOS's graph DB (src/services/graphSync.js mirrors directors/
  // shareholders/related parties/the authorized representative there on
  // every client write), shown alongside this component's own
  // client-side-derived visual graph above rather than replacing it — see
  // Nexum/services/clientos/README.md for why.
  const [showNeo4jPanel, setShowNeo4jPanel] = useState(false);
  const [neo4jData, setNeo4jData] = useState<{ nodes: ClientGraphNode[]; edges: ClientGraphEdge[] } | null>(null);
  const [neo4jLoading, setNeo4jLoading] = useState(false);
  const [neo4jError, setNeo4jError] = useState<string | null>(null);

  const fetchNeo4jGraph = () => {
    setNeo4jLoading(true);
    setNeo4jError(null);
    clientsApi.graph(currentClient.id)
      .then((data) => setNeo4jData(data))
      .catch((e) => setNeo4jError(e.message || 'Failed to load graph'))
      .finally(() => setNeo4jLoading(false));
  };

  React.useEffect(() => {
    if (showNeo4jPanel) fetchNeo4jGraph();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showNeo4jPanel, currentClient.id]);

  // Filter nodes based on visible toggles
  const visibleNodes = nodes.filter((node) => {
    if (!showPersons && node.type === 'individual') return false;
    if (!showAccounts && node.type === 'account') return false;
    if (!showWallets && node.type === 'wallet') return false;
    if (!showRegulatory && (node.type === 'regulatory' || node.type === 'tax')) return false;
    return true;
  });

  const visibleNodeIds = new Set(visibleNodes.map((n) => n.id));
  const visibleEdges = edges.filter(
    (e) => visibleNodeIds.has(e.from) && visibleNodeIds.has(e.to)
  );

  const selectedNode = nodes.find((n) => n.id === selectedNodeId) || nodes[0];

  const handleFlagNode = () => {
    const nextFlagState = !isFlagged[selectedNodeId];
    setIsFlagged((prev) => ({ ...prev, [selectedNodeId]: nextFlagState }));
    setToastMessage(
      nextFlagState
        ? `Flagged ${selectedNode.label} for Compliance Override`
        : `Cleared flag for ${selectedNode.label}`
    );
    setTimeout(() => setToastMessage(null), 3000);
  };

  const getNodeColorClass = (status: NodeVerificationStatus, type: NodeType) => {
    if (status === 'flagged') {
      return {
        bg: 'bg-rose-500',
        stroke: '#f43f5e',
        fill: '#fff1f2',
        ring: 'ring-rose-400',
        text: 'text-rose-700 bg-rose-50 border-rose-200'
      };
    }
    if (status === 'amber' || status === 'pending') {
      return {
        bg: 'bg-amber-500',
        stroke: '#f59e0b',
        fill: '#fffbeb',
        ring: 'ring-amber-400',
        text: 'text-amber-800 bg-amber-50 border-amber-200'
      };
    }
    if (type === 'entity') {
      return {
        bg: 'bg-blue-600',
        stroke: '#0474C4',
        fill: '#eff6ff',
        ring: 'ring-blue-400',
        text: 'text-blue-800 bg-blue-50 border-blue-200'
      };
    }
    if (type === 'individual') {
      return {
        bg: 'bg-emerald-600',
        stroke: '#10b981',
        fill: '#ecfdf5',
        ring: 'ring-emerald-400',
        text: 'text-emerald-800 bg-emerald-50 border-emerald-200'
      };
    }
    if (type === 'regulatory' || type === 'tax') {
      return {
        bg: 'bg-indigo-600',
        stroke: '#6366f1',
        fill: '#e0e7ff',
        ring: 'ring-indigo-400',
        text: 'text-indigo-800 bg-indigo-50 border-indigo-200'
      };
    }
    if (type === 'account') {
      return {
        bg: 'bg-purple-600',
        stroke: '#a855f7',
        fill: '#faf5ff',
        ring: 'ring-purple-400',
        text: 'text-purple-800 bg-purple-50 border-purple-200'
      };
    }
    return {
      bg: 'bg-teal-600',
      stroke: '#14b8a6',
      fill: '#f0fdfa',
      ring: 'ring-teal-400',
      text: 'text-teal-800 bg-teal-50 border-teal-200'
    };
  };

  const getIconForNodeType = (type: NodeType) => {
    switch (type) {
      case 'entity':
        return <Building2 className="w-4 h-4" />;
      case 'individual':
        return <User className="w-4 h-4" />;
      case 'regulatory':
        return <ShieldCheck className="w-4 h-4" />;
      case 'account':
        return <Landmark className="w-4 h-4" />;
      case 'wallet':
        return <Wallet className="w-4 h-4" />;
      case 'tax':
        return <FileCheck className="w-4 h-4" />;
    }
  };

  return (
    <div className="flex flex-col min-h-[750px] bg-slate-950 text-slate-100 rounded-2xl overflow-hidden border border-slate-800 shadow-2xl font-sans relative">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 bg-slate-800 text-white border border-blue-500/50 px-4 py-2 rounded-xl shadow-2xl text-xs font-semibold flex items-center gap-2 animate-bounce">
          <Sparkles className="w-4 h-4 text-blue-400 animate-spin" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Neo4j Live Knowledge Graph Panel — slide-over, real Cypher read */}
      {showNeo4jPanel && (
        <div className="absolute top-0 right-0 bottom-0 w-full sm:w-96 z-40 bg-slate-900 border-l border-slate-700 shadow-2xl flex flex-col">
          <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between shrink-0">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono font-bold uppercase tracking-wider text-blue-400">
                <Bot className="w-3.5 h-3.5" />
                <span>Knowledge Graph · Live from Neo4j</span>
              </div>
              <p className="text-[10px] text-slate-500 mt-0.5">
                ClientOS's graph DB for {currentClient.companyName} — queried directly, not derived from this view.
              </p>
            </div>
            <button
              onClick={() => setShowNeo4jPanel(false)}
              className="text-slate-500 hover:text-white text-lg leading-none px-1 cursor-pointer"
              title="Close"
            >
              &times;
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {neo4jLoading && (
              <p className="text-xs text-slate-400 font-mono">Querying Neo4j…</p>
            )}
            {neo4jError && (
              <div className="text-xs text-rose-300 bg-rose-500/10 border border-rose-500/30 rounded-lg p-3">
                {neo4jError}
                <button onClick={fetchNeo4jGraph} className="block mt-2 underline cursor-pointer">Retry</button>
              </div>
            )}
            {neo4jData && !neo4jLoading && !neo4jError && (
              neo4jData.nodes.length === 0 ? (
                <p className="text-xs text-slate-500 font-mono">
                  No graph data yet for this client — it's written the first time the client record is saved.
                </p>
              ) : (
                <>
                  <div>
                    <span className="text-[10px] font-mono uppercase text-slate-500 tracking-wider">Nodes ({neo4jData.nodes.length})</span>
                    <div className="mt-2 space-y-2">
                      {neo4jData.nodes.map((n) => (
                        <div key={n.id} className="bg-slate-800/70 border border-slate-700 rounded-lg p-2.5">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-semibold text-white">{n.label || '(unnamed)'}</span>
                            <span className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30">
                              {n.type}
                            </span>
                          </div>
                          <div className="mt-1 space-y-0.5">
                            {Object.entries(n.properties)
                              .filter(([k]) => !['clientId', 'name', 'companyName'].includes(k))
                              .map(([k, v]) => (
                                <div key={k} className="text-[10px] text-slate-400 font-mono">
                                  {k}: <span className="text-slate-300">{String(v)}</span>
                                </div>
                              ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {neo4jData.edges.length > 0 && (
                    <div>
                      <span className="text-[10px] font-mono uppercase text-slate-500 tracking-wider">Relationships ({neo4jData.edges.length})</span>
                      <div className="mt-2 space-y-1">
                        {neo4jData.edges.map((e) => (
                          <div key={e.id} className="text-[10px] font-mono text-slate-400 flex items-center gap-1.5">
                            <span className="text-blue-400">{currentClient.companyName}</span>
                            <span className="text-slate-600">—[{e.type}]→</span>
                            <span className="text-slate-300">
                              {neo4jData.nodes.find((n) => n.id === e.to)?.label || e.to}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )
            )}
          </div>
        </div>
      )}

      {/* TOP HEADER: CUSTOMER SELECTOR & KNOWLEDGE BASE METADATA */}
      <div className="px-6 py-4 bg-slate-900 border-b border-slate-800 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 shrink-0">
        
        {/* Left: Title & Customer Selector */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 w-full lg:w-auto">
          <div className="p-2.5 bg-blue-600/20 text-blue-400 rounded-xl border border-blue-500/30 shrink-0">
            <Database className="w-5 h-5 text-blue-400" />
          </div>

          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] font-mono tracking-wider text-blue-400 uppercase font-bold">
                Underlying Knowledge Base & Digital Twin
              </span>
              <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-mono">
                STAGE-BY-STAGE ACCUMULATED
              </span>
            </div>

            {/* Customer Dropdown Selector */}
            <div className="flex items-center gap-2 mt-1">
              <span className="text-xs text-slate-400 font-mono font-bold shrink-0">
                Entity Profile:
              </span>
              <div className="relative">
                <select
                  value={currentClient.id}
                  onChange={(e) => {
                    if (onSelectClient) onSelectClient(e.target.value);
                  }}
                  className="bg-slate-800 hover:bg-slate-700 text-white font-bold text-sm px-3 py-1.5 pr-8 rounded-xl border border-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer shadow-md appearance-none font-sans"
                >
                  {clients.map((c) => (
                    <option key={c.id} value={c.id} className="bg-slate-900 text-white">
                      {c.companyName} ({c.jurisdiction})
                    </option>
                  ))}
                </select>
                <ChevronDown className="w-4 h-4 text-blue-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>
          </div>
        </div>

        {/* Right: Customer Quick Metadata Pills */}
        <div className="flex items-center gap-3 flex-wrap text-xs font-mono">
          <div className="px-3 py-1.5 bg-slate-800/90 border border-slate-700 rounded-xl flex items-center gap-2">
            <Building2 className="w-3.5 h-3.5 text-blue-400" />
            <span className="text-slate-300">UEN: <strong className="text-white">{currentClient.registrationNumber}</strong></span>
          </div>

          <div className="px-3 py-1.5 bg-slate-800/90 border border-slate-700 rounded-xl flex items-center gap-2">
            <FileText className="w-3.5 h-3.5 text-indigo-400" />
            <span className="text-slate-300">Docs Attached: <strong className="text-indigo-300">{(currentClient.documents || []).length}</strong></span>
          </div>

          <div className="px-3 py-1.5 bg-slate-800/90 border border-slate-700 rounded-xl flex items-center gap-2">
            <span className="text-slate-300">Lifecycle State:</span>
            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
              currentClient.overallStatus === 'approved'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                : currentClient.overallStatus === 'rejected'
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
            }`}>
              {currentClient.overallStatus}
            </span>
          </div>
        </div>
      </div>

      {/* GRAPH CONTROL & FILTER TOOLBAR */}
      <div className="px-6 py-2.5 bg-slate-900/60 border-b border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        {/* Node Filters */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-slate-400 font-mono text-[10px] uppercase font-bold tracking-wider">Knowledge Layers:</span>
          <button
            onClick={() => setShowPersons(!showPersons)}
            className={`px-2.5 py-1 rounded-lg border text-xs font-medium flex items-center gap-1.5 cursor-pointer transition ${
              showPersons ? 'bg-emerald-600/20 text-emerald-300 border-emerald-500/40' : 'bg-slate-800 text-slate-500 border-slate-700'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Individuals & UBOs</span>
          </button>

          <button
            onClick={() => setShowAccounts(!showAccounts)}
            className={`px-2.5 py-1 rounded-lg border text-xs font-medium flex items-center gap-1.5 cursor-pointer transition ${
              showAccounts ? 'bg-purple-600/20 text-purple-300 border-purple-500/40' : 'bg-slate-800 text-slate-500 border-slate-700'
            }`}
          >
            <Landmark className="w-3.5 h-3.5" />
            <span>Bank & CASA</span>
          </button>

          <button
            onClick={() => setShowWallets(!showWallets)}
            className={`px-2.5 py-1 rounded-lg border text-xs font-medium flex items-center gap-1.5 cursor-pointer transition ${
              showWallets ? 'bg-teal-600/20 text-teal-300 border-teal-500/40' : 'bg-slate-800 text-slate-500 border-slate-700'
            }`}
          >
            <Wallet className="w-3.5 h-3.5" />
            <span>Treasury Custody</span>
          </button>

          <button
            onClick={() => setShowRegulatory(!showRegulatory)}
            className={`px-2.5 py-1 rounded-lg border text-xs font-medium flex items-center gap-1.5 cursor-pointer transition ${
              showRegulatory ? 'bg-indigo-600/20 text-indigo-300 border-indigo-500/40' : 'bg-slate-800 text-slate-500 border-slate-700'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Registry & Tax</span>
          </button>
        </div>

        {/* Zoom Controls */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-slate-800 rounded-lg border border-slate-700 p-0.5">
            <button
              onClick={() => setZoomLevel((prev) => Math.max(0.6, prev - 0.1))}
              className="p-1 text-slate-400 hover:text-white transition cursor-pointer"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="px-2 text-[10px] font-mono text-slate-300">
              {Math.round(zoomLevel * 100)}%
            </span>
            <button
              onClick={() => setZoomLevel((prev) => Math.min(1.6, prev + 0.1))}
              className="p-1 text-slate-400 hover:text-white transition cursor-pointer"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setZoomLevel(1.0)}
              className="p-1 text-slate-400 hover:text-white border-l border-slate-700 ml-1 transition cursor-pointer"
              title="Reset Zoom"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>

          <button
            onClick={() => setShowNeo4jPanel(!showNeo4jPanel)}
            className={`px-2.5 py-1 rounded-lg border text-xs font-medium flex items-center gap-1.5 cursor-pointer transition ${
              showNeo4jPanel ? 'bg-blue-600/20 text-blue-300 border-blue-500/40' : 'bg-slate-800 text-slate-500 border-slate-700'
            }`}
            title="Query ClientOS's Neo4j knowledge graph directly, live"
          >
            <Bot className="w-3.5 h-3.5" />
            <span>Knowledge Graph (Neo4j)</span>
          </button>
        </div>
      </div>

      {/* MAIN TWO-COLUMN SPLIT: INTERACTIVE GRAPH (LEFT) & KNOWLEDGE INSPECTOR (RIGHT) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 flex-1 relative">
        
        {/* ==================== LEFT GRAPH VIEW (65% / 8 cols) ==================== */}
        <div className="lg:col-span-8 bg-slate-950 p-4 flex items-center justify-center relative overflow-hidden min-h-[500px]">
          
          {/* Subtle Grid Background */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b15_1px,transparent_1px),linear-gradient(to_bottom,#1e293b15_1px,transparent_1px)] bg-[size:28px_28px] pointer-events-none" />

          {/* SVG Canvas */}
          <svg
            className="w-full h-full min-h-[520px] max-h-[660px]"
            viewBox="0 0 700 520"
            style={{ transform: `scale(${zoomLevel})`, transformOrigin: 'center center', transition: 'transform 0.2s ease-out' }}
          >
            <defs>
              <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="3" result="blur" />
                <feComposite in="SourceGraphic" in2="blur" operator="over" />
              </filter>
              <marker
                id="arrowhead"
                markerWidth="8"
                markerHeight="6"
                refX="7"
                refY="3"
                orient="auto"
              >
                <polygon points="0 0, 8 3, 0 6" fill="#64748b" />
              </marker>
            </defs>

            {/* Render Graph Edges */}
            {visibleEdges.map((edge) => {
              const fromNode = nodes.find((n) => n.id === edge.from);
              const toNode = nodes.find((n) => n.id === edge.to);
              if (!fromNode || !toNode) return null;

              const isConnectedToSelected =
                fromNode.id === selectedNodeId || toNode.id === selectedNodeId;

              const midX = (fromNode.x + toNode.x) / 2;
              const midY = (fromNode.y + toNode.y) / 2;

              return (
                <g key={edge.id} className="transition-all duration-300">
                  <line
                    x1={fromNode.x}
                    y1={fromNode.y}
                    x2={toNode.x}
                    y2={toNode.y}
                    stroke={isConnectedToSelected ? '#38bdf8' : '#334155'}
                    strokeWidth={isConnectedToSelected ? 2.5 : 1.5}
                    strokeDasharray={isConnectedToSelected ? undefined : '4 3'}
                  />
                  {/* Edge Label Pill */}
                  <g transform={`translate(${midX}, ${midY})`}>
                    <rect
                      x="-65"
                      y="-9"
                      width="130"
                      height="18"
                      rx="9"
                      fill="#0f172a"
                      stroke={isConnectedToSelected ? '#00A3E0' : '#475569'}
                      strokeWidth="1"
                    />
                    <text
                      x="0"
                      y="3"
                      textAnchor="middle"
                      fill={isConnectedToSelected ? '#38bdf8' : '#94a3b8'}
                      fontSize="8"
                      fontWeight="bold"
                      fontFamily="monospace"
                    >
                      {edge.label}
                    </text>
                  </g>
                </g>
              );
            })}

            {/* Render Graph Nodes */}
            {visibleNodes.map((node) => {
              const colorInfo = getNodeColorClass(node.status, node.type);
              const isSelected = node.id === selectedNodeId;
              const isCenterEntity = node.id === currentClient.id;
              const r = node.radius || (isCenterEntity ? 50 : 36);

              return (
                <g
                  key={node.id}
                  transform={`translate(${node.x}, ${node.y})`}
                  onClick={() => setSelectedNodeId(node.id)}
                  className="cursor-pointer group"
                >
                  {/* Glowing Outer Ring for Selected Node or Center Entity */}
                  {(isSelected || isCenterEntity) && (
                    <circle
                      r={r + 8}
                      fill="none"
                      stroke={isSelected ? '#38bdf8' : '#3b82f6'}
                      strokeWidth="2"
                      strokeDasharray="6 3"
                      className="animate-spin-slow"
                    />
                  )}

                  {/* Node Main Circle */}
                  <circle
                    r={r}
                    fill={colorInfo.fill}
                    stroke={isSelected ? '#00A3E0' : colorInfo.stroke}
                    strokeWidth={isSelected ? 3.5 : 2}
                    filter={isSelected ? 'url(#glow)' : undefined}
                    className="transition-all duration-200 group-hover:scale-105"
                  />

                  {/* Icon & Label */}
                  <foreignObject x={-r} y={-r} width={r * 2} height={r * 2} className="pointer-events-none">
                    <div className="w-full h-full flex flex-col items-center justify-center text-center p-1">
                      <div className={`p-1.5 rounded-full text-white ${colorInfo.bg} shadow-md mb-0.5`}>
                        {getIconForNodeType(node.type)}
                      </div>
                      <span className="text-[9px] font-bold text-slate-900 truncate max-w-full px-1">
                        {node.label}
                      </span>
                    </div>
                  </foreignObject>

                  {/* Verification Status Badge Dot */}
                  <circle
                    cx={r * 0.7}
                    cy={-r * 0.7}
                    r="8"
                    fill={node.status === 'verified' ? '#10b981' : node.status === 'flagged' ? '#f43f5e' : '#f59e0b'}
                    stroke="#0f172a"
                    strokeWidth="2"
                  />
                </g>
              );
            })}
          </svg>

          {/* Graph Legend & Instructions */}
          <div className="absolute bottom-4 left-4 z-10 bg-slate-900/90 border border-slate-800 rounded-xl p-2.5 backdrop-blur-sm flex items-center gap-4 text-[10px] font-mono text-slate-300">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
              <span>Entity Profile</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span>Individuals / UBO</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-500" />
              <span>Registry / Tax</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-purple-500" />
              <span>Bank & Treasury</span>
            </div>
          </div>
        </div>

        {/* ==================== RIGHT KNOWLEDGE INSPECTOR (35% / 4 cols) ==================== */}
        <div className="lg:col-span-4 bg-slate-900 flex flex-col justify-between overflow-y-auto max-h-[750px] border-t lg:border-t-0 border-slate-800 p-5">
          <div className="space-y-4">
            
            {/* Inspector Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-blue-600/20 text-blue-400 rounded-lg">
                  {getIconForNodeType(selectedNode.type)}
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white truncate max-w-[200px]">
                    {selectedNode.label}
                  </h3>
                  <span className="text-[10px] font-mono text-slate-400 block">
                    {selectedNode.subLabel}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleFlagNode}
                  className={`p-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                    isFlagged[selectedNodeId]
                      ? 'bg-rose-500/20 text-rose-400 border border-rose-500/50'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-400 border border-slate-700'
                  }`}
                  title={isFlagged[selectedNodeId] ? 'Clear Flag' : 'Flag Compliance'}
                >
                  <Flag className="w-3.5 h-3.5 text-rose-400" />
                </button>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono uppercase ${
                  getNodeColorClass(selectedNode.status, selectedNode.type).text
                }`}>
                  {selectedNode.status}
                </span>
              </div>
            </div>

            {/* Stage Provenance Banner (Explaining which Onboarding Stage Populated This Node) */}
            <div className="bg-gradient-to-r from-blue-950/60 to-indigo-950/40 border border-blue-800/40 rounded-xl p-3 space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono uppercase tracking-wider text-blue-400 font-bold flex items-center gap-1">
                  <Database className="w-3 h-3 text-blue-400" />
                  Stage Knowledge Provenance
                </span>
                <span className="text-[9px] bg-blue-500/20 text-blue-300 font-mono font-bold px-1.5 py-0.5 rounded">
                  {selectedNode.stageCode}
                </span>
              </div>
              <p className="text-xs font-semibold text-slate-200">
                {selectedNode.stageOrigin}
              </p>
              <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 font-mono">
                <span>Verified Source: <strong className="text-slate-300">{selectedNode.details.source}</strong></span>
              </div>
            </div>

            {/* Copilot Assistant Hint Card */}
            <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-2.5 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-blue-500/10 text-blue-400 rounded-lg">
                  <Bot className="w-4 h-4" />
                </div>
                <div className="text-[11px] text-slate-300">
                  <span>Need to add documents or verify details?</span>
                  <span className="text-slate-500 block text-[10px]">Drop files into Copilot or the Journey Document node.</span>
                </div>
              </div>
            </div>

            {/* Attached / Required Document Evidence Section */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono flex items-center gap-1.5">
                  <FileCheck className="w-4 h-4 text-indigo-400" />
                  Linked Proof Documents ({selectedNode.details.documents.length})
                </h4>
              </div>

              <div className="space-y-1.5">
                {selectedNode.details.documents.map((docReq) => (
                  <div
                    key={docReq.id}
                    className="bg-slate-950/80 border border-slate-800 rounded-xl p-2.5 flex items-center justify-between text-xs hover:border-slate-700 transition"
                  >
                    <div className="flex items-center gap-2 overflow-hidden">
                      <div className={`p-1 rounded ${docReq.status === 'verified' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'}`}>
                        <FileText className="w-3.5 h-3.5" />
                      </div>
                      <div className="truncate">
                        <p className="font-semibold text-slate-200 truncate">{docReq.name}</p>
                        <span className="text-[9px] text-slate-500 font-mono block">{docReq.category}</span>
                      </div>
                    </div>

                    <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold shrink-0 uppercase ${
                      docReq.status === 'verified' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-amber-500/20 text-amber-300'
                    }`}>
                      {docReq.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Verified Data Vault Fields */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                Underlying Knowledge Base Fields ({selectedNode.details.dataFields.length})
              </h4>

              <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                {selectedNode.details.dataFields.map((field, idx) => (
                  <div
                    key={idx}
                    className="bg-slate-950/80 border border-slate-800 hover:border-slate-700 rounded-xl p-2.5 text-xs space-y-1 transition"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 font-mono text-[11px]">{field.name}</span>
                      <span className="text-[10px] font-mono text-emerald-400 font-bold">
                        {Math.round(field.confidence * 100)}% Match
                      </span>
                    </div>
                    <p className="font-bold text-slate-100 break-words text-xs">
                      {field.value}
                    </p>
                    <div className="flex items-center justify-between text-[9px] text-slate-500 font-mono pt-0.5">
                      <span>Source: {field.source}</span>
                      {field.stagePopulated && <span className="text-blue-400 font-semibold">{field.stagePopulated}</span>}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Audit Log Timeline */}
            <div className="space-y-2 border-t border-slate-800 pt-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-blue-400" />
                Stage Ingestion Audit Trail
              </h4>

              <div className="space-y-1.5 max-h-[140px] overflow-y-auto pr-1">
                {events.map((ev) => (
                  <div key={ev.id} className="bg-slate-950 border border-slate-800 rounded-xl p-2 text-xs">
                    <div className="flex items-center justify-between mb-0.5">
                      <span className={`px-1.5 py-0.5 rounded text-[8px] font-mono font-bold uppercase ${ev.badgeColor}`}>
                        {ev.stageName}
                      </span>
                      <span className="text-[9px] text-slate-500 font-mono">{ev.timestamp}</span>
                    </div>
                    <p className="text-slate-300 text-[11px] leading-tight mt-1">
                      {ev.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
}
