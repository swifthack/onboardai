import React, { useState } from 'react';
import { 
  Check, 
  Loader2, 
  AlertTriangle, 
  Clock, 
  Layers,
  Lock,
  GripHorizontal
} from 'lucide-react';
import { WorkflowNode, NodeStatus } from '../../types';

interface JourneyStepperProps {
  nodes: WorkflowNode[];
  selectedNodeId: string;
  onSelectNode: (nodeId: string) => void;
  activeRunningNodeId?: string;
  onReorderNodes?: (reorderedNodes: WorkflowNode[]) => void;
}

export const JourneyStepper: React.FC<JourneyStepperProps> = ({
  nodes,
  selectedNodeId,
  onSelectNode,
  activeRunningNodeId,
  onReorderNodes
}) => {
  const [draggedNodeId, setDraggedNodeId] = useState<string | null>(null);
  const [dragOverNodeId, setDragOverNodeId] = useState<string | null>(null);
  const [lockToast, setLockToast] = useState<string | null>(null);

  const totalNodes = nodes.length;
  const completedNodes = nodes.filter(n => n.status === 'completed').length;
  const runningNodes = nodes.filter(n => n.status === 'running' || n.id === activeRunningNodeId).length;
  const flaggedNodes = nodes.filter(n => n.status === 'flagged').length;
  const awaitingNodes = nodes.filter(n => n.status === 'awaiting_approval').length;

  const percentage = totalNodes > 0 ? Math.round((completedNodes / totalNodes) * 100) : 0;

  const showLockNotification = (msg: string) => {
    setLockToast(msg);
    setTimeout(() => setLockToast(null), 3500);
  };

  const isStageLocked = (node: WorkflowNode) => {
    return node.status === 'completed';
  };

  const handleDragStart = (e: React.DragEvent, node: WorkflowNode) => {
    if (isStageLocked(node)) {
      e.preventDefault();
      showLockNotification(`🔒 Stage #${nodes.findIndex(n => n.id === node.id) + 1} (${node.name}) is verified & finalized. Completed stages are locked against re-ordering.`);
      return;
    }
    setDraggedNodeId(node.id);
    e.dataTransfer.setData('text/plain', node.id);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent, targetNode: WorkflowNode) => {
    e.preventDefault();
    if (dragOverNodeId !== targetNode.id) {
      setDragOverNodeId(targetNode.id);
    }
  };

  const handleDrop = (e: React.DragEvent, targetNode: WorkflowNode) => {
    e.preventDefault();
    e.stopPropagation();

    if (!draggedNodeId || draggedNodeId === targetNode.id) {
      setDraggedNodeId(null);
      setDragOverNodeId(null);
      return;
    }

    const sourceIndex = nodes.findIndex(n => n.id === draggedNodeId);
    const targetIndex = nodes.findIndex(n => n.id === targetNode.id);

    if (sourceIndex === -1 || targetIndex === -1) return;

    const sourceNode = nodes[sourceIndex];

    // Lock enforcement: cannot move a completed node, nor move a node onto/before a completed node if it disrupts verified order
    if (isStageLocked(sourceNode) || isStageLocked(targetNode)) {
      showLockNotification("🔒 Reordering Blocked: Verified & completed stages are automatically locked to preserve workflow integrity.");
      setDraggedNodeId(null);
      setDragOverNodeId(null);
      return;
    }

    // Check if any locked completed node exists between source and target
    const startIdx = Math.min(sourceIndex, targetIndex);
    const endIdx = Math.max(sourceIndex, targetIndex);
    const hasLockedInBetween = nodes.slice(startIdx, endIdx + 1).some(n => isStageLocked(n));

    if (hasLockedInBetween) {
      showLockNotification("🔒 Sequence Lock: Cannot move stage across finalized/completed stage boundaries.");
      setDraggedNodeId(null);
      setDragOverNodeId(null);
      return;
    }

    if (onReorderNodes) {
      const nextNodes = [...nodes];
      const [moved] = nextNodes.splice(sourceIndex, 1);
      nextNodes.splice(targetIndex, 0, moved);
      onReorderNodes(nextNodes);
    }

    setDraggedNodeId(null);
    setDragOverNodeId(null);
  };

  const getStatusColor = (status: NodeStatus, isRunning: boolean) => {
    if (isRunning || status === 'running') {
      return {
        bg: 'bg-blue-600 text-white dark:bg-blue-500 ring-4 ring-blue-100 dark:ring-blue-900/40',
        line: 'bg-blue-500',
        badge: 'bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800',
        text: 'text-blue-600 dark:text-blue-400',
        label: 'Running'
      };
    }
    switch (status) {
      case 'completed':
        return {
          bg: 'bg-emerald-600 text-white dark:bg-emerald-500 ring-4 ring-emerald-100 dark:ring-emerald-950/40',
          line: 'bg-emerald-500',
          badge: 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
          text: 'text-emerald-600 dark:text-emerald-400',
          label: 'Completed'
        };
      case 'flagged':
        return {
          bg: 'bg-rose-600 text-white dark:bg-rose-500 ring-4 ring-rose-100 dark:ring-rose-950/40',
          line: 'bg-rose-300 dark:bg-rose-800',
          badge: 'bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800',
          text: 'text-rose-600 dark:text-rose-400',
          label: 'Flagged'
        };
      case 'awaiting_approval':
        return {
          bg: 'bg-amber-500 text-white ring-4 ring-amber-100 dark:ring-amber-950/40',
          line: 'bg-amber-300 dark:bg-amber-800',
          badge: 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800',
          text: 'text-amber-600 dark:text-amber-400',
          label: 'Review Req.'
        };
      case 'pending':
      default:
        return {
          bg: 'bg-slate-200 dark:bg-slate-800 text-slate-500 dark:text-slate-400',
          line: 'bg-slate-200 dark:bg-slate-800',
          badge: 'bg-slate-100 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-700',
          text: 'text-slate-500 dark:text-slate-400',
          label: 'Pending'
        };
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 mb-6 shadow-sm relative">
      
      {/* Lock Enforcement Toast Banner */}
      {lockToast && (
        <div className="mb-4 p-3 bg-amber-500/15 border border-amber-500/40 text-amber-800 dark:text-amber-200 rounded-lg text-xs font-semibold flex items-center justify-between gap-2 shadow-sm animate-pulse">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
            <span>{lockToast}</span>
          </div>
          <button 
            onClick={() => setLockToast(null)}
            className="text-[10px] font-mono uppercase underline text-amber-700 dark:text-amber-300 hover:text-amber-900 cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Top Bar: Title, Completion %, and Breakdown */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 mb-5 border-b border-slate-100 dark:border-slate-800/80">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 rounded-lg border border-indigo-100 dark:border-indigo-900/50">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider font-mono">
                Onboarding Progress & Lifecycle Stepper
              </h3>
              <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                {completedNodes} / {totalNodes} Stages Complete
              </span>
              {completedNodes > 0 && (
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 flex items-center gap-1" title="Completed stages are automatically locked against manual reordering">
                  <Lock className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                  {completedNodes} Stage(s) Locked
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Click any stage in the workflow sequence below to inspect node execution logs and details.
            </p>
          </div>
        </div>

        {/* Progress gauge & breakdown */}
        <div className="flex items-center gap-5">
          {/* Status Breakdown Pills */}
          <div className="hidden lg:flex items-center gap-2 text-[11px] font-mono">
            {completedNodes > 0 && (
              <span className="px-2 py-0.5 rounded-md bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/60 font-semibold flex items-center gap-1">
                <Check className="w-3 h-3" /> {completedNodes} Done
              </span>
            )}
            {runningNodes > 0 && (
              <span className="px-2 py-0.5 rounded-md bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800/60 font-semibold flex items-center gap-1 animate-pulse">
                <Loader2 className="w-3 h-3 animate-spin" /> {runningNodes} Active
              </span>
            )}
            {flaggedNodes > 0 && (
              <span className="px-2 py-0.5 rounded-md bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800/60 font-semibold flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" /> {flaggedNodes} Flagged
              </span>
            )}
            {awaitingNodes > 0 && (
              <span className="px-2 py-0.5 rounded-md bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800/60 font-semibold flex items-center gap-1">
                <Clock className="w-3 h-3" /> {awaitingNodes} Review
              </span>
            )}
          </div>

          {/* Progress Bar & Percentage */}
          <div className="flex items-center gap-3 bg-slate-50 dark:bg-slate-950/50 px-3.5 py-2 rounded-xl border border-slate-100 dark:border-slate-800">
            <div className="text-right">
              <span className="text-[10px] font-mono font-bold text-slate-400 dark:text-slate-500 uppercase block leading-none">STAGE COMPLETION</span>
              <span className="text-base font-extrabold font-mono text-indigo-600 dark:text-indigo-400">
                {percentage}%
              </span>
            </div>
            <div className="w-28 h-2 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden border border-slate-200/50 dark:border-slate-700/50">
              <div 
                className="h-full bg-gradient-to-r from-indigo-500 via-blue-500 to-emerald-500 transition-all duration-500 rounded-full" 
                style={{ width: `${percentage}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Horizontal Interactive Stepper with Drag & Drop Lock Enforcement */}
      <div className="relative overflow-x-auto pb-2 scrollbar-thin">
        <div className="flex items-center justify-between min-w-[760px] px-2">
          {nodes.map((node, index) => {
            const isRunning = node.id === activeRunningNodeId || node.status === 'running';
            const isSelected = node.id === selectedNodeId;
            const style = getStatusColor(node.status, isRunning);
            const isCompleted = node.status === 'completed';
            const isFlagged = node.status === 'flagged';
            const isAwaiting = node.status === 'awaiting_approval';
            const locked = isStageLocked(node);

            const isDragged = draggedNodeId === node.id;
            const isDragOver = dragOverNodeId === node.id;

            return (
              <React.Fragment key={node.id}>
                <div
                  draggable={!locked}
                  onDragStart={(e) => handleDragStart(e, node)}
                  onDragOver={(e) => handleDragOver(e, node)}
                  onDrop={(e) => handleDrop(e, node)}
                  className={`relative group ${isDragged ? 'opacity-40 scale-95' : ''} ${isDragOver && !locked ? 'ring-2 ring-indigo-500 rounded-xl bg-indigo-50/20' : ''}`}
                >
                  <button
                    type="button"
                    onClick={() => onSelectNode(node.id)}
                    className={`flex flex-col items-center text-center focus:outline-none cursor-pointer transition-all duration-200 px-2.5 py-1.5 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800/40 shrink-0 ${
                      isSelected ? 'ring-2 ring-indigo-500/50 bg-indigo-50/50 dark:bg-indigo-950/30' : ''
                    }`}
                    title={locked ? "🔒 Verified & Finalized: Stage is locked against manual re-ordering" : "Drag to re-order pending stages"}
                  >
                    {/* Step Circle Icon */}
                    <div 
                      className={`w-9 h-9 rounded-full flex items-center justify-center font-bold font-mono text-xs z-10 transition-transform hover:scale-105 shadow-sm relative ${style.bg}`}
                    >
                      {isCompleted ? (
                        <Check className="w-4 h-4 stroke-[3]" />
                      ) : isRunning ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : isFlagged ? (
                        <AlertTriangle className="w-4 h-4" />
                      ) : isAwaiting ? (
                        <Clock className="w-4 h-4" />
                      ) : (
                        <span>{index + 1}</span>
                      )}

                      {/* Lock Icon Badge overlay for completed stages */}
                      {locked && (
                        <span className="absolute -bottom-1 -right-1 bg-emerald-700 text-white p-0.5 rounded-full border border-white dark:border-slate-900 shadow-sm" title="Completed stage locked against manual re-ordering">
                          <Lock className="w-2.5 h-2.5" />
                        </span>
                      )}
                    </div>

                    {/* Step Name & Status */}
                    <div className="mt-2 max-w-[110px] flex flex-col items-center">
                      <span className={`text-xs font-bold line-clamp-1 block ${
                        isSelected ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-800 dark:text-slate-200'
                      }`}>
                        {node.name}
                      </span>
                      
                      <div className="flex items-center gap-1 mt-1">
                        <span className={`inline-block text-[9px] font-mono font-bold uppercase px-1.5 py-0.5 rounded border ${style.badge}`}>
                          {style.label}
                        </span>
                        {locked ? (
                          <span className="text-[8px] font-mono font-extrabold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300 px-1 py-0.2 rounded flex items-center gap-0.5">
                            <Lock className="w-2 h-2" /> Locked
                          </span>
                        ) : (
                          <span className="hidden group-hover:inline-block text-[8px] font-mono text-slate-400">
                            <GripHorizontal className="w-2.5 h-2.5 inline" />
                          </span>
                        )}
                      </div>
                    </div>
                  </button>
                </div>

                {/* Connecting Line (if not last step) */}
                {index < nodes.length - 1 && (
                  <div className="flex-1 mx-1.5 h-0.5 relative top-[-18px] min-w-[20px]">
                    <div className="w-full h-full bg-slate-200 dark:bg-slate-800 rounded-full" />
                    <div 
                      className={`absolute top-0 left-0 h-full rounded-full transition-all duration-500 ${
                        isCompleted ? 'w-full bg-emerald-500' : isRunning ? 'w-1/2 bg-blue-500 animate-pulse' : 'w-0'
                      }`}
                    />
                  </div>
                )}
              </React.Fragment>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default JourneyStepper;
