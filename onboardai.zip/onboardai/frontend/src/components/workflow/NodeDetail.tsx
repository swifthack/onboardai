import React, { useState, useEffect } from 'react';
import { WorkflowNode, ClientProfile, AppPersona, NodeStatus, OrchestrationAgent } from '../../types';
import { INITIAL_AGENTS } from '../../mockData';
import { 
  Bot, 
  CheckSquare, 
  AlertTriangle, 
  ShieldAlert,
  ChevronRight, 
  HelpCircle, 
  Loader2, 
  Database,
  FileCheck,
  Award,
  ClipboardCheck,
  Coins,
  ArrowRight,
  Layers,
  Cpu
} from 'lucide-react';

// Mirrors App.tsx's handleRaiseClarification target computation — just for
// the read-only "will be routed to..." preview before the clarification
// exists. When the stage has a design-time reviewerRole (see JourneyStage
// in PersonaSubviews.tsx / WorkflowNode in types.ts) that differs from the
// persona raising it, that reviewer is who it goes to; otherwise falls back
// to the fixed compliance→ops / else→rm convention.
const nextClarificationTargetLabel = (
  fromPersona: AppPersona,
  reviewerRole?: WorkflowNode['reviewerRole']
): AppPersona =>
  (reviewerRole && reviewerRole !== fromPersona)
    ? reviewerRole
    : (fromPersona === 'compliance_officer' ? 'operations_officer' : 'rm');

// Helper to retrieve stage metadata & contextual progress description per node type
const getAgentStageProgressData = (node: WorkflowNode, client: ClientProfile) => {
  const isSg = client.jurisdiction.toLowerCase().includes('singapore') || client.jurisdiction.includes('SG');
  const docCount = client.documents.length;
  const pepCount = client.shareholders.filter(s => s.pepStatus).length;
  const maxEquity = client.shareholders.length > 0 ? Math.max(...client.shareholders.map(s => s.equity)) : 0;

  switch (node.id) {
    case 'data_aggregator':
      return {
        stageIndex: 1,
        totalStages: 8,
        category: 'Registry Intelligence & Standings',
        tagline: 'Official Business Registry Extractor',
        statusSummary: node.status === 'completed'
          ? `Successfully retrieved official corporate registry records for ${client.companyName} (${client.registrationNumber}) in ${client.jurisdiction}. Legal standing and corporate officer filings are active.`
          : node.status === 'running'
          ? `Querying ${client.jurisdiction} business registry database for ${client.companyName}...`
          : `Awaiting registry search dispatch for ${client.companyName} (${client.registrationNumber}).`,
        stageMetrics: [
          { label: 'Registry Jurisdiction', value: client.jurisdiction, status: 'good' },
          { label: 'Registration Number', value: client.registrationNumber, status: 'good' },
          { label: 'Corporate Entity Standing', value: node.status === 'completed' ? 'Live & Active' : 'Checking...', status: node.status === 'completed' ? 'good' : 'neutral' },
          { label: 'Officer Records Mapped', value: `${client.directors?.length || 2} Directors`, status: 'good' }
        ]
      };
    case 'doc_verification':
      return {
        stageIndex: 2,
        totalStages: 8,
        category: 'Multi-Modal Vision & OCR',
        tagline: 'Document Structure & Authenticity Engine',
        statusSummary: node.status === 'completed'
          ? `LayoutLMv3 vision model parsed ${docCount} document(s) in vault. Certificate of Incorporation and Board Resolutions matched 100% with registry profile for ${client.companyName}.`
          : node.status === 'running'
          ? `Scanning uploaded PDF document vault (${docCount} files) for ${client.companyName}...`
          : `Awaiting document upload parsing for ${client.companyName}.`,
        stageMetrics: [
          { label: 'Documents in Vault', value: `${docCount} File(s)`, status: docCount > 0 ? 'good' : 'warning' },
          { label: 'OCR Extraction Quality', value: node.status === 'completed' ? '99.4% Accuracy' : 'Pending', status: 'good' },
          { label: 'Digital Certificate', value: node.status === 'completed' ? 'Authentic' : 'Pending', status: 'good' },
          { label: 'Board Resolution Quorum', value: node.status === 'completed' ? 'Verified' : 'Pending', status: 'good' }
        ]
      };
    case 'biometric_verification':
      return {
        stageIndex: 3,
        totalStages: 8,
        category: 'Biometric Face Mapping & Liveness',
        tagline: '128-Point Facial Coordinate & Deepfake Defender',
        statusSummary: client.authorizedRepresentative.biometricVerified || node.status === 'completed'
          ? `Biometric face coordinates for ${client.authorizedRepresentative.name} (${client.authorizedRepresentative.role}) matched passport photo with ${client.authorizedRepresentative.biometricMatchScore || 98.6}% confidence. Passive liveness check passed.`
          : node.status === 'running'
          ? `Matching webcam video frames against passport photo for ${client.authorizedRepresentative.name}...`
          : `Awaiting live selfie capture for authorized signatory ${client.authorizedRepresentative.name}.`,
        stageMetrics: [
          { label: 'Authorized Signatory', value: client.authorizedRepresentative.name, status: 'good' },
          { label: 'Facial Vector Similarity', value: `${client.authorizedRepresentative.biometricMatchScore || 98.6}%`, status: 'good' },
          { label: 'Anti-Spoofing Liveness', value: client.authorizedRepresentative.biometricVerified ? 'PASSED' : 'Awaiting Selfie', status: client.authorizedRepresentative.biometricVerified ? 'good' : 'warning' },
          { label: 'Identity Verification', value: client.authorizedRepresentative.biometricVerified ? 'Cleared' : 'Incomplete', status: client.authorizedRepresentative.biometricVerified ? 'good' : 'warning' }
        ]
      };
    case 'name_screening':
      return {
        stageIndex: 4,
        totalStages: 8,
        category: 'Global Watchlists & PEP Screening',
        tagline: 'OFAC, UN, EU & Adverse Media Screening Engine',
        statusSummary: node.status === 'completed'
          ? `Screened ${client.companyName}, representative ${client.authorizedRepresentative.name}, and ${client.shareholders.length} shareholders. ${pepCount > 0 ? `Detected ${pepCount} Politically Exposed Person (PEP) indicator.` : '0 Sanction or PEP hits found. Cleared.'}`
          : node.status === 'running'
          ? `Cross-referencing global sanctions registers for ${client.companyName}...`
          : `Awaiting name screening list generation for ${client.companyName}.`,
        stageMetrics: [
          { label: 'Sanctions List Matches', value: '0 Hits (OFAC/UN/EU)', status: 'good' },
          { label: 'PEP Watchlist Indicators', value: pepCount > 0 ? `${pepCount} PEP Hit` : '0 Hits', status: pepCount > 0 ? 'warning' : 'good' },
          { label: 'Adverse Media Sentiment', value: 'Clean (0 Mentions)', status: 'good' },
          { label: 'Phonetic Double-Metaphone', value: 'Verified', status: 'good' }
        ]
      };
    case 'aml':
      return {
        stageIndex: 5,
        totalStages: 8,
        category: 'Ownership Chain & Source of Wealth',
        tagline: 'UBO Discovery & Offshore Layering Tracer',
        statusSummary: node.status === 'completed'
          ? `Mapped ${client.shareholders.length} ultimate beneficial owners (UBOs) holding up to ${maxEquity}% equity. ${pepCount > 0 ? 'Enhanced Due Diligence (EDD) signoff verified for PEP equity.' : 'Source of wealth verified.'}`
          : node.status === 'running'
          ? `Tracing shareholding tiers and source-of-wealth narratives for ${client.companyName}...`
          : `Awaiting UBO tree discovery for ${client.companyName}.`,
        stageMetrics: [
          { label: 'Beneficial Owners (UBOs)', value: `${client.shareholders.length} Shareholders`, status: 'good' },
          { label: 'Max Individual Equity', value: `${maxEquity}%`, status: 'good' },
          { label: 'Corporate Shell Layers', value: isSg ? '0 Layers (Transparent)' : '1 Layer (Offshore)', status: isSg ? 'good' : 'warning' },
          { label: 'EDD Status', value: pepCount > 0 ? 'EDD Triggered' : 'Standard Vetted', status: pepCount > 0 ? 'warning' : 'good' }
        ]
      };
    case 'client_risk':
      return {
        stageIndex: 6,
        totalStages: 8,
        category: 'Composite Risk Matrix & Scoring',
        tagline: 'Jurisdictional & Enterprise Risk Evaluator',
        statusSummary: node.status === 'completed'
          ? `Composite risk score computed for ${client.companyName} based on ${client.jurisdiction} jurisdiction rating, ${client.industry} industry risk, and compliance screening findings.`
          : node.status === 'running'
          ? `Calculating composite risk weights for ${client.companyName}...`
          : `Awaiting risk model aggregation for ${client.companyName}.`,
        stageMetrics: [
          { label: 'Jurisdiction Risk Rating', value: isSg ? 'Low Risk (12/100)' : 'Medium Risk (45/100)', status: isSg ? 'good' : 'warning' },
          { label: 'Industry Risk Index', value: 'Standard Commercial', status: 'good' },
          { label: 'Composite Risk Tier', value: node.status === 'completed' ? (client.overallStatus === 'approved' ? 'LOW RISK' : 'MEDIUM RISK') : 'Evaluating...', status: 'good' },
          { label: 'Underwriting Urgency', value: 'Standard SLA', status: 'good' }
        ]
      };
    case 'credit_risk':
      return {
        stageIndex: 7,
        totalStages: 8,
        category: 'Financial Balance Sheet Underwriting',
        tagline: 'Credit Exposure & Revenue Multiplier Engine',
        statusSummary: node.status === 'completed'
          ? `Parsed corporate financials for ${client.companyName}: Revenue ${client.financials.revenue}, Assets ${client.financials.assets}, Debt Ratio ${client.financials.debtRatio}. Internal credit rating assigned: ${client.financials.rating}.`
          : node.status === 'running'
          ? `Analyzing balance sheet disclosures for ${client.companyName}...`
          : `Awaiting credit line underwriting for ${client.companyName}.`,
        stageMetrics: [
          { label: 'Disclosed Revenue', value: client.financials.revenue, status: 'good' },
          { label: 'Balance Sheet Assets', value: client.financials.assets, status: 'good' },
          { label: 'Debt Leverage Ratio', value: client.financials.debtRatio, status: 'good' },
          { label: 'Assigned Internal Rating', value: client.financials.rating, status: 'good' }
        ]
      };
    case 'legal_compliance':
      return {
        stageIndex: 8,
        totalStages: 8,
        category: 'Master Contract & Core Ledger Sync',
        tagline: 'Legal Authority & SLA Contract Coordinator',
        statusSummary: node.status === 'completed'
          ? `Master Corporate Terms generated for ${client.companyName}. Authorized signatory ${client.authorizedRepresentative.name} designated for DocuSign contract execution.`
          : node.status === 'running'
          ? `Drafting master SLA contract terms for ${client.companyName}...`
          : `Awaiting final legal terms execution for ${client.companyName}.`,
        stageMetrics: [
          { label: 'Authorized Signer', value: client.authorizedRepresentative.name, status: 'good' },
          { label: 'Board Authority', value: 'Resolution Verified', status: 'good' },
          { label: 'SLA Contract Status', value: node.status === 'completed' ? 'Executed & Active' : 'Draft Ready', status: 'good' },
          { label: 'Core Banking Ledger', value: node.status === 'completed' ? 'Synced' : 'Pending', status: 'good' }
        ]
      };
    default:
      return {
        stageIndex: 1,
        totalStages: 8,
        category: 'Custom Workflow Module',
        tagline: 'Autonomous Compliance Module',
        statusSummary: `Processing workflow node for ${client.companyName}.`,
        stageMetrics: [
          { label: 'Entity Title', value: client.companyName, status: 'good' },
          { label: 'Jurisdiction', value: client.jurisdiction, status: 'good' }
        ]
      };
  }
};

// Dynamic Agent Trace Resolver mapping what input an agent got, what actions it took, and what outputs it provided
const getAgentTraceData = (node: WorkflowNode, client: ClientProfile) => {
  const isSg = client.jurisdiction.toLowerCase().includes('singapore') || client.jurisdiction.includes('SG');
  
  switch (node.id) {
    case 'data_aggregator':
      return {
        inputs: [
          { label: 'Company Name', value: client.companyName, source: 'Customer Profile Submission' },
          { label: 'Incorporation Country', value: client.jurisdiction, source: 'Customer Registration' },
          { label: 'Primary Business Class', value: client.industry, source: 'Customer Input metadata' }
        ],
        reasoning: [
          `Identified registration jurisdiction: "${client.jurisdiction}".`,
          isSg 
            ? 'Accessing Singapore ACRA BizProfile Web Service registry endpoints via mTLS.'
            : 'Accessing India MCA central corporate database portal for verification.',
          'Authenticating gateway with secure API tokens and dispatching registry search query.',
          'Extracting legal address, registration ID, registered directors, and active business license status.',
          'Normalizing key executive details to load down-stream screening rosters.'
        ],
        outputs: [
          { label: 'Corporate License Status', value: 'Live & Active', target: 'Document Verification' },
          { label: 'Verified Registration ID', value: client.registrationNumber, target: 'AML & PEP Screening' },
          { label: 'Director Registry Listing', value: `${client.directors?.length || 2} Directors Mapped`, target: 'PEP & Sanctions' }
        ]
      };
    case 'doc_verification':
      const docNames = client.documents.map(d => d.name).join(', ') || 'No documents yet';
      return {
        inputs: [
          { label: 'Uploaded PDF Vault', value: docNames, source: 'Customer Upload' },
          { label: 'Expected Entity Title', value: client.companyName, source: 'Registry database' },
          { label: 'Expected Registry ID', value: client.registrationNumber, source: 'Registry database' }
        ],
        reasoning: [
          'Locating active uploaded PDF files in client secure document-vault.',
          'Running multi-modal LayoutLMv3 models to parse layout, structure, and text fields simultaneously.',
          'Cross-referencing OCR-parsed text (Certificate of Incorporation, Board Resolutions) against official registry variables.',
          'Analyzing PDF digital certificates, embedded metadata streams, and visual signatures for manipulation anomalies.'
        ],
        outputs: [
          { label: 'OCR Extraction Accuracy', value: '99.4%', target: 'Biometric Face Match' },
          { label: 'Signing Quorum Integrity', value: 'Passed & Valid', target: 'Legal Compliance' },
          { label: 'Shareholder Structure Data', value: 'Direct Ownership structure resolved', target: 'AML Module' }
        ]
      };
    case 'biometric_verification':
      return {
        inputs: [
          { label: 'Authorized Signatory Name', value: client.authorizedRepresentative.name, source: 'Document Verification Agent' },
          { label: 'Representative Passport', value: 'Validated Bio-Data Page', source: 'Customer Document Uploads' },
          { label: 'Live Camera Selfie Stream', value: 'High-res image frames captured', source: 'Customer Webcam Stream' }
        ],
        reasoning: [
          'Extracting target face portrait crop from verified representative bio-data document.',
          'Locating and mapping 128-point spatial facial coordinate vectors from live selfie frames.',
          'Calculating Euclidean spatial distance ratio between document bio-portrait and live-selfie vectors.',
          'Applying Passive Liveness models to scan eye coordinates, depth ratios, and skin reflection to prevent deepfakes.'
        ],
        outputs: [
          { label: 'Facial Coordinate Match', value: client.authorizedRepresentative.biometricVerified ? `${client.authorizedRepresentative.biometricMatchScore || 98}% match confidence` : 'Pending Match', target: 'Client Risk Assessment' },
          { label: 'Liveness Classification', value: client.authorizedRepresentative.biometricVerified ? 'PASSED (Anti-Spoof Vetted)' : 'Awaiting Selfie', target: 'Risk Operations' },
          { label: 'Signatory Status', value: client.authorizedRepresentative.biometricVerified ? 'Identity Verified' : 'Awaiting Match', target: 'Legal Compliance Coordinator' }
        ]
      };
    case 'name_screening':
      return {
        inputs: [
          { label: 'Corporate Legal Title', value: client.companyName, source: 'Data Aggregator' },
          { label: 'Representative Name', value: client.authorizedRepresentative.name, source: 'Document Verification' },
          { label: 'Associated Shareholders', value: client.shareholders.map(s => s.name).join(', '), source: 'Data Aggregator' }
        ],
        reasoning: [
          'Normalizing names into phonetic strings using Double Metaphone to handle translations and typos.',
          'Cross-checking targets against OFAC, United Nations, European Union, and UK Sanctions consolidated registers.',
          'Querying Dow Jones politically exposed persons (PEP) databases for political alignments.',
          'Scanning 5,000+ international and regional trade publications for adverse media mentions and classifying sentiment.'
        ],
        outputs: [
          { label: 'Sanctions Clearance Status', value: '100% Cleared (0 Hits)', target: 'AML Module' },
          { label: 'PEP Alignment Status', value: client.shareholders.some(s => s.pepStatus) ? 'FLAGGED (PEP Shareholder detected)' : '0 PEP Matches found', target: 'Client Risk Assessment' },
          { label: 'Adverse Media Rating', value: 'Clear (Zero adverse mentions)', target: 'Risk Operations' }
        ]
      };
    case 'aml':
      const pepCount = client.shareholders.filter(s => s.pepStatus).length;
      return {
        inputs: [
          { label: 'PEP Alert Matrix', value: pepCount > 0 ? `${pepCount} PEP indicators detected` : 'No PEP indicators', source: 'PEP Screening Agent' },
          { label: 'Shareholder Roster', value: client.shareholders.map(s => `${s.name} (${s.equity}%)`).join(', '), source: 'Data Aggregator' }
        ],
        reasoning: [
          'Tracing corporate shareholding levels upwards to identify all natural persons holding >=10% (UBOs).',
          'Vetting intermediary corporate layers to map holding/parent structures and check for offshore proxies.',
          'Corroborating source-of-wealth assertions against capital injection registers and corporate earnings statements.',
          'Applying Enhanced Due Diligence (EDD) criteria because PEP shareholders are present in the ownership tree.'
        ],
        outputs: [
          { label: 'UBO Chain Resolution', value: `${client.shareholders.length} UBOs Mapped`, target: 'Client Risk Assessment' },
          { label: 'Corporate Shell Layer Rating', value: isSg ? '0 Layers (Transparent Structure)' : '1 Layer (Offshore Intermediary)', target: 'Risk Operations' },
          { label: 'Source of Wealth Status', value: 'Verified - Institutional Equity Capital', target: 'Credit Underwriting' }
        ]
      };
    case 'client_risk':
      return {
        inputs: [
          { label: 'Biometric Match Outcome', value: client.authorizedRepresentative.biometricVerified ? 'CLEARED' : 'PENDING', source: 'Biometric Face Match' },
          { label: 'UBO & Ownership Structure', value: 'Beneficial chain mapped', source: 'Anti-Money Laundering Module' },
          { label: 'Jurisdiction Risk Rating', value: client.jurisdiction === 'Singapore' ? 'Low Risk Index (12/100)' : 'Medium Risk Index (45/100)', source: 'Data Aggregator' }
        ],
        reasoning: [
          'Aggregating risk ratings from core segments: Geographic, industry risk coefficients, PEP alerts, and ID verification status.',
          'Running the composite risk scoring algorithm based on internal bank rules.',
          'Determining overall risk classification tier (Low / Medium / High Risk).',
          'Routing onboarding flow parameters to corresponding credit and compliance underwriters.'
        ],
        outputs: [
          { label: 'Composite Risk Tier', value: client.overallStatus === 'approved' ? 'LOW RISK (Score: 15/100)' : 'MEDIUM RISK (Due to KYC status)', target: 'Credit Underwriting Agent' },
          { label: 'EDD Underwrite Flag', value: client.shareholders.some(s => s.pepStatus) ? 'ACTIVE' : 'INACTIVE', target: 'Compliance Team' },
          { label: 'Verification Urgency Metric', value: 'High Priority (Expedited SLA)', target: 'Relationship Manager Panel' }
        ]
      };
    case 'credit_risk':
      return {
        inputs: [
          { label: 'Vetted Compliance Risk', value: 'Low composite risk score', source: 'Client Risk Assessment' },
          { label: 'Disclosed Financial Position', value: `Revenue: ${client.financials.revenue}, Assets: ${client.financials.assets}`, source: 'Customer Financials Form' },
          { label: 'Debt/Leverage Metric', value: `Debt Ratio: ${client.financials.debtRatio}`, source: 'Customer Financials Form' }
        ],
        reasoning: [
          'Analyzing corporate income records and asset balance sheets.',
          'Calculating debt-to-equity ratio and asset-to-debt coverages.',
          'Cross-referencing commercial credit agencies for default histories.',
          'Formulating safe credit exposure limits based on capital reserves, modified by the compliance risk rating.'
        ],
        outputs: [
          { label: 'Suggested Exposure Limit', value: client.financials.rating === 'AA-' ? '$1.5M SGD' : '$150,000 USD', target: 'Legal Compliance Coordinator' },
          { label: 'Assigned Internal Rating', value: client.financials.rating, target: 'Compliance & Risk Officer Panel' },
          { label: 'Asset Underwriting Status', value: 'Verified - Assets and revenue match tax returns', target: 'Relationship Manager Panel' }
        ]
      };
    case 'legal_compliance':
      return {
        inputs: [
          { label: 'Underwritten Credit Limit', value: 'Exposure limit approved', source: 'Credit Underwriting Agent' },
          { label: 'Signatory Board Authority', value: 'Signed Resolution on file', source: 'Document Verification Agent' },
          { label: 'Authenticated Signer ID', value: client.authorizedRepresentative.name, source: 'Biometric Face Match Agent' }
        ],
        reasoning: [
          'Matching designated signers against the authorized representative listed in the Board Resolution.',
          'Compiling master SLA corporate contract including legal company name and registration ID.',
          'Injecting specific credit parameters and credit limits into the contract SLA.',
          'Publishing contract to DocuSign secure e-sign gateways.'
        ],
        outputs: [
          { label: 'SLA Contract Document', value: 'Master Contract PDF Drafted', target: 'Customer Signature Portal' },
          { label: 'Legal Approval Classification', value: '100% Cleared & Approved', target: 'Bank Core Registry' },
          { label: 'Onboarding System Result', value: 'COMPLETED', target: 'Onboard.ai Core Ledger' }
        ]
      };
    default:
      return {
        inputs: [
          { label: 'Corporate Entity Name', value: client.companyName, source: 'Customer Profile Submission' }
        ],
        reasoning: [
          'Vetting default onboarding parameters.',
          'Validating structural compliance constraints.'
        ],
        outputs: [
          { label: 'Onboarding Status', value: 'Vetted', target: 'Workflow Orchestrator' }
        ]
      };
  }
};

interface NodeDetailProps {
  node: WorkflowNode;
  client: ClientProfile;
  activePersona: AppPersona;
  onUpdateNode: (nodeId: string, updatedData: Partial<WorkflowNode>) => void;
  onRunAutonomousNode: (nodeId: string) => Promise<boolean | void>;
  onTriggerAutonomousFlow?: () => void;
  isProcessing: boolean;
  agents?: OrchestrationAgent[];
  onRaiseClarification?: (clientId: string, nodeId: string, message: string) => void;
  onForwardClarification?: (clientId: string, nodeId: string, message: string) => void;
  onResolveClarification?: (clientId: string, nodeId: string, message: string) => void;
  onInitiateClarificationOutreach?: (clientId: string, nodeId: string) => void;
}

export default function NodeDetail({
  node,
  client,
  activePersona,
  onUpdateNode,
  onRunAutonomousNode,
  onTriggerAutonomousFlow,
  isProcessing,
  agents,
  onRaiseClarification,
  onForwardClarification,
  onResolveClarification,
  onInitiateClarificationOutreach
}: NodeDetailProps) {
  const [officerComment, setOfficerComment] = useState('');

  // Local states for interactive forms
  const [manualLimit, setManualLimit] = useState('1000000');
  const [selectedRating, setSelectedRating] = useState('A+');
  const [eddChecklist, setEddChecklist] = useState({
    uboIdentified: false,
    pepVetted: false,
    sourceVerified: false
  });

  // Track if RM manually flagged compliance alert
  const [rmFlagged, setRmFlagged] = useState(false);

  // Clarification thread — message box for whichever action is currently valid
  const [clarificationMessage, setClarificationMessage] = useState('');

  useEffect(() => {
    setRmFlagged(false);
    setOfficerComment('');
    setClarificationMessage('');
  }, [node.id, client.id]);

  const PERSONA_LABELS: Record<AppPersona, string> = {
    platform_admin: 'Platform Admin',
    rm: 'Relationship Manager',
    compliance_officer: 'Compliance & Risk Officer',
    operations_officer: 'Operations Officer',
    customer: 'Customer',
  };

  const clarification = node.clarification;
  const isOpenClarification = clarification?.status === 'open';
  const isMyTurn = isOpenClarification && clarification.targetPersona === activePersona;
  const canRaiseClarification = node.transitionRule !== 'auto' && !isOpenClarification && node.status !== 'completed'
    && (activePersona === 'compliance_officer' || activePersona === 'operations_officer');

  const submitRaiseClarification = () => {
    if (!clarificationMessage.trim() || !onRaiseClarification) return;
    onRaiseClarification(client.id, node.id, clarificationMessage.trim());
    setClarificationMessage('');
  };
  const submitForwardClarification = () => {
    if (!clarificationMessage.trim() || !onForwardClarification) return;
    onForwardClarification(client.id, node.id, clarificationMessage.trim());
    setClarificationMessage('');
  };
  const submitResolveClarification = () => {
    if (!onResolveClarification) return;
    onResolveClarification(client.id, node.id, clarificationMessage.trim() || 'Resolved — no further clarification needed.');
    setClarificationMessage('');
  };

  // Driven by the stage's design-time reviewerRole (JourneyStage in
  // PersonaSubviews.tsx, copied onto WorkflowNode by JourneyInitiator).
  // Previously hardcoded against old node ids ('legal_compliance',
  // 'client_risk', 'credit_risk') that never matched the real stage_1..11
  // ids JourneyInitiator actually generates, so this always fell through
  // to `true` for every real journey — reviewerRole replaces that dead
  // check with the actual design-time assignment.
  const canDirectNode = () => {
    if (activePersona === 'platform_admin') return true;
    if (!node.reviewerRole) return true; // pre-existing nodes: unchanged permissive behavior
    return activePersona === node.reviewerRole;
  };

  const isWorkflowCompleted = client.workflowNodes.every(n => n.status === 'completed');
  const isNodeCompleted = node.status === 'completed';

  // Allow approval when node is not completed, not running, workflow is not
  // completed, AND the active persona is actually the stage's assigned
  // reviewer — a persona that isn't the designated reviewer sees the
  // amber warning below but can no longer click through it; sign-off is a
  // real gate, not just an advisory.
  const isApproveDisabled =
    isNodeCompleted ||
    isWorkflowCompleted ||
    node.status === 'running' ||
    !canDirectNode();

  const isRejectDisabled =
    isNodeCompleted ||
    isWorkflowCompleted ||
    node.status === 'running' ||
    !canDirectNode();

  const availableAgents = agents || INITIAL_AGENTS;
  const currentAgent = availableAgents.find(a => a.id === node.assignedAgentId) || 
                       availableAgents.find(a => a.id === node.id + '_agent') || 
                       availableAgents.find(a => a.id === 'kyb_agent');

  // Interactive trace analysis tab
  const [traceTab, setTraceTab] = useState<'all' | 'inputs' | 'reasoning' | 'outputs'>('all');

  const traceData = getAgentTraceData(node, client);

  // Perform manual node signoff/rejection
  const handleManualSignoff = (approve: boolean) => {
    const commentText = officerComment.trim() || (approve ? 'Approved by compliance officer after review.' : 'Flagged for further compliance investigation.');

    let summaryText = approve 
      ? `Manually approved by ${activePersona}. Comment: "${commentText}"`
      : `Flagged / rejected by ${activePersona}. Comment: "${commentText}"`;

    let finalMetrics = node.results?.metrics || {};
    if (node.id === 'credit_risk') {
      finalMetrics = {
        ...finalMetrics,
        'Authorized Credit Limit': `$${Number(manualLimit).toLocaleString()} USD`,
        'Vetted Score Rating': selectedRating
      };
      summaryText = `Credit line approved at $${Number(manualLimit).toLocaleString()} USD with an internal rating of ${selectedRating}. Comment: "${commentText}"`;
    }

    const nextStatus: NodeStatus = approve ? 'completed' : 'flagged';

    onUpdateNode(node.id, {
      status: nextStatus,
      logs: [
        ...node.logs,
        `[Compliance Review] Performed by persona: ${activePersona}`,
        `Decision: ${approve ? 'APPROVED & SIGNED OFF' : 'REJECTED / FLAGGED'}`,
        `[Officer Comment]: ${commentText}`
      ],
      results: {
        summary: summaryText,
        metrics: finalMetrics,
        findings: [
          ...(node.results?.findings || []),
          `Officer Sign-Off Comment: "${commentText}"`
        ]
      }
    });

    setOfficerComment('');

    // Trigger subsequent dependent workflow nodes automatically if approved
    if (approve && onTriggerAutonomousFlow) {
      onTriggerAutonomousFlow();
    }
  };

  const toggleChecklist = (key: keyof typeof eddChecklist) => {
    setEddChecklist(prev => {
      const updated = { ...prev, [key]: !prev[key] };
      return updated;
    });
  };

  const stageProgress = getAgentStageProgressData(node, client);

  return (
    <div className="flex flex-col h-full bg-white border border-slate-200/80 rounded-xl overflow-hidden shadow-sm">
      {/* Panel Header */}
      <div className="p-4 bg-slate-900 text-slate-100 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-slate-800 text-blue-400 border border-slate-700 font-semibold tracking-wider">
              {node.team}
            </span>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-indigo-950 text-indigo-300 border border-indigo-800 font-bold">
              Stage {stageProgress.stageIndex} of {stageProgress.totalStages}
            </span>
          </div>
          <h3 className="font-semibold text-base text-white mt-1.5">{node.name}</h3>
        </div>
        <div className="flex items-center gap-1.5">
          <span className={`w-2.5 h-2.5 rounded-full ${
            node.status === 'completed' ? 'bg-emerald-400' :
            (node.status === 'flagged' || node.status === 'awaiting_approval') ? 'bg-amber-400 animate-pulse' :
            node.status === 'running' ? 'bg-blue-400 animate-pulse' :
            'bg-slate-500'
          }`} />
          <span className="text-xs font-mono font-medium uppercase tracking-wide">
            {(node.status === 'flagged' || node.status === 'awaiting_approval') ? 'Waiting Approval' : node.status}
          </span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-5 space-y-5">
        {/* Waiting for manual approval top notification banner */}
        {(node.status === 'flagged' || node.status === 'awaiting_approval') && (
          <div className="bg-amber-50 border-2 border-amber-400 rounded-xl p-3.5 flex items-center justify-between gap-3 text-amber-950 shadow-sm animate-pulse">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-amber-500 text-white rounded-lg shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-extrabold text-xs text-amber-900 tracking-tight">Waiting for Manual Approval</h4>
                <p className="text-[11px] text-amber-800 leading-snug">
                  This stage is paused pending human intervention or manual risk compliance review.
                </p>
              </div>
            </div>
            <span className="shrink-0 text-[10px] font-mono font-extrabold uppercase bg-amber-200 text-amber-900 px-2 py-1 rounded border border-amber-300">
              ACTION REQUIRED
            </span>
          </div>
        )}

        {/* 🚀 NEW: STAGE PROGRESS & CONTEXTUAL STATUS CARD */}
        <div className="bg-gradient-to-br from-indigo-50/70 via-blue-50/40 to-slate-50/60 border border-indigo-100/80 rounded-xl p-4 space-y-3.5 shadow-sm">
          <div className="flex items-center justify-between border-b border-indigo-100/60 pb-2.5">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-indigo-600 text-white text-xs font-bold font-mono">
                S{stageProgress.stageIndex}
              </span>
              <div>
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider font-mono">
                  {stageProgress.category}
                </h4>
                <p className="text-[10px] text-slate-500 font-medium">{stageProgress.tagline}</p>
              </div>
            </div>
            <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-extrabold uppercase border ${
              node.status === 'completed' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
              (node.status === 'flagged' || node.status === 'awaiting_approval') ? 'bg-amber-100 text-amber-900 border-amber-300' :
              node.status === 'running' ? 'bg-blue-50 text-blue-700 border-blue-200 animate-pulse' :
              'bg-slate-100 text-slate-600 border-slate-200'
            }`}>
              {node.status === 'completed' ? 'STAGE CLEARED' :
               (node.status === 'flagged' || node.status === 'awaiting_approval') ? 'WAITING FOR MANUAL APPROVAL' :
               node.status === 'running' ? 'EXECUTING NOW' :
               'STAGE QUEUED'}
            </span>
          </div>

          {/* Workflow Progress Bar */}
          <div className="space-y-1">
            <div className="flex justify-between text-[10px] font-mono font-semibold text-slate-500">
              <span>WORKFLOW PIPELINE PROGRESS</span>
              <span className="text-indigo-600 font-bold">{Math.round((stageProgress.stageIndex / stageProgress.totalStages) * 100)}% ({stageProgress.stageIndex}/{stageProgress.totalStages} Stages)</span>
            </div>
            <div className="w-full bg-slate-200/80 h-2 rounded-full overflow-hidden">
              <div 
                className={`h-full transition-all duration-500 ${
                  node.status === 'completed' ? 'bg-emerald-500' :
                  node.status === 'flagged' ? 'bg-rose-500' :
                  node.status === 'running' ? 'bg-blue-600 animate-pulse' :
                  'bg-indigo-500'
                }`}
                style={{ width: `${(stageProgress.stageIndex / stageProgress.totalStages) * 100}%` }}
              />
            </div>
          </div>

          {/* Dynamic Contextual Status Description */}
          <p className="text-xs text-slate-700 leading-relaxed bg-white/80 border border-indigo-100/60 rounded-lg p-3 font-sans">
            <strong className="text-indigo-900 font-semibold block text-[10px] uppercase font-mono mb-1">
              CURRENT STAGE EVALUATION • {client.companyName}
            </strong>
            {stageProgress.statusSummary}
          </p>

          {/* Key Stage Metrics Grid */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            {stageProgress.stageMetrics.map((metric, idx) => (
              <div key={idx} className="bg-white/90 border border-slate-200/60 rounded-lg p-2 flex flex-col justify-between shadow-2xs">
                <span className="text-[9px] font-mono uppercase text-slate-400 truncate block">{metric.label}</span>
                <strong className={`text-xs font-semibold truncate block mt-0.5 ${
                  metric.status === 'warning' ? 'text-amber-700' : 'text-slate-800'
                }`}>
                  {metric.value}
                </strong>
              </div>
            ))}
          </div>

          {/* Prerequisite Dependencies */}
          {node.dependsOn && node.dependsOn.length > 0 && (
            <div className="flex items-center gap-1.5 text-[9px] font-mono text-slate-500 pt-1 border-t border-indigo-100/50">
              <span className="uppercase text-slate-400 font-bold">PREREQUISITE NODES:</span>
              <div className="flex gap-1 flex-wrap">
                {node.dependsOn.map(depId => (
                  <span key={depId} className="px-1.5 py-0.2 bg-slate-100 text-slate-600 rounded border border-slate-200 font-semibold">
                    {depId}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Description Section */}
        <div className="text-xs text-slate-600 leading-relaxed bg-slate-50 border border-slate-100/60 rounded-xl p-3.5">
          <h4 className="font-semibold text-slate-800 mb-1">Agent Objective</h4>
          {node.description}
        </div>

        {/* Linked Workspace Agent Block */}
        <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3.5 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider font-mono flex items-center gap-1.5">
              <Bot className="w-4 h-4 text-indigo-500" />
              Linked Workspace Agent
            </h4>
            {currentAgent && (
              <span className="px-2 py-0.5 rounded text-[8px] font-mono font-bold bg-indigo-50 text-indigo-600 border border-indigo-100">
                {currentAgent.version || 'v1.0'}
              </span>
            )}
          </div>

          {currentAgent ? (
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-950/40 flex items-center justify-center text-indigo-600 shrink-0">
                  <Bot className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-bold text-slate-800 truncate">{currentAgent.name}</p>
                  <p className="text-[9px] text-slate-400 truncate">{currentAgent.category}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-200/60 text-[10px]">
                <div className="text-slate-500">
                  LLM Model: <span className="font-semibold text-slate-700">{currentAgent.model || 'Gemini 2.5 Pro'}</span>
                </div>
                <div className="text-slate-500 text-right">
                  Avg Latency: <span className="font-semibold text-slate-700">{currentAgent.metrics?.avgLatency || '240ms'}</span>
                </div>
              </div>

              {currentAgent.mcpConnectedSources && currentAgent.mcpConnectedSources.length > 0 && (
                <div className="text-[9px] text-slate-500 leading-normal pt-1 border-t border-slate-200/60">
                  <span className="font-mono uppercase text-slate-400 block text-[8px] mb-0.5">Connected Sources / APIs:</span>
                  <div className="flex flex-wrap gap-1">
                    {currentAgent.mcpConnectedSources.map((src, i) => (
                      <span key={i} className="bg-slate-100 text-slate-600 px-1 py-0.2 rounded font-mono text-[8px] border border-slate-200/50">
                        {src}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <p className="text-[10px] text-slate-400 italic">No custom workspace agent attached.</p>
          )}

          {/* Platform Admin Interactive Configuration Controls */}
          {activePersona === 'platform_admin' && (
            <div className="mt-3 pt-3 border-t-2 border-dashed border-slate-200 space-y-3">
              <div className="bg-indigo-50/50 border border-indigo-100 rounded-lg p-2 text-[9px] text-indigo-800 leading-normal font-medium">
                🛡️ <strong>Platform Admin Panel:</strong> Configure this step in the active workflow DAG. Changes update the live interactive canvas instantly.
              </div>

              {/* Selector to choose workspace agent */}
              <div className="space-y-1">
                <label className="text-[9px] font-mono font-bold text-slate-500 block uppercase">
                  Attach Registry Agent
                </label>
                <select
                  value={node.assignedAgentId || ''}
                  onChange={(e) => {
                    const newAgentId = e.target.value;
                    const selectedAgent = availableAgents.find(a => a.id === newAgentId);
                    onUpdateNode(node.id, {
                      assignedAgentId: newAgentId,
                      logs: [
                        ...node.logs,
                        `[Administrative Config] Workflow step "${node.name}" attached to Agent "${selectedAgent?.name || newAgentId}" by Platform Admin.`
                      ]
                    });
                  }}
                  className="w-full bg-white border border-slate-300 rounded px-2 py-1 text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-indigo-500 cursor-pointer font-semibold"
                >
                  <option value="" disabled>-- Select workspace agent --</option>
                  {availableAgents.map(a => (
                    <option key={a.id} value={a.id}>
                      {a.name} ({a.model || 'Gemini 2.5'})
                    </option>
                  ))}
                </select>
              </div>

              {/* Step Display Name Input */}
              <div className="space-y-1">
                <label className="text-[9px] font-mono font-bold text-slate-500 block uppercase">
                  Step Display Name
                </label>
                <input
                  type="text"
                  value={node.name}
                  onChange={(e) => onUpdateNode(node.id, { name: e.target.value })}
                  className="w-full bg-white border border-slate-300 rounded px-2 py-1 text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-bold"
                  placeholder="e.g. AML Verification"
                />
              </div>

              {/* Managing Team Label Input */}
              <div className="space-y-1">
                <label className="text-[9px] font-mono font-bold text-slate-500 block uppercase">
                  Managing Team Label
                </label>
                <input
                  type="text"
                  value={node.team}
                  onChange={(e) => onUpdateNode(node.id, { team: e.target.value })}
                  className="w-full bg-white border border-slate-300 rounded px-2 py-1 text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  placeholder="e.g. Risk Operations Team"
                />
              </div>

              {/* Description Input */}
              <div className="space-y-1">
                <label className="text-[9px] font-mono font-bold text-slate-500 block uppercase">
                  Step Objective / Description
                </label>
                <textarea
                  value={node.description}
                  rows={2}
                  onChange={(e) => onUpdateNode(node.id, { description: e.target.value })}
                  className="w-full bg-white border border-slate-300 rounded px-2 py-1 text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-indigo-500 leading-normal font-sans"
                  placeholder="Describe step goals..."
                />
              </div>
            </div>
          )}
        </div>

        {/* 🤖 NEW: AGENT COGNITIVE EXECUTION TRACE PANEL (Inputs, Reasoning, Outputs) */}
        <div className="border border-indigo-100/80 rounded-xl bg-slate-50/40 p-4 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider font-mono flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-indigo-600" />
              Agent Cognitive Trace Analyzer
            </h4>
            <span className="text-[9px] font-mono font-semibold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-100">
              Interactive Flow
            </span>
          </div>
          
          <p className="text-[10px] text-slate-500 leading-normal leading-relaxed">
            Trace the precise step-by-step audit route: review the upstream process values that feed into this agent (<strong>Inputs</strong>), the logical decision checklist executed (<strong>Cognitive Steps</strong>), and the resultant structured indicators emitted (<strong>Outputs</strong>).
          </p>

          {/* Trace Tabs */}
          <div className="flex bg-slate-100 p-1 rounded-lg gap-1 text-[9px] font-mono font-bold">
            <button
              onClick={() => setTraceTab('all')}
              className={`flex-1 py-1.5 rounded transition ${traceTab === 'all' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              Overview
            </button>
            <button
              onClick={() => setTraceTab('inputs')}
              className={`flex-1 py-1.5 rounded transition ${traceTab === 'inputs' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              📥 Inputs
            </button>
            <button
              onClick={() => setTraceTab('reasoning')}
              className={`flex-1 py-1.5 rounded transition ${traceTab === 'reasoning' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              🧠 Reasoning
            </button>
            <button
              onClick={() => setTraceTab('outputs')}
              className={`flex-1 py-1.5 rounded transition ${traceTab === 'outputs' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              📤 Outputs
            </button>
          </div>

          {/* Tab Viewport */}
          <div className="space-y-3">
            {/* Inputs Section */}
            {(traceTab === 'all' || traceTab === 'inputs') && (
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 text-[10px] font-mono font-bold text-slate-700">
                  <span className="p-1 rounded bg-slate-100 text-slate-600 text-[9px]">📥</span>
                  <span>INCOMING AGENT INPUTS</span>
                </div>
                <div className="grid gap-2">
                  {traceData.inputs.map((inp, idx) => (
                    <div key={idx} className="bg-white border border-slate-150 rounded-lg p-2.5 text-xs shadow-sm">
                      <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono mb-1">
                        <span>Label: {inp.label}</span>
                        <span className="bg-slate-50 text-slate-500 px-1.5 py-0.2 rounded-sm text-[8px] font-bold">Src: {inp.source}</span>
                      </div>
                      <p className="font-semibold text-slate-800 leading-snug">{inp.value}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Cognitive Reasoning Section */}
            {(traceTab === 'all' || traceTab === 'reasoning') && (
              <div className="space-y-2 pt-1">
                <div className="flex items-center gap-1.5 text-[10px] font-mono font-bold text-indigo-700">
                  <span className="p-1 rounded bg-indigo-50 text-indigo-600 text-[9px]">🧠</span>
                  <span>COGNITIVE ACTIONS & REASONING</span>
                </div>
                <div className="relative pl-3.5 space-y-3 border-l-2 border-indigo-100/80 ml-2 py-1">
                  {traceData.reasoning.map((step, idx) => (
                    <div key={idx} className="relative text-xs leading-relaxed text-slate-600">
                      {/* Left timeline dot */}
                      <span className="absolute -left-[20px] top-1 w-2.5 h-2.5 rounded-full border border-indigo-200 bg-white flex items-center justify-center text-[7px] font-bold text-indigo-600 shadow-sm">
                        {idx + 1}
                      </span>
                      <p className="pl-1.5">
                        <strong className="text-indigo-900 font-medium">Step {idx + 1}:</strong> {step}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Outputs Section */}
            {(traceTab === 'all' || traceTab === 'outputs') && (
              <div className="space-y-2 pt-1">
                <div className="flex items-center gap-1.5 text-[10px] font-mono font-bold text-emerald-700">
                  <span className="p-1 rounded bg-emerald-50 text-emerald-600 text-[9px]">📤</span>
                  <span>OUTGOING COMPLIANCE OUTPUTS</span>
                </div>
                <div className="grid gap-2">
                  {traceData.outputs.map((out, idx) => (
                    <div key={idx} className="bg-white border border-emerald-100 rounded-lg p-2.5 text-xs shadow-sm relative overflow-hidden">
                      <div className="absolute top-0 right-0 bottom-0 w-1 bg-emerald-400" />
                      <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono mb-1">
                        <span>Output: {out.label}</span>
                        <span className="bg-emerald-50 text-emerald-600 px-1.5 py-0.2 rounded-sm text-[8px] font-bold">Handoff: {out.target}</span>
                      </div>
                      <p className="font-semibold text-emerald-900 leading-snug">{out.value}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Dynamic Metrics Panel if available */}
        {node.results && (
          <div className="space-y-4">
            {/* KPI Metrics Dashboard Grid */}
            {Object.keys(node.results.metrics).length > 0 && (
              <div>
                <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider font-mono mb-2">
                  AGENT PROCESSED METRICS
                </h4>
                <div className="grid grid-cols-2 gap-3">
                  {Object.entries(node.results.metrics).map(([k, v]) => (
                    <div key={k} className="bg-blue-50/40 border border-blue-100/50 rounded-lg p-2.5">
                      <span className="text-[10px] text-slate-500 block truncate font-mono uppercase">{k}</span>
                      <strong className="text-xs text-blue-900 font-semibold truncate block mt-0.5">{String(v)}</strong>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Findings Block */}
            <div className="bg-slate-50 border border-slate-100 rounded-xl p-4">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider font-mono mb-2 flex items-center gap-1.5">
                <ClipboardCheck className="w-4 h-4 text-slate-500" />
                VETTED COMPLIANCE FINDINGS
              </h4>
              <ul className="space-y-1.5">
                {node.results.findings.map((finding, idx) => (
                  <li key={idx} className="text-xs text-slate-700 flex items-start gap-1.5">
                    <ChevronRight className="w-3.5 h-3.5 text-blue-500 shrink-0 mt-0.5" />
                    <span>{finding}</span>
                  </li>
                ))}
              </ul>
              {node.results.summary && (
                <div className="mt-3 pt-3 border-t border-slate-200/50 text-xs text-slate-600 italic leading-normal">
                  <strong className="text-slate-700 font-medium font-mono not-italic block text-[10px] uppercase mb-0.5">EXECUTIVE SUMMARY:</strong>
                  "{node.results.summary}"
                </div>
              )}
            </div>
          </div>
        )}

        {/* Live Agent Logs Stream */}
        <div className="flex flex-col bg-slate-950 border border-slate-900 rounded-xl p-4 h-[200px]">
          <h4 className="text-[10px] font-bold text-slate-400 tracking-widest font-mono uppercase pb-2 border-b border-slate-900 flex justify-between">
            <span>CONSOLE LOG STREAM</span>
            <span className="text-blue-400 animate-pulse">● LIVE AUDITING</span>
          </h4>
          <div className="flex-1 overflow-y-auto space-y-1 mt-2 pr-1 font-mono text-[10px] text-emerald-400/90 leading-relaxed scrollbar-thin scrollbar-thumb-slate-800">
            {node.logs.map((log, idx) => (
              <div key={idx} className="hover:bg-slate-900/50 px-1 py-0.5 rounded">
                <span className="text-slate-600 mr-2">[{idx + 1}]</span>
                {log}
              </div>
            ))}
          </div>
        </div>

        {/* Human-in-the-loop Clarification Thread — additive escalation path
            alongside the plain Approve/Reject below. Compliance raises a
            clarification (routed to Ops), Ops can resolve it or forward to
            RM, RM can resolve it or initiate client outreach (routes to the
            customer), and the customer's response routes back to RM. */}
        {node.transitionRule !== 'auto' && (clarification || canRaiseClarification) && (
          <div className="border-t border-slate-100 dark:border-slate-800 pt-4 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider font-mono flex items-center gap-1.5">
                <HelpCircle className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                <span>CLARIFICATION THREAD</span>
              </h4>
              {isOpenClarification && (
                <span className="px-2 py-0.5 bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 text-[10px] font-mono font-bold rounded-full border border-amber-300">
                  WAITING ON {PERSONA_LABELS[clarification.targetPersona].toUpperCase()}
                </span>
              )}
            </div>

            {clarification && (
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {clarification.history.map((entry, idx) => (
                  <div key={idx} className="bg-slate-50 dark:bg-slate-800/60 border border-slate-150 dark:border-slate-700 rounded-lg p-2.5">
                    <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 dark:text-slate-400 mb-1">
                      <span className="font-bold text-slate-700 dark:text-slate-300">{PERSONA_LABELS[entry.persona]} · {entry.action.replace('_', ' ')}</span>
                      <span>{new Date(entry.timestamp).toLocaleString()}</span>
                    </div>
                    <p className="text-xs text-slate-700 dark:text-slate-200">{entry.message}</p>
                  </div>
                ))}
              </div>
            )}

            {canRaiseClarification && (
              <div className="space-y-2">
                <p className="text-[10px] text-slate-500 dark:text-slate-400">
                  Will be routed to <strong>{PERSONA_LABELS[nextClarificationTargetLabel(activePersona, node.reviewerRole)]}</strong> for review.
                </p>
                <textarea
                  rows={2}
                  value={clarificationMessage}
                  onChange={(e) => setClarificationMessage(e.target.value)}
                  placeholder="Describe what needs clarification..."
                  className="w-full border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-lg p-2.5 text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none"
                />
                <button
                  onClick={submitRaiseClarification}
                  disabled={!clarificationMessage.trim()}
                  className="w-full py-2 font-bold rounded-lg text-xs transition text-center flex items-center justify-center gap-1.5 bg-amber-600 hover:bg-amber-700 disabled:bg-slate-200 disabled:text-slate-400 text-white cursor-pointer disabled:cursor-not-allowed"
                >
                  <HelpCircle className="w-3.5 h-3.5" /> Raise Clarification
                </button>
              </div>
            )}

            {isMyTurn && activePersona === 'operations_officer' && (
              <div className="space-y-2">
                <textarea
                  rows={2}
                  value={clarificationMessage}
                  onChange={(e) => setClarificationMessage(e.target.value)}
                  placeholder="Response / note for forwarding or resolving..."
                  className="w-full border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-lg p-2.5 text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none"
                />
                <div className="flex gap-2">
                  <button onClick={submitResolveClarification} className="flex-1 py-2 font-bold rounded-lg text-xs bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer flex items-center justify-center gap-1.5">
                    <CheckSquare className="w-3.5 h-3.5" /> Resolve
                  </button>
                  <button
                    onClick={submitForwardClarification}
                    disabled={!clarificationMessage.trim()}
                    className="flex-1 py-2 font-bold rounded-lg text-xs bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-200 disabled:text-slate-400 text-white cursor-pointer disabled:cursor-not-allowed flex items-center justify-center gap-1.5"
                  >
                    <ArrowRight className="w-3.5 h-3.5" /> Forward to RM
                  </button>
                </div>
              </div>
            )}

            {isMyTurn && activePersona === 'rm' && (
              <div className="space-y-2">
                <textarea
                  rows={2}
                  value={clarificationMessage}
                  onChange={(e) => setClarificationMessage(e.target.value)}
                  placeholder="Response / note for resolving..."
                  className="w-full border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-lg p-2.5 text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none"
                />
                <div className="flex gap-2">
                  <button onClick={submitResolveClarification} className="flex-1 py-2 font-bold rounded-lg text-xs bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer flex items-center justify-center gap-1.5">
                    <CheckSquare className="w-3.5 h-3.5" /> Resolve
                  </button>
                  <button
                    onClick={() => onInitiateClarificationOutreach?.(client.id, node.id)}
                    className="flex-1 py-2 font-bold rounded-lg text-xs bg-blue-600 hover:bg-blue-700 text-white cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Bot className="w-3.5 h-3.5" /> Initiate Client Outreach
                  </button>
                </div>
              </div>
            )}

            {isOpenClarification && clarification.targetPersona === 'customer' && activePersona !== 'customer' && (
              <div className="flex items-center gap-2 p-2.5 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-blue-900 dark:text-blue-300 rounded-lg text-xs font-medium">
                <Bot className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Awaiting the customer's response — they'll see this in their portal.</span>
              </div>
            )}
          </div>
        )}

        {/* Interactive Compliance Decisions (Manual Overrides) */}
        {node.status !== 'running' && node.transitionRule !== 'auto' && (
          <div className="border-t border-slate-100 dark:border-slate-800 pt-4 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider font-mono flex items-center gap-1.5">
                <FileCheck className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <span>COMPLIANCE & RISK OFFICER SIGN-OFF</span>
              </h4>
              {(node.status === 'flagged' || node.status === 'awaiting_approval') && (
                <span className="px-2 py-0.5 bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 text-[10px] font-mono font-bold rounded-full animate-pulse border border-amber-300">
                  PENDING APPROVAL
                </span>
              )}
            </div>

            {/* Officer Comment Input */}
            <div>
              <label className="text-[10px] font-mono font-semibold text-slate-500 dark:text-slate-400 uppercase block mb-1">
                Officer Review Comment / Justification:
              </label>
              <textarea
                rows={2}
                value={officerComment}
                onChange={(e) => setOfficerComment(e.target.value)}
                placeholder="Enter compliance evaluation notes, EDD findings, or sign-off justification..."
                className="w-full border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-lg p-2.5 text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>

            {/* Real gate, not just an advisory: a persona that isn't this
                stage's assigned reviewer cannot sign off — see
                isApproveDisabled/isRejectDisabled above. */}
            {!canDirectNode() && (
              <div className="flex items-start gap-1.5 p-2 bg-amber-50 border border-amber-200 rounded-lg text-[10px] text-amber-800 leading-normal">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                <span>
                  Your active persona is <strong className="font-semibold">{activePersona}</strong>, but this stage is assigned to <strong className="font-semibold">{node.reviewerRole ? PERSONA_LABELS[node.reviewerRole] : node.team}</strong> for sign-off. Approve/Reject are blocked here — switch to that persona to act on this node.
                </span>
              </div>
            )}

            {/* Context-Specific Forms */}
            {node.id === 'aml' && (
              <div className="bg-slate-50 border border-slate-100 rounded-lg p-3 space-y-2">
                <span className="text-[10px] font-mono text-slate-500 uppercase block">ENHANCED DUE DILIGENCE (EDD) VERIFICATIONS:</span>
                <div className="space-y-1.5">
                  <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={eddChecklist.uboIdentified} 
                      onChange={() => toggleChecklist('uboIdentified')}
                      className="rounded text-blue-600 focus:ring-blue-500" 
                    />
                    <span>Trace ownership structures up to 10% UBOs</span>
                  </label>
                  <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={eddChecklist.pepVetted} 
                      onChange={() => toggleChecklist('pepVetted')}
                      className="rounded text-blue-600 focus:ring-blue-500" 
                    />
                    <span>Verify PEP relationships and complete wealth questionnaires</span>
                  </label>
                  <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={eddChecklist.sourceVerified} 
                      onChange={() => toggleChecklist('sourceVerified')}
                      className="rounded text-blue-600 focus:ring-blue-500" 
                    />
                    <span>Cross-reference bank statement source-of-wealth</span>
                  </label>
                </div>
              </div>
            )}

            {node.id === 'credit_risk' && (
              <div className="bg-slate-50 border border-slate-100 rounded-lg p-3 space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-mono text-slate-500 uppercase block mb-1">Set Corporate Credit Limit ($):</label>
                    <input
                      type="number"
                      value={manualLimit}
                      onChange={(e) => setManualLimit(e.target.value)}
                      className="w-full border border-slate-200 rounded px-2 py-1 text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-mono text-slate-500 uppercase block mb-1">Risk Underwriter Rating:</label>
                    <select
                      value={selectedRating}
                      onChange={(e) => setSelectedRating(e.target.value)}
                      className="w-full border border-slate-200 rounded px-2 py-1 text-xs"
                    >
                      <option value="AAA">AAA (Extremely Safe)</option>
                      <option value="AA-">AA- (Very Secure)</option>
                      <option value="A+">A+ (Strong Standing)</option>
                      <option value="BBB">BBB (Medium Standing)</option>
                      <option value="BB">BB (Speculative)</option>
                      <option value="C">C (High Credit Risk)</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {(isNodeCompleted || isWorkflowCompleted) && (
              <div className="flex items-center gap-2 p-2.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-300 rounded-lg text-xs font-medium">
                <CheckSquare className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Workflow / Node is completed. No pending manual approvals required.</span>
              </div>
            )}

            {/* Approval decision row */}
            <div className="flex gap-2.5 pt-1">
              <button
                onClick={() => handleManualSignoff(true)}
                disabled={isApproveDisabled}
                title={
                  isNodeCompleted || isWorkflowCompleted
                    ? 'Workflow / node already completed.'
                    : !canDirectNode()
                      ? `Only ${node.reviewerRole ? PERSONA_LABELS[node.reviewerRole] : node.team} can sign off on this stage.`
                      : 'Approve & trigger next workflow nodes'
                }
                className={`flex-1 py-2.5 font-bold rounded-lg text-xs transition text-center shadow-sm flex items-center justify-center gap-1.5 ${
                  isApproveDisabled 
                    ? 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-600 border border-slate-200 dark:border-slate-700 cursor-not-allowed'
                    : 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer'
                }`}
              >
                <CheckSquare className="w-4 h-4" /> Approve & Trigger Next Nodes
              </button>
              <button
                onClick={() => {
                  handleManualSignoff(false);
                  if (activePersona === 'rm') {
                    setRmFlagged(true);
                  }
                }}
                disabled={isRejectDisabled}
                title={
                  isNodeCompleted || isWorkflowCompleted
                    ? 'Workflow / node already completed.'
                    : !canDirectNode()
                      ? `Only ${node.reviewerRole ? PERSONA_LABELS[node.reviewerRole] : node.team} can sign off on this stage.`
                      : 'Reject / flag this node for further review'
                }
                className={`flex-1 py-2.5 font-bold rounded-lg text-xs transition text-center flex items-center justify-center gap-1.5 ${
                  isRejectDisabled 
                    ? 'bg-slate-50 dark:bg-slate-800/50 text-slate-300 dark:text-slate-600 border border-slate-150 dark:border-slate-700 cursor-not-allowed'
                    : 'bg-rose-50 border border-rose-200 hover:bg-rose-100 text-rose-700 cursor-pointer'
                }`}
              >
                <AlertTriangle className="w-4 h-4" /> Reject / Flag Node
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Trigger auto module check if pending or running (hidden for compliance officer) */}
      {activePersona !== 'compliance_officer' && (node.status === 'pending' || node.status === 'running') && (
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
          <span className="text-[10px] text-slate-400 font-mono uppercase">NODE DELEGATION INACTIVE</span>
          <button
            onClick={() => onRunAutonomousNode(node.id)}
            disabled={isProcessing}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white font-semibold text-xs rounded-md shadow-sm transition flex items-center gap-1.5 cursor-pointer"
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-3 h-3 animate-spin" /> Vetting...
              </>
            ) : (
              <>
                <Bot className="w-3.5 h-3.5" /> Trigger Autonomous Review
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
}

