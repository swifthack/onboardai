import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  Sparkles, 
  Loader2, 
  X,
  Building2,
  ChevronDown,
  Paperclip,
  Upload,
  FileText,
  FileCheck,
  Globe,
  UserCheck
} from 'lucide-react';
import { AppPersona, ClientProfile, UploadedDocument } from '../../types';
import { PERSONA_TABS } from '../../constants/personaTabs';
import { apiService } from '../../services/apiService';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  uploadedDoc?: UploadedDocument;
}

interface StagedAttachment {
  file?: File;
  name: string;
  size: string;
  docType: string;
  source: 'customer_provided' | 'externally_sourced';
}

interface CopilotChatPanelProps {
  activePersona?: AppPersona;
  activeClient?: ClientProfile;
  clients?: ClientProfile[];
  onSelectClient?: (clientId: string) => void;
  activeTab?: string;
  onNavigateTab?: (tabId: string) => void;
  onExecuteCommand?: (command: string, args?: any) => void;
  onClose?: () => void;
  onAddDocument?: (newDoc: UploadedDocument, targetClientId?: string) => void;
}

const PERSONA_TITLES: Record<AppPersona, string> = {
  rm: 'RM Copilot',
  platform_admin: 'Admin Copilot',
  compliance_officer: 'Compliance Copilot',
  operations_officer: 'Operations Copilot',
  customer: 'Portal Copilot'
};

const PERSONA_SUGGESTED_PROMPTS: Record<AppPersona, string[]> = {
  rm: [
    "Upload Certificate of Incorporation",
    "Go to Journey Workspace",
    "Open Customer 360",
    "Show Digital Twin Explorer",
    "Summarize UBO ownership structure",
    "Check risk classification flags"
  ],
  platform_admin: [
    "Onboard New Agent",
    "Go to Agent Registry",
    "Open Agent Studio",
    "Show MCP Gateway",
    "Open Governance & Audit"
  ],
  compliance_officer: [
    "Go to Review Queue",
    "Open Compliance Workspace",
    "Show Screening Results",
    "View Escalations",
    "Check PEP risk level"
  ],
  operations_officer: [
    "Go to Ops Review Queue",
    "Open Operations Workspace",
    "Show Document Review Hub",
    "Check document verification status",
    "Review task execution exceptions"
  ],
  customer: [
    "Go to My Dashboard",
    "Check onboarding status",
    "Review submitted documents",
    "Contact Relationship Manager"
  ]
};

export default function CopilotChatPanel({ 
  activePersona = 'rm',
  activeClient, 
  clients,
  onSelectClient,
  activeTab = 'my_pipeline', 
  onNavigateTab, 
  onExecuteCommand, 
  onClose,
  onAddDocument
}: CopilotChatPanelProps) {
  const currentPersonaTitle = PERSONA_TITLES[activePersona] || 'Onboard.ai Copilot';
  const currentTabs = PERSONA_TABS[activePersona] || PERSONA_TABS.rm;
  const suggestedPrompts = PERSONA_SUGGESTED_PROMPTS[activePersona] || PERSONA_SUGGESTED_PROMPTS.rm;

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'msg_1',
      role: 'assistant',
      content: `Hello! I am your **${currentPersonaTitle}**. How can I assist you with corporate client onboarding, compliance, and verification today?\n\n💬 You can chat with me, query client data, or **click the upload button below** to attach and ingest verification documents directly from this chat window!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [stagedAttachment, setStagedAttachment] = useState<StagedAttachment | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Re-initialize welcome message when persona changes
  useEffect(() => {
    setMessages([
      {
        id: `msg_init_${Date.now()}`,
        role: 'assistant',
        content: `Hello! Switched to **${currentPersonaTitle}**. How can I assist you with this workspace?\n\n💬 You can chat, give instructions, or attach and upload verification documents directly using the upload button next to Send.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  }, [activePersona]);

  // Scroll to bottom whenever messages list grows
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, stagedAttachment]);

  // Determine document type and simulated OCR data based on file name and client context
  const buildDocMetadata = (fileName: string, customSource?: 'customer_provided' | 'externally_sourced') => {
    const lowerName = fileName.toLowerCase();
    const source: 'customer_provided' | 'externally_sourced' = customSource || 
      (lowerName.includes('external') || lowerName.includes('acra') || lowerName.includes('registry') || activePersona === 'compliance_officer'
        ? 'externally_sourced' 
        : 'customer_provided');

    let docType = 'Institutional Verification Document';
    let ocrData: Record<string, string> = {
      'Legal Entity': activeClient?.companyName || 'Corporate Entity',
      'Registration Identifier': activeClient?.registrationNumber || '202419822K',
      'Jurisdiction of Incorporation': activeClient?.jurisdiction || 'Singapore (SG)',
      'Ingestion Channel': `Copilot Chat (${PERSONA_TITLES[activePersona] || 'Staff Portal'})`,
      'Data Integrity Match': '100% (Passed Hash Audit)'
    };

    if (lowerName.includes('incorporation') || lowerName.includes('coi') || lowerName.includes('certificate')) {
      docType = 'Certificate of Incorporation';
      ocrData = {
        'Company Name': activeClient?.companyName || 'Corporate Entity',
        'Registration No (UEN)': activeClient?.registrationNumber || '202419822K',
        'Incorporation Date': '14 October 2024',
        'Registered Address': activeClient?.jurisdiction.includes('SG') ? '79 Ayer Rajah Crescent, Singapore 139955' : '10 Marina Blvd, Tower 2, Singapore',
        'Status': 'Live & Registered'
      };
    } else if (lowerName.includes('board') || lowerName.includes('resolution')) {
      docType = 'Board Resolution for Account Opening';
      ocrData = {
        'Entity Name': activeClient?.companyName || 'Corporate Entity',
        'Appointed Signatory': activeClient?.authorizedRepresentative.name || 'Authorized Signatory',
        'Authorized Powers': 'Open Corporate Accounts & Transact',
        'Board Quorum': 'Unanimously Approved'
      };
    } else if (lowerName.includes('shareholder') || lowerName.includes('ubo') || lowerName.includes('register')) {
      docType = 'Shareholder Register & Allocation';
      ocrData = {
        'Primary Shareholder': activeClient?.authorizedRepresentative.name || 'Majority Shareholder',
        'Direct Equity Stake': '70.0%',
        'Secondary Shareholder': 'Apex Global Holdings (30.0%)',
        'UBO Tracing': 'Level 1 Natural Person Identified'
      };
    } else if (lowerName.includes('registry') || lowerName.includes('acra') || lowerName.includes('extract') || lowerName.includes('bizprofile')) {
      docType = 'Business Profile Registry Extract';
      ocrData = {
        'Registry Agency': activeClient?.jurisdiction.includes('SG') ? 'Singapore ACRA' : 'Corporate Affairs Registry',
        'Entity Name': activeClient?.companyName || 'Corporate Entity',
        'Registered UEN': activeClient?.registrationNumber || '202419822K',
        'Good Standing Status': 'Active / Current'
      };
    } else if (lowerName.includes('audit') || lowerName.includes('financial') || lowerName.includes('tax')) {
      docType = 'Audited Financial Statements & Tax Certificate';
      ocrData = {
        'Reporting Entity': activeClient?.companyName || 'Corporate Entity',
        'Fiscal Year': 'FY2025/2026',
        'Net Assets': activeClient?.financials?.assets || '$12.4M SGD',
        'Credit Score Index': activeClient?.financials?.rating || 'AA-'
      };
    }

    return { docType, ocrData, source };
  };

  // Handle local file selection from file input
  const handleFileSelected = (file: File) => {
    const sizeFormatted = file.size > 1024 * 1024 
      ? `${(file.size / (1024 * 1024)).toFixed(1)} MB`
      : `${Math.round(file.size / 1024)} KB`;

    const { docType, source } = buildDocMetadata(file.name);

    setStagedAttachment({
      file,
      name: file.name,
      size: sizeFormatted,
      docType,
      source
    });
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileSelected(file);
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Handle drag and drop files onto the chat panel
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleFileSelected(file);
    }
  };

  // Execute sending a message and/or uploading staged document
  const handleSendMessage = async (textToSend: string) => {
    if ((!textToSend.trim() && !stagedAttachment) || isLoading) return;

    const lowerInput = textToSend.toLowerCase().trim();
    const targetClient = activeClient;

    // 1. If an attachment is staged, ingest and process it
    let uploadedDocObj: UploadedDocument | undefined = undefined;
    if (stagedAttachment && targetClient) {
      const timeStr = new Date().toISOString().replace('T', ' ').substring(0, 16);
      const { docType, ocrData } = buildDocMetadata(stagedAttachment.name, stagedAttachment.source);

      const sourceDetails = stagedAttachment.source === 'externally_sourced' 
        ? `Externally Sourced via ${activePersona === 'compliance_officer' ? 'Compliance Screening Registry Gateway' : 'Official Government Data Connector'}`
        : `Customer Provided (Uploaded via ${PERSONA_TITLES[activePersona]} Chat)`;

      uploadedDocObj = {
        id: `doc_${Date.now()}`,
        name: stagedAttachment.name,
        type: docType,
        size: stagedAttachment.size,
        uploadedAt: timeStr,
        status: 'verified',
        ocrData,
        source: stagedAttachment.source,
        sourceDetails
      };

      if (onAddDocument) {
        onAddDocument(uploadedDocObj, targetClient.id);
      }
    }

    // 2. Prepare user message
    let messageContent = textToSend.trim();
    if (stagedAttachment) {
      const attachmentLabel = `📎 Uploaded Document: **${stagedAttachment.name}** (${stagedAttachment.docType}) [${stagedAttachment.source === 'externally_sourced' ? 'Externally Sourced' : 'Customer Provided'}]`;
      messageContent = messageContent 
        ? `${attachmentLabel}\n\n${messageContent}` 
        : attachmentLabel;
    }

    const userMessage: Message = {
      id: `msg_user_${Date.now()}`,
      role: 'user',
      content: messageContent,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      uploadedDoc: uploadedDocObj
    };

    // Clear staging and input
    const currentAttachment = stagedAttachment;
    setStagedAttachment(null);
    setInput('');

    // Check for "onboard agent" or "onboard new agent" command
    if (lowerInput.includes('onboard agent') || lowerInput.includes('onboard new agent') || lowerInput.includes('create agent') || lowerInput.includes('add agent')) {
      if (onNavigateTab) onNavigateTab('agent_registry');
      if (onExecuteCommand) onExecuteCommand('onboard_agent');
      window.dispatchEvent(new CustomEvent('open_onboard_agent_form'));

      setMessages(prev => [
        ...prev,
        userMessage,
        {
          id: `msg_asst_${Date.now()}`,
          role: 'assistant',
          content: `🤖 **Agent Onboarding Assistant Active**: Switched view to **Agent Registry** and opened the **Onboard Custom Agent** form on the main canvas!`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
      return;
    }

    // Check for prompt-based client selection triggers (only for internal staff personas)
    if (activePersona !== 'customer' && clients && clients.length > 0 && !currentAttachment) {
      const matchedClient = clients.find(c => {
        const nameLower = c.companyName.toLowerCase();
        const idLower = c.id.toLowerCase();
        const words = nameLower.split(' ').filter(w => w.length > 3 && w !== 'pte' && w !== 'ltd' && w !== 'inc' && w !== 'corp');
        return lowerInput.includes(nameLower) || 
               lowerInput.includes(idLower) ||
               words.some(w => lowerInput.includes(w));
      });

      if (matchedClient && matchedClient.id !== activeClient?.id) {
        if (onSelectClient) onSelectClient(matchedClient.id);
        setMessages(prev => [
          ...prev,
          userMessage,
          {
            id: `msg_asst_${Date.now()}`,
            role: 'assistant',
            content: `🎯 **Client Context Updated**: Switched active customer ground to **${matchedClient.companyName}** (${matchedClient.jurisdiction}). All views now display this client.`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
        return;
      }
    }

    // Check for prompt-based navigation triggers
    if (!currentAttachment) {
      const matchedTab = currentTabs.find(tab => {
        const labelLower = tab.label.toLowerCase();
        const idLower = tab.id.toLowerCase();
        const keywords = labelLower.split(' ');
        return lowerInput.includes(labelLower) || 
               lowerInput.includes(idLower) ||
               keywords.some(kw => kw.length > 3 && lowerInput.includes(kw));
      });

      if (matchedTab) {
        if (onNavigateTab) onNavigateTab(matchedTab.id);
        if (onExecuteCommand) onExecuteCommand('navigate', { tabId: matchedTab.id });

        setMessages(prev => [
          ...prev,
          userMessage,
          {
            id: `msg_asst_${Date.now()}`,
            role: 'assistant',
            content: `🧭 **Prompt Navigation Executed**: Switched active view to **${matchedTab.label}**.`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
        return;
      }
    }

    // If an attachment was uploaded, provide immediate OCR extraction confirmation
    if (currentAttachment && targetClient) {
      const { ocrData } = buildDocMetadata(currentAttachment.name, currentAttachment.source);
      
      const asstResponseText = `✅ **Document Successfully Ingested & Verified!**\n\n📄 **${currentAttachment.name}** has been ingested into **${targetClient.companyName}**'s verification vault.\n\n- **Source Tag**: \`${currentAttachment.source === 'externally_sourced' ? 'Externally Sourced' : 'Customer Provided'}\`\n- **Document Type**: *${currentAttachment.docType}*\n- **OCR Extraction**: Extracted ${Object.keys(ocrData).length} key-value attributes with **99.4% OCR match score**.\n- **Verification Status**: Marked as **VERIFIED** in **Ingested Verification Documents**.\n\nYou can inspect this document anytime in the read-only **Document Viewer**!`;

      setMessages(prev => [
        ...prev,
        userMessage,
        {
          id: `msg_asst_${Date.now()}`,
          role: 'assistant',
          content: asstResponseText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          uploadedDoc: uploadedDocObj
        }
      ]);
      return;
    }

    // Otherwise standard copilot AI question response
    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    try {
      const formattedHistory = [...messages, userMessage]
        .slice(-10)
        .map(m => ({
          role: m.role,
          content: m.content
        }));

      const data = await apiService.askRmCopilot(formattedHistory, activeClient || null);
      
      setMessages(prev => [
        ...prev,
        {
          id: `msg_asst_${Date.now()}`,
          role: 'assistant',
          content: data.reply || "I encountered an error formulating my answer.",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);

      if (onExecuteCommand) {
        const textLower = (data.reply || "").toLowerCase();
        if (textLower.includes("triggered onboarding step") || textLower.includes("verifying biometrics")) {
          onExecuteCommand("trigger_check", { client: activeClient });
        }
      }

    } catch (err: any) {
      setMessages(prev => [
        ...prev,
        {
          id: `msg_err_${Date.now()}`,
          role: 'assistant',
          content: `⚠️ **API Connection Error**: ${err.message || 'The backend model server could not be reached.'}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickPrompt = (promptText: string) => {
    if (promptText.toLowerCase().includes('certificate')) {
      handleFileSelected(new File([''], 'Certificate_of_Incorporation_Signed.pdf', { type: 'application/pdf' }));
    } else {
      handleSendMessage(promptText);
    }
  };

  return (
    <div 
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={`flex flex-col h-full bg-white dark:bg-[#1d1d1d] border-l border-[#00A3E0]/30 w-full md:w-[580px] lg:w-[700px] xl:w-[780px] shrink-0 z-20 shadow-2xl relative ${
        isDragging ? 'ring-2 ring-emerald-500 ring-inset bg-emerald-50/20' : ''
      }`}
    >
      
      {/* Hidden file input for native file browsing triggered from chat input upload button */}
      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileInputChange} 
        className="hidden" 
        accept=".pdf,.png,.jpg,.jpeg,.docx"
      />

      {/* Header bar */}
      <div className="px-5 py-4 bg-[#002D62] text-white border-b border-[#00A3E0]/30 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-3 text-left">
          <div className="p-2 bg-[#008752] rounded-xl text-white shadow-sm shrink-0">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-sm text-white uppercase tracking-wider">{currentPersonaTitle}</h3>
              <span className="w-2 h-2 rounded-full bg-[#00A3E0] animate-pulse"></span>
            </div>
            <p className="text-[11px] text-[#00A3E0] font-medium mt-0.5">Chat, Command & Document Ingestion Window</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-[#00A3E0] animate-pulse shrink-0" />
          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 hover:bg-[#0B2545] rounded-lg text-[#00A3E0] hover:text-white transition cursor-pointer flex items-center gap-1 font-bold text-xs bg-[#0B2545]/50 border border-[#00A3E0]/30"
              title="Close Copilot Panel"
            >
              <X className="w-4 h-4 text-white" />
              <span className="text-[11px] text-white">Close</span>
            </button>
          )}
        </div>
      </div>

      {/* Active Selected Client Context bar */}
      {activePersona !== 'customer' && (activePersona as string) !== 'customer_self_service' && (
        <div className="px-5 py-2.5 bg-[#00A3E0]/10 dark:bg-indigo-950/20 border-b border-[#00A3E0]/20 text-left flex items-center justify-between gap-2">
          <div className="overflow-hidden flex-1">
            <span className="text-[8px] font-bold text-[#00A3E0] uppercase tracking-widest font-mono block">
              ACTIVE CUSTOMER GROUNDING
            </span>
            {clients && clients.length > 0 ? (
              <div className="relative mt-1">
                <select
                  value={activeClient?.id || ''}
                  onChange={(e) => onSelectClient && onSelectClient(e.target.value)}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-bold text-[#1C1C1C] dark:text-white rounded-lg px-2.5 py-1.5 outline-none focus:ring-1 focus:ring-[#008752] cursor-pointer appearance-none pr-8"
                >
                  {clients.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.companyName} — {c.registrationNumber || c.jurisdiction} ({c.overallStatus.toUpperCase()})
                    </option>
                  ))}
                </select>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-2.5 pointer-events-none" />
              </div>
            ) : (
              <div className="flex items-center gap-1.5 mt-0.5">
                <Building2 className="w-3.5 h-3.5 text-[#008752]" />
                <span className="text-xs font-bold text-[#1C1C1C] dark:text-white truncate">
                  {activeClient ? `${activeClient.companyName} (${activeClient.registrationNumber || activeClient.jurisdiction})` : 'Corporate Entity'}
                </span>
              </div>
            )}
          </div>
          {activeClient && (
            <span className="text-[9px] font-bold px-2 py-0.5 rounded bg-emerald-50 text-[#008752] border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-900 font-mono uppercase tracking-wide shrink-0">
              {activeClient.overallStatus}
            </span>
          )}
        </div>
      )}

      {/* Conversation Thread panel */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((m) => {
          const isAssistant = m.role === 'assistant';
          
          return (
            <div key={m.id} className={`flex flex-col ${isAssistant ? 'items-start' : 'items-end'} text-left`}>
              <div className={`max-w-[88%] rounded-2xl p-4 text-xs shadow-sm leading-relaxed ${
                isAssistant 
                  ? 'bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 text-[#1C1C1C] dark:text-slate-200' 
                  : 'bg-[#002D62] text-white font-medium border border-[#002D62]'
              }`}>
                <div className="whitespace-pre-wrap select-text break-words space-y-2">
                  {m.content.split('\n\n').map((para, pIdx) => {
                    return (
                      <p key={pIdx} className={pIdx > 0 ? 'mt-2' : ''}>
                        {para.split('**').map((chunk, cIdx) => {
                          if (cIdx % 2 === 1) {
                            return <strong key={cIdx} className={isAssistant ? 'font-bold text-[#1C1C1C] dark:text-white' : 'font-extrabold'}>{chunk}</strong>;
                          }
                          return chunk;
                        })}
                      </p>
                    );
                  })}
                </div>

                {/* If message has an embedded document tag */}
                {m.uploadedDoc && (
                  <div className="mt-3 p-2.5 rounded-xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <FileText className="w-4 h-4 text-indigo-500 shrink-0" />
                      <div className="min-w-0">
                        <span className="text-xs font-bold text-slate-800 dark:text-white block truncate">{m.uploadedDoc.name}</span>
                        <span className="text-[9px] text-slate-400 font-mono block">
                          {m.uploadedDoc.source === 'externally_sourced' ? '🌐 Externally Sourced' : '👤 Customer Provided'} • {m.uploadedDoc.size}
                        </span>
                      </div>
                    </div>
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 uppercase shrink-0">
                      VERIFIED
                    </span>
                  </div>
                )}
              </div>
              <span className="text-[9px] text-[#4A6572] mt-1 font-mono">{m.timestamp}</span>
            </div>
          );
        })}
        {isLoading && (
          <div className="flex items-center gap-2 text-[#4A6572] italic text-xs py-2 text-left">
            <Loader2 className="w-3.5 h-3.5 animate-spin text-[#008752]" />
            Copilot is processing request & verifying documents...
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Prompts */}
      <div className="p-3 bg-slate-50/50 dark:bg-slate-900/20 border-t border-slate-150 dark:border-slate-800/80 text-left">
        <span className="text-[8px] font-bold text-[#4A6572] uppercase tracking-widest block mb-2 font-mono">SUGGESTED COPILOT PROMPTS</span>
        <div className="flex flex-wrap gap-1.5 max-h-[110px] overflow-y-auto">
          {suggestedPrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleQuickPrompt(p)}
              className="px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 text-[#4A6572] dark:text-slate-400 hover:text-[#008752] dark:hover:text-[#00A3E0] hover:border-[#008752] rounded-xl text-[10px] font-bold text-left cursor-pointer transition shadow-sm shrink-0"
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* Staged Document Attachment Box in the Chat Window */}
      {stagedAttachment && (
        <div className="px-4 py-2 bg-indigo-50 dark:bg-indigo-950/40 border-t border-indigo-200 dark:border-indigo-900/60 text-left animate-in fade-in duration-150">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="p-1.5 rounded-lg bg-indigo-100 dark:bg-indigo-900/60 text-indigo-600 dark:text-indigo-300 shrink-0">
                <FileCheck className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-800 dark:text-white truncate">
                    {stagedAttachment.name}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    ({stagedAttachment.size})
                  </span>
                </div>
                <span className="text-[10px] text-indigo-600 dark:text-indigo-400 font-medium block">
                  {stagedAttachment.docType}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {/* Source Tag Toggle */}
              <button
                type="button"
                onClick={() => setStagedAttachment(prev => prev ? {
                  ...prev,
                  source: prev.source === 'customer_provided' ? 'externally_sourced' : 'customer_provided'
                } : null)}
                className={`px-2 py-1 rounded-md text-[10px] font-bold flex items-center gap-1 border transition cursor-pointer ${
                  stagedAttachment.source === 'externally_sourced'
                    ? 'bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-950 dark:text-purple-300 dark:border-purple-800'
                    : 'bg-blue-100 text-blue-800 border-blue-300 dark:bg-blue-950 dark:text-blue-300 dark:border-blue-800'
                }`}
                title="Click to toggle source classification"
              >
                {stagedAttachment.source === 'externally_sourced' ? (
                  <>
                    <Globe className="w-3 h-3 text-purple-600" />
                    <span>Externally Sourced</span>
                  </>
                ) : (
                  <>
                    <UserCheck className="w-3 h-3 text-blue-600" />
                    <span>Customer Provided</span>
                  </>
                )}
              </button>

              {/* Remove attachment */}
              <button
                type="button"
                onClick={() => setStagedAttachment(null)}
                className="p-1 rounded text-slate-400 hover:text-rose-500 transition cursor-pointer"
                title="Remove attached document"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Message Input Box: Primary place for typing everything and Uploading next to Send */}
      <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1d1d1d]">
        <div className="flex items-center gap-2">
          
          {/* Main Text Input */}
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage(input)}
            placeholder={stagedAttachment ? "Add a message or press Send to upload and verify..." : "Type prompt, ask questions, or attach documents..."}
            className="flex-1 bg-[#F4F6F8] dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-xs outline-none focus:ring-1 focus:ring-[#008752] text-[#1C1C1C] dark:text-white"
          />

          {/* Upload Button Next to Send Button */}
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className={`p-3 rounded-xl border transition cursor-pointer shrink-0 flex items-center justify-center gap-1.5 ${
              stagedAttachment
                ? 'bg-indigo-50 border-indigo-300 text-indigo-700 dark:bg-indigo-950 dark:border-indigo-700 dark:text-indigo-300'
                : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700'
            }`}
            title="Upload / Attach Document from Chat"
          >
            <Upload className="w-4 h-4" />
            <span className="text-xs font-bold hidden sm:inline">Upload</span>
          </button>

          {/* Send Button */}
          <button
            type="button"
            onClick={() => handleSendMessage(input)}
            disabled={(!input.trim() && !stagedAttachment) || isLoading}
            className="p-3 rounded-xl bg-[#008752] hover:bg-[#006e42] text-white disabled:opacity-40 transition cursor-pointer shrink-0 flex items-center justify-center gap-1.5 shadow-sm"
            title="Send Message / Process Upload"
          >
            <Send className="w-4 h-4" />
            <span className="text-xs font-bold hidden sm:inline">Send</span>
          </button>
        </div>
      </div>

    </div>
  );
}
