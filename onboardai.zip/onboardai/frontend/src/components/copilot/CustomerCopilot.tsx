import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  Sparkles, 
  Loader2, 
  Check, 
  Paperclip,
  Upload,
  AlertCircle,
  FileCheck,
  Smartphone,
  Fingerprint,
  Building,
  RefreshCw,
  Info,
  ExternalLink,
  X
} from 'lucide-react';
import { ClientProfile, WorkflowNode, UploadedDocument, NodeStatus } from '../../types';
import { apiService } from '../../services/apiService';

interface CustomerCopilotProps {
  activeClient: ClientProfile;
  onUpdateClient: (updatedClient: ClientProfile) => void;
  isDarkMode: boolean;
  onOcrTriggered?: (docName: string, docType: string, ocrData: Record<string, string>) => void;
  onMinimize?: () => void;
}

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  isActionFeedback?: boolean;
}

export default function CustomerCopilot({
  activeClient,
  onUpdateClient,
  isDarkMode,
  onOcrTriggered,
  onMinimize
}: CustomerCopilotProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'msg_welcome_1',
      role: 'assistant',
      content: `Hello! I am **Onboarding Buddy** (\`cib_onb_agent\`), your CIB Onboarding Assistant powered by **Gemini 2.5 Pro**. 🌟\n\nI am here to guide you through your automated corporate setup via dual-channel ingestion. You don't have to manually fill out forms — **tell me what to do or upload your corporate documents** directly right here!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showNotification, setShowNotification] = useState<string | null>(null);
  
  // Simulated file upload state inside the chat
  const [attachedFile, setAttachedFile] = useState<{ name: string; size: string; type: string } | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Scroll to bottom whenever messages list grows
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Push helper messages based on pending tasks on load or node status updates
  const getNextRecommendedAction = () => {
    const isSg = activeClient.jurisdiction.includes('SG') || activeClient.jurisdiction.toLowerCase().includes('singapore');
    const nodes = activeClient.workflowNodes;
    const isDaCompleted = nodes.find(n => n.id === 'data_aggregator')?.status === 'completed';
    const isBioCompleted = nodes.find(n => n.id === 'biometric_verification')?.status === 'completed';
    const isDocCompleted = nodes.find(n => n.id === 'doc_verification')?.status === 'completed';

    if (!isDaCompleted) {
      return isSg 
        ? { text: "Link Singapore Singpass", prompt: "I want to link our Singapore Singpass Business identity to pull ACRA details." }
        : { text: "Link India Tax Profile (PAN/GSTIN)", prompt: "I want to link our Indian PAN and GSTIN registries to sync business details." };
    }
    if (!isBioCompleted) {
      return isSg
        ? { text: "Perform Biometric Face Match", prompt: "Let's perform the biometric face verification match for Tan Min Hao." }
        : { text: "Verify Aadhaar Biometrics", prompt: "I want to verify my representative Aadhaar identity using number 543210987654." };
    }
    if (!isDocCompleted) {
      const hasCoi = activeClient.documents.some(d => d.name.toLowerCase().includes('incorporation'));
      const hasBoard = activeClient.documents.some(d => d.name.toLowerCase().includes('board'));
      const hasShareholders = activeClient.documents.some(d => d.name.toLowerCase().includes('shareholder') || d.name.toLowerCase().includes('ubo'));

      if (!hasCoi) return { text: "Upload Certificate of Incorporation", prompt: "I am ready to upload my Certificate of Incorporation.", isUploadTrigger: 'coi' };
      if (!hasBoard) return { text: "Upload Board Resolution", prompt: "I am ready to upload our signed Board Resolution.", isUploadTrigger: 'board' };
      if (!hasShareholders) return { text: "Upload Shareholder Register", prompt: "I am ready to upload our Ultimate Beneficiary Owners / Shareholder Register.", isUploadTrigger: 'shareholders' };
    }
    return null;
  };

  const nextAction = getNextRecommendedAction();

  // Unified status checker
  const isSg = activeClient.jurisdiction.includes('SG') || activeClient.jurisdiction.toLowerCase().includes('singapore');
  const isDaCompleted = activeClient.workflowNodes.find(n => n.id === 'data_aggregator')?.status === 'completed';
  const isBioCompleted = activeClient.workflowNodes.find(n => n.id === 'biometric_verification')?.status === 'completed';
  const isDocCompleted = activeClient.workflowNodes.find(n => n.id === 'doc_verification')?.status === 'completed';

  const handleSendMessage = async (textToSend: string, isFilePost = false) => {
    if (!textToSend.trim() && !attachedFile) return;
    if (isLoading) return;

    let finalPrompt = textToSend;
    if (isFilePost && attachedFile) {
      finalPrompt = `[Uploaded File: ${attachedFile.name}] ${textToSend || `Uploading corporate document for OCR verification: ${attachedFile.name}`}`;
    }

    const userMessage: Message = {
      id: `msg_user_${Date.now()}`,
      role: 'user',
      content: finalPrompt,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setAttachedFile(null);
    setIsLoading(true);

    try {
      // Send message to Customer Copilot endpoint
      const formattedHistory = [...messages, userMessage].slice(-12).map(m => ({ role: m.role as 'user' | 'assistant' | 'system', content: m.content }));
      const data = await apiService.askCustomerCopilot(formattedHistory, activeClient);
      
      // Post Assistant response
      setMessages(prev => [
        ...prev,
        {
          id: `msg_asst_${Date.now()}`,
          role: 'assistant',
          content: data.reply || "I've successfully updated your onboarding pipeline.",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);

      // Execute extracted AI action immediately if any is returned
      if (data.action && data.action.type !== 'NONE') {
        executeAIAction(data.action.type, data.action.params);
      }

    } catch (err: any) {
      setMessages(prev => [
        ...prev,
        {
          id: `msg_err_${Date.now()}`,
          role: 'assistant',
          content: `⚠️ **API Error**: I was unable to connect to the central AI Model to process that request. Let me simulate a standard onboarding processing step for you instead!`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
      // Run fallback simulation if server fails
      simulateFallbackOnboarding(textToSend);
    } finally {
      setIsLoading(false);
    }
  };

  // Automated Action Executor - Updates Client profile dynamically based on prompts
  const executeAIAction = (actionType: string, params: any) => {
    let updatedClient: ClientProfile = { ...activeClient };
    let successMessage = "";

    if (actionType === 'LINK_SINGPASS') {
      if (isDaCompleted) return;
      const directors = [
        { name: activeClient.authorizedRepresentative.name, role: 'Managing Director', appointmentDate: '12 Jan 2022', nationality: 'Singaporean' },
        { name: 'Sarah Jenkins', role: 'Director', appointmentDate: '01 Jun 2023', nationality: 'British' }
      ];

      const shareholders = [
        { name: activeClient.authorizedRepresentative.name, equity: 70.0, pepStatus: false },
        { name: 'Sarah Jenkins', equity: 30.0, pepStatus: false }
      ];

      const updatedNodes = activeClient.workflowNodes.map(node => {
        if (node.id === 'data_aggregator') {
          return {
            ...node,
            status: 'completed' as NodeStatus,
            logs: [
              ...node.logs,
              '[06:07:33] 📡 Connecting to Singpass MyInfo API Gateway via Prompt...',
              '[06:07:34] 🔒 Performing OAuth authorization handshake...',
              '[06:07:34] ✅ Retrieve corporate registry details success!',
              '[06:07:34] 📝 Populating ACRA details into local core profile.'
            ],
            results: {
              summary: 'ACRA database retrieved successfully via Singpass MyInfo Business.',
              metrics: {
                'ACRA Standing': 'ACTIVE',
                'Entity Type': 'Private Limited Company',
                'UEN Verification': 'MATCHED',
                'Registered Address': '10 Marina Boulevard, Tower 2 Level 39, Singapore 018983'
              },
              findings: [
                'Entity exists in active status in ACRA register.',
                'Tan Min Hao listed as authorized Managing Director.',
                'Registered office address matches Singpass official government records.'
              ]
            }
          };
        }
        return node;
      });

      updatedClient = {
        ...activeClient,
        directors,
        shareholders,
        workflowNodes: updatedNodes,
        overallStatus: 'in_progress'
      };
      successMessage = "🔗 Singpass Link: Corporate profile updated from ACRA registries successfully!";

    } else if (actionType === 'LINK_AADHAAR') {
      if (isBioCompleted) return;
      const verifiedAadhaar = params?.aadhaarNumber || '543210987654';

      const updatedNodes = activeClient.workflowNodes.map(node => {
        if (node.id === 'biometric_verification') {
          return {
            ...node,
            status: 'completed' as NodeStatus,
            logs: [
              ...node.logs,
              `[06:08:12] 📡 Requesting UIDAI secure OTP session for Aadhaar ${verifiedAadhaar}...`,
              '[06:08:14] 🔑 OTP validation successful.',
              '[06:08:15] 📸 Retrieving Aadhaar e-KYC photograph and coordinate vector.',
              '[06:08:15] ✅ Secure e-KYC fingerprint & facial handshake passed.'
            ],
            results: {
              summary: 'Aadhaar e-KYC verification completed successfully with UIDAI National Registry.',
              metrics: {
                'UIDAI Reference': 'AADH-8472-KYC',
                'Identity Match score': '99.2%',
                'Face Map Confidence': '98.5%'
              },
              findings: [
                `Representative Aadhaar Name matched: "${activeClient.authorizedRepresentative.name}"`,
                'UIDAI status verified: Authentic & Active.'
              ]
            }
          };
        }
        return node;
      });

      updatedClient = {
        ...activeClient,
        authorizedRepresentative: {
          ...activeClient.authorizedRepresentative,
          biometricVerified: true,
          biometricMatchScore: 99,
          biometricSelfieUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200'
        },
        workflowNodes: updatedNodes
      };
      successMessage = "👤 e-KYC Complete: Biometric Face match successfully verified with UIDAI registry!";

    } else if (actionType === 'LINK_PAN_GSTIN') {
      if (isDaCompleted) return;
      const pan = params?.panNumber || 'ABCDE1234F';
      const gstin = params?.gstinNumber || '29ABCDE1234F1Z5';

      const updatedNodes = activeClient.workflowNodes.map(node => {
        if (node.id === 'data_aggregator') {
          return {
            ...node,
            status: 'completed' as NodeStatus,
            logs: [
              ...node.logs,
              `[06:09:12] 📡 Connecting to GSTN & NSDL Tax gateway using PAN: ${pan.toUpperCase()}`,
              `[06:09:13] 🔒 Validating Corporate GSTIN: ${gstin.toUpperCase()}`,
              `[06:09:14] ✅ Registered Business Name found: "${activeClient.companyName}"`,
              `[06:09:14] 📂 Metadata fetched: ACTIVE, Private Limited Co, Registered Address in India.`
            ],
            results: {
              summary: 'NSDL Income Tax & GSTN databases matched.',
              metrics: {
                'PAN Validation': 'MATCHED',
                'GSTIN Status': 'ACTIVE',
                'GST Registry Name': activeClient.companyName,
                'Filing Compliance': '98.5%'
              },
              findings: [
                `Verified company PAN matches central CBDT databases.`,
                `GSTIN registered on Central Board of Indirect Taxes & Customs.`,
                `Active corporate tax standing with clear historical logs.`
              ]
            }
          };
        }
        return node;
      });

      updatedClient = {
        ...activeClient,
        registrationNumber: gstin.toUpperCase(),
        workflowNodes: updatedNodes,
        overallStatus: 'in_progress'
      };
      successMessage = `💼 Tax Registry Connected: PAN/GSTIN linked successfully!`;

    } else if (actionType === 'UPLOAD_DOCUMENT') {
      const docType = params?.documentType || 'coi';
      const fileName = params?.fileName || (docType === 'coi' ? 'Certificate_of_Incorporation_Signed.pdf' : docType === 'board' ? 'Board_Resolution_onboard_ai_CASA.pdf' : 'UBO_Shareholder_Register_2026.pdf');

      // Check if already present to avoid duplicate assets
      const alreadyExists = activeClient.documents.some(d => d.name.toLowerCase().includes(docType === 'shareholders' ? 'shareholder' : docType));
      if (alreadyExists) return;

      let ocrData: Record<string, string> = {};
      if (docType === 'coi') {
        ocrData = {
          'Legal Entity Name': activeClient.companyName,
          'Registration Number': activeClient.registrationNumber,
          'Date of Incorporation': '14-Feb-2021',
          'Country': activeClient.jurisdiction.includes('SG') ? 'Singapore' : 'India',
          'Document Type': 'Certificate of Incorporation'
        };
      } else if (docType === 'board') {
        ocrData = {
          'Resolution Scope': 'Authority to Open Corporate Accounts',
          'Institution': 'Onboard.ai Bank Group',
          'Authorized Signatory': activeClient.authorizedRepresentative.name,
          'SLA Threshold Approval': 'Accepted',
          'Date of Meeting': '10-Jul-2026'
        };
      } else {
        ocrData = {
          'Significant Shareholder 1': activeClient.shareholders[0]?.name || activeClient.authorizedRepresentative.name,
          'Equity Holdings 1': `${activeClient.shareholders[0]?.equity || 100}%`,
          'Ultimate Beneficiary Owners Detected': '1',
          'Seychelles Layer Checked': 'Cleared (Direct Holding)'
        };
      }

      const newDoc: UploadedDocument = {
        id: `doc_${Date.now()}`,
        name: fileName,
        type: docType === 'coi' ? 'Certificate of Incorporation' : docType === 'board' ? 'Board Resolution for Account Opening' : 'Shareholder Register & Allocation',
        size: '1.4 MB',
        uploadedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
        status: 'verified',
        ocrData,
        source: 'customer_provided',
        sourceDetails: 'Uploaded directly by Customer via Portal Copilot'
      };

      const updatedDocs = [...activeClient.documents, newDoc];

      const hasCoi = updatedDocs.some(d => d.name.toLowerCase().includes('incorporation'));
      const hasBoard = updatedDocs.some(d => d.name.toLowerCase().includes('board'));
      const hasShareholders = updatedDocs.some(d => d.name.toLowerCase().includes('shareholder') || d.name.toLowerCase().includes('ubo'));

      const allDocsUploaded = hasCoi && hasBoard && hasShareholders;

      const updatedNodes = activeClient.workflowNodes.map(node => {
        if (node.id === 'doc_verification') {
          return {
            ...node,
            status: (allDocsUploaded ? 'completed' : 'pending') as NodeStatus,
            logs: [
              ...node.logs,
              `[06:09:40] 📂 Received file: ${newDoc.name} via Prompt OCR`,
              `[06:09:41] 🤖 Executing layout-aware Vision OCR models...`,
              `[06:09:42] ✅ Extracted: ${Object.entries(ocrData).map(([k, v]) => `${k}=${v}`).slice(0, 3).join(', ')}`,
              allDocsUploaded ? `[06:09:42] 🎉 All 3 required documents verified successfully.` : `[06:09:42] ⚠️ Document check complete. Still waiting for other files.`
            ],
            results: {
              summary: allDocsUploaded 
                ? 'All mandatory onboarding documents successfully uploaded, verified, and mapped.' 
                : 'Partially verified files. Complete upload checklist to resolve node.',
              metrics: {
                'OCR Accuracy': '99.4%',
                'Signature Detection': 'Passed',
                'Submitted Files': updatedDocs.length,
                'Authenticity Handshake': 'SECURE_PDF'
              },
              findings: [
                `Extracted entity name matched registered registries.`,
                `Signatory "${activeClient.authorizedRepresentative.name}" verified on Board Resolution.`,
                `UBO structure mapped to central registries. No shell layers detected.`
              ]
            }
          };
        }
        return node;
      });

      updatedClient = {
        ...activeClient,
        documents: updatedDocs,
        workflowNodes: updatedNodes
      };
      successMessage = `📄 Document Uploaded & OCR Scanned: '${fileName}' key-value pairs ready for verification!`;

      if (onOcrTriggered) {
        onOcrTriggered(fileName, docType, ocrData);
      }
    }

    if (successMessage) {
      onUpdateClient(updatedClient);
      setShowNotification(successMessage);
      setTimeout(() => setShowNotification(null), 5000);

      // Append systems message as feedback bubble in the chat
      setMessages(prev => [
        ...prev,
        {
          id: `sys_feedback_${Date.now()}`,
          role: 'assistant',
          content: `🤖 **Pipeline Sync Success**:\n${successMessage}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isActionFeedback: true
        }
      ]);
    }
  };

  // Simulates standard fallback triggers if Gemini models encounter localized environment/credentials error
  const simulateFallbackOnboarding = (text: string) => {
    const textLower = text.toLowerCase();
    
    // Simulate actions based on keywords in prompts
    if (textLower.includes('singpass') || textLower.includes('acra') || textLower.includes('singapore')) {
      executeAIAction('LINK_SINGPASS', null);
    } else if (textLower.includes('aadhaar') || textLower.includes('biometric') || textLower.includes('otp')) {
      const match = text.match(/\d{12}/);
      executeAIAction('LINK_AADHAAR', { aadhaarNumber: match ? match[0] : null });
    } else if (textLower.includes('pan') || textLower.includes('gstin') || textLower.includes('tax')) {
      executeAIAction('LINK_PAN_GSTIN', null);
    } else if (textLower.includes('incorporation') || textLower.includes('coi')) {
      executeAIAction('UPLOAD_DOCUMENT', { documentType: 'coi', fileName: 'Certificate_of_Incorporation_Signed.pdf' });
    } else if (textLower.includes('board') || textLower.includes('resolution')) {
      executeAIAction('UPLOAD_DOCUMENT', { documentType: 'board', fileName: 'Board_Resolution_onboard_ai_CASA.pdf' });
    } else if (textLower.includes('shareholder') || textLower.includes('register') || textLower.includes('ubo')) {
      executeAIAction('UPLOAD_DOCUMENT', { documentType: 'shareholders', fileName: 'UBO_Shareholder_Register_2026.pdf' });
    } else {
      // General feedback
      setMessages(prev => [
        ...prev,
        {
          id: `fallback_gen_${Date.now()}`,
          role: 'assistant',
          content: `I've registered your query. Let me know if you would like me to link your national identity (Singpass / Aadhaar) or parse corporate documents such as Certificate of Incorporation, Board Resolutions, or Shareholders registers. Just let me know in simple English!`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }
  };

  // Attachment Handler
  const handleAttachmentClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      setAttachedFile({
        name: file.name,
        size: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
        type: file.type
      });
    }
  };

  const handleSuggestedPrompt = (promptText: string) => {
    handleSendMessage(promptText);
  };

  const handleAttachmentSubmit = () => {
    if (!attachedFile) return;
    handleSendMessage(`Submitting file attachment: ${attachedFile.name}`, true);
  };

  return (
    <div className={`p-4 rounded-xl border flex flex-col h-[520px] shadow-sm relative overflow-hidden ${
      isDarkMode ? 'bg-slate-900/40 border-slate-800' : 'bg-white border-slate-100'
    }`}>
      
      {/* Toast Notification Alert Banner */}
      {showNotification && (
        <div className="absolute top-2 left-2 right-2 p-2.5 bg-emerald-500 text-white rounded-lg text-[10px] font-mono font-bold leading-tight z-30 flex items-center gap-2 shadow-lg animate-bounce">
          <Check className="w-3.5 h-3.5 shrink-0" />
          <span>{showNotification}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between pb-3.5 border-b border-slate-800/10 dark:border-slate-800/60 shrink-0">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-emerald-500/10 text-emerald-500 rounded-lg">
            <Bot className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-800 dark:text-white flex items-center gap-1.5">
              Onboarding Buddy <span className="px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-500 font-mono text-[9px] font-bold">cib_onb_agent</span> <Sparkles className="w-3 h-3 text-emerald-500" />
            </h4>
            <p className="text-[10px] text-slate-500">Dual-Channel Ingestion & Document Copilot</p>
          </div>
        </div>

        {onMinimize && (
          <button
            onClick={onMinimize}
            className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400 transition cursor-pointer flex items-center gap-1"
            title="Minimise Copilot panel"
          >
            <X className="w-3.5 h-3.5" />
            <span className="text-[10px] font-semibold hidden sm:inline">Minimise</span>
          </button>
        )}
      </div>

      {/* Chat messages viewport */}
      <div className="flex-1 overflow-y-auto py-3 space-y-3 px-1">
        {messages.map((m) => {
          const isMe = m.role === 'user';
          return (
            <div 
              key={m.id} 
              className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[85%] rounded-xl px-3.5 py-2.5 text-xs relative ${
                m.isActionFeedback 
                  ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-700 dark:text-emerald-300 font-mono text-[10px]'
                  : isMe 
                    ? 'bg-slate-800 dark:bg-emerald-600 text-white' 
                    : 'bg-slate-100 dark:bg-slate-800/80 text-slate-800 dark:text-slate-200'
              }`}>
                {/* Micro role marker */}
                {!isMe && !m.isActionFeedback && (
                  <span className="text-[9px] font-bold text-emerald-600 dark:text-emerald-400 block mb-1">COPILOT</span>
                )}
                
                <p className="whitespace-pre-line leading-relaxed">{m.content}</p>
                <span className={`text-[8px] block mt-1.5 text-right font-mono ${
                  isMe ? 'text-slate-300' : 'text-slate-500'
                }`}>
                  {m.timestamp}
                </span>
              </div>
            </div>
          );
        })}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-slate-100 dark:bg-slate-800/80 rounded-xl px-3 py-2.5 text-xs flex items-center gap-2 text-slate-500">
              <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-600" />
              <span>Analyzing client context...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Suggested prompts area */}
      {nextAction && !isLoading && (
        <div className="p-2 border-t border-slate-800/5 dark:border-slate-800/40 shrink-0">
          <p className="text-[9px] font-mono font-bold text-slate-500 mb-1.5 uppercase tracking-wider">Next Suggested Action:</p>
          <button
            onClick={() => handleSuggestedPrompt(nextAction.prompt)}
            className="w-full text-left p-2 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border border-emerald-500/20 text-[11px] font-medium flex items-center justify-between transition cursor-pointer"
          >
            <span className="truncate">{nextAction.text}</span>
            <Sparkles className="w-3.5 h-3.5 shrink-0" />
          </button>
        </div>
      )}

      {/* File Attachment staging banner */}
      {attachedFile && (
        <div className="p-2 bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900/60 rounded-lg text-xs flex items-center justify-between gap-2 mb-2 shrink-0 animate-fade-in">
          <div className="flex items-center gap-2 overflow-hidden">
            <FileCheck className="w-4 h-4 text-indigo-600 shrink-0 animate-pulse" />
            <div className="truncate">
              <p className="font-semibold text-slate-800 dark:text-slate-200 text-[11px] truncate">{attachedFile.name}</p>
              <p className="text-[9px] text-slate-500 font-mono">{attachedFile.size}</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button 
              onClick={() => setAttachedFile(null)}
              className="text-[10px] text-rose-500 hover:text-rose-600 font-semibold px-2 py-1 rounded"
            >
              Cancel
            </button>
            <button 
              onClick={handleAttachmentSubmit}
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-[10px] px-2.5 py-1.5 rounded-md uppercase tracking-wider shadow-sm"
            >
              Upload
            </button>
          </div>
        </div>
      )}

      {/* Input controls form */}
      <div className="pt-2 border-t border-slate-800/10 dark:border-slate-800/60 flex items-center gap-2 shrink-0">
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleFileChange}
          accept=".pdf,.png,.jpg,.jpeg"
          className="hidden" 
        />

        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && (attachedFile ? handleAttachmentSubmit() : handleSendMessage(input))}
          placeholder={attachedFile ? "Type a message or click Send to upload..." : "Type message or attach document to upload..."}
          className="flex-1 py-2 px-3 border border-slate-200 dark:border-slate-700 rounded-lg text-xs outline-none bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:border-emerald-500"
          disabled={isLoading}
        />

        <button
          onClick={handleAttachmentClick}
          className="p-2.5 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-700/80 rounded-lg text-slate-500 dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition cursor-pointer shrink-0 flex items-center gap-1.5"
          title="Attach / Upload Document from Chat"
          disabled={isLoading}
        >
          <Upload className="w-3.5 h-3.5" />
          <span className="text-xs font-semibold hidden sm:inline">Upload</span>
        </button>

        <button
          onClick={() => {
            if (attachedFile) {
              handleAttachmentSubmit();
            } else {
              handleSendMessage(input);
            }
          }}
          className="p-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition shrink-0 cursor-pointer disabled:opacity-50 flex items-center gap-1.5"
          disabled={isLoading || (!input.trim() && !attachedFile)}
          title="Send Message / Upload Document"
        >
          <Send className="w-3.5 h-3.5" />
          <span className="text-xs font-semibold hidden sm:inline">Send</span>
        </button>
      </div>
    </div>
  );
}
