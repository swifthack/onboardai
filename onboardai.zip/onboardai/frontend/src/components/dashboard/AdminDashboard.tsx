import React, { useState, useEffect } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line,
  Legend
} from 'recharts';
import { 
  Sliders, 
  Cpu, 
  Database, 
  Activity, 
  ShieldCheck, 
  Clock, 
  TrendingUp, 
  AlertCircle,
  FileSpreadsheet,
  CheckCircle,
  ArrowRight,
  RefreshCw,
  Terminal,
  Play,
  Briefcase,
  FileText,
  Search,
  ChevronDown,
  ChevronUp,
  Radio,
  Gauge,
  Zap,
  Crosshair,
  Wind,
  Send,
  AlertTriangle,
  Layers,
  Building2,
  DollarSign,
  UserCheck,
  Compass
} from 'lucide-react';
import { ClientProfile } from '../../types';

interface AdminDashboardProps {
  clients: ClientProfile[];
  onNavigateToOrchestrator: () => void;
  onSelectClient: (id: string) => void;
  persona?: string;
  onInitiateJourney?: () => void;
  onCleanupWorkspace?: () => void;
  sentEmails?: { id: string; clientId: string; status?: string; date?: string; email?: string }[];
  onSendOutreachEmail?: (client: ClientProfile) => void;
}

// System history analytics for Recharts
const PERFORMANCE_DATA = [
  { name: 'Onboarding Agent', Corporate: 12, Funds: 18, avgMs: 420 },
  { name: 'Data Doc Agent', Corporate: 25, Funds: 15, avgMs: 840 },
  { name: 'Registry Agent', Corporate: 32, Funds: 22, avgMs: 310 },
  { name: 'KYC Agent', Corporate: 18, Funds: 34, avgMs: 1250 },
  { name: 'Product Agent', Corporate: 44, Funds: 28, avgMs: 950 },
];

const OVERTIME_DATA = [
  { month: 'Feb', 'Funds Onboarding': 3, 'Corporate Onboarding': 4 },
  { month: 'Mar', 'Funds Onboarding': 6, 'Corporate Onboarding': 5 },
  { month: 'Apr', 'Funds Onboarding': 11, 'Corporate Onboarding': 8 },
  { month: 'May', 'Funds Onboarding': 15, 'Corporate Onboarding': 14 },
  { month: 'Jun', 'Funds Onboarding': 22, 'Corporate Onboarding': 19 },
  { month: 'Jul', 'Funds Onboarding': 28, 'Corporate Onboarding': 24 },
];

export default function AdminDashboard({ 
  clients, 
  onNavigateToOrchestrator, 
  onSelectClient,
  persona,
  onInitiateJourney,
  onCleanupWorkspace,
  sentEmails = [],
  onSendOutreachEmail
}: AdminDashboardProps) {
  const [cpuUsage, setCpuUsage] = useState(24);
  const [memoryUsage, setMemoryUsage] = useState(48.2);
  const [activeSocketCount, setActiveSocketCount] = useState(12);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedJurisdiction, setSelectedJurisdiction] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedRisk, setSelectedRisk] = useState('all');
  const [showAnalytics, setShowAnalytics] = useState(true);

  // Simulate telemetry pulses
  useEffect(() => {
    const interval = setInterval(() => {
      setCpuUsage(Math.round(20 + Math.random() * 15));
      setMemoryUsage(parseFloat((47.8 + Math.random() * 1.2).toFixed(1)));
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const triggerRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => setIsRefreshing(false), 800);
  };

  const totalClientsCount = clients.length;
  const approvedCount = clients.filter(c => c.overallStatus === 'approved').length;
  const inProgressCount = clients.filter(c => c.overallStatus === 'in_progress').length;
  const flaggedCount = clients.filter(c => c.workflowNodes.some(n => n.status === 'flagged')).length;

  const isRM = persona === 'rm';

  const jurisdictionsList = Array.from(new Set(clients.map(c => c.jurisdiction))).filter(Boolean);

  // Filter clients based on search and dropdown selections
  const filteredClients = clients.filter(c => {
    const matchesSearch = !searchTerm.trim() || 
      c.companyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.registrationNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.jurisdiction.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.industry.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.authorizedRepresentative.name.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesJurisdiction = selectedJurisdiction === 'all' || c.jurisdiction === selectedJurisdiction;

    const isFlagged = c.workflowNodes.some(n => n.status === 'flagged');
    const matchesStatus = selectedStatus === 'all' || 
      (selectedStatus === 'flagged' ? isFlagged : c.overallStatus === selectedStatus);

    const hasHighRiskShareholder = c.shareholders.some(s => s.pepStatus);
    const clientRiskLevel = hasHighRiskShareholder || isFlagged ? 'High' : c.workflowNodes.some(n => n.status === 'running') ? 'Medium' : 'Low';
    const matchesRisk = selectedRisk === 'all' || clientRiskLevel === selectedRisk;

    return matchesSearch && matchesJurisdiction && matchesStatus && matchesRisk;
  });

  const hasActiveFilters = searchTerm !== '' || selectedJurisdiction !== 'all' || selectedStatus !== 'all' || selectedRisk !== 'all';

  return (
    <div className="space-y-6">
      {/* COCKPIT COMMAND HEADER BAR */}
      <div className="bg-gradient-to-r from-[#0F172A] via-[#1E293B] to-[#0F172A] border border-[#334155] rounded-2xl p-5 text-white shadow-xl relative overflow-hidden">
        {/* Subtle Cockpit Instrumentation Pattern */}
        <div className="absolute inset-0 bg-[radial-gradient(#38BDF8_1px,transparent_1px)] [background-size:16px_16px] opacity-10 pointer-events-none" />
        
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <h2 className="text-xl font-bold tracking-tight text-white font-sans text-left">
            {isRM ? 'Relationship Manager Onboarding Cockpit' : 'System Administration Command Deck'}
          </h2>

          <div className="flex items-center gap-3 shrink-0">
            {isRM && onInitiateJourney && (
              <button
                onClick={onInitiateJourney}
                className="px-4 py-2.5 bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-sky-500/20 border border-sky-300/30 transition flex items-center gap-2 cursor-pointer transform hover:-translate-y-0.5"
              >
                <Building2 className="w-4 h-4 text-white" /> Initiate Onboarding Journey
              </button>
            )}
          </div>
        </div>
      </div>

      {/* COCKPIT INSTRUMENT GAUGES (CLM METRICS) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {isRM ? (
          <>
            {/* Metric Gauge 1: Pipeline AUM */}
            <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white border border-slate-700/80 rounded-2xl p-4.5 shadow-lg relative overflow-hidden group hover:border-sky-500/50 transition text-left">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black font-mono text-sky-400 uppercase tracking-widest flex items-center gap-1.5">
                  <DollarSign className="w-3.5 h-3.5" /> PIPELINE AUM VALUE
                </span>
                <span className="px-1.5 py-0.5 rounded bg-sky-950 text-sky-300 text-[9px] font-mono font-bold border border-sky-800">
                  TOTAL CAPITAL
                </span>
              </div>
              <div className="text-2xl font-black text-white mt-2 font-mono tracking-tight">$128.5M</div>
              <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono mt-1 pt-2 border-t border-slate-800">
                <span>Active Entities: {totalClientsCount}</span>
                <span className="text-emerald-400 font-bold">100% Verified</span>
              </div>
            </div>

            {/* Metric Gauge 2: Active Onboardings */}
            <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white border border-slate-700/80 rounded-2xl p-4.5 shadow-lg relative overflow-hidden group hover:border-amber-500/50 transition text-left">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black font-mono text-amber-400 uppercase tracking-widest flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5" /> ONBOARDING PIPELINE STATUS
                </span>
                <span className="px-1.5 py-0.5 rounded bg-amber-950 text-amber-300 text-[9px] font-mono font-bold border border-amber-800">
                  IN PROGRESS
                </span>
              </div>
              <div className="text-2xl font-black text-white mt-2 font-mono tracking-tight">{inProgressCount} Active</div>
              <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono mt-1 pt-2 border-t border-slate-800">
                <span className="text-emerald-400 font-bold">{approvedCount} Approved</span>
                <span className="text-rose-400 font-bold">{flaggedCount} Flagged</span>
              </div>
            </div>

            {/* Metric Gauge 3: Average SLA Turnaround */}
            <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white border border-slate-700/80 rounded-2xl p-4.5 shadow-lg relative overflow-hidden group hover:border-emerald-500/50 transition text-left">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black font-mono text-emerald-400 uppercase tracking-widest flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" /> AVG SLA TURNAROUND TIME
                </span>
                <span className="px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 text-[9px] font-mono font-bold border border-emerald-800">
                  SLA PERFORMANCE
                </span>
              </div>
              <div className="text-2xl font-black text-white mt-2 font-mono tracking-tight">4.2 Days</div>
              <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono mt-1 pt-2 border-t border-slate-800">
                <span>Target SLA: &lt; 5.0 Days</span>
                <span className="text-emerald-400 font-bold">16% Faster</span>
              </div>
            </div>

            {/* Metric Gauge 4: Automated Compliance Rate */}
            <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white border border-slate-700/80 rounded-2xl p-4.5 shadow-lg relative overflow-hidden group hover:border-purple-500/50 transition text-left">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black font-mono text-purple-400 uppercase tracking-widest flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5" /> STAGE-GATE COMPLIANCE RATE
                </span>
                <span className="px-1.5 py-0.5 rounded bg-purple-950 text-purple-300 text-[9px] font-mono font-bold border border-purple-800">
                  AUTOMATED PASS
                </span>
              </div>
              <div className="text-2xl font-black text-white mt-2 font-mono tracking-tight">96.4% Auto Pass</div>
              <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono mt-1 pt-2 border-t border-slate-800">
                <span>KYC / Sanctions / OCR</span>
                <span className="text-purple-300 font-bold">Zero Bypass</span>
              </div>
            </div>
          </>
        ) : (
          <>
            {/* Core CPU Stats */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4.5 text-white shadow-lg text-left">
              <span className="text-[10px] font-mono font-bold text-sky-400 uppercase tracking-wider block">CPU ORCHESTRATOR PULSE</span>
              <div className="text-2xl font-black text-white mt-1 font-mono">{cpuUsage}%</div>
              <p className="text-[10px] text-slate-400 mt-1 font-mono">Autonomous loop ticker active</p>
            </div>

            {/* Core Memory Stats */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4.5 text-white shadow-lg text-left">
              <span className="text-[10px] font-mono font-bold text-blue-400 uppercase tracking-wider block">VIRTUAL HEAP MEMORY</span>
              <div className="text-2xl font-black text-white mt-1 font-mono">{memoryUsage} MB</div>
              <p className="text-[10px] text-slate-400 mt-1 font-mono">Micro-server allocation</p>
            </div>

            {/* Active Sockets Stats */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4.5 text-white shadow-lg text-left">
              <span className="text-[10px] font-mono font-bold text-purple-400 uppercase tracking-wider block">DELEGATE AGENTS</span>
              <div className="text-2xl font-black text-white mt-1 font-mono">{activeSocketCount} Active</div>
              <p className="text-[10px] text-slate-400 mt-1 font-mono">CASA, Trade & Risk agents</p>
            </div>

            {/* Global Compliance Pass rate */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4.5 text-white shadow-lg text-left">
              <span className="text-[10px] font-mono font-bold text-rose-400 uppercase tracking-wider block">AUTO PASS RATE</span>
              <div className="text-2xl font-black text-white mt-1 font-mono">96.4%</div>
              <p className="text-[10px] text-slate-400 mt-1 font-mono">Manual bypass target</p>
            </div>
          </>
        )}
      </div>

      {/* Conditionally rendered Recharts Analytics Section */}
      {showAnalytics && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-2xl text-white">
          {/* Chart 1: Onboarding Volume Trends */}
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 text-left">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
              <div>
                <h3 className="font-extrabold text-white text-sm flex items-center gap-2">
                  <Activity className="w-4 h-4 text-sky-400" />
                  Onboarding Journey Volume Trends
                </h3>
                <p className="text-[10px] font-mono text-slate-400 uppercase tracking-wider mt-0.5">Historic monthly throughput by client entity type</p>
              </div>
              <TrendingUp className="w-4 h-4 text-sky-400" />
            </div>
            <div className="h-[200px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={OVERTIME_DATA} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
                  <XAxis dataKey="month" stroke="#64748b" fontSize={11} tickLine={false} />
                  <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#fff' }} />
                  <Legend iconSize={8} wrapperStyle={{ fontSize: 11 }} />
                  <Line type="monotone" dataKey="Corporate Onboarding" stroke="#38bdf8" strokeWidth={3} activeDot={{ r: 6 }} />
                  <Line type="monotone" dataKey="Funds Onboarding" stroke="#a855f7" strokeWidth={3} activeDot={{ r: 6 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Chart 2: Agent Node Performance */}
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 text-left">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
              <div>
                <h3 className="font-extrabold text-white text-sm flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-emerald-400" />
                  Autonomous Agent Execution Latency
                </h3>
                <p className="text-[10px] font-mono text-slate-400 uppercase tracking-wider mt-0.5">Processed tasks & execution duration per agent node</p>
              </div>
              <Clock className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="h-[200px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={PERFORMANCE_DATA} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
                  <XAxis dataKey="name" stroke="#64748b" fontSize={11} tickLine={false} />
                  <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#fff' }} />
                  <Legend iconSize={8} wrapperStyle={{ fontSize: 11 }} />
                  <Bar dataKey="Corporate" fill="#38bdf8" radius={[4, 4, 0, 0]} barSize={16} />
                  <Bar dataKey="Funds" fill="#34d399" radius={[4, 4, 0, 0]} barSize={16} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* COCKPIT CLIENT ONBOARDING DIRECTORY TABLE */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-lg text-left space-y-4">
        <div className="flex flex-col xl:flex-row xl:items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-sky-500/10 text-sky-600 dark:text-sky-400 rounded-xl border border-sky-500/20">
              <Building2 className="w-5 h-5 text-sky-500" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-800 dark:text-white text-base font-sans flex items-center gap-2">
                Active Corporate Onboarding Directory
              </h3>
              <p className="text-[10px] font-mono text-slate-400 dark:text-slate-500 uppercase tracking-wider mt-0.5">
                SHOWING {filteredClients.length} CORPORATE CLIENT JOURNEYS • COCKPIT VIEW
              </p>
            </div>
          </div>
          
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Search Input */}
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search entity, registration #, UBO..."
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs outline-none text-slate-800 dark:text-white placeholder-slate-400 focus:ring-1 focus:ring-sky-500"
              />
            </div>

            {/* Jurisdiction Dropdown */}
            <div className="flex items-center gap-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-2.5 py-1 text-xs">
              <span className="text-[10px] font-mono font-bold text-slate-400 uppercase">Jurisdiction:</span>
              <select
                value={selectedJurisdiction}
                onChange={(e) => setSelectedJurisdiction(e.target.value)}
                className="bg-transparent text-xs font-semibold text-slate-800 dark:text-slate-200 outline-none cursor-pointer"
              >
                <option value="all">All Jurisdictions</option>
                {jurisdictionsList.map(j => (
                  <option key={j} value={j}>{j}</option>
                ))}
              </select>
            </div>

            {/* Status Dropdown */}
            <div className="flex items-center gap-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-2.5 py-1 text-xs">
              <span className="text-[10px] font-mono font-bold text-slate-400 uppercase">Status:</span>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="bg-transparent text-xs font-semibold text-slate-800 dark:text-slate-200 outline-none cursor-pointer"
              >
                <option value="all">All Statuses</option>
                <option value="in_progress">In Progress</option>
                <option value="approved">Approved</option>
                <option value="flagged">Flagged / Review Required</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>

            {/* Risk Category Dropdown */}
            <div className="flex items-center gap-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-2.5 py-1 text-xs">
              <span className="text-[10px] font-mono font-bold text-slate-400 uppercase">Risk Level:</span>
              <select
                value={selectedRisk}
                onChange={(e) => setSelectedRisk(e.target.value)}
                className="bg-transparent text-xs font-semibold text-slate-800 dark:text-slate-200 outline-none cursor-pointer"
              >
                <option value="all">All Risk Levels</option>
                <option value="Low">Low Risk</option>
                <option value="Medium">Medium Risk</option>
                <option value="High">High Risk / PEP</option>
              </select>
            </div>

            {/* Clear Filters Button */}
            {hasActiveFilters && (
              <button
                onClick={() => {
                  setSearchTerm('');
                  setSelectedJurisdiction('all');
                  setSelectedStatus('all');
                  setSelectedRisk('all');
                }}
                className="px-2.5 py-1 bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 font-mono text-[10px] font-bold rounded-xl hover:bg-rose-100 transition cursor-pointer"
              >
                Reset Filters
              </button>
            )}
          </div>
        </div>
        
        {filteredClients.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-700 dark:text-slate-300">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 dark:text-slate-500 font-mono font-bold uppercase">
                  <th className="pb-3 pl-2">Corporate Entity & Details</th>
                  <th className="pb-3">Jurisdiction</th>
                  <th className="pb-3">Onboarding Completion</th>
                  <th className="pb-3">Authorized UBO Representative</th>
                  <th className="pb-3">Workflow Status</th>
                  <th className="pb-3">Outreach Status</th>
                  <th className="pb-3 pr-2 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredClients.map((c, idx) => {
                  const clientEmailRecord = sentEmails.find(e => e.clientId === c.id);
                  const outreachStatus = clientEmailRecord?.status || 'not_sent';

                  const completedNodesCount = c.workflowNodes.filter(n => n.status === 'completed').length;
                  const totalNodesCount = c.workflowNodes.length;
                  const progressPct = Math.round((completedNodesCount / totalNodesCount) * 100);

                  return (
                    <tr key={`${c.id}_${idx}`} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition duration-150">
                      <td className="py-3.5 pl-2 font-bold text-slate-800 dark:text-white">
                        <div className="flex items-center gap-2.5">
                          <div className="p-2 rounded-lg bg-sky-500/10 text-sky-600 dark:text-sky-400 shrink-0 border border-sky-500/20">
                            <Building2 className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="font-extrabold text-slate-900 dark:text-white text-xs">{c.companyName}</div>
                            <span className="text-[10px] text-slate-400 dark:text-slate-500 font-mono font-normal">Reg #: {c.registrationNumber} • {c.industry}</span>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 font-semibold text-slate-700 dark:text-slate-300">
                        <span className="inline-flex items-center gap-1 font-mono text-[11px]">
                          📍 {c.jurisdiction}
                        </span>
                      </td>

                      {/* Onboarding Completion Progress Bar */}
                      <td className="py-3.5">
                        <div className="w-36 space-y-1">
                          <div className="flex justify-between items-center text-[9px] font-mono">
                            <span className="text-slate-400">{completedNodesCount}/{totalNodesCount} STEPS</span>
                            <span className="font-bold text-sky-600 dark:text-sky-400">{progressPct}%</span>
                          </div>
                          <div className="h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden border border-slate-200/60 dark:border-slate-700/60">
                            <div 
                              className={`h-full transition-all duration-500 ${
                                c.overallStatus === 'approved' ? 'bg-emerald-500' :
                                c.workflowNodes.some(n => n.status === 'flagged') ? 'bg-rose-500' :
                                'bg-sky-500'
                              }`}
                              style={{ width: `${progressPct}%` }}
                            />
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5">
                        <div className="font-semibold text-slate-800 dark:text-slate-300 text-xs">{c.authorizedRepresentative.name}</div>
                        <span className="text-[10px] text-slate-400 dark:text-slate-500 font-mono block">{c.authorizedRepresentative.email}</span>
                      </td>

                      <td className="py-3.5">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full font-mono text-[10px] font-bold uppercase border shadow-xs ${
                          c.overallStatus === 'approved' ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800' :
                          c.overallStatus === 'rejected' ? 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/40 dark:text-rose-400 dark:border-rose-800' :
                          c.workflowNodes.some(n => n.status === 'flagged') ? 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/40 dark:text-rose-400 dark:border-rose-800' :
                          'bg-sky-50 text-sky-700 border-sky-200 dark:bg-sky-950/40 dark:text-sky-400 dark:border-sky-800'
                        }`}>
                          {c.overallStatus === 'approved' ? 'Approved' :
                           c.workflowNodes.some(n => n.status === 'flagged') ? 'Flagged / Action Needed' :
                           'In Progress'}
                        </span>
                      </td>

                      <td className="py-3.5">
                        {outreachStatus === 'not_sent' ? (
                          <button
                            onClick={() => onSendOutreachEmail && onSendOutreachEmail(c)}
                            className="px-2.5 py-1 bg-sky-50 hover:bg-sky-100 dark:bg-sky-950/40 text-sky-700 dark:text-sky-400 border border-sky-200 dark:border-sky-800 rounded-lg text-[10px] font-mono font-bold transition cursor-pointer flex items-center gap-1"
                          >
                            <Send className="w-3 h-3 text-sky-500" /> Send Email
                          </button>
                        ) : (
                          <div className="flex flex-col gap-0.5">
                            <span className={`px-2 py-0.5 rounded font-mono text-[9px] font-bold w-max flex items-center gap-1 ${
                              outreachStatus === 'clicked' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-400' :
                              outreachStatus === 'opened' ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-400' :
                              outreachStatus === 'delivered' ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-400' :
                              'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                            }`}>
                              <Radio className="w-3 h-3" />
                              {outreachStatus === 'clicked' ? '✓ Link Clicked' :
                               outreachStatus === 'opened' ? '✓ Email Opened' :
                               outreachStatus === 'delivered' ? '✓ Delivered' : '• Sent'}
                            </span>
                          </div>
                        )}
                      </td>

                      <td className="py-3.5 pr-2 text-right">
                        <button
                          onClick={() => onSelectClient(c.id)}
                          className="px-3 py-1.5 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-xl text-xs transition duration-150 flex items-center gap-1.5 ml-auto cursor-pointer shadow-md shadow-sky-600/10"
                        >
                          View Workspace <ArrowRight className="w-3 h-3 text-sky-200" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-12 text-center text-slate-400 italic text-xs font-mono">
            No corporate client onboardings match your current search and filter criteria.
          </div>
        )}
      </div>
    </div>
  );
}
