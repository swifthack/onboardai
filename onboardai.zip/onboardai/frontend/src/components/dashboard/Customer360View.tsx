import React, { useState } from 'react';
import { 
  Building2, 
  Users, 
  ShieldCheck, 
  ShieldAlert, 
  Plus, 
  CheckCircle, 
  Network, 
  Scale, 
  Globe, 
  FileText,
  UserCheck,
  Building,
  ChevronDown,
  Sparkles,
  Shield,
  Layers,
  Activity,
  Award,
  Calendar,
  MapPin,
  Briefcase,
  Hash,
  FileCheck2,
  TrendingUp,
  AlertCircle,
  Eye
} from 'lucide-react';
import { ClientProfile, UploadedDocument } from '../../types';
import { DocumentViewerModal } from '../common/DocumentViewerModal';

interface Customer360ViewProps {
  clients: ClientProfile[];
  activeClientId: string;
  onSelectClient: (clientId: string) => void;
  onAddDirector: (clientId: string, name: string, role: string, nationality: string) => void;
  onAddRelatedParty: (clientId: string, name: string, relationType: string, riskLevel: 'Low' | 'Medium' | 'High') => void;
  onTriggerKycReview?: (clientId: string, alert: { type: string; title: string; severity: string; details: string }) => void;
}

export default function Customer360View({ 
  clients, 
  activeClientId,
  onSelectClient,
  onAddDirector, 
  onAddRelatedParty
}: Customer360ViewProps) {
  // Currently selected active journey client
  const client = clients.find(c => c.id === activeClientId) || clients[0];

  // Interactive forms state for entity enrichment
  const [showAddDirectorForm, setShowAddDirectorForm] = useState(false);
  const [newDirectorName, setNewDirectorName] = useState('');
  const [newDirectorRole, setNewDirectorRole] = useState('Director');
  const [newDirectorNationality, setNewDirectorNationality] = useState('');

  const [showAddRelatedForm, setShowAddRelatedForm] = useState(false);
  const [newRelatedName, setNewRelatedName] = useState('');
  const [newRelatedType, setNewRelatedType] = useState('Subsidiary');
  const [newRelatedRisk, setNewRelatedRisk] = useState<'Low' | 'Medium' | 'High'>('Low');

  // Interactive Document Viewer Modal State (Read-only, no download)
  const [viewingDocument, setViewingDocument] = useState<UploadedDocument | null>(null);

  const handleDirectorSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDirectorName || !client) return;
    onAddDirector(client.id, newDirectorName, newDirectorRole, newDirectorNationality || 'Global');
    setNewDirectorName('');
    setNewDirectorNationality('');
    setShowAddDirectorForm(false);
  };

  const handleRelatedSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRelatedName || !client) return;
    onAddRelatedParty(client.id, newRelatedName, newRelatedType, newRelatedRisk);
    setNewRelatedName('');
    setShowAddRelatedForm(false);
  };

  if (!client) {
    return (
      <div id="customer-360-empty-state" className="bg-white dark:bg-[#1d1d1d] border border-slate-200 dark:border-slate-800 rounded-2xl p-12 text-center text-slate-500">
        <Building2 className="w-12 h-12 mx-auto text-slate-400 mb-3" />
        <h3 className="text-base font-bold text-slate-800 dark:text-white">No Client Record Found</h3>
        <p className="text-xs text-slate-400 mt-1">Please select an active journey or onboard a new client.</p>
      </div>
    );
  }

  const isApproved = client.overallStatus === 'approved';

  return (
    <div id="customer-360-view" className="space-y-4 animate-fadeIn text-left">
      
      {/* 1. Header with Active Journey Client Selector & Core Metadata */}
      <div id="customer-360-header-card" className="bg-white dark:bg-[#1d1d1d] border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm space-y-3">
        {/* Row 1: Section Title + Client Selector Dropdown + Status Badges */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 rounded-xl">
                <Building2 className="w-5 h-5 shrink-0" />
              </div>
              <div>
                <span className="text-[10px] font-extrabold text-blue-600 dark:text-blue-400 uppercase tracking-widest font-mono block">
                  Customer 360 Profile • Active Journey
                </span>
                <h2 className="text-lg font-black text-slate-900 dark:text-white">
                  {client.companyName}
                </h2>
              </div>
            </div>

            {/* Quick Client Switcher Dropdown */}
            <div className="relative inline-flex items-center">
              <span className="text-[10px] font-bold text-slate-400 uppercase font-mono mr-2 hidden sm:inline">
                Active Client:
              </span>
              <div className="relative">
                <select
                  id="customer-360-client-select"
                  value={client.id}
                  onChange={(e) => onSelectClient(e.target.value)}
                  className="appearance-none bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold rounded-xl pl-3 pr-8 py-1.5 outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition cursor-pointer shadow-2xs"
                >
                  {clients.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.companyName} ({c.jurisdiction})
                    </option>
                  ))}
                </select>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>
          </div>

          {/* Badges / Rating / Overall Status */}
          <div className="flex items-center gap-2 shrink-0 flex-wrap">
            <span className="text-xs font-medium text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800/80 px-2.5 py-1 rounded-lg">
              {client.jurisdiction} • {client.industry}
            </span>
            <span className="font-mono text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-2.5 py-1 rounded-lg font-bold border border-slate-200 dark:border-slate-700">
              REG: {client.registrationNumber}
            </span>
            <span className={`text-[10px] font-bold font-mono px-2.5 py-1 rounded-lg border ${
              client.financials?.rating === 'AA-' || client.financials?.rating === 'A'
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800'
                : 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-800'
            }`}>
              RATING: {client.financials?.rating || 'B+'}
            </span>
            <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wide border ${
              isApproved 
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800'
                : 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/40 dark:text-blue-400 dark:border-blue-800'
            }`}>
              {client.overallStatus}
            </span>
          </div>
        </div>

        {/* Row 2: Authorized Representative & Key Entity Identifiers */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2.5 border-t border-slate-100 dark:border-slate-800/80 text-xs">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[10px] font-bold text-slate-400 uppercase font-mono">AUTH REPRESENTATIVE:</span>
            <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1">
              <UserCheck className="w-3.5 h-3.5 text-blue-500" />
              {client.authorizedRepresentative.name}
            </span>
            <span className="text-slate-400">({client.authorizedRepresentative.role})</span>
            <span className="text-slate-400 font-mono text-[11px] hidden sm:inline">• {client.authorizedRepresentative.email}</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase font-mono">REGISTRY RECORD:</span>
            <span className="px-2.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/30 dark:text-emerald-400 font-mono text-[10px] font-bold flex items-center gap-1">
              <CheckCircle className="w-3 h-3 text-emerald-500" /> OFFICIAL REGISTRY VERIFIED
            </span>
          </div>
        </div>
      </div>

      {/* 2. Enriched Entity Attributes & Corporate Profile Cards */}
      <div id="customer-360-profile-cards" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        
        {/* Jurisdiction & Industry */}
        <div className="bg-white dark:bg-[#1d1d1d] border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Incorporation & Sector</span>
            <Globe className="w-4 h-4 text-blue-500" />
          </div>
          <p className="text-sm font-bold text-slate-900 dark:text-white">{client.jurisdiction}</p>
          <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{client.industry}</p>
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400">
            <span>Reg. Type</span>
            <span className="font-semibold text-slate-700 dark:text-slate-300">Pte. Ltd. / Corporate</span>
          </div>
        </div>

        {/* Financial & Revenue Highlights */}
        <div className="bg-white dark:bg-[#1d1d1d] border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Annual Revenue / Cap</span>
            <TrendingUp className="w-4 h-4 text-emerald-500" />
          </div>
          <p className="text-sm font-bold text-slate-900 dark:text-white">
            {client.financials?.revenue || '$24.5M SGD'}
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Total Assets: {client.financials?.assets || '$14.8M SGD'}
          </p>
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400">
            <span>Debt Ratio</span>
            <span className="font-semibold text-emerald-600 dark:text-emerald-400 font-mono">{client.financials?.debtRatio || '0.24'}</span>
          </div>
        </div>

        {/* Compliance Risk Index */}
        <div className="bg-white dark:bg-[#1d1d1d] border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Risk Assessment Tier</span>
            <ShieldCheck className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="flex items-center gap-2">
            <p className="text-sm font-bold text-slate-900 dark:text-white">
              {client.financials?.rating === 'AA-' || client.financials?.rating === 'A' ? 'Low Risk (Tier 1)' : 'Standard Risk'}
            </p>
            <span className="px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400 font-mono text-[9px] font-bold">
              VERIFIED
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Sanctions: 0 Hits • Adverse Media: 0
          </p>
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400">
            <span>KYB Tier</span>
            <span className="font-semibold text-slate-700 dark:text-slate-300">Enhanced Due Diligence Complete</span>
          </div>
        </div>

        {/* Operational / Account Status */}
        <div className="bg-white dark:bg-[#1d1d1d] border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold uppercase text-slate-400">Account Governance</span>
            <Award className="w-4 h-4 text-purple-500" />
          </div>
          <p className="text-sm font-bold text-slate-900 dark:text-white">Active Institutional Account</p>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Mandate: Multi-Sig Directorship
          </p>
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400">
            <span>Registry Status</span>
            <span className="font-semibold text-emerald-600 dark:text-emerald-400">In Good Standing</span>
          </div>
        </div>

      </div>

      {/* 3. Ultimate Beneficial Owners (UBO) Tree Graph */}
      <div id="customer-360-ubo-hierarchy" className="bg-white dark:bg-[#1d1d1d] border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
        <div className="pb-3 border-b border-slate-100 dark:border-slate-800 mb-4 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-slate-800 dark:text-white text-xs flex items-center gap-1.5 uppercase font-mono">
              <Network className="w-4 h-4 text-purple-500" />
              Ultimate Beneficial Ownership (UBO) Visual Hierarchy
            </h3>
            <p className="text-[10px] text-slate-400 mt-0.5">
              Resolved hierarchy structure of equity allocation & direct UBO controllers for {client.companyName}.
            </p>
          </div>
          <span className="px-2.5 py-0.5 rounded-full bg-purple-50 text-purple-700 border border-purple-100 dark:bg-purple-950/30 dark:text-purple-400 dark:border-purple-900 text-[10px] font-bold font-mono">
            resolved_depth: 3
          </span>
        </div>

        {/* Visual Ownership Chart Tree */}
        <div className="bg-slate-50/50 dark:bg-slate-950/40 rounded-2xl border border-slate-100 dark:border-slate-800/80 p-6 flex flex-col items-center">
          
          {/* Central Parent Node */}
          <div className="bg-blue-600 text-white px-5 py-3 rounded-2xl shadow-md border border-blue-500 flex flex-col items-center max-w-[280px] text-center shrink-0 z-10">
            <Building className="w-4 h-4 text-blue-200 mb-1" />
            <span className="font-bold text-xs">{client.companyName}</span>
            <span className="text-[9px] text-blue-100 uppercase tracking-widest font-mono mt-0.5">Target Entity</span>
          </div>

          {/* Vertical SVG connector line */}
          <div className="w-full max-w-[500px] h-10 flex justify-center">
            <svg className="w-full h-full" overflow="visible">
              <line x1="50%" y1="0%" x2="50%" y2="100%" stroke="#cbd5e1" strokeWidth="2" className="dark:stroke-slate-800" />
              <line x1="15%" y1="50%" x2="85%" y2="50%" stroke="#cbd5e1" strokeWidth="2" className="dark:stroke-slate-800" />
              <line x1="15%" y1="50%" x2="15%" y2="100%" stroke="#cbd5e1" strokeWidth="2" className="dark:stroke-slate-800" />
              <line x1="85%" y1="50%" x2="85%" y2="100%" stroke="#cbd5e1" strokeWidth="2" className="dark:stroke-slate-800" />
            </svg>
          </div>

          {/* Shareholders row */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-4xl relative mt-1">
            {client.shareholders.map((sh, idx) => {
              const isPEP = sh.pepStatus;
              const isHighEquity = sh.equity >= 25;
              
              return (
                <div 
                  key={idx} 
                  className={`bg-white dark:bg-slate-900 border rounded-2xl p-4 shadow-sm flex flex-col justify-between transition-all hover:scale-105 ${
                    isPEP 
                      ? 'border-rose-200 dark:border-rose-950 shadow-rose-100/10' 
                      : 'border-slate-200 dark:border-slate-800'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="px-2 py-0.5 rounded-md bg-purple-50 text-purple-700 dark:bg-purple-950/30 dark:text-purple-400 font-bold font-mono text-[9px] border border-purple-100 dark:border-purple-900/50">
                        {sh.equity}% Equity
                      </span>
                      {isPEP && (
                        <span className="px-2 py-0.5 rounded-md bg-rose-50 text-rose-700 dark:bg-rose-950/30 dark:text-rose-400 font-bold font-mono text-[9px] border border-rose-100 dark:border-rose-900/50">
                          PEP FLAG
                        </span>
                      )}
                    </div>
                    
                    <h4 className="font-bold text-xs text-slate-800 dark:text-white flex items-center gap-1.5 text-left">
                      <Users className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      {sh.name}
                    </h4>
                  </div>

                  <div className="border-t border-slate-50 dark:border-slate-800/60 mt-3 pt-2 text-[10px] text-slate-400 text-left">
                    <div className="flex justify-between">
                      <span>UBO Classification</span>
                      <span className="font-bold text-slate-600 dark:text-slate-300">
                        {isHighEquity ? 'Significant Controller' : 'Minor Shareholder'}
                      </span>
                    </div>
                    <div className="flex justify-between mt-1">
                      <span>Screening Status</span>
                      <span className={`font-bold ${isPEP ? 'text-rose-500' : 'text-emerald-500'}`}>
                        {isPEP ? 'EDD Vetting Required' : 'CLEAR'}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* 4. Directors & Related Parties Grid */}
      <div id="customer-360-directors-related-grid" className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* Board of Directors Section */}
        <div id="customer-360-directors-panel" className="bg-white dark:bg-[#1d1d1d] border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm flex flex-col text-left">
          <div className="pb-2.5 border-b border-slate-100 dark:border-slate-800 mb-3 flex justify-between items-center">
            <div>
              <h3 className="font-bold text-slate-800 dark:text-white text-xs uppercase font-mono flex items-center gap-1.5">
                <Scale className="w-4 h-4 text-blue-500" />
                Board of Directors & Signers
              </h3>
              <p className="text-[10px] text-slate-400 mt-0.5">
                Authorized corporate signers & board members.
              </p>
            </div>
            
            <button 
              id="btn-add-director-modal"
              onClick={() => setShowAddDirectorForm(!showAddDirectorForm)}
              className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg dark:text-blue-400 dark:hover:bg-blue-950/20 cursor-pointer text-xs font-bold flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" /> Add Member
            </button>
          </div>

          {/* Inline add director form */}
          {showAddDirectorForm && (
            <form onSubmit={handleDirectorSubmit} className="bg-slate-50 dark:bg-slate-950 p-3 rounded-xl border border-slate-200 dark:border-slate-800 mb-3 space-y-2.5">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[9px] font-bold text-slate-400 block mb-1">Director Name</label>
                  <input 
                    type="text" 
                    required
                    value={newDirectorName}
                    onChange={(e) => setNewDirectorName(e.target.value)}
                    placeholder="Dr. John Doe"
                    className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-2.5 py-1 text-xs outline-none text-slate-800 dark:text-white focus:ring-1 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="text-[9px] font-bold text-slate-400 block mb-1">Designated Role</label>
                  <select 
                    value={newDirectorRole}
                    onChange={(e) => setNewDirectorRole(e.target.value)}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-2.5 py-1 text-xs outline-none text-slate-800 dark:text-white focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="Executive Director">Executive Director</option>
                    <option value="Non-Executive Director">Non-Executive Director</option>
                    <option value="Independent Director">Independent Director</option>
                    <option value="Chairman">Chairman & Director</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="text-[9px] font-bold text-slate-400 block mb-1">Nationality</label>
                <input 
                  type="text" 
                  value={newDirectorNationality}
                  onChange={(e) => setNewDirectorNationality(e.target.value)}
                  placeholder="Singapore / United Kingdom"
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-2.5 py-1 text-xs outline-none text-slate-800 dark:text-white focus:ring-1 focus:ring-blue-500"
                />
              </div>
              <div className="flex justify-end gap-1.5 pt-1">
                <button 
                  type="button" 
                  onClick={() => setShowAddDirectorForm(false)}
                  className="px-2 py-1 text-[10px] font-bold text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="px-2.5 py-1 bg-blue-600 text-white rounded-lg text-[10px] font-bold hover:bg-blue-700 shadow-sm cursor-pointer"
                >
                  Save Director
                </button>
              </div>
            </form>
          )}

          <div className="space-y-2.5 flex-1 overflow-y-auto max-h-[220px] pr-1">
            {client.directors && client.directors.length > 0 ? (
              client.directors.map((dir, idx) => (
                <div key={idx} className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50/70 dark:bg-slate-900/40 border border-slate-100 dark:border-slate-800/60">
                  <div className="text-left">
                    <span className="font-bold text-xs text-slate-800 dark:text-white block">{dir.name}</span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">{dir.role}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 block">{dir.nationality}</span>
                    <span className="text-[9px] font-mono text-slate-400 block mt-0.5">Appointed: {dir.appointmentDate}</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="py-8 text-center text-slate-400 italic text-xs">
                No board members listed. Click Add Member to register directors.
              </div>
            )}
          </div>
        </div>

        {/* Related Parties & Group Structure Section */}
        <div id="customer-360-related-parties-panel" className="bg-white dark:bg-[#1d1d1d] border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm flex flex-col text-left">
          <div className="pb-2.5 border-b border-slate-100 dark:border-slate-800 mb-3 flex justify-between items-center">
            <div>
              <h3 className="font-bold text-slate-800 dark:text-white text-xs uppercase font-mono flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-emerald-500" />
                Related Parties & Subsidiaries
              </h3>
              <p className="text-[10px] text-slate-400 mt-0.5">
                Affiliated holdings, subsidiaries, and joint ventures.
              </p>
            </div>
            
            <button 
              id="btn-add-related-party-modal"
              onClick={() => setShowAddRelatedForm(!showAddRelatedForm)}
              className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg dark:text-emerald-400 dark:hover:bg-emerald-950/20 cursor-pointer text-xs font-bold flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" /> Add Entity
            </button>
          </div>

          {/* Inline add related party form */}
          {showAddRelatedForm && (
            <form onSubmit={handleRelatedSubmit} className="bg-slate-50 dark:bg-slate-950 p-3 rounded-xl border border-slate-200 dark:border-slate-800 mb-3 space-y-2.5">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[9px] font-bold text-slate-400 block mb-1">Entity Name</label>
                  <input 
                    type="text" 
                    required
                    value={newRelatedName}
                    onChange={(e) => setNewRelatedName(e.target.value)}
                    placeholder="Apex Parent Holdings"
                    className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-2.5 py-1 text-xs outline-none text-slate-800 dark:text-white focus:ring-1 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="text-[9px] font-bold text-slate-400 block mb-1">Relation Type</label>
                  <select 
                    value={newRelatedType}
                    onChange={(e) => setNewRelatedType(e.target.value)}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-2.5 py-1 text-xs outline-none text-slate-800 dark:text-white focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="Parent Holding Company">Parent Holding Company</option>
                    <option value="Subsidiary (100% Owned)">Subsidiary (100% Owned)</option>
                    <option value="Subsidiary (Vested)">Subsidiary (Vested)</option>
                    <option value="Sovereign Anchor Backer">Sovereign Anchor Backer</option>
                    <option value="Regional Affiliate Branch">Regional Affiliate Branch</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="text-[9px] font-bold text-slate-400 block mb-1">AML Country Risk Rating</label>
                <select 
                  value={newRelatedRisk}
                  onChange={(e) => setNewRelatedRisk(e.target.value as any)}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-2.5 py-1 text-xs outline-none text-slate-800 dark:text-white focus:ring-1 focus:ring-blue-500"
                >
                  <option value="Low">Low Risk</option>
                  <option value="Medium">Medium Risk</option>
                  <option value="High">High Risk (Offshore jurisdiction)</option>
                </select>
              </div>
              <div className="flex justify-end gap-1.5 pt-1">
                <button 
                  type="button" 
                  onClick={() => setShowAddRelatedForm(false)}
                  className="px-2 py-1 text-[10px] font-bold text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="px-2.5 py-1 bg-emerald-600 text-white rounded-lg text-[10px] font-bold hover:bg-emerald-700 shadow-sm cursor-pointer"
                >
                  Save Entity
                </button>
              </div>
            </form>
          )}

          <div className="space-y-2.5 flex-1 overflow-y-auto max-h-[220px] pr-1">
            {client.relatedParties && client.relatedParties.length > 0 ? (
              client.relatedParties.map((rp, idx) => (
                <div key={idx} className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50/70 dark:bg-slate-900/40 border border-slate-100 dark:border-slate-800/60">
                  <div className="text-left">
                    <span className="font-bold text-xs text-slate-800 dark:text-white block">{rp.name}</span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">{rp.relationType}</span>
                  </div>
                  <div>
                    <span className={`inline-block px-2 py-0.5 rounded font-mono text-[9px] font-bold uppercase ${
                      rp.riskLevel === 'Low' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100 dark:bg-emerald-950/20 dark:text-emerald-400' :
                      rp.riskLevel === 'Medium' ? 'bg-amber-50 text-amber-700 border border-amber-100 dark:bg-amber-950/20 dark:text-amber-400' :
                      'bg-rose-50 text-rose-700 border border-rose-100 dark:bg-rose-950/20 dark:text-rose-400'
                    }`}>
                      {rp.riskLevel} Risk
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <div className="py-8 text-center text-slate-400 italic text-xs">
                No related party linkages declared. Click Add Entity to create mapping relationships.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 5. Static Compliance & Adverse Media Governance Records */}
      <div id="customer-360-compliance-records" className="bg-white dark:bg-[#1d1d1d] border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm text-left">
        <div className="pb-2.5 border-b border-slate-100 dark:border-slate-800 mb-3 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-slate-800 dark:text-white text-xs uppercase font-mono flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              Compliance Screening & Risk Audit Record
            </h3>
            <p className="text-[10px] text-slate-400 mt-0.5">
              Enriched statutory screening ledger, adverse news audit records, and sanctions findings for {client.companyName}.
            </p>
          </div>
          <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-100 dark:bg-emerald-950/30 dark:text-emerald-400 text-[10px] font-mono font-bold">
            AUDIT TRAIL VERIFIED
          </span>
        </div>

        {/* Alerts & Screening Records List */}
        <div className="space-y-2.5">
          {client.alerts && client.alerts.length > 0 ? (
            client.alerts.map((alert) => (
              <div 
                key={alert.id} 
                className={`p-3 rounded-xl border flex flex-col sm:flex-row sm:items-start justify-between gap-3 ${
                  alert.severity === 'critical' 
                    ? 'bg-rose-50/50 dark:bg-rose-950/10 border-rose-150 dark:border-rose-900/50' 
                    : 'bg-slate-50/70 dark:bg-slate-900/40 border-slate-200 dark:border-slate-800'
                }`}
              >
                <div className="space-y-1 text-left">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`px-2 py-0.5 rounded text-[9px] font-extrabold uppercase font-mono tracking-wider ${
                      alert.type === 'adverse_media' ? 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-400' :
                      alert.type === 'payment_alert' ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400' :
                      'bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-400'
                    }`}>
                      {alert.type.replace('_', ' ')}
                    </span>
                    
                    <span className={`px-1.5 py-0.5 rounded text-[8px] font-mono uppercase font-bold ${
                      alert.severity === 'critical' ? 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400' : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                    }`}>
                      {alert.severity} Risk
                    </span>

                    <span className="text-[10px] text-slate-400 font-mono">
                      {alert.date}
                    </span>
                  </div>

                  <h4 className="font-bold text-slate-800 dark:text-white text-xs">
                    {alert.title}
                  </h4>
                  <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-normal">
                    {alert.description}
                  </p>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-mono text-[9px] font-bold">
                    RECORDED
                  </span>
                </div>
              </div>
            ))
          ) : (
            <div className="py-6 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/30 text-center text-slate-400 text-xs">
              No historical adverse findings on file. Entity sanctions & PEP screening registers are clean.
            </div>
          )}
        </div>
      </div>

      {/* 6. Verified Legal Document Vault */}
      <div id="customer-360-document-vault" className="bg-white dark:bg-[#1d1d1d] border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm text-left">
        <div className="pb-2.5 border-b border-slate-100 dark:border-slate-800 mb-3 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <FileText className="w-4 h-4 text-indigo-500" />
            <h3 className="font-bold text-slate-800 dark:text-white text-xs uppercase font-mono">
              Verified Legal Document Vault & Ingested Records
            </h3>
          </div>
          <span className="text-[10px] text-slate-400 font-mono">
            {client.documents?.length || 0} Ingested Files
          </span>
        </div>
        
        <div className="space-y-2.5">
          {client.documents && client.documents.length > 0 ? (
            client.documents.map((doc) => (
              <div 
                key={doc.id} 
                onClick={() => setViewingDocument(doc)}
                className="p-3 bg-slate-50/70 dark:bg-slate-900/40 hover:bg-slate-100/80 dark:hover:bg-slate-800/60 transition-all rounded-xl border border-slate-100 dark:border-slate-800/80 cursor-pointer group"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 bg-blue-50 dark:bg-slate-800 text-blue-600 dark:text-blue-400 rounded-lg group-hover:bg-blue-600 group-hover:text-white transition-colors">
                      <FileText className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-slate-800 dark:text-white block group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">{doc.name}</span>
                        <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase tracking-wider ${
                          doc.source === 'externally_sourced' 
                            ? 'bg-purple-100 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 border border-purple-200 dark:border-purple-800' 
                            : 'bg-blue-100 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200 dark:border-blue-800'
                        }`}>
                          {doc.source === 'externally_sourced' ? '🌐 Externally Sourced' : '👤 Customer Provided'}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 block mt-0.5">{doc.type} • {doc.size} {doc.sourceDetails ? `• ${doc.sourceDetails}` : ''}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400 text-[10px] font-mono font-bold uppercase border border-emerald-100 dark:border-emerald-900/50">
                      {doc.status}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setViewingDocument(doc);
                      }}
                      className="px-2 py-1 rounded bg-indigo-50 hover:bg-indigo-100 text-indigo-700 dark:bg-indigo-950/50 dark:hover:bg-indigo-900 dark:text-indigo-300 text-[10px] font-bold transition flex items-center gap-1 cursor-pointer border border-indigo-200 dark:border-indigo-800"
                    >
                      <Eye className="w-3 h-3" />
                      <span>View</span>
                    </button>
                  </div>
                </div>
                
                {doc.ocrData && (
                  <div className="mt-2.5 text-[10px] text-slate-500">
                    <div className="font-mono uppercase text-slate-400 tracking-wider font-bold mb-1.5 text-[8px]">Extracted Registry Metadata</div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 bg-white dark:bg-slate-950 p-2 rounded-lg border border-slate-100 dark:border-slate-800">
                      {Object.entries(doc.ocrData).map(([k, v]) => (
                        <div key={k}>
                          <span className="text-slate-400 block font-medium">{k}</span>
                          <span className="text-slate-800 dark:text-slate-200 font-semibold truncate block mt-0.5">{v}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="py-6 text-center text-slate-400 italic text-xs">
              No documents found in registry vault.
            </div>
          )}
        </div>
      </div>

      {/* REACT DOCUMENT VIEWER MODAL (RM / COMPLIANCE ACCESS - READ ONLY, NO DOWNLOAD) */}
      <DocumentViewerModal
        document={viewingDocument}
        isOpen={Boolean(viewingDocument)}
        onClose={() => setViewingDocument(null)}
        readOnly={false}
        userRole="rm"
      />

    </div>
  );
}
