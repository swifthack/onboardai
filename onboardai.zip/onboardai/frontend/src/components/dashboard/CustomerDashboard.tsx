import React, { useState, useEffect } from 'react';
import { 
  Building, 
  FileText, 
  UploadCloud, 
  CheckCircle, 
  AlertCircle, 
  AlertTriangle,
  ArrowRight, 
  Sparkles, 
  Lock, 
  Mail, 
  User, 
  Fingerprint, 
  Check, 
  ShieldAlert, 
  Clock, 
  ExternalLink,
  RefreshCw,
  Eye,
  FileCheck,
  Building2,
  Database,
  Smartphone,
  ChevronRight,
  LogOut,
  X,
  Trash2,
  Plus,
  Edit3,
  ShieldCheck,
  Landmark,
  Settings,
  Layers,
  Info,
  CreditCard,
  FileSpreadsheet,
  Save,
  CheckSquare,
  MessageSquare,
  Send,
  Users,
  KeyRound,
  UserPlus,
  Globe,
  FileBadge,
  UserCheck,
  Bot,
  Scan,
  Upload,
  Camera,
  CheckCircle2,
  SlidersHorizontal,
  FileCheck2,
  ArrowUpRight,
  HelpCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ClientProfile, 
  WorkflowNode, 
  UploadedDocument, 
  NodeStatus, 
  SystemNotification,
  InternalRepresentative,
  InternalSignatory,
  InternalOperator,
  TaxSelfCertEntry,
  GovtRegistryUpdateRequest
} from '../../types';
import { DocumentViewerModal } from '../common/DocumentViewerModal';

interface CustomerDashboardProps {
  clients: ClientProfile[];
  activeClient: ClientProfile | null;
  onUpdateClient: (updatedClient: ClientProfile) => void;
  onClientCreated: (client: ClientProfile) => void;
  onSelectClient: (clientId: string) => void;
  isDarkMode: boolean;
  onAddNotification?: (notification: SystemNotification) => void;
  onRespondToClarification?: (clientId: string, nodeId: string, message: string) => void;
}

export default function CustomerDashboard({
  clients,
  activeClient,
  onUpdateClient,
  onClientCreated,
  onSelectClient,
  isDarkMode,
  onAddNotification,
  onRespondToClarification
}: CustomerDashboardProps) {
  // Auth view states: 'signin' | 'register'
  const [authMode, setAuthMode] = useState<'signin' | 'register'>(activeClient ? 'signin' : 'register');
  const [isLoggedIn, setIsLoggedIn] = useState(activeClient ? true : false);

  // Form states for Registration
  const [regCompanyName, setRegCompanyName] = useState('');
  const [regRepName, setRegRepName] = useState('');
  const [regRepEmail, setRegRepEmail] = useState('');
  const [regJurisdiction, setRegJurisdiction] = useState('SG'); // SG or IN
  const [regPassword, setRegPassword] = useState('');
  const [regError, setRegError] = useState('');

  // Form states for Sign-in
  const [loginEmail, setLoginEmail] = useState(activeClient?.authorizedRepresentative.email || '');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  // Active Category View Tab
  // Category 1: Verified External Registry Data (Read-Only)
  // Category 2: Internal Organization & Account Systems Data (Customer Modifiable)
  // Category 3: Required Deliverables & Action Items (Interactive OCR & Biometrics)
  const [activeCategory, setActiveCategory] = useState<'category1_registry' | 'category2_internal' | 'category3_deliverables'>('category1_registry');

  // Category 3 Interactive OCR & Document Vault States
  const [selectedDocForOcr, setSelectedDocForOcr] = useState<UploadedDocument | null>(null);
  const [editableOcrData, setEditableOcrData] = useState<Record<string, string>>({});
  const [newOcrKey, setNewOcrKey] = useState('');
  const [newOcrValue, setNewOcrValue] = useState('');
  const [isVerifyingOcr, setIsVerifyingOcr] = useState(false);
  const [isVerifyingBio, setIsVerifyingBio] = useState(false);
  const [activeDeliverableFilter, setActiveDeliverableFilter] = useState<'all' | 'verified' | 'action_required'>('all');

  // Response drafts for open RM/Ops/Compliance clarifications, keyed by node id.
  const [clarificationResponses, setClarificationResponses] = useState<Record<string, string>>({});
  const [ocrScanningProgress, setOcrScanningProgress] = useState<number | null>(null);

  // Listen for copilot document upload event to automatically show OCR progress and preview in left panel
  useEffect(() => {
    const handleCopilotDocUploaded = (event: CustomEvent<{ document: UploadedDocument; autoOpenOcr?: boolean }>) => {
      const doc = event.detail?.document;
      if (doc) {
        // Switch to Category 3 so the customer immediately sees the OCR progress and verification panel
        setActiveCategory('category3_deliverables');
        
        // Simulate real-time OCR scanning progress
        setOcrScanningProgress(15);
        setSelectedDocForOcr(doc);
        const ocrAttrs = doc.ocrData && Object.keys(doc.ocrData).length > 0 
          ? { ...doc.ocrData } 
          : getSampleOcrDataForType(doc.type || doc.name, activeClient);
        setEditableOcrData(ocrAttrs);

        const timer1 = setTimeout(() => setOcrScanningProgress(55), 350);
        const timer2 = setTimeout(() => setOcrScanningProgress(88), 750);
        const timer3 = setTimeout(() => {
          setOcrScanningProgress(100);
          setTimeout(() => setOcrScanningProgress(null), 500);
        }, 1100);

        return () => {
          clearTimeout(timer1);
          clearTimeout(timer2);
          clearTimeout(timer3);
        };
      }
    };

    window.addEventListener('customer_copilot_doc_uploaded', handleCopilotDocUploaded as EventListener);
    return () => {
      window.removeEventListener('customer_copilot_doc_uploaded', handleCopilotDocUploaded as EventListener);
    };
  }, [activeClient]);

  // Local interactive flow states
  const [showSingpassModal, setShowSingpassModal] = useState(false);
  const [singpassStep, setSingpassStep] = useState<'intro' | 'qr' | 'consent' | 'success'>('intro');

  const [showPanGstModal, setShowPanGstModal] = useState(false);
  const [panNumber, setPanNumber] = useState('');
  const [gstinNumber, setGstinNumber] = useState('');
  const [isLinkingPanGst, setIsLinkingPanGst] = useState(false);

  const [ocrSubmitSuccessMsg, setOcrSubmitSuccessMsg] = useState<string | null>(null);

  // Govt Registry Request / Mismatch Reporting Modal States
  const [showGovtRegistryModal, setShowGovtRegistryModal] = useState(false);
  const [govtRegistryMismatchCategory, setGovtRegistryMismatchCategory] = useState('Official Company Name / UEN');
  const [govtRegistryCommentary, setGovtRegistryCommentary] = useState('');
  const [govtRegistryFilingRef, setGovtRegistryFilingRef] = useState('');

  // Interactive Document Viewer Modal State (Read-only, no download)
  const [viewingDocument, setViewingDocument] = useState<UploadedDocument | null>(null);

  // Category 2 Internal Profile Editing Modal & Multi-Entity Form States
  const [showEditInternalModal, setShowEditInternalModal] = useState(false);
  const [editModalActiveTab, setEditModalActiveTab] = useState<'representatives' | 'signatories' | 'operators' | 'tax' | 'mandates'>('representatives');
  const [editRepresentatives, setEditRepresentatives] = useState<InternalRepresentative[]>([]);
  const [editSignatories, setEditSignatories] = useState<InternalSignatory[]>([]);
  const [editOperators, setEditOperators] = useState<InternalOperator[]>([]);
  const [editTaxCertifications, setEditTaxCertifications] = useState<TaxSelfCertEntry[]>([]);
  
  const [editPhoneContact, setEditPhoneContact] = useState('');
  const [editSecondaryEmail, setEditSecondaryEmail] = useState('');
  const [editAccountType, setEditAccountType] = useState('');
  const [editPrimaryCurrency, setEditPrimaryCurrency] = useState('');
  const [editEstMonthlyVolume, setEditEstMonthlyVolume] = useState('');
  const [editStatementDelivery, setEditStatementDelivery] = useState('');
  const [editOperatingMandate, setEditOperatingMandate] = useState('');

  // Natural Language Prompt State for Record Modification
  const [promptInput, setPromptInput] = useState('');

  // Pre-fill Category 2 multi-entity form states whenever activeClient updates or edit modal opens
  const openEditInternalModalHandler = (initialTab: 'representatives' | 'signatories' | 'operators' | 'tax' | 'mandates' = 'representatives') => {
    if (!activeClient) return;

    setEditModalActiveTab(initialTab);

    // Prefill representatives list or seed defaults
    const defaultReps: InternalRepresentative[] = activeClient.internalAccountSettings?.representatives?.length 
      ? [...activeClient.internalAccountSettings.representatives]
      : [
          {
            id: `rep_1`,
            name: activeClient.authorizedRepresentative?.name || 'John Tan',
            role: activeClient.authorizedRepresentative?.role || 'Managing Director',
            email: activeClient.authorizedRepresentative?.email || 'j.tan@company.com',
            phone: activeClient.internalAccountSettings?.phoneContact || '+65 9123 4567',
            isPrimary: true
          },
          {
            id: `rep_2`,
            name: 'Sarah Jenkins',
            role: 'Head of Corporate Treasury',
            email: 's.jenkins@company.com',
            phone: '+65 9876 5432',
            isPrimary: false
          }
        ];

    // Prefill signatories list or seed defaults
    const defaultSigs: InternalSignatory[] = activeClient.internalAccountSettings?.signatories?.length
      ? [...activeClient.internalAccountSettings.signatories]
      : [
          {
            id: `sig_1`,
            name: activeClient.authorizedRepresentative?.name || 'John Tan',
            role: activeClient.authorizedRepresentative?.role || 'Managing Director',
            signingPower: 'Class A (Unlimited)',
            email: activeClient.authorizedRepresentative?.email || 'j.tan@company.com',
            status: 'Active'
          },
          {
            id: `sig_2`,
            name: 'Michael Chen',
            role: 'Chief Financial Officer',
            signingPower: 'Class B (Up to $500,000 USD)',
            email: 'm.chen@company.com',
            status: 'Active'
          }
        ];

    // Prefill operators list or seed defaults
    const defaultOps: InternalOperator[] = activeClient.internalAccountSettings?.operators?.length
      ? [...activeClient.internalAccountSettings.operators]
      : [
          {
            id: `op_1`,
            name: activeClient.authorizedRepresentative?.name || 'John Tan',
            role: activeClient.authorizedRepresentative?.role || 'Managing Director',
            accessLevel: 'Full Admin',
            email: activeClient.authorizedRepresentative?.email || 'j.tan@company.com'
          },
          {
            id: `op_2`,
            name: 'Elena Rostova',
            role: 'Finance Operations Lead',
            accessLevel: 'Payment Drafter (Maker)',
            email: 'elena.r@company.com'
          },
          {
            id: `op_3`,
            name: 'David Tan',
            role: 'Finance Director',
            accessLevel: 'Payment Approver (Checker)',
            email: 'david.tan@company.com'
          }
        ];

    // Prefill tax certifications or seed defaults
    const isSg = activeClient.jurisdiction.includes('SG') || activeClient.jurisdiction.includes('Singapore');
    const defaultTax: TaxSelfCertEntry[] = activeClient.internalAccountSettings?.taxCertifications?.length
      ? [...activeClient.internalAccountSettings.taxCertifications]
      : [
          {
            id: `tax_1`,
            taxResidencyCountry: isSg ? 'Singapore' : 'India',
            tinReferenceNumber: activeClient.registrationNumber || '202104812K',
            fatcaClassification: activeClient.internalAccountSettings?.fatcaClassification || 'Active NFFE (Non-Financial Foreign Entity)',
            crsStatus: 'Reportable Entity',
            isPrimary: true
          },
          {
            id: `tax_2`,
            taxResidencyCountry: 'United States',
            tinReferenceNumber: 'US-982103982',
            fatcaClassification: 'Specified US Person (Form W-9)',
            crsStatus: 'Non-Reportable (US)',
            isPrimary: false
          }
        ];

    setEditRepresentatives(defaultReps);
    setEditSignatories(defaultSigs);
    setEditOperators(defaultOps);
    setEditTaxCertifications(defaultTax);

    setEditPhoneContact(activeClient.internalAccountSettings?.phoneContact || '+65 9123 4567');
    setEditSecondaryEmail(activeClient.internalAccountSettings?.secondaryEmail || 'compliance-ops@company.com');
    setEditAccountType(activeClient.internalAccountSettings?.accountType || 'Corporate Multi-Currency CASA');
    setEditPrimaryCurrency(activeClient.internalAccountSettings?.primaryCurrency || 'SGD');
    setEditEstMonthlyVolume(activeClient.internalAccountSettings?.estMonthlyVolume || '$250,000 - $1,000,000 USD');
    setEditStatementDelivery(activeClient.internalAccountSettings?.statementDelivery || 'Electronic Portal & PDF Email');
    setEditOperatingMandate(activeClient.internalAccountSettings?.operatingMandate || 'Joint Signatories - Any Two Directors');

    setShowEditInternalModal(true);
  };

  // Natural Language Prompt-Based Internal System Record Modification Handler
  const handleExecutePromptRecordUpdate = (e?: React.FormEvent, overrideText?: string) => {
    if (e) e.preventDefault();
    const rawText = (overrideText !== undefined ? overrideText : promptInput).trim();
    if (!activeClient || !rawText) return;

    const lower = rawText.toLowerCase();
    const isSg = activeClient.jurisdiction.includes('SG') || activeClient.jurisdiction.includes('Singapore');

    // Fetch current or seed defaults
    let currentReps: InternalRepresentative[] = activeClient.internalAccountSettings?.representatives?.length 
      ? [...activeClient.internalAccountSettings.representatives]
      : [
          {
            id: `rep_1`,
            name: activeClient.authorizedRepresentative?.name || 'John Tan',
            role: activeClient.authorizedRepresentative?.role || 'Managing Director',
            email: activeClient.authorizedRepresentative?.email || 'j.tan@company.com',
            phone: activeClient.internalAccountSettings?.phoneContact || '+65 9123 4567',
            isPrimary: true
          },
          {
            id: `rep_2`,
            name: 'Sarah Jenkins',
            role: 'Head of Corporate Treasury',
            email: 's.jenkins@company.com',
            phone: '+65 9876 5432',
            isPrimary: false
          }
        ];

    let currentSigs: InternalSignatory[] = activeClient.internalAccountSettings?.signatories?.length
      ? [...activeClient.internalAccountSettings.signatories]
      : [
          {
            id: `sig_1`,
            name: activeClient.authorizedRepresentative?.name || 'John Tan',
            role: activeClient.authorizedRepresentative?.role || 'Managing Director',
            signingPower: 'Class A (Unlimited)',
            email: activeClient.authorizedRepresentative?.email || 'j.tan@company.com',
            status: 'Active'
          },
          {
            id: `sig_2`,
            name: 'Michael Chen',
            role: 'Chief Financial Officer',
            signingPower: 'Class B (Up to $500,000 USD)',
            email: 'm.chen@company.com',
            status: 'Active'
          }
        ];

    let currentOps: InternalOperator[] = activeClient.internalAccountSettings?.operators?.length
      ? [...activeClient.internalAccountSettings.operators]
      : [
          {
            id: `op_1`,
            name: activeClient.authorizedRepresentative?.name || 'John Tan',
            role: activeClient.authorizedRepresentative?.role || 'Managing Director',
            accessLevel: 'Full Admin',
            email: activeClient.authorizedRepresentative?.email || 'j.tan@company.com'
          },
          {
            id: `op_2`,
            name: 'Elena Rostova',
            role: 'Finance Operations Lead',
            accessLevel: 'Payment Drafter (Maker)',
            email: 'elena.r@company.com'
          },
          {
            id: `op_3`,
            name: 'David Tan',
            role: 'Finance Director',
            accessLevel: 'Payment Approver (Checker)',
            email: 'david.tan@company.com'
          }
        ];

    let currentTax: TaxSelfCertEntry[] = activeClient.internalAccountSettings?.taxCertifications?.length
      ? [...activeClient.internalAccountSettings.taxCertifications]
      : [
          {
            id: `tax_1`,
            taxResidencyCountry: isSg ? 'Singapore' : 'India',
            tinReferenceNumber: activeClient.registrationNumber || '202104812K',
            fatcaClassification: 'Active NFFE',
            crsStatus: 'Reportable Entity',
            isPrimary: true
          },
          {
            id: `tax_2`,
            taxResidencyCountry: 'United States',
            tinReferenceNumber: 'US-982103982',
            fatcaClassification: 'Specified US Person (Form W-9)',
            crsStatus: 'Non-Reportable (US)',
            isPrimary: false
          }
        ];

    let currentMandate = activeClient.internalAccountSettings?.operatingMandate || 'Joint Signatories - Any Two Directors';

    const parsedActions: string[] = [];

    // 1. Elena Rostova departure
    if (lower.includes('elena') && (lower.includes('no longer') || lower.includes('moved') || lower.includes('left') || lower.includes('remove') || lower.includes('delete'))) {
      const initialCount = currentOps.length;
      currentOps = currentOps.filter(o => !o.name.toLowerCase().includes('elena'));
      if (currentOps.length < initialCount) {
        parsedActions.push('Removed operator Elena Rostova (no longer with company)');
      }
    }

    // 2. David Tan departure / moved out
    if (lower.includes('david tan') && (lower.includes('moved out') || lower.includes('no longer') || lower.includes('left') || lower.includes('remove'))) {
      const initialCount = currentOps.length;
      currentOps = currentOps.filter(o => !o.name.toLowerCase().includes('david tan'));
      if (currentOps.length < initialCount) {
        parsedActions.push('Removed operator David Tan (moved out)');
      }
    }

    // 3. John Smith addition as new Finance Director / Operator / Representative
    if (lower.includes('john smith') || lower.includes('new finance director')) {
      if (!currentOps.some(o => o.name.toLowerCase().includes('john smith'))) {
        currentOps.push({
          id: `op_${Date.now()}`,
          name: 'John Smith',
          role: 'Finance Director',
          accessLevel: 'Payment Approver (Checker)',
          email: 'john.smith@company.com'
        });
        parsedActions.push('Added John Smith as Finance Director with Payment Approver (Checker) access');
      }
      if (!currentReps.some(r => r.name.toLowerCase().includes('john smith'))) {
        currentReps.push({
          id: `rep_${Date.now()}`,
          name: 'John Smith',
          role: 'Finance Director',
          email: 'john.smith@company.com',
          phone: '+65 9111 2233',
          isPrimary: false
        });
        parsedActions.push('Added John Smith to Designated Representatives');
      }
    }

    // 4. MPC or Signatory addition
    if (lower.includes('mpc') || lower.includes('signatory') || lower.includes('signing power')) {
      const sigName = lower.includes('john smith') ? 'John Smith' : 'MPC Designated Signatory';
      if (!currentSigs.some(s => s.name.toLowerCase().includes(sigName.toLowerCase()))) {
        currentSigs.push({
          id: `sig_${Date.now()}`,
          name: sigName,
          role: 'Authorized Officer / Director',
          signingPower: lower.includes('class a') ? 'Class A (Unlimited)' : 'Class B (Up to $500,000 USD)',
          email: `${sigName.toLowerCase().replace(/\s+/g, '.')}@company.com`,
          status: 'Active'
        });
        parsedActions.push(`Added ${sigName} as Class B Account Signatory`);
      }
    }

    // 5. USD Operating Mandate addition/update
    if (lower.includes('mandate') || lower.includes('usd currency') || lower.includes('usd')) {
      currentMandate = 'Joint Signatories - USD Currency Dual Control Mandate';
      parsedActions.push('Updated operating mandate to USD Currency Dual Control Mandate');
    }

    // 6. Tax Self-Certification addition/update
    if (lower.includes('tax') || lower.includes('tin') || lower.includes('fatca') || lower.includes('crs')) {
      if (!currentTax.some(t => t.taxResidencyCountry.toLowerCase().includes('united states') || t.taxResidencyCountry.toLowerCase().includes('us'))) {
        currentTax.push({
          id: `tax_${Date.now()}`,
          taxResidencyCountry: 'United States',
          tinReferenceNumber: 'US-982103982',
          fatcaClassification: 'Specified US Person (Form W-9)',
          crsStatus: 'Non-Reportable (US)',
          isPrimary: false
        });
        parsedActions.push('Added US Jurisdiction Tax Self-Certification (Form W-9)');
      }
    }

    if (parsedActions.length === 0) {
      parsedActions.push('Logged custom record update prompt for Relationship Manager review');
    }

    // Create prompt request log entry
    const newReq: GovtRegistryUpdateRequest = {
      id: `rec_req_${Date.now()}`,
      mismatchCategory: 'Internal Systems Prompt Update',
      commentary: rawText,
      submittedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'pending_review'
    };

    const updatedClient: ClientProfile = {
      ...activeClient,
      govtRegistryUpdateRequests: [
        ...(activeClient.govtRegistryUpdateRequests || []),
        newReq
      ],
      internalAccountSettings: {
        ...activeClient.internalAccountSettings,
        representatives: currentReps,
        signatories: currentSigs,
        operators: currentOps,
        taxCertifications: currentTax,
        operatingMandate: currentMandate,
        lastUpdatedByCustomer: new Date().toISOString().replace('T', ' ').substring(0, 16)
      }
    };

    onUpdateClient(updatedClient);

    // Dispatch System Notification to Relationship Manager Action Center
    if (onAddNotification) {
      onAddNotification({
        id: `notif_${Date.now()}`,
        type: 'info',
        title: 'Customer Submitted Record Update Prompt',
        msg: `Customer "${activeClient.companyName}" submitted prompt: "${rawText}". Executed actions: ${parsedActions.join('; ')}.`,
        time: 'Just now',
        node: 'data_aggregator',
        clientId: activeClient.id,
        clientName: activeClient.companyName,
        actionRequired: true,
        actioned: false
      });
    }

    setOcrSubmitSuccessMsg(`✓ Prompt processed! RM notified. Executed: ${parsedActions.join(', ')}.`);
    setTimeout(() => setOcrSubmitSuccessMsg(null), 8000);
    setPromptInput('');
    setShowEditInternalModal(false);
  };

  // Save Category 2 Internal Systems Data
  const handleSaveInternalSettings = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeClient) return;

    const primaryRep = editRepresentatives.find(r => r.isPrimary) || editRepresentatives[0];

    const updatedClient: ClientProfile = {
      ...activeClient,
      authorizedRepresentative: primaryRep ? {
        ...activeClient.authorizedRepresentative,
        name: primaryRep.name,
        role: primaryRep.role,
        email: primaryRep.email,
      } : activeClient.authorizedRepresentative,
      internalAccountSettings: {
        representatives: editRepresentatives,
        signatories: editSignatories,
        operators: editOperators,
        taxCertifications: editTaxCertifications,
        phoneContact: primaryRep?.phone || editPhoneContact.trim(),
        secondaryEmail: editSecondaryEmail.trim(),
        primaryCurrency: editPrimaryCurrency,
        accountType: editAccountType,
        estMonthlyVolume: editEstMonthlyVolume,
        statementDelivery: editStatementDelivery,
        operatingMandate: editOperatingMandate,
        fatcaClassification: editTaxCertifications[0]?.fatcaClassification || 'Active NFFE',
        taxResidencyCountry: editTaxCertifications[0]?.taxResidencyCountry || 'Singapore',
        tinReferenceNumber: editTaxCertifications[0]?.tinReferenceNumber || activeClient.registrationNumber,
        lastUpdatedByCustomer: new Date().toISOString().replace('T', ' ').substring(0, 16)
      }
    };

    onUpdateClient(updatedClient);
    setShowEditInternalModal(false);

    if (onAddNotification) {
      onAddNotification({
        id: `notif_${Date.now()}`,
        type: 'info',
        title: 'Internal System Records Updated',
        msg: `Customer "${activeClient.companyName}" updated internal system records: ${editRepresentatives.length} representatives, ${editSignatories.length} signatories, ${editOperators.length} account operators, and ${editTaxCertifications.length} tax certifications.`,
        time: 'Just now',
        node: 'data_aggregator',
        clientId: activeClient.id,
        clientName: activeClient.companyName,
        actionRequired: false,
        actioned: true
      });
    }

    setOcrSubmitSuccessMsg('✓ Internal organization records updated successfully in our core systems!');
    setTimeout(() => setOcrSubmitSuccessMsg(null), 6000);
  };

  // Submit Government Registry Request / Mismatch Report
  const handleSendGovtRegistryUpdateRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeClient || !govtRegistryCommentary.trim()) return;

    const newReq: GovtRegistryUpdateRequest = {
      id: `gov_req_${Date.now()}`,
      mismatchCategory: govtRegistryMismatchCategory,
      commentary: govtRegistryCommentary.trim(),
      filingReferenceNo: govtRegistryFilingRef.trim() || undefined,
      submittedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'pending_review'
    };

    const updatedClient: ClientProfile = {
      ...activeClient,
      govtRegistryUpdateRequests: [
        ...(activeClient.govtRegistryUpdateRequests || []),
        newReq
      ]
    };

    onUpdateClient(updatedClient);
    setShowGovtRegistryModal(false);
    setGovtRegistryCommentary('');
    setGovtRegistryFilingRef('');

    if (onAddNotification) {
      onAddNotification({
        id: `notif_${Date.now()}`,
        type: 'warning',
        title: 'Third-Party Data Mismatch Feedback',
        msg: `Customer "${activeClient.companyName}" provided feedback regarding a third-party data mismatch for "${govtRegistryMismatchCategory}". Commentary: "${newReq.commentary}".`,
        time: 'Just now',
        node: 'data_aggregator',
        clientId: activeClient.id,
        clientName: activeClient.companyName,
        actionRequired: true,
        actioned: false
      });
    }

    setOcrSubmitSuccessMsg('✓ Government registry mismatch report & update request submitted to your Relationship Manager.');
    setTimeout(() => setOcrSubmitSuccessMsg(null), 6000);
  };

  // Trigger login
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    if (!loginEmail.trim() || !loginPassword.trim()) {
      setLoginError('Please enter your registered email and password.');
      return;
    }

    const found = clients.find(
      c => c.authorizedRepresentative.email.toLowerCase() === loginEmail.toLowerCase().trim()
    );

    if (found) {
      onSelectClient(found.id);
      setIsLoggedIn(true);
    } else {
      const generatedId = `client_journey_${Date.now()}`;
      const mockRegNo = loginEmail.includes('india') || loginEmail.includes('.in') ? `IN-${Math.floor(100000 + Math.random() * 900000)}` : `SG-${Math.floor(100000 + Math.random() * 900000)}`;
      const jur = loginEmail.includes('india') || loginEmail.includes('.in') ? 'India (IN)' : 'Singapore (SG)';
      
      const newClient: ClientProfile = {
        id: generatedId,
        companyName: loginEmail.split('@')[0].toUpperCase() + ' Corp',
        registrationNumber: mockRegNo,
        jurisdiction: jur,
        industry: 'Interested Products: Corporate Operating Account',
        authorizedRepresentative: {
          name: loginEmail.split('@')[0].replace(/[^a-zA-Z]/g, ' ').toUpperCase(),
          role: 'Managing Director',
          email: loginEmail.trim(),
          biometricVerified: false,
          biometricMatchScore: 0,
        },
        shareholders: [
          { name: 'Core Shareholder', equity: 100.0, pepStatus: false }
        ],
        financials: {
          revenue: '$1.2M USD',
          assets: '$500K USD',
          debtRatio: '0.12',
          rating: 'BBB'
        },
        documents: [],
        workflowNodes: createInitialWorkflowNodes(jur.includes('SG') ? 'SG' : 'IN'),
        overallStatus: 'draft'
      };

      onClientCreated(newClient);
      setIsLoggedIn(true);
    }
  };

  function createInitialWorkflowNodes(jurCode: 'SG' | 'IN'): WorkflowNode[] {
    return [
      {
        id: 'data_aggregator',
        name: 'Data Aggregator Module',
        agentType: 'data_aggregator',
        team: 'Internal/External API Integrations',
        description: jurCode === 'SG' 
          ? 'Retrieves Singapore ACRA corporate details and registry standing dynamically via Singpass MyInfo API.'
          : 'Validates Indian GSTIN and PAN details against the NSDL & GST Network registries.',
        status: 'pending',
        dependsOn: [],
        logs: ['Awaiting corporate identity linkage...']
      },
      {
        id: 'name_screening',
        name: 'PEP & Sanctions Screening Agent',
        agentType: 'name_screening',
        team: 'Compliance Screening Module',
        description: 'Cross-checks listed directors, shareholders, and representatives against global sanctions (OFAC, UN, HMT) and PEP registers.',
        status: 'pending',
        dependsOn: ['data_aggregator'],
        logs: ['Awaiting registered corporate shareholder listings...']
      },
      {
        id: 'aml',
        name: 'Anti-Money Laundering Module',
        agentType: 'aml',
        team: 'AML & KYB Compliance Team',
        description: 'Traces ownership up to natural persons (UBOs) holding >=10% capital and risk rates source-of-wealth narratives.',
        status: 'pending',
        dependsOn: ['name_screening'],
        logs: ['Awaiting finished screening results.']
      },
      {
        id: 'client_risk',
        name: 'Composite Risk Assessment Agent',
        agentType: 'client_risk',
        team: 'Risk Assessment Team',
        description: 'Evaluates entity jurisdiction, ownership structure, and PEP flags to compute composite risk score.',
        status: 'pending',
        dependsOn: ['aml'],
        logs: ['Awaiting AML evaluation...']
      },
      {
        id: 'legal_compliance',
        name: 'Legal & Regulatory Sign-Off',
        agentType: 'legal_compliance',
        team: 'Legal Compliance Module',
        description: 'Verifies account mandate structures and generates final approval credentials.',
        status: 'pending',
        dependsOn: ['client_risk'],
        logs: ['Awaiting risk scoring...']
      }
    ];
  }

  // Trigger registration
  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError('');

    if (!regCompanyName.trim() || !regRepName.trim() || !regRepEmail.trim() || !regPassword.trim()) {
      setRegError('All fields marked with an asterisk are required.');
      return;
    }

    const mockRegNo = regJurisdiction === 'SG' 
      ? `SG-${Math.floor(100000 + Math.random() * 900000)}` 
      : `IN-${Math.floor(100000 + Math.random() * 900000)}`;

    const newClient: ClientProfile = {
      id: `client_journey_${Date.now()}`,
      companyName: regCompanyName.trim(),
      registrationNumber: mockRegNo,
      jurisdiction: regJurisdiction === 'SG' ? 'Singapore (SG)' : 'India (IN)',
      industry: 'Interested Products: Self-Service Corporate Cash Account (CASA)',
      authorizedRepresentative: {
        name: regRepName.trim(),
        role: 'Managing Director',
        email: regRepEmail.trim().toLowerCase(),
        biometricVerified: false,
        biometricMatchScore: 0,
      },
      shareholders: [
        { name: regRepName.trim(), equity: 100.0, pepStatus: false }
      ],
      financials: {
        revenue: '$150K USD',
        assets: '$100K USD',
        debtRatio: '0.05',
        rating: 'A'
      },
      documents: [],
      workflowNodes: createInitialWorkflowNodes(regJurisdiction as 'SG' | 'IN'),
      overallStatus: 'draft'
    };

    onClientCreated(newClient);
    setIsLoggedIn(true);
  };

  // Simulating Singpass Consent & ACRA Retrieval
  const triggerSingpassSimulate = () => {
    if (!activeClient) return;

    setSingpassStep('consent');

    setTimeout(() => {
      const directors = [
        { name: activeClient.authorizedRepresentative.name, role: 'Managing Director', appointmentDate: '12 Jan 2022', nationality: 'Singaporean' },
        { name: 'Sarah Jenkins', role: 'Director', appointmentDate: '01 Jun 2023', nationality: 'British' }
      ];

      const shareholders = [
        { name: activeClient.authorizedRepresentative.name, equity: 70.0, pepStatus: false },
        { name: 'Sarah Jenkins', equity: 30.0, pepStatus: false }
      ];

      const updatedNodes = activeClient.workflowNodes.map(node => {
        if (node.id === 'data_aggregator') {
          return {
            ...node,
            status: 'completed' as NodeStatus,
            logs: [
              ...node.logs,
              '[06:07:33] 📡 Connecting to Singpass MyInfo API Gateway...',
              '[06:07:34] 🔒 Performing OAuth authorization handshake...',
              '[06:07:34] ✅ Retrieve corporate registry details success!',
              '[06:07:34] 📝 Populating ACRA details into local core profile.'
            ],
            results: {
              summary: 'ACRA database retrieved successfully via Singpass MyInfo Business.',
              metrics: {
                'ACRA Standing': 'ACTIVE',
                'Entity Type': 'Private Limited Company',
                'UEN Verification': 'MATCHED',
                'Registered Address': '10 Marina Boulevard, Tower 2 Level 39, Singapore 018983'
              },
              findings: [
                'Entity exists in active status in ACRA register.',
                'Tan Min Hao listed as authorized Managing Director.',
                'Registered office address matches Singpass official government records.'
              ]
            }
          };
        }
        return node;
      });

      const updatedClient: ClientProfile = {
        ...activeClient,
        directors,
        shareholders,
        workflowNodes: updatedNodes,
        overallStatus: 'in_progress'
      };

      onUpdateClient(updatedClient);
      setSingpassStep('success');
    }, 2000);
  };

  // Simulating Indian GSTIN & PAN Linking
  const triggerGstinPanSimulate = () => {
    if (!activeClient || !panNumber || !gstinNumber) return;

    setIsLinkingPanGst(true);

    setTimeout(() => {
      const updatedNodes = activeClient.workflowNodes.map(node => {
        if (node.id === 'data_aggregator') {
          return {
            ...node,
            status: 'completed' as NodeStatus,
            logs: [
              ...node.logs,
              `[06:09:12] 📡 Connecting to GSTN & NSDL Tax gateway using PAN: ${panNumber.toUpperCase()}`,
              `[06:09:13] 🔒 Validating Corporate GSTIN: ${gstinNumber.toUpperCase()}`,
              `[06:09:14] ✅ Registered Business Name found: "${activeClient.companyName}"`,
              `[06:09:14] 📂 Metadata fetched: ACTIVE, Private Limited Co, Registered Address in India.`
            ],
            results: {
              summary: 'NSDL Income Tax & GSTN databases matched.',
              metrics: {
                'PAN Validation': 'MATCHED',
                'GSTIN Status': 'ACTIVE',
                'GST Registry Name': activeClient.companyName,
                'Filing Compliance': '98.5%'
              },
              findings: [
                `Verified company PAN matches central CBDT databases.`,
                `GSTIN registered on Central Board of Indirect Taxes & Customs.`,
                `Active corporate tax standing with clear historical logs.`
              ]
            }
          };
        }
        return node;
      });

      const updatedClient: ClientProfile = {
        ...activeClient,
        registrationNumber: gstinNumber.toUpperCase(),
        workflowNodes: updatedNodes,
        overallStatus: 'in_progress'
      };

      onUpdateClient(updatedClient);
      setIsLinkingPanGst(false);
      setShowPanGstModal(false);
    }, 2000);
  };

  const getProgressPercentage = () => {
    if (!activeClient) return 0;
    const completedCount = activeClient.workflowNodes.filter(n => n.status === 'completed').length;
    return Math.round((completedCount / activeClient.workflowNodes.length) * 100);
  };

  // Generate contextual OCR key-value attributes for documents
  const getSampleOcrDataForType = (typeOrName: string, client: ClientProfile | null): Record<string, string> => {
    const cName = client?.companyName || 'Apex Capital Logistics Pte Ltd';
    const regNo = client?.registrationNumber || 'SG-202109841K';
    const jur = client?.jurisdiction || 'Singapore';
    const repName = client?.authorizedRepresentative?.name || 'John Tan';

    const lower = typeOrName.toLowerCase();
    if (lower.includes('incorporation') || lower.includes('coi') || lower.includes('certificate')) {
      return {
        'Legal Company Name': cName,
        'Registration / UEN': regNo,
        'Date of Incorporation': '14-Feb-2021',
        'Entity Classification': 'Private Company Limited by Shares',
        'Issued & Paid-up Capital': 'SGD 1,000,000',
        'Registered Office': jur.includes('SG') ? '10 Marina Boulevard, Tower 2 Level 39, Singapore 018983' : 'Plot 42, Bandra-Kurla Complex, Mumbai, India 400051',
        'Registrar Authority': jur.includes('SG') ? 'Accounting and Corporate Regulatory Authority (ACRA)' : 'Ministry of Corporate Affairs (MCA)',
        'Digital Certificate Hash': 'SHA256:7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069'
      };
    } else if (lower.includes('board') || lower.includes('resolution')) {
      return {
        'Entity Name': cName,
        'Resolution Date': '20-Jan-2026',
        'Meeting Quorum': 'Quorum Met (2 of 2 Directors Present)',
        'Authorized Signatories': `${repName} (Managing Director), Sarah Jenkins (Executive Director)`,
        'Operating Mandate': 'Any Two Directors Jointly / Class A Unlimited',
        'Approved Facilities': 'Multi-Currency Current Account, Global Treasury & FX Dealing',
        'Chairman Signature': 'VERIFIED (Cryptographic Signature Validated)'
      };
    } else if (lower.includes('shareholder') || lower.includes('ubo') || lower.includes('register')) {
      return {
        'Entity Name': cName,
        'Primary Shareholder': `${repName} (70.0% Ordinary Voting Shares)`,
        'Secondary Shareholder': 'Sarah Jenkins (30.0% Ordinary Voting Shares)',
        'Ultimate Beneficial Owner (UBO)': `${repName} (>25% Controlling Stake)`,
        'Sanctions & PEP Status': 'PASSED (0 Watchlist Matches)',
        'Register Stamp': 'Certified True Copy by Corporate Secretary'
      };
    } else if (lower.includes('tax') || lower.includes('fatca') || lower.includes('crs') || lower.includes('w8') || lower.includes('w-8')) {
      return {
        'Entity Name': cName,
        'Tax Residency Country': jur.includes('SG') ? 'Singapore' : 'India',
        'TIN / Tax Registration Number': regNo,
        'FATCA Chapter 4 Status': 'Active Non-Financial Foreign Entity (Active NFFE)',
        'CRS Entity Status': 'Reporting Financial / Commercial Active Entity',
        'Authorized Signer': repName,
        'Self-Certification Date': '10-Feb-2026'
      };
    } else if (lower.includes('constitution') || lower.includes('article') || lower.includes('memorandum')) {
      return {
        'Company Name': cName,
        'Constitution Adoption Date': '14-Feb-2021',
        'Object Clause': 'International freight forwarding, multi-currency trade facilitation and supply chain logistics',
        'Borrowing Powers': 'Directors may exercise all company powers to borrow money and mortgage property',
        'Share Transfer Restrictions': 'Subject to Board of Directors pre-emptive approval'
      };
    } else {
      return {
        'Document Name': typeOrName,
        'Entity Name': cName,
        'Identification Number': regNo,
        'Verification Status': 'Valid Official Document',
        'Extracted Timestamp': new Date().toLocaleDateString(),
        'OCR Extraction Confidence': '99.4%'
      };
    }
  };

  // Document selection for interactive OCR inspection
  const handleSelectDocForOcr = (doc: UploadedDocument) => {
    setSelectedDocForOcr(doc);
    if (doc.ocrData && Object.keys(doc.ocrData).length > 0) {
      setEditableOcrData({ ...doc.ocrData });
    } else {
      const defaultData = getSampleOcrDataForType(doc.type || doc.name, activeClient);
      setEditableOcrData(defaultData);
    }
  };

  // OCR key-value inline modifications
  const handleUpdateOcrField = (key: string, value: string) => {
    setEditableOcrData(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleDeleteOcrField = (keyToDelete: string) => {
    setEditableOcrData(prev => {
      const next = { ...prev };
      delete next[keyToDelete];
      return next;
    });
  };

  const handleAddOcrField = () => {
    if (!newOcrKey.trim()) return;
    setEditableOcrData(prev => ({
      ...prev,
      [newOcrKey.trim()]: newOcrValue.trim()
    }));
    setNewOcrKey('');
    setNewOcrValue('');
  };

  // Approve and dispatch verified OCR document attributes to RM Action Center
  const handleApproveAndSubmitOcr = () => {
    if (!activeClient || !selectedDocForOcr) return;

    setIsVerifyingOcr(true);

    setTimeout(() => {
      // 1. Update the document in client's document vault with pending_review status
      const currentDocs = activeClient.documents || [];
      const updatedDocs: UploadedDocument[] = currentDocs.map(doc => {
        if (doc.id === selectedDocForOcr.id) {
          return {
            ...doc,
            status: 'pending_review' as const,
            ocrData: editableOcrData
          };
        }
        return doc;
      });

      if (!updatedDocs.some(d => d.id === selectedDocForOcr.id)) {
        updatedDocs.push({
          ...selectedDocForOcr,
          status: 'pending_review',
          ocrData: editableOcrData
        });
      }

      // 2. Mark doc_verification workflow node as pending RM review with detailed audit findings
      const updatedNodes = activeClient.workflowNodes.map(node => {
        if (node.id === 'doc_verification') {
          return {
            ...node,
            status: 'in_progress' as NodeStatus,
            logs: [
              ...node.logs,
              `[${new Date().toLocaleTimeString()}] 📄 Customer reviewed and validated OCR key-value attributes for "${selectedDocForOcr.name}".`,
              `[${new Date().toLocaleTimeString()}] ⏳ Document status updated to "Pending Review by RM".`,
              `[${new Date().toLocaleTimeString()}] ✅ Dispatched verified document package to Relationship Manager Action Center.`,
              `[${new Date().toLocaleTimeString()}] 🔒 Document authenticity validated with 99.4% confidence.`
            ],
            results: {
              summary: `OCR extraction verified by customer for ${selectedDocForOcr.name}. Pending Relationship Manager review.`,
              metrics: {
                'OCR Trust Score': '99.4%',
                'Verified Attributes': Object.keys(editableOcrData).length,
                'Digital Signature': 'Validated',
                'Status': 'PENDING RM REVIEW'
              },
              findings: [
                `Customer verified ${Object.keys(editableOcrData).length} key-value attributes.`,
                'Awaiting final sign-off by Relationship Manager in Action Center.'
              ]
            }
          };
        }
        return node;
      });

      const updatedClient: ClientProfile = {
        ...activeClient,
        documents: updatedDocs,
        workflowNodes: updatedNodes
      };

      onUpdateClient(updatedClient);

      // 3. Dispatch System Notification to RM Action Center
      if (onAddNotification) {
        onAddNotification({
          id: `notif_${Date.now()}`,
          type: 'info',
          title: 'Document OCR Verified by Customer',
          msg: `Customer "${activeClient.companyName}" submitted verified OCR key-value attributes for ${selectedDocForOcr.name}.`,
          time: 'Just now',
          node: 'doc_verification',
          clientId: activeClient.id,
          clientName: activeClient.companyName,
          actionRequired: true,
          documentDetails: {
            docId: selectedDocForOcr.id,
            docName: selectedDocForOcr.name,
            docType: selectedDocForOcr.type || 'corporate_doc',
            ocrData: editableOcrData
          }
        });
      }

      setIsVerifyingOcr(false);
      setOcrSubmitSuccessMsg(`Verified OCR attributes for "${selectedDocForOcr.name}" dispatched to Relationship Manager for final review!`);
    }, 700);
  };

  // Upload or ingest sample corporate document into vault
  const handleUploadNewDocument = (docName: string, docType: string) => {
    if (!activeClient) return;
    const newDocId = `doc_${Date.now()}`;
    const sampleOcr = getSampleOcrDataForType(docName, activeClient);

    const newDoc: UploadedDocument = {
      id: newDocId,
      name: docName,
      type: docType,
      size: '2.4 MB',
      uploadedAt: new Date().toLocaleDateString(),
      status: 'pending',
      ocrData: sampleOcr,
      source: 'customer_provided',
      sourceDetails: 'Uploaded by Customer in Self-Service Portal'
    };

    const currentDocs = activeClient.documents || [];
    const updatedDocs = [...currentDocs.filter(d => d.name !== docName), newDoc];

    const updatedClient: ClientProfile = {
      ...activeClient,
      documents: updatedDocs
    };

    onUpdateClient(updatedClient);
    handleSelectDocForOcr(newDoc);
  };

  // Biometric Facial Liveness Verification
  const handleRunBiometricCheck = () => {
    if (!activeClient) return;
    setIsVerifyingBio(true);

    setTimeout(() => {
      const updatedNodes = activeClient.workflowNodes.map(node => {
        if (node.id === 'biometric_verification') {
          return {
            ...node,
            status: 'completed' as NodeStatus,
            logs: [
              ...node.logs,
              `[${new Date().toLocaleTimeString()}] 👤 Initializing 3D Facial Liveness detection for ${activeClient.authorizedRepresentative.name}...`,
              `[${new Date().toLocaleTimeString()}] 🔍 Passive texture analysis: 99.8% human skin authenticity.`,
              `[${new Date().toLocaleTimeString()}] 📸 Face-to-ID passport photo matching: 99.6% biometric vector confidence.`,
              `[${new Date().toLocaleTimeString()}] ✅ Biometric anti-spoofing verification passed.`
            ],
            results: {
              summary: `Facial liveness and passport biometric vector matched for ${activeClient.authorizedRepresentative.name}.`,
              metrics: {
                'Liveness Confidence': '99.8%',
                'Face-to-ID Match': '99.6%',
                'Anti-Spoofing Status': 'PASSED',
                'Representative ID': activeClient.authorizedRepresentative.email
              },
              findings: [
                '3D facial geometry strictly matched with government-issued photo record.',
                'No micro-expression anomalies or spoofing artifacts detected.'
              ]
            }
          };
        }
        return node;
      });

      const updatedClient: ClientProfile = {
        ...activeClient,
        workflowNodes: updatedNodes
      };

      onUpdateClient(updatedClient);
      setIsVerifyingBio(false);
      setOcrSubmitSuccessMsg(`3D Biometric Liveness Verification completed with 99.8% match confidence!`);
    }, 1400);
  };

  const isSg = activeClient?.jurisdiction.includes('SG') || activeClient?.jurisdiction.includes('Singapore');
  const isDaCompleted = activeClient?.workflowNodes.find(n => n.id === 'data_aggregator')?.status === 'completed';
  const isDocCompleted = activeClient?.workflowNodes.find(n => n.id === 'doc_verification')?.status === 'completed';
  const isBioCompleted = activeClient?.workflowNodes.find(n => n.id === 'biometric_verification')?.status === 'completed';

  // Auth Card Styles
  const cardBg = isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200';
  const textTitle = isDarkMode ? 'text-white' : 'text-slate-900';
  const textSub = isDarkMode ? 'text-slate-400' : 'text-slate-500';

  if (!isLoggedIn || !activeClient) {
    return (
      <div className="min-h-[80vh] flex flex-col justify-center items-center py-12 px-4 sm:px-6 lg:px-8 font-sans">
        <div className={`max-w-md w-full p-8 rounded-2xl border shadow-xl ${cardBg} space-y-6 relative overflow-hidden`}>
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-emerald-500 via-teal-500 to-indigo-500" />
          
          <div className="text-center space-y-2">
            <div className="mx-auto h-12 w-12 rounded-xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center font-bold text-xl border border-emerald-500/20">
              O
            </div>
            <h2 className={`text-2xl font-bold tracking-tight ${textTitle}`}>
              Onboard.ai Client Portal
            </h2>
            <p className={`text-xs ${textSub}`}>
              Complete your corporate onboarding journey securely
            </p>
          </div>

          <div className="flex border-b border-slate-800/20 pb-3">
            <button
              onClick={() => { setAuthMode('register'); setRegError(''); setLoginError(''); }}
              className={`flex-1 text-center py-2 text-xs font-mono font-bold tracking-wider uppercase border-b-2 transition ${
                authMode === 'register' 
                  ? 'border-emerald-500 text-emerald-500' 
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              REGISTER
            </button>
            <button
              onClick={() => { setAuthMode('signin'); setRegError(''); setLoginError(''); }}
              className={`flex-1 text-center py-2 text-xs font-mono font-bold tracking-wider uppercase border-b-2 transition ${
                authMode === 'signin' 
                  ? 'border-emerald-500 text-emerald-500' 
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              SIGN IN
            </button>
          </div>

          {authMode === 'signin' ? (
            <form onSubmit={handleLogin} className="space-y-4">
              {loginError && (
                <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-500 text-xs rounded-xl flex items-center gap-2 font-semibold">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{loginError}</span>
                </div>
              )}

              <div className="space-y-1">
                <label className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Authorized Representative Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 w-4 h-4 text-slate-500" />
                  <input
                    type="email"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="rep@company.com"
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-2.5 pl-9 text-xs outline-none focus:ring-1 focus:ring-emerald-500 text-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Portal Security Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 w-4 h-4 text-slate-500" />
                  <input
                    type="password"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-2.5 pl-9 text-xs outline-none focus:ring-1 focus:ring-emerald-500 text-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs tracking-wider uppercase transition shadow-lg cursor-pointer"
              >
                Access Self-Service Portal
              </button>
            </form>
          ) : (
            <form onSubmit={handleRegister} className="space-y-4">
              {regError && (
                <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-500 text-xs rounded-xl flex items-center gap-2 font-semibold">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{regError}</span>
                </div>
              )}

              <div className="space-y-1">
                <label className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Legal Entity / Company Name *</label>
                <div className="relative">
                  <Building className="absolute left-3 top-3 w-4 h-4 text-slate-500" />
                  <input
                    type="text"
                    value={regCompanyName}
                    onChange={(e) => setRegCompanyName(e.target.value)}
                    placeholder="e.g. ACME Global Pte Ltd"
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-2.5 pl-9 text-xs outline-none focus:ring-1 focus:ring-emerald-500 text-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Managing Rep *</label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 w-4 h-4 text-slate-500" />
                    <input
                      type="text"
                      value={regRepName}
                      onChange={(e) => setRegRepName(e.target.value)}
                      placeholder="e.g. John Doe"
                      className="w-full rounded-xl border border-slate-300 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-2.5 pl-9 text-xs outline-none focus:ring-1 focus:ring-emerald-500 text-slate-800 dark:text-white"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Jurisdiction *</label>
                  <select
                    value={regJurisdiction}
                    onChange={(e) => setRegJurisdiction(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-2.5 text-xs outline-none focus:ring-1 focus:ring-emerald-500 text-slate-800 dark:text-white font-semibold"
                  >
                    <option value="SG">Singapore (SG)</option>
                    <option value="IN">India (IN)</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Corporate Email *</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 w-4 h-4 text-slate-500" />
                  <input
                    type="email"
                    value={regRepEmail}
                    onChange={(e) => setRegRepEmail(e.target.value)}
                    placeholder="rep@company.com"
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-2.5 pl-9 text-xs outline-none focus:ring-1 focus:ring-emerald-500 text-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Portal Security Password *</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 w-4 h-4 text-slate-500" />
                  <input
                    type="password"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="Create a strong password"
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-2.5 pl-9 text-xs outline-none focus:ring-1 focus:ring-emerald-500 text-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs tracking-wider uppercase transition shadow-lg cursor-pointer"
              >
                Create Onboarding Portal Account
              </button>
            </form>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 text-left max-w-7xl mx-auto pb-16 font-sans">
      
      {/* Overview Banner Header Card */}
      <div className="p-6 bg-white border border-slate-200 rounded-2xl relative overflow-hidden text-slate-900 shadow-sm">
        <div className="absolute top-0 right-0 p-8 text-slate-500/5 pointer-events-none">
          <Building2 className="w-48 h-48 -mr-12 -mt-12" />
        </div>

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 z-10 relative">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-700 border border-emerald-500/20 text-[10px] font-mono uppercase tracking-widest font-bold">
              <span>● CUSTOMER SELF-SERVICE DASHBOARD</span>
            </div>
            <h1 className="text-2xl font-black tracking-tight text-slate-900">{activeClient.companyName}</h1>
            <p className="text-xs text-slate-500 max-w-2xl">
              Representative: <strong className="text-slate-800">{activeClient.authorizedRepresentative.name}</strong> ({activeClient.authorizedRepresentative.role}) • UEN / Reg #: <strong className="text-slate-800">{activeClient.registrationNumber}</strong> • Jurisdiction: <strong className="text-slate-800">{activeClient.jurisdiction}</strong>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <div className="text-right">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-mono">Onboarding Readiness</span>
              <span className="text-sm font-black text-emerald-600 px-3 py-1 bg-emerald-50 border border-emerald-200 rounded-xl inline-block mt-0.5">
                {getProgressPercentage()}% Deliverables Ready
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* SUCCESS TOAST NOTIFICATION BANNER */}
      {ocrSubmitSuccessMsg && (
        <div className="p-4 bg-emerald-600 text-white font-semibold text-xs rounded-xl shadow-lg flex items-center justify-between animate-fade-in">
          <span className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-emerald-200 shrink-0" />
            {ocrSubmitSuccessMsg}
          </span>
          <button onClick={() => setOcrSubmitSuccessMsg(null)} className="text-emerald-200 hover:text-white text-xs font-bold cursor-pointer">Dismiss</button>
        </div>
      )}

      {/* MAIN TWO-COLUMN DASHBOARD LAYOUT */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">

        {/* LEFT COLUMN: CATEGORY NAVIGATION SWITCHERS & CATEGORY VIEWS (xl:col-span-7) */}
        <div className="xl:col-span-7 space-y-6">

          {/* THREE CATEGORY DASHBOARD NAVIGATION SWITCHER */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            
            {/* Category 1 Switcher Card - BLUE */}
            <button
              onClick={() => setActiveCategory('category1_registry')}
              className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer relative overflow-hidden ${
                activeCategory === 'category1_registry'
                  ? 'bg-gradient-to-br from-slate-900 to-blue-950 text-white border-blue-500 shadow-lg ring-2 ring-blue-500/30'
                  : 'bg-white hover:bg-blue-50/30 text-slate-800 border-slate-200 hover:border-blue-200'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className={`p-2 rounded-xl shrink-0 ${activeCategory === 'category1_registry' ? 'bg-blue-500/20 text-blue-400' : 'bg-blue-50 text-blue-600'}`}>
                  <Landmark className="w-4 h-4" />
                </div>
                <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded-full uppercase ${
                  activeCategory === 'category1_registry' ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30' : 'bg-blue-100 text-blue-800'
                }`}>
                  External Data
                </span>
              </div>
              <div className="mt-2.5 space-y-0.5">
                <h3 className="text-xs font-bold tracking-tight text-blue-600 dark:text-blue-400 flex items-center gap-1">
                  1. External Registry
                </h3>
                <p className={`text-[10px] leading-normal ${activeCategory === 'category1_registry' ? 'text-slate-300' : 'text-slate-500'}`}>
                  ACRA / MyInfo / GSTN sources.
                </p>
              </div>
            </button>

            {/* Category 2 Switcher Card - GREEN */}
            <button
              onClick={() => setActiveCategory('category2_internal')}
              className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer relative overflow-hidden ${
                activeCategory === 'category2_internal'
                  ? 'bg-gradient-to-br from-slate-900 to-emerald-950 text-white border-emerald-500 shadow-lg ring-2 ring-emerald-500/30'
                  : 'bg-white hover:bg-emerald-50/30 text-slate-800 border-slate-200 hover:border-emerald-200'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className={`p-2 rounded-xl shrink-0 ${activeCategory === 'category2_internal' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-emerald-50 text-emerald-600'}`}>
                  <Settings className="w-4 h-4" />
                </div>
                <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded-full uppercase ${
                  activeCategory === 'category2_internal' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-emerald-100 text-emerald-800'
                }`}>
                  To Be Validated
                </span>
              </div>
              <div className="mt-2.5 space-y-0.5">
                <h3 className="text-xs font-bold tracking-tight text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                  2. Internal Records (To Be Validated)
                </h3>
                <p className={`text-[10px] leading-normal ${activeCategory === 'category2_internal' ? 'text-slate-300' : 'text-slate-500'}`}>
                  Org data & account settings.
                </p>
              </div>
            </button>

            {/* Category 3 Switcher Card - ORANGE */}
            <button
              onClick={() => setActiveCategory('category3_deliverables')}
              className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer relative overflow-hidden ${
                activeCategory === 'category3_deliverables'
                  ? 'bg-gradient-to-br from-slate-900 to-orange-950 text-white border-orange-500 shadow-lg ring-2 ring-orange-500/30'
                  : 'bg-white hover:bg-orange-50/30 text-slate-800 border-slate-200 hover:border-orange-200'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className={`p-2 rounded-xl shrink-0 ${activeCategory === 'category3_deliverables' ? 'bg-orange-500/20 text-orange-400' : 'bg-orange-50 text-orange-600'}`}>
                  <FileCheck2 className="w-4 h-4" />
                </div>
                <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded-full uppercase ${
                  activeCategory === 'category3_deliverables' ? 'bg-orange-500/20 text-orange-300 border border-orange-500/30' : 'bg-orange-100 text-orange-800'
                }`}>
                  Action Items
                </span>
              </div>
              <div className="mt-2.5 space-y-0.5">
                <h3 className="text-xs font-bold tracking-tight text-orange-600 dark:text-orange-400 flex items-center gap-1">
                  3. Required Deliverables
                </h3>
                <p className={`text-[10px] leading-normal ${activeCategory === 'category3_deliverables' ? 'text-slate-300' : 'text-slate-500'}`}>
                  OCR vault & biometrics.
                </p>
              </div>
            </button>

          </div>

          {/* RENDER CATEGORY VIEW CONTENT */}
          {/* mode="wait" previously used here would block the incoming category's
              motion.div from mounting until the outgoing one's exit animation fully
              settled. Frequent re-renders (from the customer backend-sync cycle) kept
              interrupting/restarting that exit animation so it never reached rest,
              permanently wedging AnimatePresence mid-transition — the card highlight
              (driven by the same activeCategory state) updated fine, but the content
              never switched. Default (simultaneous) mode renders the new category
              immediately regardless of the old one's exit animation state. */}
          <AnimatePresence>

        {/* ==================================================================== */}
        {/* CATEGORY 1: VERIFIED EXTERNAL REGISTRY DATA (BLUE THEME)            */}
        {/* ==================================================================== */}
        {activeCategory === 'category1_registry' && (
          <motion.div
            key="category1"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-6"
          >
            {/* Informational Guidance Notice Banner */}
            <div className="p-5 bg-gradient-to-r from-slate-900 via-slate-850 to-blue-950 text-white rounded-2xl border border-blue-500/30 shadow-md space-y-3">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-blue-500/20 text-blue-300 rounded-xl shrink-0 mt-0.5">
                  <Landmark className="w-5 h-5" />
                </div>
                <div className="space-y-1 text-left flex-1">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-400/30 uppercase tracking-wider">
                        1. External Registry (Verified Sources)
                      </span>
                      <span className="text-[10px] font-mono text-emerald-400 font-bold flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5" /> Immutable Core Record
                      </span>
                    </div>

                    <button
                      onClick={() => {
                        setGovtRegistryMismatchCategory('General Registry Mismatch');
                        setShowGovtRegistryModal(true);
                      }}
                      className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-blue-200" /> Provide Feedback
                    </button>
                  </div>

                  <h3 className="text-base font-extrabold text-white">1. External Registry Data</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    The details below were fetched directly from official, authenticated third-party registries (e.g. <strong>Singapore ACRA MyInfo Business</strong> or <strong>Indian GSTN / NSDL Portal</strong>). 
                    To ensure strict regulatory compliance and legal validity, <strong>no customer action is required on these verified records</strong>. 
                    If you observe any data mismatch from third-party sources or official registries, click <strong>"Provide Feedback"</strong> to submit details and commentary directly to your Relationship Manager.
                  </p>
                </div>
              </div>
            </div>

            {/* Category 1 Data Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              
              {/* Card 1: Official Corporate Entity Data */}
              <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-sm space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <Building className="w-4 h-4 text-blue-600" />
                    <h4 className="text-xs font-extrabold uppercase font-mono tracking-wider text-slate-800">
                      Official Entity Profile
                    </h4>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-blue-100 text-blue-800 border border-blue-200">
                      ACRA / GSTN VERIFIED
                    </span>
                    <button
                      onClick={() => {
                        setGovtRegistryMismatchCategory('Official Company Name / UEN');
                        setShowGovtRegistryModal(true);
                      }}
                      className="text-[10px] text-blue-600 hover:text-blue-800 font-bold underline cursor-pointer"
                    >
                      Report Mismatch
                    </button>
                  </div>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-500">Legal Company Name</span>
                    <span className="font-bold text-slate-900">{activeClient.companyName}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-500">UEN / Registration ID</span>
                    <span className="font-mono font-bold text-slate-900">{activeClient.registrationNumber}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-500">Jurisdiction</span>
                    <span className="font-semibold text-slate-800">{activeClient.jurisdiction}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-500">Entity Legal Type</span>
                    <span className="font-semibold text-slate-800">Private Limited Company</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-500">Incorporation Date</span>
                    <span className="font-semibold text-slate-800">14-Feb-2021</span>
                  </div>
                  <div className="flex justify-between py-1">
                    <span className="text-slate-500">Registry Standing</span>
                    <span className="font-bold text-emerald-600 flex items-center gap-1">
                      <CheckCircle className="w-3.5 h-3.5" /> ACTIVE & IN GOOD STANDING
                    </span>
                  </div>
                </div>
              </div>

              {/* Card 2: Official Registered Office Address */}
              <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-sm space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <Landmark className="w-4 h-4 text-indigo-600" />
                    <h4 className="text-xs font-extrabold uppercase font-mono tracking-wider text-slate-800">
                      Official Registered Office
                    </h4>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
                      GOVERNMENT LAND REGISTRY
                    </span>
                    <button
                      onClick={() => {
                        setGovtRegistryMismatchCategory('Registered Headquarters Address');
                        setShowGovtRegistryModal(true);
                      }}
                      className="text-[10px] text-indigo-600 hover:text-indigo-800 font-bold underline cursor-pointer"
                    >
                      Report Mismatch
                    </button>
                  </div>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <span className="text-slate-500 block mb-1">Official Address On File</span>
                    <p className="font-semibold text-slate-800 bg-slate-50 p-3 rounded-xl border border-slate-200 leading-relaxed">
                      {isSg ? '10 Marina Boulevard, Tower 2 Level 39, Singapore 018983' : 'Plot 42, Bandra-Kurla Complex, Commercial District, Mumbai, India 400051'}
                    </p>
                  </div>

                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-500">Registry Verification Hash</span>
                    <span className="font-mono text-[10px] text-indigo-600 font-bold">REG-HASH-849204812</span>
                  </div>
                  <div className="flex justify-between py-1">
                    <span className="text-slate-500">Data Synchronization SLA</span>
                    <span className="font-mono text-[10px] text-slate-700 font-semibold">Real-Time Government Gateway</span>
                  </div>
                </div>
              </div>

              {/* Card 3: Official Listed Directors */}
              <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-sm space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-indigo-600" />
                    <h4 className="text-xs font-extrabold uppercase font-mono tracking-wider text-slate-800">
                      Official Board Directors List
                    </h4>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-emerald-100 text-emerald-800">
                      PUBLIC FILING
                    </span>
                    <button
                      onClick={() => {
                        setGovtRegistryMismatchCategory('Board Directors List');
                        setShowGovtRegistryModal(true);
                      }}
                      className="text-[10px] text-indigo-600 hover:text-indigo-800 font-bold underline cursor-pointer"
                    >
                      Report Mismatch
                    </button>
                  </div>
                </div>

                <div className="space-y-2.5">
                  {(activeClient.directors || [
                    { name: activeClient.authorizedRepresentative?.name || 'John Tan', role: 'Managing Director', appointmentDate: '12 Jan 2022', nationality: 'Singaporean' },
                    { name: 'Sarah Jenkins', role: 'Executive Director', appointmentDate: '01 Jun 2023', nationality: 'British' }
                  ]).map((dir, idx) => (
                    <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-slate-900 block">{dir.name}</span>
                        <span className="text-[10px] text-slate-500">{dir.role} • Appointed {dir.appointmentDate}</span>
                      </div>
                      <span className="text-[10px] font-mono font-semibold px-2 py-0.5 bg-white rounded border border-slate-200 text-slate-700">
                        {dir.nationality}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Card 4: Official Shareholding Structure */}
              <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-sm space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <FileSpreadsheet className="w-4 h-4 text-indigo-600" />
                    <h4 className="text-xs font-extrabold uppercase font-mono tracking-wider text-slate-800">
                      Registered Equity Holders
                    </h4>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-indigo-50 text-indigo-700">
                      REGISTERED CAPITAL
                    </span>
                    <button
                      onClick={() => {
                        setGovtRegistryMismatchCategory('Equity & Shareholders Register');
                        setShowGovtRegistryModal(true);
                      }}
                      className="text-[10px] text-indigo-600 hover:text-indigo-800 font-bold underline cursor-pointer"
                    >
                      Report Mismatch
                    </button>
                  </div>
                </div>

                <div className="space-y-2.5">
                  {activeClient.shareholders.map((sh, idx) => (
                    <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-slate-900 block">{sh.name}</span>
                        <span className="text-[10px] text-slate-500">Ultimate Beneficial Owner (UBO)</span>
                      </div>
                      <div className="text-right">
                        <span className="text-xs font-black text-indigo-600 font-mono">{sh.equity}% Equity</span>
                        <span className="text-[9px] text-emerald-600 font-bold block">● Sanctions Cleared</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>

            {/* Submitted Registry Requests Log Section */}
            {activeClient.govtRegistryUpdateRequests && activeClient.govtRegistryUpdateRequests.length > 0 && (
              <div className="p-5 bg-blue-50/70 border border-blue-200 rounded-2xl space-y-3">
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-blue-700" />
                  <h4 className="text-xs font-extrabold uppercase font-mono tracking-wider text-blue-900">
                    Submitted Third-Party Source Feedback ({activeClient.govtRegistryUpdateRequests.length})
                  </h4>
                </div>
                <div className="space-y-2">
                  {activeClient.govtRegistryUpdateRequests.map((req) => (
                    <div key={req.id} className="p-3.5 bg-white border border-blue-200 rounded-xl space-y-1.5 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900 text-xs">{req.mismatchCategory}</span>
                        <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-blue-100 text-blue-800 border border-blue-300">
                          PENDING RM REVIEW
                        </span>
                      </div>
                      <p className="text-slate-600 text-[11px] bg-slate-50 p-2 rounded border border-slate-150 font-sans">
                        "{req.commentary}"
                      </p>
                      <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 pt-0.5">
                        <span>Submitted: {req.submittedAt}</span>
                        {req.filingReferenceNo && <span>Filing Ref: {req.filingReferenceNo}</span>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Category 1 Actions Bar */}
            <div className="p-4 bg-slate-100 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
              <span className="text-slate-600 font-medium">
                Noticed any data mismatch from third-party sources or official registries? Provide feedback and commentary to your Relationship Manager.
              </span>
              <button
                onClick={() => {
                  setGovtRegistryMismatchCategory('General Registry Mismatch');
                  setShowGovtRegistryModal(true);
                }}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow transition flex items-center gap-2 shrink-0 cursor-pointer"
              >
                <MessageSquare className="w-4 h-4 text-blue-200" /> Provide Feedback
              </button>
            </div>
          </motion.div>
        )}

        {/* ==================================================================== */}
        {/* CATEGORY 2: INTERNAL RECORDS (TO BE VALIDATED) - GREEN THEME         */}
        {/* ==================================================================== */}
        {activeCategory === 'category2_internal' && (
          <motion.div
            key="category2"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-6"
          >
            {/* Informational Guidance Notice Banner */}
            <div className="p-5 bg-gradient-to-r from-slate-900 via-slate-850 to-emerald-950 text-white rounded-2xl border border-emerald-500/30 shadow-md space-y-3">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-emerald-500/20 text-emerald-300 rounded-xl shrink-0 mt-0.5">
                  <Edit3 className="w-5 h-5" />
                </div>
                <div className="space-y-1 text-left flex-1">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 uppercase tracking-wider">
                        2. Internal Records (To Be Validated)
                      </span>
                      <span className="text-[10px] font-mono text-emerald-300 font-bold flex items-center gap-1">
                        <CheckCircle className="w-3.5 h-3.5" /> Customer Modifiable
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => openEditInternalModalHandler('representatives')}
                      className="px-4 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs rounded-xl shadow-lg transition flex items-center gap-1.5 cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" /> Modify Internal Records
                    </button>
                  </div>

                  <h3 className="text-base font-extrabold text-white">2. Internal Records (To Be Validated)</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    This section displays the corporate representatives, account signatories, system operators, operating mandates, and tax self-certifications recorded in our internal core systems for your company. Click <strong>"Modify Internal Records"</strong> above to edit fields, add, or update records in the popup form.
                  </p>
                </div>
              </div>
            </div>

            {/* Category 2 Data Display Cards Grid - PRISTINE READ-ONLY TILES WITHOUT CLUTTER LINKS */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              
              {/* Card 1: Multiple Designated Representatives */}
              <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-sm space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-emerald-600" />
                    <h4 className="text-xs font-extrabold uppercase font-mono tracking-wider text-slate-800">
                      Designated Representatives ({activeClient.internalAccountSettings?.representatives?.length || 2})
                    </h4>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                    SYSTEM SYNCED
                  </span>
                </div>

                <div className="space-y-3">
                  {(activeClient.internalAccountSettings?.representatives || [
                    { id: 'rep1', name: activeClient.authorizedRepresentative?.name || 'John Tan', role: activeClient.authorizedRepresentative?.role || 'Managing Director', email: activeClient.authorizedRepresentative?.email || 'j.tan@company.com', phone: '+65 9123 4567', isPrimary: true },
                    { id: 'rep2', name: 'Sarah Jenkins', role: 'Head of Corporate Treasury', email: 's.jenkins@company.com', phone: '+65 9876 5432', isPrimary: false }
                  ]).map((rep) => (
                    <div key={rep.id} className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900">{rep.name}</span>
                        {rep.isPrimary ? (
                          <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-indigo-100 text-indigo-800">
                            PRIMARY CONTACT
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-slate-200 text-slate-700">
                            ACTIVE REP
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-600 space-y-0.5">
                        <p><strong className="text-slate-700">Role:</strong> {rep.role}</p>
                        <p><strong className="text-slate-700">Email:</strong> {rep.email}</p>
                        <p><strong className="text-slate-700">Phone:</strong> {rep.phone}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Card 2: Multiple Account Signatories */}
              <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-sm space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <UserCheck className="w-4 h-4 text-emerald-600" />
                    <h4 className="text-xs font-extrabold uppercase font-mono tracking-wider text-slate-800">
                      Account Signatories ({activeClient.internalAccountSettings?.signatories?.length || 2})
                    </h4>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                    ACTIVE SIGNATORIES
                  </span>
                </div>

                <div className="space-y-3">
                  {(activeClient.internalAccountSettings?.signatories || [
                    { id: 'sig1', name: activeClient.authorizedRepresentative?.name || 'John Tan', role: 'Managing Director', signingPower: 'Class A (Unlimited)', email: activeClient.authorizedRepresentative?.email || 'j.tan@company.com', status: 'Active' },
                    { id: 'sig2', name: 'Michael Chen', role: 'Chief Financial Officer', signingPower: 'Class B (Up to $500,000 USD)', email: 'm.chen@company.com', status: 'Active' }
                  ]).map((sig) => (
                    <div key={sig.id} className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900">{sig.name}</span>
                        <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-emerald-100 text-emerald-800">
                          {sig.status}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-600 space-y-0.5">
                        <p><strong className="text-slate-700">Role:</strong> {sig.role}</p>
                        <p><strong className="text-slate-700">Signing Authority:</strong> <span className="font-mono text-emerald-700 font-bold">{sig.signingPower}</span></p>
                        <p><strong className="text-slate-700">Email:</strong> {sig.email}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Card 3: Multiple Account Operators / System Users */}
              <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-sm space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <KeyRound className="w-4 h-4 text-emerald-600" />
                    <h4 className="text-xs font-extrabold uppercase font-mono tracking-wider text-slate-800">
                      Account Operators ({activeClient.internalAccountSettings?.operators?.length || 3})
                    </h4>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                    SYSTEM USERS
                  </span>
                </div>

                <div className="space-y-3">
                  {(activeClient.internalAccountSettings?.operators || [
                    { id: 'op1', name: activeClient.authorizedRepresentative?.name || 'John Tan', role: 'Managing Director', accessLevel: 'Full Admin', email: activeClient.authorizedRepresentative?.email || 'j.tan@company.com' },
                    { id: 'op2', name: 'Elena Rostova', role: 'Finance Operations Lead', accessLevel: 'Payment Drafter (Maker)', email: 'elena.r@company.com' },
                    { id: 'op3', name: 'David Tan', role: 'Finance Director', accessLevel: 'Payment Approver (Checker)', email: 'david.tan@company.com' }
                  ]).map((op) => (
                    <div key={op.id} className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900">{op.name}</span>
                        <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-slate-200 text-slate-800">
                          {op.accessLevel}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-600 space-y-0.5">
                        <p><strong className="text-slate-700">Role:</strong> {op.role}</p>
                        <p><strong className="text-slate-700">Email:</strong> {op.email}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Card 4: Tax Self-Certification (FATCA / CRS) */}
              <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-sm space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <Globe className="w-4 h-4 text-emerald-600" />
                    <h4 className="text-xs font-extrabold uppercase font-mono tracking-wider text-slate-800">
                      Tax Self-Certifications ({activeClient.internalAccountSettings?.taxCertifications?.length || 2})
                    </h4>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                    VALIDATED TAX CERTS
                  </span>
                </div>

                <div className="space-y-3">
                  {(activeClient.internalAccountSettings?.taxCertifications || [
                    { id: 'tax1', taxResidencyCountry: activeClient.jurisdiction.includes('SG') || activeClient.jurisdiction.includes('Singapore') ? 'Singapore' : 'India', tinReferenceNumber: activeClient.registrationNumber, fatcaClassification: 'Active NFFE', crsStatus: 'Reportable Entity', isPrimary: true },
                    { id: 'tax2', taxResidencyCountry: 'United States', tinReferenceNumber: 'US-982103982', fatcaClassification: 'Specified US Person (Form W-9)', crsStatus: 'Non-Reportable (US)', isPrimary: false }
                  ]).map((tax) => (
                    <div key={tax.id} className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900">{tax.taxResidencyCountry}</span>
                        {tax.isPrimary && (
                          <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-emerald-100 text-emerald-800">
                            PRIMARY RESIDENCY
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-600 space-y-0.5">
                        <p><strong className="text-slate-700">TIN / Ref No:</strong> <span className="font-mono text-slate-800">{tax.tinReferenceNumber}</span></p>
                        <p><strong className="text-slate-700">FATCA Classification:</strong> {tax.fatcaClassification}</p>
                        <p><strong className="text-slate-700">CRS Status:</strong> {tax.crsStatus}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Card 5: Operating Account & Facility Parameters */}
              <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-sm space-y-4 md:col-span-2">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-emerald-600" />
                    <h4 className="text-xs font-extrabold uppercase font-mono tracking-wider text-slate-800">
                      Account Facilities & Operating Mandates
                    </h4>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                    ACTIVE MANDATES
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <span className="text-slate-500 text-[10px] block">Primary Account Facility</span>
                    <span className="font-bold text-slate-900">{activeClient.internalAccountSettings?.accountType || 'Corporate Multi-Currency CASA'}</span>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <span className="text-slate-500 text-[10px] block">Settlement Currency</span>
                    <span className="font-mono font-bold text-emerald-600">{activeClient.internalAccountSettings?.primaryCurrency || 'SGD'}</span>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <span className="text-slate-500 text-[10px] block">Estimated Monthly Volume</span>
                    <span className="font-semibold text-slate-800">{activeClient.internalAccountSettings?.estMonthlyVolume || '$250,000 - $1,000,000 USD'}</span>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <span className="text-slate-500 text-[10px] block">Operating Mandate Rule</span>
                    <span className="font-bold text-slate-900">{activeClient.internalAccountSettings?.operatingMandate || 'Joint Signatories - Any Two Directors'}</span>
                  </div>
                </div>
              </div>

            </div>

            {/* Submitted Record Requests Log Section */}
            {activeClient.govtRegistryUpdateRequests && activeClient.govtRegistryUpdateRequests.filter(r => r.mismatchCategory.includes('Internal') || r.mismatchCategory.includes('Prompt')).length > 0 && (
              <div className="p-5 bg-emerald-50/70 border border-emerald-200 rounded-2xl space-y-3">
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-emerald-700" />
                  <h4 className="text-xs font-extrabold uppercase font-mono tracking-wider text-emerald-900">
                    Submitted Internal Record Prompt Requests ({activeClient.govtRegistryUpdateRequests.filter(r => r.mismatchCategory.includes('Internal') || r.mismatchCategory.includes('Prompt')).length})
                  </h4>
                </div>
                <div className="space-y-2">
                  {activeClient.govtRegistryUpdateRequests.filter(r => r.mismatchCategory.includes('Internal') || r.mismatchCategory.includes('Prompt')).map((req) => (
                    <div key={req.id} className="p-3.5 bg-white border border-emerald-200 rounded-xl space-y-1.5 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900 text-xs">{req.mismatchCategory}</span>
                        <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                          PENDING RM REVIEW
                        </span>
                      </div>
                      <p className="text-slate-600 text-[11px] bg-slate-50 p-2 rounded border border-slate-150 font-sans">
                        "{req.commentary}"
                      </p>
                      <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 pt-0.5">
                        <span>Submitted: {req.submittedAt}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Bottom Prompt CTA Bar */}
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
              <span className="text-emerald-900 font-medium">
                Prefer guided entry or editing forms for representatives, signatories, operators or tax self-certifications?
              </span>
              <button
                onClick={openEditInternalModalHandler}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow transition flex items-center gap-2 shrink-0 cursor-pointer"
              >
                <Edit3 className="w-4 h-4 text-emerald-100" /> Open Detailed Record Form
              </button>
            </div>
          </motion.div>
        )}

        {/* ==================================================================== */}
        {/* CATEGORY 3: REQUIRED DELIVERABLES, DOCUMENT VAULT & INTERACTIVE OCR   */}
        {/* ==================================================================== */}
        {activeCategory === 'category3_deliverables' && (
          <motion.div
            key="category3"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-6"
          >
            {/* Header info banner - ORANGE THEME */}
            <div className="p-5 bg-gradient-to-br from-slate-900 via-slate-850 to-orange-950 text-white rounded-2xl border border-orange-500/30 shadow-md relative overflow-hidden">
              <div className="absolute right-0 top-0 p-6 text-orange-500/10 pointer-events-none">
                <FileCheck2 className="w-32 h-32 -mr-6 -mt-6" />
              </div>
              <div className="relative z-10 space-y-2">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded-full bg-orange-500/20 text-orange-300 border border-orange-500/30 text-[9px] font-mono uppercase font-bold tracking-wider">
                    3. Required Deliverables • Action Items
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">Interactive Ingestion & OCR Intelligence</span>
                </div>
                <h2 className="text-lg font-black tracking-tight text-white">
                  3. Required Onboarding Deliverables & Document Vault
                </h2>
                <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
                  Upload corporate governance documents, inspect AI-extracted key-value pairs in real-time, and complete 3D biometric facial liveness verification. Verified attributes are dispatched directly to your Relationship Manager for workflow approval.
                </p>
              </div>
            </div>

            {/* Requests From Your Relationship Manager — open clarifications
                routed to the customer (raised by Compliance/Ops, escalated
                to RM, then sent to the customer via outreach). Responding
                routes it back to RM/Ops for re-review. */}
            {activeClient && (() => {
              const openRequests = (activeClient.workflowNodes || []).filter(
                n => n.clarification?.status === 'open' && n.clarification.targetPersona === 'customer'
              );
              if (openRequests.length === 0) return null;
              return (
                <div className="p-5 bg-blue-50 border-2 border-blue-300 rounded-2xl shadow-sm space-y-4">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 bg-blue-600 text-white rounded-lg shrink-0">
                      <HelpCircle className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-sm font-black text-blue-950">Requests From Your Relationship Manager</h3>
                      <p className="text-[11px] text-blue-800">Please respond so your onboarding can continue.</p>
                    </div>
                  </div>

                  {openRequests.map(reqNode => {
                    const latest = reqNode.clarification!.history[reqNode.clarification!.history.length - 1];
                    return (
                      <div key={reqNode.id} className="bg-white border border-blue-200 rounded-xl p-4 space-y-3">
                        <div>
                          <span className="text-[10px] font-mono font-bold text-blue-700 uppercase tracking-wider">{reqNode.name}</span>
                          <p className="text-xs text-slate-800 mt-1">{latest.message}</p>
                        </div>
                        <textarea
                          rows={2}
                          value={clarificationResponses[reqNode.id] || ''}
                          onChange={(e) => setClarificationResponses(prev => ({ ...prev, [reqNode.id]: e.target.value }))}
                          placeholder="Type your response here..."
                          className="w-full border border-slate-200 rounded-lg p-2.5 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        />
                        <button
                          onClick={() => {
                            const message = (clarificationResponses[reqNode.id] || '').trim();
                            if (!message || !onRespondToClarification) return;
                            onRespondToClarification(activeClient.id, reqNode.id, message);
                            setClarificationResponses(prev => ({ ...prev, [reqNode.id]: '' }));
                          }}
                          disabled={!clarificationResponses[reqNode.id]?.trim()}
                          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-400 text-white text-xs font-bold rounded-lg transition flex items-center gap-1.5 cursor-pointer disabled:cursor-not-allowed"
                        >
                          <Send className="w-3.5 h-3.5" /> Send Response
                        </button>
                        <p className="text-[10px] text-slate-400">
                          Have a document to attach? Use the vault below to upload it, then send your response.
                        </p>
                      </div>
                    );
                  })}
                </div>
              );
            })()}

            {/* Fast Action Cards Row: Gov Registry Sync & 3D Biometric Liveness */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Card 1: Official Registry Synchronization */}
              <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-sm text-left space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2.5 rounded-xl bg-orange-50 text-orange-600 border border-orange-100">
                      <Landmark className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-xs font-bold text-slate-900">Government Registry Gateway</h3>
                      <p className="text-[10px] text-slate-500 font-mono">
                        {isSg ? 'Singpass MyInfo Business / ACRA' : 'GSTN & NSDL Corporate Tax Registry'}
                      </p>
                    </div>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase ${
                    isDaCompleted ? 'bg-emerald-100 text-emerald-800' : 'bg-orange-100 text-orange-800'
                  }`}>
                    {isDaCompleted ? 'SYNCHRONIZED' : 'ACTION REQUIRED'}
                  </span>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">
                  {isDaCompleted 
                    ? `Authentic registry records linked for ${activeClient.companyName} (${activeClient.registrationNumber}). Directors & UBO records verified.`
                    : 'Connect directly to authentic registry systems for zero-entry automated corporate data retrieval.'
                  }
                </p>

                <div className="pt-1">
                  {isDaCompleted ? (
                    <div className="p-2.5 bg-emerald-50 rounded-xl border border-emerald-200 flex items-center justify-between text-xs text-emerald-800 font-semibold">
                      <span className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        Live Registry Verified
                      </span>
                      <button 
                        onClick={() => isSg ? setShowSingpassModal(true) : setShowPanGstModal(true)}
                        className="text-[11px] text-emerald-700 hover:text-emerald-900 font-bold underline cursor-pointer"
                      >
                        Re-sync
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => isSg ? setShowSingpassModal(true) : setShowPanGstModal(true)}
                      className="w-full py-2.5 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs rounded-xl shadow transition flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      {isSg ? 'Authenticate via Singpass MyInfo' : 'Link PAN & GSTIN Gateway'}
                    </button>
                  )}
                </div>
              </div>

              {/* Card 2: 3D Facial Liveness Biometric Verification */}
              <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-sm text-left space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2.5 rounded-xl bg-orange-50 text-orange-600 border border-orange-100">
                      <Camera className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-xs font-bold text-slate-900">3D Facial Liveness Verification</h3>
                      <p className="text-[10px] text-slate-500 font-mono">
                        {activeClient.authorizedRepresentative.name} ({activeClient.authorizedRepresentative.role})
                      </p>
                    </div>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase ${
                    isBioCompleted ? 'bg-emerald-100 text-emerald-800' : 'bg-orange-100 text-orange-800'
                  }`}>
                    {isBioCompleted ? 'VERIFIED (99.8%)' : 'PENDING CHECK'}
                  </span>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">
                  {isBioCompleted
                    ? '3D biometric facial scan matched against official photo ID vector. Passive anti-spoofing validation passed.'
                    : 'Perform automated 3D optical facial liveness scan to verify authorized signatory identity without physical branches.'
                  }
                </p>

                <div className="pt-1">
                  <button
                    onClick={handleRunBiometricCheck}
                    disabled={isVerifyingBio}
                    className={`w-full py-2.5 font-bold text-xs rounded-xl shadow transition flex items-center justify-center gap-2 cursor-pointer ${
                      isBioCompleted 
                        ? 'bg-orange-50 hover:bg-orange-100 text-orange-800 border border-orange-200' 
                        : 'bg-orange-600 hover:bg-orange-700 text-white'
                    }`}
                  >
                    {isVerifyingBio ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        Scanning 3D Facial Geometry...
                      </>
                    ) : isBioCompleted ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5 text-orange-600" />
                        Re-run Biometric Verification
                      </>
                    ) : (
                      <>
                        <Fingerprint className="w-3.5 h-3.5" />
                        Start 3D Facial Liveness Scan
                      </>
                    )}
                  </button>
                </div>
              </div>

            </div>

            {/* INTERACTIVE ON-SCREEN OCR KEY-VALUE VERIFICATION PANEL - ORANGE ACCENTS */}
            {selectedDocForOcr && (
              <div className="p-6 bg-white border-2 border-orange-500/40 rounded-2xl shadow-xl text-left space-y-5 animate-fade-in ring-4 ring-orange-500/10">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-3 rounded-xl bg-orange-600 text-white shadow-md">
                      <Scan className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-sm font-black text-slate-900 tracking-tight">
                          OCR Key-Value Verification: {selectedDocForOcr.name}
                        </h3>
                        <span className="px-2 py-0.5 rounded-full bg-orange-100 text-orange-800 text-[9px] font-mono font-bold">
                          AI Extraction (99.4% Confidence)
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Inspect document preview, verify extracted attributes, or amend values before submitting for Relationship Manager review.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setViewingDocument(selectedDocForOcr)}
                      className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-xs rounded-xl border border-blue-200 transition flex items-center gap-1.5 cursor-pointer"
                      title="Open full document preview in modal"
                    >
                      <Eye className="w-4 h-4" />
                      Full Preview
                    </button>
                    <button
                      onClick={() => setSelectedDocForOcr(null)}
                      className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition cursor-pointer"
                      title="Close OCR Panel"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                {/* Simulated OCR Real-time Ingestion Progress Bar */}
                {ocrScanningProgress !== null && (
                  <div className="p-3 bg-orange-50 border border-orange-200 rounded-xl space-y-1.5 animate-pulse">
                    <div className="flex items-center justify-between text-xs font-mono font-bold text-orange-900">
                      <span className="flex items-center gap-1.5">
                        <RefreshCw className="w-3.5 h-3.5 animate-spin text-orange-600" />
                        Running OCR Extraction & Authenticity Models...
                      </span>
                      <span>{ocrScanningProgress}%</span>
                    </div>
                    <div className="w-full bg-orange-200 rounded-full h-2 overflow-hidden">
                      <div 
                        className="bg-orange-600 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${ocrScanningProgress}%` }}
                      />
                    </div>
                  </div>
                )}

                {/* Embedded Document Preview & Key-Value Split Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
                  {/* Left sub-box: Document Preview Snippet */}
                  <div className="lg:col-span-5 bg-slate-900 rounded-xl p-4 text-white space-y-3 flex flex-col justify-between border border-slate-800">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                        <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-emerald-400">
                          <FileCheck className="w-4 h-4" />
                          <span>DOCUMENT PREVIEW</span>
                        </div>
                        <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                          {selectedDocForOcr.size || '1.8 MB'}
                        </span>
                      </div>

                      <div className="bg-slate-950/90 rounded-lg p-3 border border-slate-800 space-y-1.5 font-mono text-[11px] text-slate-300 leading-relaxed max-h-[220px] overflow-y-auto">
                        <div className="text-orange-400 font-bold text-xs uppercase tracking-wider">
                          [RECORD / OFFICIAL CERTIFICATE]
                        </div>
                        <p><strong className="text-white">Document:</strong> {selectedDocForOcr.name}</p>
                        <p><strong className="text-white">Entity:</strong> {activeClient.companyName}</p>
                        <p><strong className="text-white">Reg ID:</strong> {activeClient.registrationNumber}</p>
                        <p><strong className="text-white">Jurisdiction:</strong> {activeClient.jurisdiction}</p>
                        <p><strong className="text-white">Ingestion:</strong> {selectedDocForOcr.uploadedAt || 'Current Session'}</p>
                        <div className="pt-2 border-t border-slate-800 text-[10px] text-slate-400">
                          ✓ Digital cryptographic signature verified.<br/>
                          ✓ High-confidence OCR layer extracted.
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => setViewingDocument(selectedDocForOcr)}
                      className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-xs font-bold rounded-lg border border-slate-700 transition flex items-center justify-center gap-1.5 cursor-pointer mt-2"
                    >
                      <Eye className="w-3.5 h-3.5 text-orange-400" />
                      Expand High-Res Viewer
                    </button>
                  </div>

                  {/* Right sub-box: Editable Attributes Table */}
                  <div className="lg:col-span-7 space-y-3">
                    <div className="flex items-center justify-between text-[11px] font-mono font-bold text-slate-500 uppercase px-1">
                      <span>Document Attribute (Key)</span>
                      <span>Extracted / Verified Value</span>
                    </div>

                    <div className="space-y-2 max-h-[260px] overflow-y-auto pr-1">
                      {Object.entries(editableOcrData).map(([key, val]) => (
                        <div key={key} className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between gap-2 hover:border-slate-300 transition">
                          <div className="w-2/5 text-xs font-bold text-slate-800 font-mono truncate" title={key}>
                            {key}
                          </div>
                          <div className="flex-1 flex items-center gap-1.5">
                            <input
                              type="text"
                              value={val}
                              onChange={(e) => handleUpdateOcrField(key, e.target.value)}
                              className="w-full text-xs font-medium text-slate-900 bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 outline-none focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
                            />
                            <button
                              onClick={() => handleDeleteOcrField(key)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer shrink-0"
                              title="Remove attribute"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Add New Key-Value Field Row */}
                    <div className="p-2.5 bg-orange-50/60 border border-orange-200 rounded-xl flex items-center gap-2">
                      <input
                        type="text"
                        placeholder="Key (e.g. Tax ID)"
                        value={newOcrKey}
                        onChange={(e) => setNewOcrKey(e.target.value)}
                        className="w-1/3 text-xs bg-white border border-orange-200 rounded-lg px-2.5 py-1.5 outline-none focus:ring-1 focus:ring-orange-500 text-slate-800"
                      />
                      <input
                        type="text"
                        placeholder="Attribute Value"
                        value={newOcrValue}
                        onChange={(e) => setNewOcrValue(e.target.value)}
                        className="flex-1 text-xs bg-white border border-orange-200 rounded-lg px-2.5 py-1.5 outline-none focus:ring-1 focus:ring-orange-500 text-slate-800"
                      />
                      <button
                        onClick={handleAddOcrField}
                        disabled={!newOcrKey.trim()}
                        className="px-3 py-1.5 bg-orange-600 hover:bg-orange-700 disabled:opacity-40 text-white text-xs font-bold rounded-lg transition flex items-center gap-1 shrink-0 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        Add
                      </button>
                    </div>
                  </div>
                </div>

                {/* OCR Verification Submission Actions */}
                <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping" />
                    <p className="text-[11px] text-slate-600">
                      Submitting will verify <strong className="text-slate-800">{Object.keys(editableOcrData).length} attributes</strong> and mark status as <strong className="text-amber-700">Pending Review by RM</strong>.
                    </p>
                  </div>

                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    <button
                      onClick={() => setSelectedDocForOcr(null)}
                      className="flex-1 sm:flex-none px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleApproveAndSubmitOcr}
                      disabled={isVerifyingOcr}
                      className="flex-1 sm:flex-none px-6 py-2.5 bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs rounded-xl shadow-lg transition flex items-center justify-center gap-2 cursor-pointer"
                    >
                      {isVerifyingOcr ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          Submitting for RM Review...
                        </>
                      ) : (
                        <>
                          <CheckCircle2 className="w-4 h-4" />
                          Confirm & Submit to RM Review
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* MANDATORY DOCUMENT VAULT - STRUCTURED AS DOCUMENTS BANK HAS VS ADDITIONAL DOCUMENTS REQUIRED */}
            <div className="p-6 bg-white border border-slate-200 rounded-2xl shadow-sm text-left space-y-6">
              
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
                <div>
                  <h3 className="text-sm font-black text-slate-900 tracking-tight flex items-center gap-2">
                    <FileBadge className="w-4 h-4 text-orange-600" /> Corporate Governance Document Vault
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Clear breakdown of verified documents held by the bank and additional mandatory deliverables required from the customer.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-mono px-2.5 py-1 bg-slate-100 text-slate-700 rounded-lg font-bold border border-slate-200">
                    {(activeClient.documents || []).length} Ingested Records
                  </span>
                </div>
              </div>

              {/* SECTION 1: DOCUMENTS THE BANK ALREADY HAS */}
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <div className="flex items-center gap-2">
                    <div className="p-1 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                    </div>
                    <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider font-mono">
                      1. Documents the Bank Has ({(activeClient.documents || []).length})
                    </h4>
                  </div>
                  <span className="text-[10px] text-emerald-700 font-mono font-bold bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    Sourced & Ingested
                  </span>
                </div>

                {(activeClient.documents || []).length === 0 ? (
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-center text-xs text-slate-500">
                    No documents currently ingested. Use the Required Documents section below or upload via Copilot.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                    {(activeClient.documents || []).map((doc, idx) => {
                      const isPendingReview = doc.status === 'pending_review';
                      const isVerified = doc.status === 'verified';
                      const isSelected = selectedDocForOcr?.id === doc.id;

                      return (
                        <div 
                          key={doc.id || idx}
                          className={`p-4 rounded-2xl border transition-all space-y-3 text-left ${
                            isSelected 
                              ? 'bg-orange-50/70 border-orange-500 shadow-md ring-2 ring-orange-500/20' 
                              : isPendingReview
                                ? 'bg-amber-50/40 border-amber-300 hover:border-amber-400'
                                : isVerified
                                  ? 'bg-white border-slate-200 hover:border-emerald-300' 
                                  : 'bg-white border-slate-200 hover:border-orange-300'
                          }`}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex items-center gap-2.5">
                              <div className={`p-2 rounded-xl shrink-0 ${
                                isPendingReview
                                  ? 'bg-amber-100 text-amber-700'
                                  : isVerified 
                                    ? 'bg-emerald-50 text-emerald-600' 
                                    : 'bg-slate-100 text-slate-600'
                              }`}>
                                <FileText className="w-4 h-4" />
                              </div>
                              <div>
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <h5 className="text-xs font-bold text-slate-900 leading-snug">{doc.name}</h5>
                                  <span className={`px-1.5 py-0.5 rounded text-[8px] font-mono font-bold uppercase tracking-wider ${
                                    doc.source === 'externally_sourced'
                                      ? 'bg-purple-100 text-purple-700 border border-purple-200'
                                      : 'bg-blue-100 text-blue-700 border border-blue-200'
                                  }`}>
                                    {doc.source === 'externally_sourced' ? '🌐 Externally Sourced' : '👤 Customer Provided'}
                                  </span>
                                </div>
                                <span className="text-[10px] text-slate-500 font-mono block mt-0.5">
                                  {doc.type || 'Corporate Document'} • {doc.size || '1.8 MB'}
                                </span>
                              </div>
                            </div>

                            <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase shrink-0 ${
                              isPendingReview
                                ? 'bg-amber-100 text-amber-800 border border-amber-300'
                                : isVerified 
                                  ? 'bg-emerald-100 text-emerald-800' 
                                  : 'bg-orange-100 text-orange-800'
                            }`}>
                              {isPendingReview ? 'PENDING REVIEW BY RM' : isVerified ? 'VERIFIED' : 'PENDING'}
                            </span>
                          </div>

                          <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                            <span className="text-[10px] font-mono text-slate-500">
                              Ingested: {doc.uploadedAt || 'Current Session'}
                            </span>

                            <div className="flex items-center gap-2">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setViewingDocument(doc);
                                }}
                                className="px-2.5 py-1.5 rounded-lg text-xs font-bold bg-blue-50 hover:bg-blue-100 text-blue-700 transition flex items-center gap-1 cursor-pointer border border-blue-200"
                                title="View document contents in secure viewer"
                              >
                                <Eye className="w-3.5 h-3.5" />
                                <span>Preview</span>
                              </button>
                              <button
                                onClick={() => handleSelectDocForOcr(doc)}
                                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                                  isSelected
                                    ? 'bg-orange-600 text-white shadow-xs'
                                    : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                                }`}
                              >
                                <Scan className="w-3.5 h-3.5" />
                                <span>{doc.ocrData && Object.keys(doc.ocrData).length > 0 ? 'Inspect / Edit OCR' : 'Run OCR'}</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* SECTION 2: ADDITIONAL DOCUMENTS REQUIRED */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <div className="flex items-center gap-2">
                    <div className="p-1 rounded-md bg-orange-50 text-orange-700 border border-orange-200">
                      <AlertCircle className="w-3.5 h-3.5" />
                    </div>
                    <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider font-mono">
                      2. Additional Documents Required
                    </h4>
                  </div>
                  <span className="text-[10px] text-orange-700 font-mono font-bold bg-orange-50 px-2 py-0.5 rounded-full border border-orange-200">
                    Mandatory Action Items
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  {[
                    {
                      name: 'Certificate of Incorporation (ACRA / COI)',
                      type: 'incorporation_certificate',
                      category: 'Core Entity Proof',
                      format: 'PDF (Digital e-Certificate)',
                      description: 'Official corporate registration proof establishing legal existence and date of incorporation.'
                    },
                    {
                      name: 'Board Resolution for Bank Account Opening',
                      type: 'board_resolution',
                      category: 'Corporate Governance',
                      format: 'PDF (Digitally Signed)',
                      description: 'Formal resolution passed by the Board authorizing opening institutional accounts and appointing signatories.'
                    },
                    {
                      name: 'Register of Ultimate Beneficial Owners (UBO)',
                      type: 'ubo_register',
                      category: 'Compliance & Equity',
                      format: 'PDF (Certified True Copy)',
                      description: 'Certified extract identifying all natural persons holding 25% or more voting rights or controlling shares.'
                    },
                    {
                      name: 'FATCA & CRS Self-Certification (Form W-8BEN-E)',
                      type: 'tax_certification',
                      category: 'Tax & Regulatory',
                      format: 'PDF (Completed Form)',
                      description: 'Statutory global tax residency declaration establishing FATCA classification and CRS reporting status.'
                    },
                    {
                      name: 'Memorandum & Articles of Association (Constitution)',
                      type: 'constitution_mna',
                      category: 'Governance & Powers',
                      format: 'PDF (Official Filing)',
                      description: 'Constitutional bylaws outlining director signing authorities and borrowing limitations.'
                    }
                  ].map((item, idx) => {
                    const existingDoc = (activeClient.documents || []).find(d => 
                      d.name.toLowerCase().includes(item.name.toLowerCase()) || 
                      item.name.toLowerCase().includes(d.name.toLowerCase()) ||
                      d.type === item.type
                    );
                    const isFulfilled = !!existingDoc;
                    const isPendingReview = existingDoc?.status === 'pending_review';
                    const isVerified = existingDoc?.status === 'verified';

                    return (
                      <div 
                        key={idx}
                        className={`p-4 rounded-2xl border transition-all space-y-3 text-left ${
                          isFulfilled
                            ? isPendingReview
                              ? 'bg-amber-50/30 border-amber-200'
                              : 'bg-emerald-50/30 border-emerald-200'
                            : 'bg-white border-slate-200 hover:border-orange-300'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-2.5">
                            <div className={`p-2 rounded-xl shrink-0 ${
                              isFulfilled
                                ? isPendingReview
                                  ? 'bg-amber-100 text-amber-700'
                                  : 'bg-emerald-100 text-emerald-700'
                                : 'bg-orange-50 text-orange-600 border border-orange-100'
                            }`}>
                              {isFulfilled ? <CheckCircle2 className="w-4 h-4" /> : <FileText className="w-4 h-4" />}
                            </div>
                            <div>
                              <h5 className="text-xs font-bold text-slate-900 leading-snug">{item.name}</h5>
                              <span className="text-[10px] text-slate-500 font-mono block mt-0.5">
                                {item.category} • {item.format}
                              </span>
                            </div>
                          </div>

                          <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase shrink-0 ${
                            isPendingReview
                              ? 'bg-amber-100 text-amber-800 border border-amber-300'
                              : isVerified 
                                ? 'bg-emerald-100 text-emerald-800' 
                                : 'bg-rose-100 text-rose-800 border border-rose-200'
                          }`}>
                            {isPendingReview ? 'PENDING RM REVIEW' : isVerified ? 'PROVIDED' : 'REQUIRED'}
                          </span>
                        </div>

                        <p className="text-[11px] text-slate-600 leading-relaxed">
                          {item.description}
                        </p>

                        <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                          <span className="text-[10px] font-mono text-slate-500">
                            {isFulfilled ? `Fulfilled by ${existingDoc.name}` : 'Upload via Copilot or click below'}
                          </span>

                          <div className="flex items-center gap-2">
                            {isFulfilled ? (
                              <button
                                onClick={() => handleSelectDocForOcr(existingDoc)}
                                className="px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-800 transition flex items-center gap-1 cursor-pointer"
                              >
                                <Scan className="w-3.5 h-3.5" />
                                Inspect OCR
                              </button>
                            ) : (
                              <button
                                onClick={() => handleUploadNewDocument(item.name, item.type)}
                                className="px-3.5 py-1.5 rounded-lg text-xs font-bold bg-orange-600 hover:bg-orange-700 text-white shadow-xs transition flex items-center gap-1.5 cursor-pointer"
                              >
                                <UploadCloud className="w-3.5 h-3.5" />
                                Upload & Run OCR
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Copilot Upload Banner Helper */}
              <div className="p-4 bg-gradient-to-r from-orange-50 via-amber-50 to-orange-50 border border-orange-200 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 text-left">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-orange-600 text-white shadow-xs">
                    <Bot className="w-5 h-5" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-900">Upload Directly via Customer Copilot</h5>
                    <p className="text-[11px] text-slate-600 mt-0.5">
                      You can drop or attach files into the Copilot chat on the right panel. OCR progress and attribute extraction will automatically display here for your confirmation.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => handleUploadNewDocument('Supplemental Corporate Mandate Document', 'supplemental_document')}
                  className="px-4 py-2 bg-white hover:bg-slate-50 border border-orange-300 text-orange-900 font-bold text-xs rounded-xl transition shrink-0 cursor-pointer shadow-xs"
                >
                  Upload Other Custom Document
                </button>
              </div>

            </div>

          </motion.div>
        )}

      </AnimatePresence>

        </div> {/* END LEFT COLUMN */}

        {/* RIGHT COLUMN: ENTITY COMPLIANCE & STATUS PANEL (xl:col-span-5) */}
        <div className="xl:col-span-5 space-y-6 lg:sticky lg:top-4">

          {/* Entity Onboarding Status Card */}
          <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-sm space-y-4 text-left">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-xs font-extrabold uppercase font-mono tracking-wider text-slate-800 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-indigo-600" /> Entity Onboarding Status
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">Real-time status of client record synchronization and governance verification.</p>
              </div>
              <span className="px-2.5 py-1 rounded text-[10px] font-mono font-bold bg-emerald-100 text-emerald-800">
                ACTIVE
              </span>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                <span className="text-[10px] font-mono text-slate-500 uppercase block font-bold">Registry Sync</span>
                <span className="text-xs font-bold text-emerald-700 flex items-center gap-1">
                  <CheckCircle className="w-3.5 h-3.5" /> Authenticated
                </span>
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                <span className="text-[10px] font-mono text-slate-500 uppercase block font-bold">Jurisdiction</span>
                <span className="text-xs font-bold text-slate-900">{activeClient.jurisdiction}</span>
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                <span className="text-[10px] font-mono text-slate-500 uppercase block font-bold">Authorized Rep</span>
                <span className="text-xs font-bold text-slate-900 truncate block">{activeClient.authorizedRepresentative.name}</span>
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                <span className="text-[10px] font-mono text-slate-500 uppercase block font-bold">Designation</span>
                <span className="text-xs font-bold text-slate-900 truncate block">{activeClient.authorizedRepresentative.role}</span>
              </div>
            </div>

            {/* High-Level Application Review Status Summary */}
            <div className="space-y-3 pt-2 border-t border-slate-100">
              <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block">
                Application Review Status
              </span>
              
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                    {getProgressPercentage() >= 100 ? (
                      <>
                        <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>Ready for Final Sign-Off</span>
                      </>
                    ) : (
                      <>
                        <Clock className="w-4 h-4 text-blue-600 shrink-0" />
                        <span>Application In Progress</span>
                      </>
                    )}
                  </span>
                  <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded uppercase ${
                    getProgressPercentage() >= 100 
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' 
                      : 'bg-blue-100 text-blue-800 border border-blue-200'
                  }`}>
                    {getProgressPercentage() >= 100 ? 'ALL ITEMS SUBMITTED' : 'ACTION PENDING'}
                  </span>
                </div>

                <p className="text-[11px] text-slate-600 leading-relaxed">
                  {getProgressPercentage() >= 100 
                    ? 'All required documents and identity checks have been submitted. Your assigned Relationship Manager is completing the final institutional sign-off.'
                    : 'Please complete your pending deliverables in Section 3 (Document Vault & Biometrics). Our compliance team reviews incoming items in real time.'}
                </p>

                <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between text-[10px] font-mono text-slate-500">
                  <span>Assigned RM: <strong>Corporate KYC Desk</strong></span>
                  <span className="text-emerald-700 font-bold">● Active Intake</span>
                </div>
              </div>
            </div>
          </div>

        </div> {/* END RIGHT COLUMN */}

      </div> {/* END MAIN TWO-COLUMN DASHBOARD LAYOUT */}

      {/* ==================================================================== */}
      {/* CATEGORY 1: THIRD-PARTY DATA MISMATCH FEEDBACK MODAL DIALOG           */}
      {/* ==================================================================== */}
      {showGovtRegistryModal && (
        <div className="fixed inset-0 bg-slate-950/85 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl p-6 max-w-lg w-full text-left space-y-5 shadow-2xl relative overflow-hidden border border-blue-500/20 text-slate-900 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-blue-100 text-blue-800 uppercase tracking-wider">
                  <MessageSquare className="w-3.5 h-3.5 text-blue-600" />
                  <span>THIRD-PARTY DATA FEEDBACK</span>
                </div>
                <h3 className="text-lg font-black text-slate-900 mt-1">Provide Feedback on Data Mismatch</h3>
                <p className="text-xs text-slate-500">
                  Provide feedback if there is any data mismatch from third-party sources or official registries (e.g. ACRA / GSTN). Your Relationship Manager will review your feedback and notes.
                </p>
              </div>
              <button
                onClick={() => setShowGovtRegistryModal(false)}
                className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-500 rounded-lg transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSendGovtRegistryUpdateRequest} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-[10px] font-mono font-bold text-slate-600 uppercase">Third-Party Data Category *</label>
                <select
                  value={govtRegistryMismatchCategory}
                  onChange={(e) => setGovtRegistryMismatchCategory(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 rounded-xl border border-slate-200 font-semibold outline-none focus:ring-1 focus:ring-blue-600"
                >
                  <option value="Official Company Name / UEN">Official Company Name / UEN</option>
                  <option value="Registered Headquarters Address">Registered Headquarters Address</option>
                  <option value="Board Directors List">Board Directors List</option>
                  <option value="Equity & Shareholders Register">Equity & Shareholders Register</option>
                  <option value="Tax / GST Registration Details">Tax / GST Registration Details</option>
                  <option value="General Registry Mismatch">General Registry Mismatch</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-mono font-bold text-slate-600 uppercase">Feedback Details & Commentary *</label>
                <textarea
                  rows={4}
                  required
                  value={govtRegistryCommentary}
                  onChange={(e) => setGovtRegistryCommentary(e.target.value)}
                  placeholder="Provide feedback detailing the third-party source mismatch (e.g., recent ACRA/MCA filing, pending director change, updated registered office address)..."
                  className="w-full p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-slate-800 outline-none focus:ring-1 focus:ring-blue-600 resize-none font-sans"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-mono font-bold text-slate-600 uppercase">Official Filing / Transaction Ref No. (Optional)</label>
                <input
                  type="text"
                  value={govtRegistryFilingRef}
                  onChange={(e) => setGovtRegistryFilingRef(e.target.value)}
                  placeholder="e.g. ACRA Ref #2026-849201 or GSTN Filing #981203"
                  className="w-full p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-slate-800 font-mono text-xs outline-none focus:ring-1 focus:ring-blue-600"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowGovtRegistryModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!govtRegistryCommentary.trim()}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5 text-blue-200" /> Submit Feedback to RM
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* CATEGORY 2: EDIT INTERNAL RECORDS MULTI-ENTITY MODAL DIALOG           */}
      {/* ==================================================================== */}
      {showEditInternalModal && (
        <div className="fixed inset-0 bg-slate-950/85 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl p-6 max-w-2xl w-full text-left space-y-5 shadow-2xl relative overflow-hidden border border-emerald-500/20 text-slate-900 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-100 text-emerald-800 uppercase tracking-wider">
                  <Edit3 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>MODIFY INTERNAL ORGANIZATION RECORDS</span>
                </div>
                <h3 className="text-lg font-black text-slate-900 mt-1">Manage Representatives, Signatories, Operators & Tax Certs</h3>
                <p className="text-xs text-slate-500">
                  Update internal records for your corporate account. You can add multiple representatives, account signatories, system operators, and tax self-certifications.
                </p>
              </div>
              <button
                onClick={() => setShowEditInternalModal(false)}
                className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-500 rounded-lg transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Sub-Tab Navigation Bar */}
            <div className="flex items-center gap-1.5 border-b border-slate-100 pb-2 overflow-x-auto">
              <button
                type="button"
                onClick={() => setEditModalActiveTab('representatives')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition shrink-0 cursor-pointer flex items-center gap-1.5 ${editModalActiveTab === 'representatives' ? 'bg-emerald-600 text-white shadow-sm' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}`}
              >
                <Users className="w-3.5 h-3.5" /> Representatives ({editRepresentatives.length})
              </button>
              <button
                type="button"
                onClick={() => setEditModalActiveTab('signatories')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition shrink-0 cursor-pointer flex items-center gap-1.5 ${editModalActiveTab === 'signatories' ? 'bg-emerald-600 text-white shadow-sm' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}`}
              >
                <UserCheck className="w-3.5 h-3.5" /> Signatories ({editSignatories.length})
              </button>
              <button
                type="button"
                onClick={() => setEditModalActiveTab('operators')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition shrink-0 cursor-pointer flex items-center gap-1.5 ${editModalActiveTab === 'operators' ? 'bg-emerald-600 text-white shadow-sm' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}`}
              >
                <KeyRound className="w-3.5 h-3.5" /> Operators ({editOperators.length})
              </button>
              <button
                type="button"
                onClick={() => setEditModalActiveTab('tax')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition shrink-0 cursor-pointer flex items-center gap-1.5 ${editModalActiveTab === 'tax' ? 'bg-emerald-600 text-white shadow-sm' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}`}
              >
                <Globe className="w-3.5 h-3.5" /> Tax Certs ({editTaxCertifications.length})
              </button>
              <button
                type="button"
                onClick={() => setEditModalActiveTab('mandates')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition shrink-0 cursor-pointer flex items-center gap-1.5 ${editModalActiveTab === 'mandates' ? 'bg-emerald-600 text-white shadow-sm' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}`}
              >
                <CreditCard className="w-3.5 h-3.5" /> Mandate & Account
              </button>
            </div>

            <form onSubmit={handleSaveInternalSettings} className="space-y-6 text-xs">
              
              {/* SECTION 1: MULTIPLE DESIGNATED REPRESENTATIVES */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <h4 className="font-bold text-slate-800 uppercase font-mono text-[10px] text-emerald-700 flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5" /> 1. Designated Corporate Representatives ({editRepresentatives.length})
                  </h4>
                  <button
                    type="button"
                    onClick={() => {
                      setEditRepresentatives([
                        ...editRepresentatives,
                        {
                          id: `rep_${Date.now()}`,
                          name: '',
                          role: 'Corporate Officer',
                          email: '',
                          phone: '',
                          isPrimary: editRepresentatives.length === 0
                        }
                      ]);
                    }}
                    className="px-2.5 py-1 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-lg font-bold text-[10px] transition flex items-center gap-1 cursor-pointer"
                  >
                    <UserPlus className="w-3 h-3" /> Add Representative
                  </button>
                </div>

                <div className="space-y-3">
                  {editRepresentatives.map((rep, idx) => (
                    <div key={rep.id} className="p-3 bg-white rounded-lg border border-slate-200 space-y-2 relative">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[10px] font-mono font-bold text-slate-400">REP #{idx + 1}</span>
                        <div className="flex items-center gap-2">
                          <label className="flex items-center gap-1 text-[10px] font-bold text-slate-600 cursor-pointer">
                            <input
                              type="radio"
                              name="primaryRep"
                              checked={rep.isPrimary}
                              onChange={() => {
                                setEditRepresentatives(editRepresentatives.map(r => ({
                                  ...r,
                                  isPrimary: r.id === rep.id
                                })));
                              }}
                              className="text-emerald-600 focus:ring-emerald-500"
                            />
                            Primary Contact
                          </label>
                          {editRepresentatives.length > 1 && (
                            <button
                              type="button"
                              onClick={() => setEditRepresentatives(editRepresentatives.filter(r => r.id !== rep.id))}
                              className="p-1 text-rose-500 hover:bg-rose-50 rounded transition cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <input
                          type="text"
                          placeholder="Representative Full Name *"
                          value={rep.name}
                          onChange={(e) => {
                            const updated = [...editRepresentatives];
                            updated[idx].name = e.target.value;
                            setEditRepresentatives(updated);
                          }}
                          className="p-2 bg-slate-50 rounded border border-slate-200 font-semibold text-xs outline-none focus:ring-1 focus:ring-emerald-500"
                        />
                        <input
                          type="text"
                          placeholder="Official Role *"
                          value={rep.role}
                          onChange={(e) => {
                            const updated = [...editRepresentatives];
                            updated[idx].role = e.target.value;
                            setEditRepresentatives(updated);
                          }}
                          className="p-2 bg-slate-50 rounded border border-slate-200 font-semibold text-xs outline-none focus:ring-1 focus:ring-emerald-500"
                        />
                        <input
                          type="email"
                          placeholder="Email Address *"
                          value={rep.email}
                          onChange={(e) => {
                            const updated = [...editRepresentatives];
                            updated[idx].email = e.target.value;
                            setEditRepresentatives(updated);
                          }}
                          className="p-2 bg-slate-50 rounded border border-slate-200 font-semibold text-xs outline-none focus:ring-1 focus:ring-emerald-500"
                        />
                        <input
                          type="text"
                          placeholder="Phone Contact *"
                          value={rep.phone}
                          onChange={(e) => {
                            const updated = [...editRepresentatives];
                            updated[idx].phone = e.target.value;
                            setEditRepresentatives(updated);
                          }}
                          className="p-2 bg-slate-50 rounded border border-slate-200 font-semibold text-xs outline-none focus:ring-1 focus:ring-emerald-500"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* SECTION 2: MULTIPLE ACCOUNT SIGNATORIES */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <h4 className="font-bold text-slate-800 uppercase font-mono text-[10px] text-emerald-700 flex items-center gap-1.5">
                    <UserCheck className="w-3.5 h-3.5" /> 2. Authorized Account Signatories ({editSignatories.length})
                  </h4>
                  <button
                    type="button"
                    onClick={() => {
                      setEditSignatories([
                        ...editSignatories,
                        {
                          id: `sig_${Date.now()}`,
                          name: '',
                          role: 'Board Director / Officer',
                          signingPower: 'Class B (Up to $500,000 USD)',
                          email: '',
                          status: 'Active'
                        }
                      ]);
                    }}
                    className="px-2.5 py-1 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-lg font-bold text-[10px] transition flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3 h-3" /> Add Signatory
                  </button>
                </div>

                <div className="space-y-3">
                  {editSignatories.map((sig, idx) => (
                    <div key={sig.id} className="p-3 bg-white rounded-lg border border-slate-200 space-y-2 relative">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[10px] font-mono font-bold text-slate-400">SIGNATORY #{idx + 1}</span>
                        {editSignatories.length > 1 && (
                          <button
                            type="button"
                            onClick={() => setEditSignatories(editSignatories.filter(s => s.id !== sig.id))}
                            className="p-1 text-rose-500 hover:bg-rose-50 rounded transition cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        <input
                          type="text"
                          placeholder="Signatory Name *"
                          value={sig.name}
                          onChange={(e) => {
                            const updated = [...editSignatories];
                            updated[idx].name = e.target.value;
                            setEditSignatories(updated);
                          }}
                          className="p-2 bg-slate-50 rounded border border-slate-200 font-semibold text-xs outline-none focus:ring-1 focus:ring-emerald-500"
                        />
                        <input
                          type="text"
                          placeholder="Official Role *"
                          value={sig.role}
                          onChange={(e) => {
                            const updated = [...editSignatories];
                            updated[idx].role = e.target.value;
                            setEditSignatories(updated);
                          }}
                          className="p-2 bg-slate-50 rounded border border-slate-200 font-semibold text-xs outline-none focus:ring-1 focus:ring-emerald-500"
                        />
                        <select
                          value={sig.signingPower}
                          onChange={(e) => {
                            const updated = [...editSignatories];
                            updated[idx].signingPower = e.target.value;
                            setEditSignatories(updated);
                          }}
                          className="p-2 bg-slate-50 rounded border border-slate-200 font-semibold text-xs outline-none focus:ring-1 focus:ring-emerald-500"
                        >
                          <option value="Class A (Unlimited)">Class A (Unlimited)</option>
                          <option value="Class B (Up to $500,000 USD)">Class B (Up to $500k)</option>
                          <option value="Class C (Up to $100,000 USD)">Class C (Up to $100k)</option>
                          <option value="Joint Signatory Requirement">Joint Signatory</option>
                        </select>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <input
                          type="email"
                          placeholder="Signatory Email *"
                          value={sig.email}
                          onChange={(e) => {
                            const updated = [...editSignatories];
                            updated[idx].email = e.target.value;
                            setEditSignatories(updated);
                          }}
                          className="p-2 bg-slate-50 rounded border border-slate-200 font-semibold text-xs outline-none focus:ring-1 focus:ring-emerald-500"
                        />
                        <select
                          value={sig.status}
                          onChange={(e) => {
                            const updated = [...editSignatories];
                            updated[idx].status = e.target.value as 'Active' | 'Pending Verification' | 'Inactive';
                            setEditSignatories(updated);
                          }}
                          className="p-2 bg-slate-50 rounded border border-slate-200 font-semibold text-xs outline-none focus:ring-1 focus:ring-emerald-500"
                        >
                          <option value="Active">Active</option>
                          <option value="Pending Verification">Pending Verification</option>
                          <option value="Inactive">Inactive</option>
                        </select>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* SECTION 3: MULTIPLE ACCOUNT OPERATORS / SYSTEM USERS */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <h4 className="font-bold text-slate-800 uppercase font-mono text-[10px] text-emerald-700 flex items-center gap-1.5">
                    <KeyRound className="w-3.5 h-3.5" /> 3. Account Operators & Portal Users ({editOperators.length})
                  </h4>
                  <button
                    type="button"
                    onClick={() => {
                      setEditOperators([
                        ...editOperators,
                        {
                          id: `op_${Date.now()}`,
                          name: '',
                          role: 'Finance User',
                          accessLevel: 'Payment Drafter (Maker)',
                          email: ''
                        }
                      ]);
                    }}
                    className="px-2.5 py-1 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-lg font-bold text-[10px] transition flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3 h-3" /> Add Operator
                  </button>
                </div>

                <div className="space-y-3">
                  {editOperators.map((op, idx) => (
                    <div key={op.id} className="p-3 bg-white rounded-lg border border-slate-200 space-y-2 relative">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[10px] font-mono font-bold text-slate-400">OPERATOR #{idx + 1}</span>
                        {editOperators.length > 1 && (
                          <button
                            type="button"
                            onClick={() => setEditOperators(editOperators.filter(o => o.id !== op.id))}
                            className="p-1 text-rose-500 hover:bg-rose-50 rounded transition cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        <input
                          type="text"
                          placeholder="User Full Name *"
                          value={op.name}
                          onChange={(e) => {
                            const updated = [...editOperators];
                            updated[idx].name = e.target.value;
                            setEditOperators(updated);
                          }}
                          className="p-2 bg-slate-50 rounded border border-slate-200 font-semibold text-xs outline-none focus:ring-1 focus:ring-emerald-500"
                        />
                        <input
                          type="text"
                          placeholder="Company Role *"
                          value={op.role}
                          onChange={(e) => {
                            const updated = [...editOperators];
                            updated[idx].role = e.target.value;
                            setEditOperators(updated);
                          }}
                          className="p-2 bg-slate-50 rounded border border-slate-200 font-semibold text-xs outline-none focus:ring-1 focus:ring-emerald-500"
                        />
                        <select
                          value={op.accessLevel}
                          onChange={(e) => {
                            const updated = [...editOperators];
                            updated[idx].accessLevel = e.target.value as any;
                            setEditOperators(updated);
                          }}
                          className="p-2 bg-slate-50 rounded border border-slate-200 font-semibold text-xs outline-none focus:ring-1 focus:ring-emerald-500"
                        >
                          <option value="Full Admin">Full Admin</option>
                          <option value="Payment Drafter (Maker)">Payment Drafter (Maker)</option>
                          <option value="Payment Approver (Checker)">Payment Approver (Checker)</option>
                          <option value="View Only">View Only</option>
                        </select>
                      </div>
                      <div>
                        <input
                          type="email"
                          placeholder="Operator Portal Email *"
                          value={op.email}
                          onChange={(e) => {
                            const updated = [...editOperators];
                            updated[idx].email = e.target.value;
                            setEditOperators(updated);
                          }}
                          className="w-full p-2 bg-slate-50 rounded border border-slate-200 font-semibold text-xs outline-none focus:ring-1 focus:ring-emerald-500"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* SECTION 4: MULTIPLE TAX SELF-CERTIFICATIONS (FATCA / CRS) */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <h4 className="font-bold text-slate-800 uppercase font-mono text-[10px] text-emerald-700 flex items-center gap-1.5">
                    <Globe className="w-3.5 h-3.5" /> 4. Tax Self-Certifications FATCA / CRS ({editTaxCertifications.length})
                  </h4>
                  <button
                    type="button"
                    onClick={() => {
                      setEditTaxCertifications([
                        ...editTaxCertifications,
                        {
                          id: `tax_${Date.now()}`,
                          taxResidencyCountry: 'Singapore',
                          tinReferenceNumber: '',
                          fatcaClassification: 'Active NFFE',
                          crsStatus: 'Reportable Entity',
                          isPrimary: false
                        }
                      ]);
                    }}
                    className="px-2.5 py-1 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-lg font-bold text-[10px] transition flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3 h-3" /> Add Tax Self-Cert
                  </button>
                </div>

                <div className="space-y-3">
                  {editTaxCertifications.map((tax, idx) => (
                    <div key={tax.id} className="p-3 bg-white rounded-lg border border-slate-200 space-y-2 relative">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[10px] font-mono font-bold text-slate-400">TAX CERT #{idx + 1}</span>
                        {editTaxCertifications.length > 1 && (
                          <button
                            type="button"
                            onClick={() => setEditTaxCertifications(editTaxCertifications.filter(t => t.id !== tax.id))}
                            className="p-1 text-rose-500 hover:bg-rose-50 rounded transition cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <input
                          type="text"
                          placeholder="Tax Residency Jurisdiction *"
                          value={tax.taxResidencyCountry}
                          onChange={(e) => {
                            const updated = [...editTaxCertifications];
                            updated[idx].taxResidencyCountry = e.target.value;
                            setEditTaxCertifications(updated);
                          }}
                          className="p-2 bg-slate-50 rounded border border-slate-200 font-semibold text-xs outline-none focus:ring-1 focus:ring-emerald-500"
                        />
                        <input
                          type="text"
                          placeholder="TIN / Tax Registration Ref No. *"
                          value={tax.tinReferenceNumber}
                          onChange={(e) => {
                            const updated = [...editTaxCertifications];
                            updated[idx].tinReferenceNumber = e.target.value;
                            setEditTaxCertifications(updated);
                          }}
                          className="p-2 bg-slate-50 rounded border border-slate-200 font-mono font-semibold text-xs outline-none focus:ring-1 focus:ring-emerald-500"
                        />
                        <input
                          type="text"
                          placeholder="FATCA Classification *"
                          value={tax.fatcaClassification}
                          onChange={(e) => {
                            const updated = [...editTaxCertifications];
                            updated[idx].fatcaClassification = e.target.value;
                            setEditTaxCertifications(updated);
                          }}
                          className="p-2 bg-slate-50 rounded border border-slate-200 font-semibold text-xs outline-none focus:ring-1 focus:ring-emerald-500"
                        />
                        <input
                          type="text"
                          placeholder="CRS Status *"
                          value={tax.crsStatus}
                          onChange={(e) => {
                            const updated = [...editTaxCertifications];
                            updated[idx].crsStatus = e.target.value;
                            setEditTaxCertifications(updated);
                          }}
                          className="p-2 bg-slate-50 rounded border border-slate-200 font-semibold text-xs outline-none focus:ring-1 focus:ring-emerald-500"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* SECTION 5: ACCOUNT OPERATING PREFERENCES */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                <h4 className="font-bold text-slate-800 uppercase font-mono text-[10px] text-emerald-700 flex items-center gap-1.5">
                  <CreditCard className="w-3.5 h-3.5" /> 5. Account Facility & Mandate Parameters
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold text-slate-500 uppercase">Primary Account Facility</label>
                    <select
                      value={editAccountType}
                      onChange={(e) => setEditAccountType(e.target.value)}
                      className="w-full p-2 bg-white rounded-lg border border-slate-200 font-semibold outline-none focus:ring-1 focus:ring-emerald-500"
                    >
                      <option value="Corporate Multi-Currency CASA">Corporate Multi-Currency CASA</option>
                      <option value="Treasury & Trade Liquidity Account">Treasury & Trade Liquidity Account</option>
                      <option value="Escrow & Capital Holding Account">Escrow & Capital Holding Account</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold text-slate-500 uppercase">Settlement Currency</label>
                    <select
                      value={editPrimaryCurrency}
                      onChange={(e) => setEditPrimaryCurrency(e.target.value)}
                      className="w-full p-2 bg-white rounded-lg border border-slate-200 font-semibold outline-none focus:ring-1 focus:ring-emerald-500"
                    >
                      <option value="SGD">SGD (Singapore Dollar)</option>
                      <option value="USD">USD (US Dollar)</option>
                      <option value="EUR">EUR (Euro)</option>
                      <option value="INR">INR (Indian Rupee)</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold text-slate-500 uppercase">Est. Monthly Transaction Volume</label>
                    <select
                      value={editEstMonthlyVolume}
                      onChange={(e) => setEditEstMonthlyVolume(e.target.value)}
                      className="w-full p-2 bg-white rounded-lg border border-slate-200 font-semibold outline-none focus:ring-1 focus:ring-emerald-500"
                    >
                      <option value="<$100,000 USD">&lt;$100,000 USD</option>
                      <option value="$100,000 - $500,000 USD">$100,000 - $500,000 USD</option>
                      <option value="$250,000 - $1,000,000 USD">$250,000 - $1,000,000 USD</option>
                      <option value=">$1,000,000 USD">&gt;$1,000,000 USD</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold text-slate-500 uppercase">Signing Mandate Rule</label>
                    <select
                      value={editOperatingMandate}
                      onChange={(e) => setEditOperatingMandate(e.target.value)}
                      className="w-full p-2 bg-white rounded-lg border border-slate-200 font-semibold outline-none focus:ring-1 focus:ring-emerald-500"
                    >
                      <option value="Single Authorized Signatory">Single Authorized Signatory</option>
                      <option value="Joint Signatories - Any Two Directors">Joint Signatories - Any Two Directors</option>
                      <option value="Board Authorized Power of Attorney">Board Authorized Power of Attorney</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Modal Action Buttons */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowEditInternalModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-lg transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Save className="w-4 h-4" /> Save Internal System Updates
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* SINGPASS MYINFO LIGHTBOX MODAL */}
      {showSingpassModal && (
        <div className="fixed inset-0 bg-slate-950/85 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full text-left space-y-5 shadow-2xl relative overflow-hidden border border-red-500/20 text-slate-900">
            {singpassStep === 'intro' && (
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <div className="h-10 w-10 rounded-lg bg-red-600 flex items-center justify-center text-white font-bold text-lg">
                    S
                  </div>
                  <div>
                    <h3 className="font-extrabold text-sm tracking-tight text-red-600">singpass</h3>
                    <p className="text-[10px] text-slate-500 font-mono">SINGAPORE CITIZEN IDENTITY SYSTEM</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="text-xs font-black text-slate-800">Onboard.ai Onboarding Gateway Request</h4>
                  <p className="text-[11px] text-slate-600 leading-normal">
                    Onboard.ai is requesting verification of corporate representative identity and Accounting & Corporate Regulatory Authority (ACRA) properties.
                  </p>
                </div>

                <div className="p-3 bg-slate-50 rounded-lg space-y-1.5 text-[10px] text-slate-500">
                  <p className="font-semibold text-slate-700">Data variables to be retrieved:</p>
                  <p>• Company Entity Name & UEN Registration Number</p>
                  <p>• Registered Headquarter Address</p>
                  <p>• Directors & Ultimate Shareholders register</p>
                  <p>• Paid Up Capital & Constitution</p>
                </div>

                <button
                  onClick={triggerSingpassSimulate}
                  className="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg text-xs tracking-wider uppercase transition flex items-center justify-center gap-1 cursor-pointer"
                >
                  Agree & Consent via Singpass MyInfo
                </button>
              </div>
            )}

            {singpassStep === 'consent' && (
              <div className="py-6 text-center space-y-4">
                <div className="mx-auto h-12 w-12 rounded-xl bg-red-600/10 text-red-600 flex items-center justify-center animate-spin">
                  <RefreshCw className="w-6 h-6 text-red-600" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-widest font-mono">Retrieving ACRA records...</h4>
                  <p className="text-[11px] text-slate-500">Establishing zero-trust handshake link with Singapore Government MyInfo Core API gateway...</p>
                </div>
              </div>
            )}

            {singpassStep === 'success' && (
              <div className="py-6 text-center space-y-4">
                <div className="mx-auto h-12 w-12 rounded-full bg-emerald-500/15 text-emerald-600 flex items-center justify-center">
                  <CheckCircle className="w-8 h-8 text-emerald-600" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-widest font-mono">Verification Success</h4>
                  <p className="text-[11px] text-slate-500">Onboard.ai corporate profile updated from official ACRA register.</p>
                </div>
                <button
                  onClick={() => setShowSingpassModal(false)}
                  className="px-6 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded text-xs transition cursor-pointer"
                >
                  Proceed to Portal
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* PAN & GSTIN MODAL */}
      {showPanGstModal && (
        <div className="fixed inset-0 bg-slate-950/85 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full text-left space-y-5 shadow-2xl relative overflow-hidden border border-blue-500/20 text-slate-900">
            <div className="flex items-center gap-2">
              <div className="h-8 w-12 rounded bg-amber-500/10 text-amber-500 flex items-center justify-center font-bold text-[10px]">
                🇮🇳 GSTN
              </div>
              <div>
                <h3 className="font-extrabold text-sm tracking-tight text-indigo-900">NSDL Tax & GSTN Registry</h3>
                <p className="text-[9px] text-slate-500 font-mono">Government of India Tax Identification Hub</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-1">
                <label className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Corporate PAN Card Number *</label>
                <input
                  type="text"
                  maxLength={10}
                  value={panNumber}
                  onChange={(e) => setPanNumber(e.target.value.toUpperCase())}
                  placeholder="e.g. ABCDE1234F"
                  className="w-full rounded-lg border border-slate-200 p-2.5 text-xs outline-none focus:ring-1 focus:ring-indigo-600 text-slate-800 font-bold uppercase tracking-widest text-center"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Corporate GSTIN Registration Number *</label>
                <input
                  type="text"
                  maxLength={15}
                  value={gstinNumber}
                  onChange={(e) => setGstinNumber(e.target.value.toUpperCase())}
                  placeholder="e.g. 29ABCDE1234F1Z5"
                  className="w-full rounded-lg border border-slate-200 p-2.5 text-xs outline-none focus:ring-1 focus:ring-indigo-600 text-slate-800 font-bold uppercase tracking-widest text-center"
                />
              </div>

              <button
                onClick={triggerGstinPanSimulate}
                disabled={isLinkingPanGst || !panNumber || !gstinNumber}
                className="w-full py-2.5 bg-indigo-900 hover:bg-indigo-950 text-white font-bold rounded-lg text-xs tracking-wider uppercase transition cursor-pointer disabled:opacity-50"
              >
                {isLinkingPanGst ? 'Connecting Tax Gateway...' : 'Link Corporate Accounts'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* REACT DOCUMENT VIEWER MODAL (CUSTOMER ACCESS - READ ONLY, NO DOWNLOAD) */}
      <DocumentViewerModal
        document={viewingDocument}
        isOpen={Boolean(viewingDocument)}
        onClose={() => setViewingDocument(null)}
        readOnly={true}
        userRole="customer"
      />

    </div>
  );
}
