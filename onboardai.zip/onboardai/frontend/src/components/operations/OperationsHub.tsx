import React, { useState, useMemo } from 'react';
import { 
  ClipboardList, 
  AlertTriangle, 
  ShieldAlert, 
  FileText, 
  CheckCircle2, 
  Clock, 
  Search, 
  ArrowRight, 
  Send, 
  Users, 
  RefreshCw, 
  Bot, 
  XCircle, 
  Info, 
  Lock, 
  Database, 
  Award, 
  Terminal, 
  Brain, 
  MessageSquare, 
  Sparkles, 
  Download, 
  Layers, 
  Scale, 
  ChevronRight, 
  ChevronDown, 
  Zap, 
  CheckSquare, 
  Square, 
  Eye, 
  BookOpen, 
  HelpCircle,
  FileCheck,
  Building2,
  AlertOctagon,
  TrendingUp,
  RotateCcw,
  ShieldCheck,
  UserCheck,
  Sliders,
  Filter
} from 'lucide-react';
import { ClientProfile, SystemNotification } from '../../types';

// Exception Classification Types
export type ExceptionType = 
  | 'SCREENING_HIT_SANCTIONS'
  | 'SCREENING_HIT_PEP'
  | 'SCREENING_HIT_ADVERSE_MEDIA'
  | 'DOCUMENT_EXTRACTION_FAILURE'
  | 'LOW_CONFIDENCE_STRUCTURE'
  | 'MANUAL_REQUIRED_JURISDICTION'
  | 'QUALITY_AUDIT_SAMPLE'
  | 'OVERRIDE_REQUEST_RM'
  | 'EXPIRING_DOCUMENT';

export interface OpsExceptionCase {
  id: string;
  clientId: string;
  entityName: string;
  entityType: string;
  jurisdiction: string;
  exceptionType: ExceptionType;
  exceptionReason: string;
  escalationSentence: string;
  rmName: string;
  ageInQueue: string;
  timeInQueueMinutes: number;
  deadline: string;
  riskRating: 'Tier 1 Low' | 'Tier 2 Medium' | 'Tier 3 High' | 'Tier 4 Very High EDD';
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  agentConfidence: number; // e.g. 58% or 94%
  agentReasoningChain: string[];
  tier4PreScreenDone?: boolean;
  batchId?: string;
  status: 'PENDING_OPS' | 'RETURNED_TO_AGENT' | 'OPS_VERIFIED' | 'ESCALATED_COMPLIANCE' | 'REJECTED';
  extractedData: Record<string, string>;
  rawSourceData: Record<string, string>;
  screeningDetails?: {
    watchlistName: string;
    lastUpdated: string;
    entryText: string;
    matchBasis: string;
    adverseMediaScore?: {
      sourceCredibility: number;
      nameMatchStrength: number;
      recency: string;
      allegationSeverity: string;
    };
  };
  disposition?: {
    category: 'NOT_A_MATCH' | 'MATCH_CLEARED' | 'MATCH_ESCALATE' | 'MATCH_REJECT_FILE' | 'PENDING_INFO';
    narrative: string;
    disposedBy: string;
    disposedAt: string;
  };
  overrideDetails?: {
    isWithinMandate: boolean;
    policyRequirement: string;
    acceptedAlternative: string;
    riskMitigant: string;
    reviewTrigger: string;
    requiresSecondApprover: boolean;
    firstApprover?: string;
    secondApprover?: string;
  };
  gapReport?: {
    status: 'COMPLETE' | 'GAP_COVERED' | 'GAP_OPEN';
    items: { element: string; verified: boolean; exceptionApproved?: boolean; notes?: string }[];
  };
}

// Initial Mock Ops Exceptions Machine-Ordered
const INITIAL_EXCEPTIONS: OpsExceptionCase[] = [
  {
    id: 'EXC-801',
    clientId: 'c1',
    entityName: 'Apex Capital Holdings Pte Ltd',
    entityType: 'Private Limited Company',
    jurisdiction: 'Singapore (SG)',
    exceptionType: 'SCREENING_HIT_SANCTIONS',
    exceptionReason: 'Potential OFAC/EU secondary sanctions proximity match on minority shareholder entity.',
    escalationSentence: 'Agent stopped autonomous clearing at 58% confidence due to partial name match on sanctions target "Apex Maritime Intermediary Corp".',
    rmName: 'Sarah Jenkins',
    ageInQueue: '1h 15m',
    timeInQueueMinutes: 75,
    deadline: '2 hours remaining (SLA Priority 1)',
    riskRating: 'Tier 4 Very High EDD',
    severity: 'Critical',
    agentConfidence: 58,
    tier4PreScreenDone: true,
    agentReasoningChain: [
      'Identified 12.5% indirect ownership trace to "Apex Maritime Intermediary Corp".',
      'Queried OFAC Specially Designated Nationals List via MCP tool.',
      'Name fuzzy match ratio: 82%. DOB/Address missing in registry payload.',
      'Stopped short of auto-disposition per Mandate Rule #204 (Sanctions proximity requires human sign-off).'
    ],
    status: 'PENDING_OPS',
    extractedData: {
      'Entity Legal Name': 'Apex Capital Holdings Pte Ltd',
      'Registration UEN': '201938102K',
      'Shareholder Match': 'Apex Maritime Intermediary Corp (12.5%)',
      'Sanctions Alert ID': 'OFAC-SDN-99812'
    },
    rawSourceData: {
      'ACRA Registry Text': 'Shareholder 3: Apex Maritime Intermediary Corp (Address: Tortola, BVI)',
      'OFAC Watchlist Record': 'Apex Maritime Corp (Sanctioned 2023-11-14; Sectoral Sanctions List)'
    },
    screeningDetails: {
      watchlistName: 'OFAC SDN / EU Consolidated Sanctions List',
      lastUpdated: '2026-08-01',
      entryText: 'Apex Maritime Corp | Alias: Apex Maritime Intermediary | BVI Registration #99182',
      matchBasis: 'Name fuzzy similarity (82%) + Corporate Directorship linkage'
    },
    gapReport: {
      status: 'GAP_COVERED',
      items: [
        { element: 'Certificate of Incorporation', verified: true },
        { element: 'UBO Ownership Declaration', verified: true },
        { element: 'Sanctions Clearance Audit', verified: false, exceptionApproved: true, notes: 'Awaiting Ops disposition' }
      ]
    }
  },
  {
    id: 'EXC-802',
    clientId: 'c2',
    entityName: 'Horizon Fintech Global Ltd',
    entityType: 'Fund/Holding Entity',
    jurisdiction: 'Hong Kong (HK)',
    exceptionType: 'MANUAL_REQUIRED_JURISDICTION',
    exceptionReason: 'Hong Kong Monetary Authority (HKMA) AML Mandate requires human verifier sign-off for offshore holding structures.',
    escalationSentence: 'Agent completed 94% of extraction cleanly, but jurisdiction policy requires mandatory Ops verifier review prior to Compliance handoff.',
    rmName: 'David Lee',
    ageInQueue: '3h 40m',
    timeInQueueMinutes: 220,
    deadline: '5 hours remaining',
    riskRating: 'Tier 3 High',
    severity: 'High',
    agentConfidence: 94,
    agentReasoningChain: [
      'Successfully extracted HK Companies Registry profile (Reg #309812).',
      'Verified 3 Directors and 2 UBOs via passport OCR.',
      'Matched HKMA Cross-Border Rule #402: Human verification required for non-resident UBOs.'
    ],
    status: 'PENDING_OPS',
    extractedData: {
      'Entity Name': 'Horizon Fintech Global Ltd',
      'HK CR Number': '309812',
      'UBO 1': 'Michael Chang (60% Ownership, Passport: HK991827)',
      'UBO 2': 'Elena Rostova (40% Ownership, Passport: P4491029)'
    },
    rawSourceData: {
      'HK Companies Registry Scan': 'CR No. 309812 | Incorporated: 2021-04-12 | Share Capital: HKD 10,000,000',
      'Passport OCR Payload': 'Michael Chang | Expiry: 2030-01-15 | Verification Score: 99.2%'
    },
    gapReport: {
      status: 'COMPLETE',
      items: [
        { element: 'HK Registry Search', verified: true },
        { element: 'UBO Identification', verified: true },
        { element: 'HKMA Mandatory Verifier Sign-off', verified: false }
      ]
    }
  },
  {
    id: 'EXC-803',
    clientId: 'c3',
    entityName: 'Nesta Trading Solutions Private Limited',
    entityType: 'Private Limited Entity',
    jurisdiction: 'India (IN)',
    exceptionType: 'DOCUMENT_EXTRACTION_FAILURE',
    exceptionReason: 'Board Resolution scan contained low-contrast stamp overlay; auto-OCR OCR failed on signatory designation field.',
    escalationSentence: 'Agent extracted company name and PAN successfully, but flagged low optical confidence (42%) on authorized signatory signatures.',
    rmName: 'Rajesh Sharma',
    ageInQueue: '4h 10m',
    timeInQueueMinutes: 250,
    deadline: '8 hours remaining',
    riskRating: 'Tier 2 Medium',
    severity: 'Medium',
    agentConfidence: 62,
    agentReasoningChain: [
      'Processed Board Resolution PDF (3 pages).',
      'Page 2 resolution text legible, but signature block obscured by official seal.',
      'Agent Confidence score 62% is below the 85% requirement for auto-verification.'
    ],
    status: 'PENDING_OPS',
    extractedData: {
      'Company Name': 'Nesta Trading Solutions Private Limited',
      'CIN': 'U72900KA2020PTC134012',
      'Signatory 1': 'Aarav Patel (Designation: Unclear - Needs Ops Manual Correction)'
    },
    rawSourceData: {
      'Board Resolution Document': 'Page 2: RESOLVED THAT Aarav Patel, Managing Director, be authorized... [Seal overlay obscuring line 14]'
    },
    gapReport: {
      status: 'GAP_OPEN',
      items: [
        { element: 'Certificate of Incorporation', verified: true },
        { element: 'Board Resolution Signatory Confirmation', verified: false, notes: 'Awaiting manual field confirmation' }
      ]
    }
  },
  {
    id: 'EXC-804',
    clientId: 'c4',
    entityName: 'Vanguard Energy Logistics LLC',
    entityType: 'LLC / Operating Entity',
    jurisdiction: 'Dubai / UAE (AE)',
    exceptionType: 'SCREENING_HIT_ADVERSE_MEDIA',
    exceptionReason: 'Adverse media news hit flagged regarding past environmental regulatory fine in 2021.',
    escalationSentence: 'Agent flagged news article on Reuters mentioning $50k administrative settlement; requires Ops qualitative narrative disposition.',
    rmName: 'Amanda Vance',
    ageInQueue: '6h 05m',
    timeInQueueMinutes: 365,
    deadline: '12 hours remaining',
    riskRating: 'Tier 3 High',
    severity: 'Medium',
    agentConfidence: 78,
    agentReasoningChain: [
      'Scanned Web News Corpus via Tavily/Serp API.',
      'Identified Reuters article (2021-08-14) covering UAE Port Authority fine.',
      'Agent Adverse Media Score: Credibility 95%, Severity: Low/Administrative, Recency: 5 Years Ago.'
    ],
    status: 'PENDING_OPS',
    extractedData: {
      'Target Company': 'Vanguard Energy Logistics LLC',
      'Media Source': 'Reuters Business News',
      'Topic': 'UAE Port Authority Civil Settlement ($50,000 USD)'
    },
    rawSourceData: {
      'News Article Text': 'DUBAI - Vanguard Energy Logistics agreed to pay a AED 180,000 administrative fine regarding delayed berth discharge reporting in Q2 2021. Case resolved with no criminal findings.'
    },
    screeningDetails: {
      watchlistName: 'Global News & Regulatory Enforcement Index',
      lastUpdated: '2021-08-14',
      entryText: 'Vanguard Energy Logistics UAE Fine Settlement 2021',
      matchBasis: 'Entity Name Exact Match',
      adverseMediaScore: {
        sourceCredibility: 95,
        nameMatchStrength: 100,
        recency: '5 Years Ago (Historical)',
        allegationSeverity: 'Low (Civil Administrative Fine)'
      }
    },
    gapReport: {
      status: 'GAP_COVERED',
      items: [
        { element: 'Incorporation Vault Documents', verified: true },
        { element: 'Adverse Media Disposition Narrative', verified: false, exceptionApproved: true, notes: 'Requires narrative disposition' }
      ]
    }
  },
  {
    id: 'EXC-805',
    clientId: 'c5',
    entityName: 'BlueSky BioTech Ventures AG',
    entityType: 'Joint Venture',
    jurisdiction: 'Switzerland (CH)',
    exceptionType: 'QUALITY_AUDIT_SAMPLE',
    exceptionReason: 'System Random Quality Audit (5% Sample): Agent auto-approved standard onboarding; Ops post-hoc verification check.',
    escalationSentence: 'Automated Agent approved this case with 98% confidence. Case routed for random Ops quality calibration.',
    rmName: 'Sarah Jenkins',
    ageInQueue: '12h 30m',
    timeInQueueMinutes: 750,
    deadline: 'Post-Hoc Audit (No SLA Breach)',
    riskRating: 'Tier 1 Low',
    severity: 'Low',
    agentConfidence: 98,
    agentReasoningChain: [
      'Validated Commercial Registry of Canton Zurich.',
      'Verified 100% Swiss Re ownership structure.',
      'All sanctions & PEP screens returned 0 hits.',
      'Auto-approved by KybAgent v3.2.'
    ],
    status: 'PENDING_OPS',
    extractedData: {
      'Company Name': 'BlueSky BioTech Ventures AG',
      'UID': 'CHE-109.812.332',
      'Parent Entity': 'Swiss Re Investments (100%)'
    },
    rawSourceData: {
      'Zefix Swiss Registry': 'CHE-109.812.332 Active Standing. Fully compliant.'
    },
    gapReport: {
      status: 'COMPLETE',
      items: [
        { element: 'Swiss Registry Record', verified: true },
        { element: 'PEP / Sanctions Clearance', verified: true }
      ]
    }
  }
];

export function OperationsHub({
  clients,
  onSelectClient,
  onNavigateToWorkspace
}: {
  clients: ClientProfile[];
  onSelectClient: (id: string) => void;
  onNavigateToWorkspace: () => void;
}) {
  const [exceptions, setExceptions] = useState<OpsExceptionCase[]>(INITIAL_EXCEPTIONS);
  const [selectedCaseId, setSelectedCaseId] = useState<string>('EXC-801');
  const [activeModule, setActiveModule] = useState<'queue' | 'review' | 'screening' | 'overrides' | 'handoff' | 'quality' | 'compliance_status' | 'prompt_analytics' | 'exam_pack'>('queue');
  const [selectedBatchIds, setSelectedBatchIds] = useState<string[]>([]);
  const [returnInstructions, setReturnInstructions] = useState<string>('');
  const [showReturnModal, setShowReturnModal] = useState<boolean>(false);
  const [showTwoPersonModal, setShowTwoPersonModal] = useState<boolean>(false);
  const [twoPersonNote, setTwoPersonNote] = useState<string>('');

  // Screening Disposition Form
  const [dispCategory, setDispCategory] = useState<'NOT_A_MATCH' | 'MATCH_CLEARED' | 'MATCH_ESCALATE' | 'MATCH_REJECT_FILE' | 'PENDING_INFO'>('NOT_A_MATCH');
  const [dispNarrative, setDispNarrative] = useState<string>('');

  // Override Form
  const [overrideForm, setOverrideForm] = useState({
    policyReq: 'Certified Board Resolution required within 30 days',
    acceptedAlt: 'Unnotarized Board Resolution accompanied by RM Email confirmation from MD',
    riskMitigant: 'Low transaction limit ($50k) imposed until certified copy delivered at 90-day review',
    reviewTrigger: '90-Day Post-Onboarding Perpetual KYC Check',
    authority: 'Ops Level 2 Senior Officer'
  });

  // Prompt Analytics State
  const [promptQuery, setPromptQuery] = useState<string>('');
  const [analyticsChat, setAnalyticsChat] = useState<{ role: 'user' | 'assistant'; content: string; reasoning?: string }[]>([
    {
      role: 'assistant',
      content: 'Hello Operations Officer. I am monitoring your workspace. Here is today’s operational pulse:\n\n• Queue Depth: 5 active cases (2 Priority SLA, 1 Tier 4 EDD Pre-screen).\n• Compliance Returns Today: 0 returned files.\n• Agent Override Rate: 4.2% over last 30 days.\n\nHow can I analyze your exception pipeline today?',
      reasoning: 'System initialized workspace state and aggregated real-time metrics across Exception Queue, Compliance returns, and agent confidence scores.'
    }
  ]);
  const [isAnalyzingPrompt, setIsAnalyzingPrompt] = useState<boolean>(false);

  // Exam Pack State
  const [examPackGenerated, setExamPackGenerated] = useState<boolean>(false);

  // Selected Active Case
  const activeCase = useMemo(() => {
    return exceptions.find(e => e.id === selectedCaseId) || exceptions[0];
  }, [exceptions, selectedCaseId]);

  // Priority Queue Machine Sorting: regulatory deadline > risk rating > severity > time in queue
  const sortedExceptions = useMemo(() => {
    return [...exceptions].sort((a, b) => {
      // Priority ordering logic
      const severityMap = { Critical: 4, High: 3, Medium: 2, Low: 1 };
      const riskMap = { 'Tier 4 Very High EDD': 4, 'Tier 3 High': 3, 'Tier 2 Medium': 2, 'Tier 1 Low': 1 };
      
      const riskDiff = riskMap[b.riskRating] - riskMap[a.riskRating];
      if (riskDiff !== 0) return riskDiff;

      const sevDiff = severityMap[b.severity] - severityMap[a.severity];
      if (sevDiff !== 0) return sevDiff;

      return b.timeInQueueMinutes - a.timeInQueueMinutes;
    });
  }, [exceptions]);

  // Handlers
  const handleSelectCase = (caseId: string) => {
    setSelectedCaseId(caseId);
    setSelectedBatchIds([]);
  };

  const handleReturnToAgent = () => {
    if (!returnInstructions.trim()) return;
    setExceptions(prev => prev.map(c => {
      if (c.id === activeCase.id) {
        return {
          ...c,
          status: 'RETURNED_TO_AGENT',
          escalationSentence: `Pushed back to Agent with instruction: "${returnInstructions}"`
        };
      }
      return c;
    }));
    setShowReturnModal(false);
    setReturnInstructions('');
  };

  const handleBatchSelectToggle = (id: string) => {
    setSelectedBatchIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const handleApplyBatchDisposition = (category: 'NOT_A_MATCH' | 'MATCH_CLEARED' | 'MATCH_ESCALATE') => {
    setExceptions(prev => prev.map(c => {
      if (selectedBatchIds.includes(c.id)) {
        return {
          ...c,
          status: category === 'MATCH_ESCALATE' ? 'ESCALATED_COMPLIANCE' : 'OPS_VERIFIED',
          disposition: {
            category,
            narrative: `Batch Disposition applied to ${selectedBatchIds.length} cases based on identical exception pattern audit.`,
            disposedBy: 'Ops Officer (Batch Action)',
            disposedAt: new Date().toISOString()
          }
        };
      }
      return c;
    }));
    setSelectedBatchIds([]);
  };

  const handleSaveDisposition = () => {
    setExceptions(prev => prev.map(c => {
      if (c.id === activeCase.id) {
        return {
          ...c,
          status: dispCategory === 'MATCH_ESCALATE' ? 'ESCALATED_COMPLIANCE' : dispCategory === 'MATCH_REJECT_FILE' ? 'REJECTED' : 'OPS_VERIFIED',
          disposition: {
            category: dispCategory,
            narrative: dispNarrative || 'Standard verification completed per Ops mandate guidelines.',
            disposedBy: 'Alex Rivera (Ops Verifier L2)',
            disposedAt: new Date().toLocaleTimeString()
          }
        };
      }
      return c;
    }));
    setDispNarrative('');
  };

  const handleSubmitToCompliance = () => {
    setExceptions(prev => prev.map(c => {
      if (c.id === activeCase.id) {
        return {
          ...c,
          status: 'ESCALATED_COMPLIANCE',
          gapReport: {
            status: 'COMPLETE',
            items: c.gapReport?.items.map(i => ({ ...i, verified: true })) || []
          }
        };
      }
      return c;
    }));
  };

  const handlePromptSubmit = (queryText?: string) => {
    const q = queryText || promptQuery;
    if (!q.trim()) return;

    setAnalyticsChat(prev => [...prev, { role: 'user', content: q }]);
    if (!queryText) setPromptQuery('');
    setIsAnalyzingPrompt(true);

    setTimeout(() => {
      let responseContent = '';
      let reasoningText = '';

      const lowerQ = q.toLowerCase();
      if (lowerQ.includes('queue') || lowerQ.includes('looking like')) {
        responseContent = `**Queue Analysis Summary:**\n• **Total Active Queue:** ${exceptions.length} exception cases.\n• **SLA Risk:** 1 case (EXC-801) is within 2 hours of SLA breach due to OFAC sanctions proximity.\n• **Top Exception Reason:** Document Extraction & Screening hits account for 80% of current backlog.\n• **Recommended Action:** Address EXC-801 (Apex Capital) immediately before tackling Hong Kong manual sign-offs.`;
        reasoningText = 'Evaluated priority queue machine-ordering: regulatory deadlines and Tier 4 EDD status prioritized first.';
      } else if (lowerQ.includes('compliance returning') || lowerQ.includes('returns')) {
        responseContent = `**Compliance Return Metrics:**\n• **Return Rate:** 3.8% of handoffs returned by Compliance over past 14 days.\n• **Primary Reason:** Missing notarized board resolutions in UAE / HK jurisdictions (62% of returns).\n• **Root Cause Analysis:** Ops gap check previously passed uncertified PDFs. Adding mandatory document certification flag to Module 5 completeness check reduced returns by 40%.`;
        reasoningText = 'Analyzed historical handoff logs between Ops and Compliance, categorizing return reason codes.';
      } else if (lowerQ.includes('override') || lowerQ.includes('agent decisions')) {
        responseContent = `**Agent Override Breakdown:**\n• **Overall Override Rate:** 4.2% across all 240 onboardings.\n• **Most Overridden Agent:** Sanctions Screener Agent (68% of manual overrides were false-positive name clears).\n• **Jurisdiction Pattern:** Chinese entity legal structures trigger high false-positive UBO ambiguity due to transliteration limits.`;
        reasoningText = 'Compared agent initial recommendations against final Ops dispositions across Digital Twin audit trail.';
      } else if (lowerQ.includes('apex capital') || lowerQ.includes('exc-801')) {
        responseContent = `**Case Walkthrough: Apex Capital Holdings Pte Ltd (EXC-801)**\n• **Arrived:** 1h 15m ago from RM Sarah Jenkins.\n• **Agent Action:** KybAgent extracted 100% of ACRA documents. Sanctions Agent hit partial name match on "Apex Maritime Intermediary Corp" (12.5% shareholder).\n• **Current Status:** Held in Ops queue for human disposition. Tier 4 EDD Compliance pre-screen completed cleanly.\n• **Next Step:** Perform structured disposition in Screening Module.`;
        reasoningText = 'Polled full timeline from Digital Twin Knowledge Graph and screening audit logs for Apex Capital Holdings.';
      } else {
        responseContent = `**Operational Analysis for Query:** "${q}"\n\n• All 5 active exception cases are mapped to verified Digital Twin nodes.\n• SLA Compliance rate is currently 98.4%.\n• No open regulatory gaps detected in submitted Compliance packages.`;
        reasoningText = 'Queried Ops telemetry database and agent performance records.';
      }

      setAnalyticsChat(prev => [...prev, {
        role: 'assistant',
        content: responseContent,
        reasoning: reasoningText
      }]);
      setIsAnalyzingPrompt(false);
    }, 800);
  };

  return (
    <div className="space-y-6 text-left">
      {/* Ops Header Banner */}
      <div className="bg-gradient-to-r from-[#002D62] via-[#004B87] to-[#00A3E0] p-6 rounded-2xl text-white shadow-md relative overflow-hidden">
        <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-white/5 rounded-full blur-2xl pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-1 bg-white/10 backdrop-blur-md rounded-md text-[11px] font-mono font-bold tracking-wider text-amber-300 border border-white/20 uppercase flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 text-amber-300" />
                Ops Verifier Hub • Decision Completer
              </span>
              <span className="px-2.5 py-1 bg-emerald-500/20 rounded-md text-[11px] font-mono font-bold text-emerald-300 border border-emerald-400/30">
                Compliance Gatekeeper Active
              </span>
            </div>
            <h1 className="text-2xl font-black tracking-tight text-white flex items-center gap-2">
              Operations Verification & Exception Queue
            </h1>
            <p className="text-xs text-blue-100 max-w-3xl mt-1 leading-relaxed">
              Receive incomplete decisions from agents, complete verification, dispose hits within mandate, and hand off fully verified, completeness-checked files to Compliance.
            </p>
          </div>

          {/* SLA Overview Pill */}
          <div className="bg-white/10 backdrop-blur-md p-3.5 rounded-xl border border-white/15 flex items-center gap-4 self-start shrink-0">
            <div>
              <div className="text-[10px] font-mono text-blue-200 uppercase font-bold">Priority Exceptions</div>
              <div className="text-xl font-extrabold text-amber-300 font-mono">{exceptions.filter(e => e.status === 'PENDING_OPS').length} Cases</div>
            </div>
            <div className="h-8 w-px bg-white/20" />
            <div>
              <div className="text-[10px] font-mono text-blue-200 uppercase font-bold">Compliance Gate</div>
              <div className="text-xs font-bold text-emerald-300 flex items-center gap-1 mt-1">
                <ShieldCheck className="w-3.5 h-3.5" /> Ready for Handoff
              </div>
            </div>
          </div>
        </div>

        {/* Workflow Lifecycle Sequence bar */}
        <div className="mt-5 pt-4 border-t border-white/15 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-7 gap-2 text-[11px] font-mono">
          <div className="p-1.5 bg-white/5 rounded border border-white/10 text-slate-300 flex items-center justify-between">
            <span>1. Agent Collect</span>
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
          </div>
          <div className="p-1.5 bg-white/5 rounded border border-white/10 text-slate-300 flex items-center justify-between">
            <span>2. Agent Verify</span>
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
          </div>
          <div className="p-1.5 bg-amber-500/20 rounded border border-amber-400/40 text-amber-200 font-bold flex items-center justify-between shadow-sm">
            <span>3. Ops Exception</span>
            <Clock className="w-3 h-3 text-amber-300 animate-pulse" />
          </div>
          <div className="p-1.5 bg-white/5 rounded border border-white/10 text-slate-300 flex items-center justify-between">
            <span>4. Risk Rating</span>
            <BarChartIcon className="w-3 h-3 text-blue-300" />
          </div>
          <div className="p-1.5 bg-emerald-500/10 rounded border border-emerald-400/30 text-emerald-300 font-bold flex items-center justify-between">
            <span>5. Compliance Review</span>
            <Lock className="w-3 h-3 text-emerald-300" />
          </div>
          <div className="p-1.5 bg-white/5 rounded border border-white/10 text-slate-300 flex items-center justify-between">
            <span>6. Legal Review</span>
            <Scale className="w-3 h-3 text-purple-300" />
          </div>
          <div className="p-1.5 bg-white/5 rounded border border-white/10 text-slate-300 flex items-center justify-between col-span-2 sm:col-span-1">
            <span>7. Activation</span>
            <Award className="w-3 h-3 text-emerald-400" />
          </div>
        </div>
      </div>

      {/* Primary Ops Navigation Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-1.5 flex flex-wrap items-center gap-1 shadow-sm overflow-x-auto">
        <button
          onClick={() => setActiveModule('queue')}
          className={`px-3.5 py-2 rounded-lg text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            activeModule === 'queue'
              ? 'bg-[#002D62] text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <ClipboardList className="w-4 h-4" />
          <span>Module 1: Exception Queue ({exceptions.length})</span>
        </button>

        <button
          onClick={() => setActiveModule('review')}
          className={`px-3.5 py-2 rounded-lg text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            activeModule === 'review'
              ? 'bg-[#002D62] text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Eye className="w-4 h-4 text-blue-400" />
          <span>Module 2: Case Review & Evidence Studio</span>
        </button>

        <button
          onClick={() => setActiveModule('screening')}
          className={`px-3.5 py-2 rounded-lg text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            activeModule === 'screening'
              ? 'bg-[#002D62] text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <ShieldAlert className="w-4 h-4 text-amber-500" />
          <span>Module 3: Screening & Adverse Media</span>
        </button>

        <button
          onClick={() => setActiveModule('overrides')}
          className={`px-3.5 py-2 rounded-lg text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            activeModule === 'overrides'
              ? 'bg-[#002D62] text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Sliders className="w-4 h-4 text-purple-400" />
          <span>Module 4: Overrides & Waivers</span>
        </button>

        <button
          onClick={() => setActiveModule('handoff')}
          className={`px-3.5 py-2 rounded-lg text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            activeModule === 'handoff'
              ? 'bg-[#002D62] text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <FileCheck className="w-4 h-4 text-emerald-500" />
          <span>Module 5: Compliance Readiness & Handoff</span>
        </button>

        <button
          onClick={() => setActiveModule('quality')}
          className={`px-3.5 py-2 rounded-lg text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            activeModule === 'quality'
              ? 'bg-[#002D62] text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Award className="w-4 h-4 text-indigo-400" />
          <span>Module 6: Quality Audit (5% Sample)</span>
        </button>

        <button
          onClick={() => setActiveModule('compliance_status')}
          className={`px-3.5 py-2 rounded-lg text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            activeModule === 'compliance_status'
              ? 'bg-[#002D62] text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Lock className="w-4 h-4 text-teal-400" />
          <span>Module 7: Compliance Status (Read-Only)</span>
        </button>

        <button
          onClick={() => setActiveModule('prompt_analytics')}
          className={`px-3.5 py-2 rounded-lg text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            activeModule === 'prompt_analytics'
              ? 'bg-[#002D62] text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>Module 8: Prompt Analytics</span>
        </button>

        <button
          onClick={() => setActiveModule('exam_pack')}
          className={`px-3.5 py-2 rounded-lg text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            activeModule === 'exam_pack'
              ? 'bg-[#002D62] text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Download className="w-4 h-4 text-sky-400" />
          <span>Module 9: Exam Pack</span>
        </button>
      </div>

      {/* MODULE 1: EXCEPTION QUEUE */}
      {activeModule === 'queue' && (
        <div className="space-y-4">
          {/* Machine Ordering Banner */}
          <div className="bg-slate-900 text-white p-4 rounded-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border border-slate-800">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-blue-600/20 rounded-lg text-blue-400 border border-blue-500/30">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold font-mono text-blue-300 uppercase tracking-wider flex items-center gap-2">
                  MACHINE-ORDERED PRIORITY DISPATCH
                  <span className="text-[10px] bg-blue-500/20 text-blue-300 border border-blue-400/30 px-2 py-0.5 rounded">Machine Rules Active</span>
                </h3>
                <p className="text-xs text-slate-300 mt-0.5">
                  Queue is ordered automatically: <strong className="text-amber-300">Regulatory Deadline &gt; Risk Rating &gt; Exception Severity &gt; Time in Queue</strong>.
                </p>
              </div>
            </div>

            {/* Batch Action Controller */}
            {selectedBatchIds.length > 0 && (
              <div className="flex items-center gap-2 bg-slate-800 p-2 rounded-lg border border-slate-700">
                <span className="text-xs font-mono font-bold text-amber-300 px-2">
                  {selectedBatchIds.length} Selected
                </span>
                <button
                  onClick={() => handleApplyBatchDisposition('NOT_A_MATCH')}
                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-bold transition cursor-pointer"
                >
                  Batch Clear (False Hit)
                </button>
                <button
                  onClick={() => handleApplyBatchDisposition('MATCH_ESCALATE')}
                  className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded text-xs font-bold transition cursor-pointer"
                >
                  Batch Escalate
                </button>
              </div>
            )}
          </div>

          {/* Machine-Ordered Cards Grid */}
          <div className="grid grid-cols-1 gap-4">
            {sortedExceptions.map((item, index) => {
              const isSelected = item.id === selectedCaseId;
              const isBatchChecked = selectedBatchIds.includes(item.id);

              return (
                <div
                  key={item.id}
                  className={`bg-white dark:bg-slate-900 border rounded-2xl p-5 transition-all shadow-sm relative text-left ${
                    isSelected 
                      ? 'border-[#002D62] dark:border-[#00A3E0] ring-2 ring-[#002D62]/10 dark:ring-[#00A3E0]/20' 
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                  }`}
                >
                  {/* Top Priority Header */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
                    <div className="flex items-center gap-3">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleBatchSelectToggle(item.id);
                        }}
                        className="text-slate-400 hover:text-slate-600 cursor-pointer"
                      >
                        {isBatchChecked ? <CheckSquare className="w-5 h-5 text-blue-600" /> : <Square className="w-5 h-5" />}
                      </button>

                      <span className="w-6 h-6 rounded-full bg-slate-900 dark:bg-slate-800 text-white text-xs font-mono font-bold flex items-center justify-center">
                        #{index + 1}
                      </span>

                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-extrabold text-slate-900 dark:text-white text-base">{item.entityName}</h3>
                          <span className="text-xs font-mono px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-md font-bold">
                            {item.entityType}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                          RM: <strong className="text-slate-700 dark:text-slate-300">{item.rmName}</strong> • Jurisdiction: <strong>{item.jurisdiction}</strong> • Queue Age: <strong className="text-amber-600">{item.ageInQueue}</strong>
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-start sm:self-auto">
                      <span className={`px-2.5 py-1 rounded-md text-[11px] font-mono font-bold border ${
                        item.severity === 'Critical' ? 'bg-red-50 text-red-700 border-red-200 dark:bg-red-950/40 dark:text-red-300 dark:border-red-800' :
                        item.severity === 'High' ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800' :
                        'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/40 dark:text-blue-300 dark:border-blue-800'
                      }`}>
                        {item.severity} Risk ({item.riskRating})
                      </span>

                      <span className={`px-2.5 py-1 rounded-md text-[11px] font-mono font-bold border ${
                        item.status === 'OPS_VERIFIED' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
                        item.status === 'RETURNED_TO_AGENT' ? 'bg-purple-50 text-purple-700 border-purple-200' :
                        item.status === 'ESCALATED_COMPLIANCE' ? 'bg-teal-50 text-teal-700 border-teal-200' :
                        'bg-slate-100 text-slate-700 border-slate-200'
                      }`}>
                        {item.status.replace(/_/g, ' ')}
                      </span>
                    </div>
                  </div>

                  {/* Single Sentence Escalation Trigger */}
                  <div className="mt-3 p-3 bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/50 rounded-xl flex items-start gap-3">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div className="text-xs text-amber-950 dark:text-amber-200 leading-relaxed font-sans">
                      <strong className="font-bold text-amber-900 dark:text-amber-300 uppercase font-mono text-[10px] block mb-0.5">
                        ESCALATION REASON &amp; SINGLE-SENTENCE TRIGGER
                      </strong>
                      <span className="font-semibold">{item.exceptionReason}</span> — <em>"{item.escalationSentence}"</em>
                    </div>
                  </div>

                  {/* Quick Action Footer */}
                  <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-3 text-xs font-mono text-slate-500">
                      <span className="flex items-center gap-1 font-bold text-slate-700 dark:text-slate-300">
                        <Bot className="w-3.5 h-3.5 text-blue-600" />
                        Agent Confidence: {item.agentConfidence}%
                      </span>
                      <span>SLA: {item.deadline}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          handleSelectCase(item.id);
                          setShowReturnModal(true);
                        }}
                        className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                      >
                        <RotateCcw className="w-3.5 h-3.5 text-purple-600" />
                        Return to Agent
                      </button>

                      <button
                        onClick={() => {
                          handleSelectCase(item.id);
                          setActiveModule('review');
                        }}
                        className="px-3.5 py-1.5 bg-[#002D62] hover:bg-[#001D42] text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        Inspect Case Review &amp; Evidence
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* MODULE 2: CASE REVIEW INTERFACE & EVIDENCE STUDIO */}
      {activeModule === 'review' && (
        <div className="space-y-6">
          {/* Active Case Context Banner */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-blue-600 bg-blue-50 dark:bg-blue-950/40 px-2 py-0.5 rounded border border-blue-200 dark:border-blue-800">
                  Case ID: {activeCase.id}
                </span>
                <span className="text-xs font-mono font-bold text-purple-600 bg-purple-50 dark:bg-purple-950/40 px-2 py-0.5 rounded border border-purple-200 dark:border-purple-800">
                  {activeCase.exceptionType}
                </span>
              </div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white mt-1.5">{activeCase.entityName}</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Jurisdiction: <strong>{activeCase.jurisdiction}</strong> • RM: <strong>{activeCase.rmName}</strong> • Risk Rating: <strong className="text-amber-600">{activeCase.riskRating}</strong>
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveModule('screening')}
                className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                <ShieldAlert className="w-4 h-4" /> Go to Screening Disposition
              </button>

              <button
                onClick={() => setActiveModule('handoff')}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                <FileCheck className="w-4 h-4" /> Check Compliance Readiness
              </button>
            </div>
          </div>

          {/* 2.1 Agent Reasoning Transparency */}
          <div className="bg-slate-900 text-white border border-slate-800 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Brain className="w-5 h-5 text-blue-400" />
                <h3 className="font-mono font-bold text-sm text-blue-300 uppercase">2.1 Agent Reasoning Transparency &amp; Chain-of-Thought</h3>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-slate-400">Stopping Confidence:</span>
                <span className={`text-sm font-mono font-bold px-2 py-0.5 rounded ${
                  activeCase.agentConfidence >= 80 ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-amber-950 text-amber-300 border border-amber-800'
                }`}>
                  {activeCase.agentConfidence}% Confidence
                </span>
              </div>
            </div>

            <div className="space-y-2 font-mono text-xs text-slate-300">
              {activeCase.agentReasoningChain.map((step, idx) => (
                <div key={idx} className="flex items-start gap-2.5 bg-slate-850 p-2.5 rounded-lg border border-slate-800">
                  <span className="text-blue-400 font-bold shrink-0">[{idx + 1}]</span>
                  <span>{step}</span>
                </div>
              ))}
            </div>
          </div>

          {/* 2.2 Evidence Panel: Side-by-Side View */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Raw Source Data (Left) */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3 shadow-sm">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <h3 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                  <Database className="w-4 h-4 text-slate-500" />
                  RAW SOURCE PAYLOAD / REGISTRY DOCUMENT
                </h3>
                <span className="text-[10px] font-mono bg-slate-100 dark:bg-slate-800 text-slate-500 px-2 py-0.5 rounded">
                  Source Raw Text
                </span>
              </div>

              <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-mono text-slate-700 dark:text-slate-300 space-y-2 max-h-72 overflow-y-auto">
                {Object.entries(activeCase.rawSourceData).map(([key, val]) => (
                  <div key={key} className="border-b border-slate-200 dark:border-slate-800/80 pb-2">
                    <span className="text-slate-400 uppercase font-bold text-[10px] block mb-0.5">{key}</span>
                    <p className="whitespace-pre-wrap leading-relaxed">{val}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Agent Extracted Data & Manual Correction (Right) */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3 shadow-sm">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <h3 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                  <FileText className="w-4 h-4 text-blue-600" />
                  2.3 DOCUMENT MANUAL REVIEW &amp; EXTRACTION CONFIRMATION
                </h3>
                <span className="text-[10px] font-mono bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 px-2 py-0.5 rounded border border-emerald-200">
                  Ops Attribution Verified
                </span>
              </div>

              <div className="space-y-3">
                {Object.entries(activeCase.extractedData).map(([field, val]) => (
                  <div key={field} className="space-y-1">
                    <label className="text-[10px] font-mono text-slate-400 uppercase font-bold">{field}</label>
                    <input
                      type="text"
                      defaultValue={val}
                      className="w-full text-xs font-mono p-2 border border-slate-200 dark:border-slate-700 rounded-lg bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-1 focus:ring-blue-500"
                    />
                  </div>
                ))}

                <button
                  onClick={() => alert(`Confirmed manual data for ${activeCase.entityName}. Event dispatched to Digital Twin.`)}
                  className="w-full mt-2 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" /> Confirm &amp; Fire Verified Event to Digital Twin
                </button>
              </div>
            </div>
          </div>

          {/* 2.4 Similar Case Reference & 2.5 Inline Policy Query */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Similar Case Reference */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3 shadow-sm">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-2">
                <BookOpen className="w-4 h-4 text-purple-600" />
                2.4 SIMILAR HISTORICAL CASES REFERENCE (AI MATCHED)
              </h3>
              <div className="space-y-2 text-xs">
                <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700">
                  <div className="flex justify-between font-bold text-slate-800 dark:text-slate-200">
                    <span>Alpha Logistics Pte Ltd (EXC-409)</span>
                    <span className="text-emerald-600">Cleared / Disposed</span>
                  </div>
                  <p className="text-slate-500 mt-1">Exception: 10% shareholder sanctions fuzzy match. Disposition: MATCH_CLEARED after secondary registry cross-check confirmed different entity registration number.</p>
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700">
                  <div className="flex justify-between font-bold text-slate-800 dark:text-slate-200">
                    <span>Vortex Energy FZ (EXC-211)</span>
                    <span className="text-amber-600">Escalated to Compliance</span>
                  </div>
                  <p className="text-slate-500 mt-1">Exception: UAE Board Resolution seal overlay. Disposition: Escalated to Compliance due to missing certified copy.</p>
                </div>
              </div>
            </div>

            {/* Inline Policy Query */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3 shadow-sm">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-2">
                <HelpCircle className="w-4 h-4 text-blue-600" />
                2.5 INLINE POLICY &amp; MANDATE SEARCH
              </h3>
              <div className="p-3 bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800/50 rounded-xl text-xs space-y-2 text-blue-950 dark:text-blue-200">
                <div className="font-bold uppercase font-mono text-[10px] text-blue-700 dark:text-blue-300">
                  POLICY SECTION #402.1 • JURISDICTION VARIANT: {activeCase.jurisdiction}
                </div>
                <p>
                  "For entities with sanctions proximity matches under 15% indirect equity, Operations Officers Level 2 are authorized to dispose as MATCH_CLEARED if registry verification proves zero direct control or management rights."
                </p>
                <div className="font-mono text-[11px] text-slate-600 dark:text-slate-400">
                  Approval Authority Required: <strong>Ops Level 2 Officer Sign-off</strong>
                </div>
              </div>
            </div>
          </div>

          {/* 2.6 Digital Twin Knowledge Graph Context Panel */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3 shadow-sm">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
              <span className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-emerald-600" />
                2.6 DIGITAL TWIN KNOWLEDGE GRAPH ENTITY PANEL
              </span>
              <span className="text-[10px] font-mono text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded">
                Live Knowledge Graph Sync
              </span>
            </h3>

            <div className="p-4 bg-slate-950 rounded-xl text-white font-mono text-xs space-y-3">
              <div className="flex items-center justify-between text-slate-400 border-b border-slate-800 pb-2">
                <span>[ROOT ENTITY]: {activeCase.entityName}</span>
                <span>Node ID: twin_node_{activeCase.clientId}</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                  <span className="text-[10px] text-blue-400 block font-bold">CONNECTED ENTITIES</span>
                  <p className="mt-1 text-slate-200 font-semibold">{Object.values(activeCase.extractedData)[2] || 'Parent Holding Co (100%)'}</p>
                </div>
                <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                  <span className="text-[10px] text-purple-400 block font-bold">PRIOR EXCEPTIONS</span>
                  <p className="mt-1 text-slate-200 font-semibold">0 Historical Exceptions Flagged</p>
                </div>
                <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                  <span className="text-[10px] text-amber-400 block font-bold">PERPETUAL KYC STATUS</span>
                  <p className="mt-1 text-slate-200 font-semibold">Active Monitoring Target</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODULE 3: SCREENING AND ADVERSE MEDIA DISPOSITION */}
      {activeModule === 'screening' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5 shadow-sm">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
              <div>
                <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <ShieldAlert className="w-5 h-5 text-amber-600" />
                  Module 3: Screening &amp; Adverse Media Disposition Workflow
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Structured disposition required for all screening hits. Mandatory narrative stored directly in Digital Twin &amp; Examination Pack.
                </p>
              </div>

              <div className="px-3 py-1 bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 rounded-lg text-xs font-mono font-bold border border-red-200">
                Rule: Ops cannot clear confirmed Sanctions matches.
              </div>
            </div>

            {/* 3.2 Watchlist Source & 3.3 Adverse Media Scoring Display */}
            {activeCase.screeningDetails ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
                  <h3 className="text-xs font-mono uppercase font-bold text-slate-500">3.2 Watchlist Source Details</h3>
                  <div className="text-xs font-mono space-y-1 text-slate-800 dark:text-slate-200">
                    <div><strong>Watchlist Name:</strong> {activeCase.screeningDetails.watchlistName}</div>
                    <div><strong>Last Update Date:</strong> {activeCase.screeningDetails.lastUpdated}</div>
                    <div><strong>Match Basis:</strong> {activeCase.screeningDetails.matchBasis}</div>
                    <div className="p-2 bg-white dark:bg-slate-900 border rounded font-sans text-slate-600 dark:text-slate-300 mt-2">
                      <strong>Exact Watchlist Text:</strong> {activeCase.screeningDetails.entryText}
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
                  <h3 className="text-xs font-mono uppercase font-bold text-slate-500">3.3 Adverse Media Scoring Card</h3>
                  {activeCase.screeningDetails.adverseMediaScore ? (
                    <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                      <div className="p-2 bg-white dark:bg-slate-900 border rounded">
                        <span className="text-[10px] text-slate-400 block">SOURCE CREDIBILITY</span>
                        <strong className="text-blue-600 text-sm">{activeCase.screeningDetails.adverseMediaScore.sourceCredibility}%</strong>
                      </div>
                      <div className="p-2 bg-white dark:bg-slate-900 border rounded">
                        <span className="text-[10px] text-slate-400 block">NAME MATCH STRENGTH</span>
                        <strong className="text-purple-600 text-sm">{activeCase.screeningDetails.adverseMediaScore.nameMatchStrength}%</strong>
                      </div>
                      <div className="p-2 bg-white dark:bg-slate-900 border rounded">
                        <span className="text-[10px] text-slate-400 block">RECENCY</span>
                        <strong className="text-slate-700 dark:text-slate-200">{activeCase.screeningDetails.adverseMediaScore.recency}</strong>
                      </div>
                      <div className="p-2 bg-white dark:bg-slate-900 border rounded">
                        <span className="text-[10px] text-slate-400 block">ALLEGATION SEVERITY</span>
                        <strong className="text-amber-600">{activeCase.screeningDetails.adverseMediaScore.allegationSeverity}</strong>
                      </div>
                    </div>
                  ) : (
                    <p className="text-xs text-slate-400 font-mono">No adverse media article attached to this watchlist hit.</p>
                  )}
                </div>
              </div>
            ) : (
              <div className="p-4 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs text-slate-500 font-mono">
                No active watchlist screening alerts attached to this case.
              </div>
            )}

            {/* 3.1 Structured Disposition Category Selection */}
            <div className="space-y-3 pt-2">
              <label className="text-xs font-mono font-bold text-slate-700 dark:text-slate-300 uppercase block">
                3.1 Select Structured Disposition Category
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
                {[
                  { id: 'NOT_A_MATCH', label: 'NOT A MATCH', color: 'bg-emerald-600 text-white' },
                  { id: 'MATCH_CLEARED', label: 'MATCH CLEARED', color: 'bg-blue-600 text-white' },
                  { id: 'MATCH_ESCALATE', label: 'MATCH ESCALATE (Compliance)', color: 'bg-amber-600 text-white' },
                  { id: 'MATCH_REJECT_FILE', label: 'MATCH REJECT FILE', color: 'bg-red-600 text-white' },
                  { id: 'PENDING_INFO', label: 'PENDING INFO', color: 'bg-purple-600 text-white' }
                ].map((cat) => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setDispCategory(cat.id as any)}
                    className={`p-2.5 rounded-xl text-xs font-bold font-mono transition cursor-pointer text-center border ${
                      dispCategory === cat.id ? `${cat.color} shadow-md ring-2 ring-offset-1` : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>
            </div>

            {/* 3.4 Mandatory Structured Disposition Narrative */}
            <div className="space-y-2">
              <label className="text-xs font-mono font-bold text-slate-700 dark:text-slate-300 uppercase block">
                3.4 Mandatory Structured Disposition Narrative
              </label>
              <textarea
                rows={3}
                value={dispNarrative}
                onChange={(e) => setDispNarrative(e.target.value)}
                placeholder="Explain the rationale behind this disposition in detail. This narrative will be locked immutably into the Digital Twin and examination pack..."
                className="w-full text-xs font-mono p-3 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-1 focus:ring-blue-500"
              />
            </div>

            <button
              onClick={handleSaveDisposition}
              className="px-5 py-2.5 bg-[#002D62] hover:bg-[#001D42] text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-sm"
            >
              <ShieldCheck className="w-4 h-4" /> Save Immutably &amp; Apply Disposition
            </button>
          </div>
        </div>
      )}

      {/* MODULE 4: OVERRIDES AND WAIVERS */}
      {activeModule === 'overrides' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5 shadow-sm">
            <div className="border-b border-slate-100 dark:border-slate-800 pb-4">
              <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Sliders className="w-5 h-5 text-purple-600" />
                Module 4: Mandate-Bounded Overrides &amp; Waivers
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Ops approves exceptions strictly within mandate. Out-of-mandate requests route automatically to Compliance.
              </p>
            </div>

            {/* 4.1 Mandate Boundaries Display */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
              <div className="p-4 bg-emerald-50/70 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800 rounded-xl space-y-1.5">
                <span className="font-bold text-emerald-800 dark:text-emerald-300 uppercase block">WITHIN OPS MANDATE (APPROVABLE)</span>
                <ul className="list-disc list-inside space-y-1 text-slate-700 dark:text-slate-300 font-sans">
                  <li>Document format exception (standard alternative accepted)</li>
                  <li>Minor information gap with documented mitigant</li>
                  <li>Non-material date discrepancy in documents</li>
                </ul>
              </div>

              <div className="p-4 bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-xl space-y-1.5">
                <span className="font-bold text-amber-800 dark:text-amber-300 uppercase block">OUT OF OPS MANDATE (ROUTES TO COMPLIANCE)</span>
                <ul className="list-disc list-inside space-y-1 text-slate-700 dark:text-slate-300 font-sans">
                  <li>PEP-adjacent relationships</li>
                  <li>Sanctions proximity (related party / prior association)</li>
                  <li>Source of wealth unable to be evidenced</li>
                  <li>Legal structure opacity (beneficial owner unresolved)</li>
                </ul>
              </div>
            </div>

            {/* 4.2 Structured Exception Form */}
            <div className="space-y-3 bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-200 dark:border-slate-700">
              <h3 className="text-xs font-mono font-bold uppercase text-slate-700 dark:text-slate-300">4.2 Structured Exception Approval Form</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">POLICY REQUIREMENT</label>
                  <input
                    type="text"
                    value={overrideForm.policyReq}
                    onChange={(e) => setOverrideForm({ ...overrideForm, policyReq: e.target.value })}
                    className="w-full p-2 border rounded font-mono bg-white dark:bg-slate-900"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">EXCEPTION ACCEPTED</label>
                  <input
                    type="text"
                    value={overrideForm.acceptedAlt}
                    onChange={(e) => setOverrideForm({ ...overrideForm, acceptedAlt: e.target.value })}
                    className="w-full p-2 border rounded font-mono bg-white dark:bg-slate-900"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">RISK MITIGANT</label>
                  <input
                    type="text"
                    value={overrideForm.riskMitigant}
                    onChange={(e) => setOverrideForm({ ...overrideForm, riskMitigant: e.target.value })}
                    className="w-full p-2 border rounded font-mono bg-white dark:bg-slate-900"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">REVIEW TRIGGER</label>
                  <input
                    type="text"
                    value={overrideForm.reviewTrigger}
                    onChange={(e) => setOverrideForm({ ...overrideForm, reviewTrigger: e.target.value })}
                    className="w-full p-2 border rounded font-mono bg-white dark:bg-slate-900"
                  />
                </div>
              </div>

              {/* 4.3 Two-Person Integrity Trigger */}
              <div className="pt-2 flex items-center justify-between">
                <button
                  onClick={() => setShowTwoPersonModal(true)}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-lg transition flex items-center gap-1.5 cursor-pointer"
                >
                  <UserCheck className="w-4 h-4" /> Trigger 4.3 Two-Person Integrity Sign-Off
                </button>

                <span className="text-[11px] font-mono text-slate-500">
                  4.4 Overrides tracked post-onboarding for Perpetual KYC alignment.
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODULE 5: FILE READINESS AND HANDOFF TO COMPLIANCE */}
      {activeModule === 'handoff' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5 shadow-sm">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
              <div>
                <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <FileCheck className="w-5 h-5 text-emerald-600" />
                  Module 5: File Readiness Check &amp; Handoff Checkpoint
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Explicit checkpoint before transferring file ownership to Compliance for final onboarding review.
                </p>
              </div>

              <div className={`px-3 py-1 rounded-xl text-xs font-mono font-bold border ${
                activeCase.gapReport?.status === 'COMPLETE' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
                activeCase.gapReport?.status === 'GAP_COVERED' ? 'bg-amber-50 text-amber-700 border-amber-200' :
                'bg-red-50 text-red-700 border-red-200'
              }`}>
                5.1 Gap Status: {activeCase.gapReport?.status || 'COMPLETE'}
              </div>
            </div>

            {/* 5.1 Completeness Check Report */}
            <div className="space-y-2">
              <h3 className="text-xs font-mono uppercase font-bold text-slate-500">5.1 Journey Template Completeness Report</h3>
              <div className="space-y-2">
                {activeCase.gapReport?.items.map((item, idx) => (
                  <div key={idx} className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs font-mono">
                    <span className="font-bold text-slate-800 dark:text-slate-200">{item.element}</span>
                    <div className="flex items-center gap-2">
                      {item.verified ? (
                        <span className="text-emerald-600 flex items-center gap-1 font-bold">
                          <CheckCircle2 className="w-4 h-4" /> VERIFIED
                        </span>
                      ) : item.exceptionApproved ? (
                        <span className="text-amber-600 flex items-center gap-1 font-bold">
                          <AlertTriangle className="w-4 h-4" /> GAP COVERED (WAIVER)
                        </span>
                      ) : (
                        <span className="text-red-600 flex items-center gap-1 font-bold">
                          <XCircle className="w-4 h-4" /> GAP OPEN (BLOCKS HANDOFF)
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 5.2 Verification Summary & 5.3 Risk Rating Confirmation */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
                <h3 className="text-xs font-mono uppercase font-bold text-slate-500">5.2 Ops Verification Summary</h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 font-sans leading-relaxed">
                  All 3 source documents extracted. Screening hit cleared per policy section #402.1. Gap report status verified as COMPLETE.
                </p>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
                <h3 className="text-xs font-mono uppercase font-bold text-slate-500">5.3 Risk Rating Confirmation</h3>
                <div className="flex items-center justify-between text-xs font-mono">
                  <span>Agent Calculated Rating:</span>
                  <strong className="text-amber-600">{activeCase.riskRating}</strong>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <input type="checkbox" defaultChecked className="accent-emerald-600" />
                  <span className="text-slate-700 dark:text-slate-300">Ops Confirms Risk Rating is aligned with verified file</span>
                </div>
              </div>
            </div>

            {/* 5.4 Submit Action */}
            <button
              onClick={handleSubmitToCompliance}
              disabled={activeCase.gapReport?.status === 'GAP_OPEN'}
              className={`w-full py-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-md ${
                activeCase.gapReport?.status === 'GAP_OPEN'
                  ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                  : 'bg-emerald-600 hover:bg-emerald-700 text-white'
              }`}
            >
              <Send className="w-4 h-4" /> 5.4 Lock Ops Record &amp; Submit File to Compliance Review
            </button>
          </div>
        </div>
      )}

      {/* MODULE 6: QUALITY AUDIT */}
      {activeModule === 'quality' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4 shadow-sm">
          <div className="border-b border-slate-100 dark:border-slate-800 pb-3">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Award className="w-5 h-5 text-indigo-600" />
              Module 6: Quality Audit (5% Post-Hoc Sample Queue)
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Review agent auto-approved cases to measure accuracy and feed calibration models.
            </p>
          </div>

          <div className="p-4 bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-200 rounded-xl space-y-2 text-xs font-mono">
            <div className="flex justify-between text-indigo-950 dark:text-indigo-200">
              <span>Agent Accuracy Score (Last 30 Days): <strong>96.2%</strong></span>
              <span>Sample Rate: <strong>5.0% Configured</strong></span>
            </div>
            <p className="font-sans text-slate-600 dark:text-slate-300">
              Quality feedback automatically updates agent performance models in Platform Admin Agent Registry.
            </p>
          </div>
        </div>
      )}

      {/* MODULE 7: COMPLIANCE AND LEGAL ROUTING (READ-ONLY) */}
      {activeModule === 'compliance_status' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4 shadow-sm">
          <div className="border-b border-slate-100 dark:border-slate-800 pb-3">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Lock className="w-5 h-5 text-teal-600" />
              Module 7: Compliance Queue Visibility (Read-Only Status)
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Ops tracks handoff status without side-channel chasing. Returned files land back in Ops queue automatically.
            </p>
          </div>

          <div className="space-y-2 text-xs font-mono">
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
              <span>Apex Capital Holdings (EXC-801)</span>
              <span className="text-amber-600 font-bold">In Review (Compliance Officer Marcus Vance)</span>
            </div>
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
              <span>Horizon Fintech Global (EXC-802)</span>
              <span className="text-emerald-600 font-bold">Approved by Compliance</span>
            </div>
          </div>
        </div>
      )}

      {/* MODULE 8: PROMPT-DRIVEN ANALYTICS */}
      {activeModule === 'prompt_analytics' && (
        <div className="space-y-6">
          {/* Ambient Minimal Dashboard */}
          <div className="bg-slate-900 text-white rounded-2xl p-5 border border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="text-xs font-mono font-bold text-blue-400 uppercase tracking-widest flex items-center gap-2">
                <BarChartIcon className="w-4 h-4 text-blue-400" />
                Module 8: Ambient Operational Surface
              </span>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800">
                Live Pulse Active
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
              <div className="p-3 bg-slate-850 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 block uppercase">Queue Depth</span>
                <span className="text-xl font-bold text-white">{exceptions.length} Cases</span>
              </div>
              <div className="p-3 bg-slate-850 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 block uppercase">SLA Status</span>
                <span className="text-xs font-bold text-emerald-400 block mt-1">12 On Track | 2 Amber</span>
              </div>
              <div className="p-3 bg-slate-850 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 block uppercase">Compliance Returns</span>
                <span className="text-xl font-bold text-amber-400">0 Today</span>
              </div>
              <div className="p-3 bg-slate-850 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 block uppercase">Submitted Today</span>
                <span className="text-xl font-bold text-emerald-400">3 Handed Off</span>
              </div>
            </div>
          </div>

          {/* Interactive AI Analytics Prompt Engine */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4 shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-500" />
                <h3 className="font-bold text-slate-900 dark:text-white text-base">Prompt-Driven Analytics &amp; Reasoning Engine</h3>
              </div>
              <span className="text-[10px] font-mono bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 px-2.5 py-1 rounded-md border border-amber-200">
                AI Reasoning Model Ready
              </span>
            </div>

            {/* Quick Prompt Chips */}
            <div className="flex flex-wrap gap-2 text-xs">
              {[
                "What's my queue looking like today?",
                "Why did exception volume spike on Thursday?",
                "How often is Compliance returning files, and what for?",
                "Where am I overriding agent decisions most often?",
                "Walk me through everything on Apex Capital"
              ].map((chip, idx) => (
                <button
                  key={idx}
                  onClick={() => handlePromptSubmit(chip)}
                  className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg font-mono text-[11px] transition cursor-pointer border border-slate-200 dark:border-slate-700"
                >
                  "{chip}"
                </button>
              ))}
            </div>

            {/* Chat Thread */}
            <div className="space-y-4 max-h-96 overflow-y-auto p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
              {analyticsChat.map((msg, idx) => (
                <div key={idx} className={`space-y-1 ${msg.role === 'user' ? 'text-right' : 'text-left'}`}>
                  <div className={`inline-block p-3.5 rounded-2xl text-xs max-w-2xl ${
                    msg.role === 'user'
                      ? 'bg-[#002D62] text-white font-mono'
                      : 'bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-800 font-sans shadow-sm'
                  }`}>
                    <p className="whitespace-pre-wrap leading-relaxed">{msg.content}</p>
                    {msg.reasoning && (
                      <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-800 text-[10px] font-mono text-slate-500 flex items-start gap-1">
                        <Brain className="w-3 h-3 text-blue-500 shrink-0 mt-0.5" />
                        <span>AI Reasoning: {msg.reasoning}</span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {isAnalyzingPrompt && (
                <div className="text-xs font-mono text-slate-500 flex items-center gap-2 animate-pulse">
                  <Sparkles className="w-4 h-4 text-amber-500" /> AI Ops Reasoning Engine is evaluating queue telemetry...
                </div>
              )}
            </div>

            {/* Input Bar */}
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={promptQuery}
                onChange={(e) => setPromptQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handlePromptSubmit()}
                placeholder="Ask any question about workload, trends, agent accuracy, or file history..."
                className="flex-1 p-3 text-xs font-mono border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500"
              />
              <button
                onClick={() => handlePromptSubmit()}
                className="px-4 py-3 bg-[#002D62] hover:bg-[#001D42] text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                <Send className="w-4 h-4" /> Ask AI
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODULE 9: REGULATORY EXAMINATION PACK */}
      {activeModule === 'exam_pack' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5 shadow-sm">
          <div className="border-b border-slate-100 dark:border-slate-800 pb-3">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Download className="w-5 h-5 text-sky-600" />
              Module 9: Regulatory Examination Pack Generator
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Generate 1-click immutable examination packs for regulatory auditors with cryptographic event hashes.
            </p>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl text-white font-mono text-xs space-y-3">
            <div className="flex justify-between items-center text-slate-400 border-b border-slate-800 pb-2">
              <span>9.2 Cryptographic Audit Hash: 0x99A182F...B910283</span>
              <span className="text-emerald-400 font-bold">Immutable Ledger Verified</span>
            </div>
            <p className="text-slate-300 font-sans">
              Contains source documents, extracted data, screening records, exception approvals, Ops summary, Compliance approval, and timestamped decision trail.
            </p>
          </div>

          <button
            onClick={() => {
              setExamPackGenerated(true);
              alert(`Regulatory Examination Pack generated for ${activeCase.entityName}. Complete audit trail exported.`);
            }}
            className="px-5 py-3 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-md"
          >
            <Download className="w-4 h-4" /> 9.1 Generate 1-Click Regulatory Examination Pack (PDF/ZIP)
          </button>
        </div>
      )}

      {/* MODAL: RETURN TO AGENT */}
      {showReturnModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-lg w-full space-y-4 shadow-xl text-left">
            <div className="flex justify-between items-center border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                <RotateCcw className="w-5 h-5 text-purple-600" />
                1.3 Return Case to Autonomous Agent
              </h3>
              <button onClick={() => setShowReturnModal(false)} className="text-slate-400 hover:text-slate-600">
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 font-sans">
              Specify instructions for the agent. The agent will re-engage customer via their outreach channel while holding its queue position.
            </p>

            <textarea
              rows={4}
              value={returnInstructions}
              onChange={(e) => setReturnInstructions(e.target.value)}
              placeholder="e.g. Please ask customer to upload a certified high-resolution scan of the Board Resolution document..."
              className="w-full text-xs font-mono p-3 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-800"
            />

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setShowReturnModal(false)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-bold"
              >
                Cancel
              </button>
              <button
                onClick={handleReturnToAgent}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-xs font-bold"
              >
                Dispatch Instructions to Agent
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: TWO-PERSON INTEGRITY */}
      {showTwoPersonModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-lg w-full space-y-4 shadow-xl text-left">
            <div className="flex justify-between items-center border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-purple-600" />
                4.3 Two-Person Integrity Dual Approval
              </h3>
              <button onClick={() => setShowTwoPersonModal(false)} className="text-slate-400 hover:text-slate-600">
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 bg-purple-50 dark:bg-purple-950/30 border border-purple-200 rounded-xl text-xs space-y-1 font-mono">
              <div><strong>First Approver:</strong> Alex Rivera (Ops Verifier Level 2)</div>
              <div><strong>Mandate Check:</strong> Top-of-mandate document exception requires second sign-off.</div>
            </div>

            <textarea
              rows={3}
              value={twoPersonNote}
              onChange={(e) => setTwoPersonNote(e.target.value)}
              placeholder="Second Approver (Senior Ops Manager) review note and concurrence..."
              className="w-full text-xs font-mono p-3 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-800"
            />

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setShowTwoPersonModal(false)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-bold"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  alert('Dual sign-off completed by Second Approver. Exception approved.');
                  setShowTwoPersonModal(false);
                }}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-xs font-bold"
              >
                Confirm Dual Sign-Off
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function BarChartIcon(props: any) {
  return (
    <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24" width="24" height="24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
    </svg>
  );
}
