import React, { useState } from 'react';
import { 
  FileText, X, ZoomIn, ZoomOut, RotateCw, ShieldCheck, 
  CheckCircle2, Clock, AlertTriangle, Building, User, Calendar, 
  Layers, Lock, Eye, Check
} from 'lucide-react';
import { UploadedDocument } from '../../types';

interface DocumentViewerModalProps {
  document: UploadedDocument | null;
  isOpen: boolean;
  onClose: () => void;
  onApprove?: (docId: string) => void;
  onReject?: (docId: string, reason?: string) => void;
  onApproveDoc?: (docId: string) => void;
  onRejectDoc?: (docId: string, reason?: string) => void;
  readOnly?: boolean;
  userRole?: 'rm' | 'compliance' | 'customer';
}

export function DocumentViewerModal({
  document,
  isOpen,
  onClose,
  onApprove,
  onReject,
  onApproveDoc,
  onRejectDoc,
  readOnly = false,
  userRole = 'customer'
}: DocumentViewerModalProps) {
  const [zoomLevel, setZoomLevel] = useState(100);
  const [rotation, setRotation] = useState(0);
  const [activeViewTab, setActiveViewTab] = useState<'preview' | 'ocr_data' | 'audit_log'>('preview');
  const [showRejectInput, setShowRejectInput] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');

  const handleApprove = () => {
    if (onApprove && document) onApprove(document.id);
    if (onApproveDoc && document) onApproveDoc(document.id);
  };

  const handleReject = (reason?: string) => {
    if (onReject && document) onReject(document.id, reason);
    if (onRejectDoc && document) onRejectDoc(document.id, reason);
  };

  if (!isOpen || !document) return null;

  const handleZoomIn = () => setZoomLevel(prev => Math.min(prev + 20, 200));
  const handleZoomOut = () => setZoomLevel(prev => Math.max(prev - 20, 60));
  const handleRotate = () => setRotation(prev => (prev + 90) % 360);

  // Generate realistic styled simulated preview pages based on doc type
  const renderDocumentContent = () => {
    const isIncorporation = document.name.toLowerCase().includes('incorporation') || document.type.toLowerCase().includes('incorporation');
    const isBoardRes = document.name.toLowerCase().includes('board') || document.type.toLowerCase().includes('board');
    const isUbo = document.name.toLowerCase().includes('controller') || document.name.toLowerCase().includes('ubo') || document.type.toLowerCase().includes('ubo');
    const isFinancials = document.name.toLowerCase().includes('financial') || document.type.toLowerCase().includes('financial');
    const isPassport = document.name.toLowerCase().includes('passport') || document.type.toLowerCase().includes('identification') || document.type.toLowerCase().includes('passport');

    return (
      <div 
        className="bg-white text-slate-900 shadow-2xl rounded-lg p-8 sm:p-12 mx-auto transition-transform duration-200 border border-slate-300 min-h-[720px] max-w-[650px] relative select-none"
        style={{
          transform: `scale(${zoomLevel / 100}) rotate(${rotation}deg)`,
          transformOrigin: 'top center',
          fontFamily: 'serif'
        }}
      >
        {/* Institutional Watermark */}
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center opacity-[0.04] overflow-hidden select-none">
          <span className="text-7xl font-black text-slate-900 transform -rotate-45 font-sans tracking-widest uppercase">
            CONFIDENTIAL • INSTITUTIONAL BANKING
          </span>
        </div>

        {/* Header Ribbon */}
        <div className="border-b-2 border-slate-900 pb-4 mb-6 flex items-start justify-between">
          <div className="space-y-1">
            <div className="text-[10px] uppercase tracking-widest font-sans font-extrabold text-slate-500">
              OFFICIAL GOVERNANCE & REGULATORY RECORD
            </div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
              {document.name.replace('.pdf', '').replace(/_/g, ' ')}
            </h1>
            <p className="text-xs text-slate-600 font-sans">
              Type: <strong className="text-slate-900">{document.type}</strong> • Ingestion Date: {document.uploadedAt}
            </p>
          </div>
          <div className="text-right font-sans">
            <div className="px-2.5 py-1 bg-slate-900 text-white text-[10px] font-bold rounded tracking-wider uppercase">
              CERTIFIED TRUE COPY
            </div>
            <span className="text-[9px] text-slate-400 font-mono block mt-1">Doc ID: {document.id}</span>
          </div>
        </div>

        {/* Dynamic Body Content according to Document Archetype */}
        {isIncorporation && (
          <div className="space-y-6 text-sm leading-relaxed">
            <div className="text-center py-3 border-y border-slate-300">
              <span className="text-xs uppercase tracking-wider font-sans font-bold text-slate-700">
                ACCOUNTING AND CORPORATE REGULATORY AUTHORITY
              </span>
              <h2 className="text-lg font-bold mt-1 text-slate-900">CERTIFICATE OF INCORPORATION OF A PRIVATE COMPANY</h2>
            </div>

            <p className="text-justify indent-8">
              This is to certify that pursuant to Section 19(4) of the Companies Act, the company whose details are set forth below is duly incorporated and that the liability of the members is limited.
            </p>

            <div className="p-4 bg-slate-50 border border-slate-300 rounded font-sans space-y-2 text-xs">
              <div className="grid grid-cols-3 gap-2 border-b border-slate-200 pb-1.5">
                <span className="text-slate-500 font-medium">Company Name:</span>
                <span className="col-span-2 font-bold text-slate-900">{document.ocrData?.['Company Name'] || 'Apex Holdings Global Pte Ltd'}</span>
              </div>
              <div className="grid grid-cols-3 gap-2 border-b border-slate-200 pb-1.5">
                <span className="text-slate-500 font-medium">Company Registration / UEN:</span>
                <span className="col-span-2 font-bold font-mono text-slate-900">{document.ocrData?.['Registration Number (UEN)'] || '201934812K'}</span>
              </div>
              <div className="grid grid-cols-3 gap-2 border-b border-slate-200 pb-1.5">
                <span className="text-slate-500 font-medium">Date of Incorporation:</span>
                <span className="col-span-2 font-bold text-slate-900">{document.ocrData?.['Date of Incorporation'] || '14 October 2019'}</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <span className="text-slate-500 font-medium">Registered Address:</span>
                <span className="col-span-2 text-slate-800">{document.ocrData?.['Registered Address'] || '12 Marina Boulevard #28-01, MBFC Tower 3, Singapore 018982'}</span>
              </div>
            </div>

            <div className="pt-8 flex justify-between items-end font-sans">
              <div className="text-left">
                <div className="w-28 h-12 border-b border-slate-400 mb-1 flex items-center justify-center italic text-slate-400 text-xs">
                  [Official Digital Seal]
                </div>
                <span className="text-[10px] text-slate-500 block">Registrar of Companies</span>
              </div>
              <div className="text-right">
                <span className="text-[10px] font-mono text-slate-400">Auth Code: ACRA-SG-92840182</span>
              </div>
            </div>
          </div>
        )}

        {isBoardRes && (
          <div className="space-y-5 text-sm leading-relaxed">
            <div className="text-center py-2 border-y border-slate-300">
              <h2 className="text-base font-bold text-slate-900 uppercase">EXTRACT OF MINUTES & BOARD RESOLUTION</h2>
              <span className="text-xs font-sans text-slate-600">APPOINTMENT OF AUTHORISED BANKING SIGNATORIES</span>
            </div>

            <p className="text-justify">
              At a duly convened meeting of the Board of Directors, it was unanimously RESOLVED that the Company establish and maintain institutional banking facilities and that the following officers are authorised to execute transactions on behalf of the company:
            </p>

            <div className="space-y-3 font-sans text-xs">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded">
                <span className="font-bold text-slate-900 block mb-1">Authorised Signatory Group A:</span>
                <p className="text-slate-700">{document.ocrData?.['Authorised Signatory 1'] || 'Elena Rostova (Managing Director)'}</p>
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded">
                <span className="font-bold text-slate-900 block mb-1">Authorised Signatory Group B:</span>
                <p className="text-slate-700">{document.ocrData?.['Authorised Signatory 2'] || 'Michael Chen (Chief Financial Officer)'}</p>
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded">
                <span className="font-bold text-slate-900 block mb-1">Signing Mandate / Operational Matrix:</span>
                <p className="text-slate-700">{document.ocrData?.['Banking Mandate'] || 'Dual signatures required for transactions exceeding SGD 500,000 equivalent.'}</p>
              </div>
            </div>

            <div className="pt-6 flex justify-between items-end font-sans">
              <div>
                <div className="w-32 h-10 border-b border-slate-400 mb-1 flex items-center justify-center italic text-slate-400 text-xs">
                  Elena Rostova
                </div>
                <span className="text-[10px] text-slate-500 block font-bold">Elena Rostova, Managing Director</span>
              </div>
              <div>
                <div className="w-32 h-10 border-b border-slate-400 mb-1 flex items-center justify-center italic text-slate-400 text-xs">
                  Michael Chen
                </div>
                <span className="text-[10px] text-slate-500 block font-bold">Michael Chen, CFO & Secretary</span>
              </div>
            </div>
          </div>
        )}

        {isUbo && (
          <div className="space-y-5 text-sm leading-relaxed">
            <div className="text-center py-2 border-y border-slate-300">
              <h2 className="text-base font-bold text-slate-900 uppercase">REGISTER OF REGISTRABLE CONTROLLERS (RORC)</h2>
              <span className="text-xs font-sans text-slate-600">CONFIRMATION OF ULTIMATE BENEFICIAL OWNERSHIP</span>
            </div>

            <p className="text-xs text-justify font-sans text-slate-600">
              Pursuant to statutory regulatory mandates on anti-money laundering and corporate transparency, the following individual(s) hold significant interest (exceeding 25% voting power or ownership equity):
            </p>

            <table className="w-full text-left font-sans text-xs border border-slate-300">
              <thead className="bg-slate-100 border-b border-slate-300 text-slate-700">
                <tr>
                  <th className="p-2 border-r border-slate-300">Controller Name</th>
                  <th className="p-2 border-r border-slate-300">Equity / Voting %</th>
                  <th className="p-2">Nature of Control</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                <tr>
                  <td className="p-2 border-r border-slate-300 font-bold text-slate-900">
                    {document.ocrData?.['Primary Controller'] || 'Elena Rostova'}
                  </td>
                  <td className="p-2 border-r border-slate-300 font-mono font-bold text-emerald-800">
                    65.00%
                  </td>
                  <td className="p-2 text-slate-700">Direct Shareholding & Board Control</td>
                </tr>
                <tr>
                  <td className="p-2 border-r border-slate-300 font-bold text-slate-900">
                    {document.ocrData?.['Secondary Controller'] || 'Apex Capital Investments Ltd'}
                  </td>
                  <td className="p-2 border-r border-slate-300 font-mono text-slate-800">
                    35.00%
                  </td>
                  <td className="p-2 text-slate-700">Institutional Holding Entity</td>
                </tr>
              </tbody>
            </table>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded font-sans text-xs">
              <span className="font-bold text-slate-800 block">Filing Confirmation:</span>
              <p className="text-slate-600 text-[11px] mt-0.5">
                {document.ocrData?.['ACRA Filing Status'] || 'Lodged and verified in Electronic Register of Registrable Controllers (RORC)'}
              </p>
            </div>
          </div>
        )}

        {isFinancials && (
          <div className="space-y-4 text-sm">
            <div className="text-center py-2 border-y border-slate-300 font-sans">
              <h2 className="text-base font-bold text-slate-900">INDEPENDENT AUDITOR'S REPORT</h2>
              <span className="text-xs text-slate-600">FINANCIAL STATEMENTS FOR YEAR ENDED 31 DECEMBER 2025</span>
            </div>

            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded font-sans text-xs">
              <span className="font-bold text-emerald-900 block">Auditor Opinion:</span>
              <p className="text-emerald-800 text-[11px] mt-0.5">
                {document.ocrData?.['Audit Opinion'] || 'In our opinion, the financial statements present fairly, in all material respects, the financial position of the Group.'}
              </p>
              <span className="text-[10px] text-emerald-700 font-mono mt-1 block">Firm: {document.ocrData?.['Audit Firm'] || 'PricewaterhouseCoopers LLP'}</span>
            </div>

            <div className="font-sans text-xs space-y-2">
              <h3 className="font-bold text-slate-900">Key Financial Highlights (USD)</h3>
              <div className="grid grid-cols-3 gap-2">
                <div className="p-2.5 bg-slate-50 border border-slate-200 rounded">
                  <span className="text-[10px] text-slate-500 block">Total Revenue</span>
                  <span className="font-bold font-mono text-slate-900 text-sm">{document.ocrData?.['Total Revenue (FY2025)'] || '$42,500,000'}</span>
                </div>
                <div className="p-2.5 bg-slate-50 border border-slate-200 rounded">
                  <span className="text-[10px] text-slate-500 block">Net Profit Pre-Tax</span>
                  <span className="font-bold font-mono text-emerald-700 text-sm">{document.ocrData?.['Net Profit Before Tax'] || '$8,420,000'}</span>
                </div>
                <div className="p-2.5 bg-slate-50 border border-slate-200 rounded">
                  <span className="text-[10px] text-slate-500 block">Total Assets</span>
                  <span className="font-bold font-mono text-slate-900 text-sm">{document.ocrData?.['Total Assets'] || '$78,900,000'}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {isPassport && (
          <div className="space-y-5 text-sm">
            <div className="text-center py-2 border-y border-slate-300 font-sans">
              <h2 className="text-base font-bold text-slate-900">OFFICIAL PASSPORT & IDENTITY VERIFICATION</h2>
              <span className="text-xs text-slate-600">NOTARISED & CERTIFIED TRUE COPY</span>
            </div>

            <div className="p-4 bg-slate-50 border border-slate-300 rounded font-sans text-xs space-y-2">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-slate-500 block text-[10px]">Full Name:</span>
                  <span className="font-bold text-slate-900 text-sm">{document.ocrData?.['Full Name'] || 'Elena Rostova'}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">Passport No:</span>
                  <span className="font-bold font-mono text-slate-900 text-sm">{document.ocrData?.['Passport Number'] || 'E74920148'}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">Nationality:</span>
                  <span className="font-bold text-slate-800">{document.ocrData?.['Nationality'] || 'Singaporean'}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">Date of Birth / Expiry:</span>
                  <span className="font-bold text-slate-800">{document.ocrData?.['Date of Birth'] || '12 March 1982'} (Exp: {document.ocrData?.['Expiry Date'] || '2034'})</span>
                </div>
              </div>
            </div>

            <div className="p-3 bg-blue-50 border border-blue-200 rounded font-sans text-xs text-blue-900">
              <span className="font-bold block">Notary Certification:</span>
              <p className="text-[11px] text-blue-800 mt-0.5">
                {document.ocrData?.['Certification'] || 'Certified as a genuine and authentic photographic identity document.'}
              </p>
            </div>
          </div>
        )}

        {/* Fallback for general uploaded documents */}
        {!isIncorporation && !isBoardRes && !isUbo && !isFinancials && !isPassport && (
          <div className="space-y-4 text-sm font-sans">
            <div className="p-4 bg-slate-50 border border-slate-200 rounded space-y-2">
              <span className="font-bold text-slate-900 text-xs block uppercase">Document Metadata & Verification Record</span>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-slate-500 block text-[10px]">File Name:</span>
                  <span className="font-mono font-bold text-slate-800">{document.name}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">File Size:</span>
                  <span className="font-mono text-slate-800">{document.size}</span>
                </div>
              </div>
            </div>

            {document.ocrData && Object.keys(document.ocrData).length > 0 ? (
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-800">Extracted OCR Attributes:</span>
                <div className="divide-y divide-slate-200 border border-slate-200 rounded bg-white text-xs">
                  {Object.entries(document.ocrData).map(([k, v]) => (
                    <div key={k} className="p-2.5 flex justify-between items-center">
                      <span className="font-bold text-slate-700">{k}:</span>
                      <span className="font-mono text-slate-900 text-right">{v}</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="p-6 text-center text-slate-500 bg-slate-50 rounded border border-dashed border-slate-300">
                <FileText className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                <p className="text-xs">Standard scanned PDF container. OCR parsing completed.</p>
              </div>
            )}
          </div>
        )}

        {/* Footer Security Seal */}
        <div className="mt-12 pt-4 border-t border-slate-200 flex items-center justify-between text-[10px] font-sans text-slate-400">
          <span>Onboard.ai Secure Document Vault</span>
          <span className="flex items-center gap-1 font-mono">
            <Lock className="w-3 h-3 text-slate-400" /> Tamper-Evident SHA-256 Hash Verified
          </span>
        </div>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 overflow-hidden">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-6xl h-[92vh] rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-fade-in text-white">
        
        {/* Top Control Bar */}
        <div className="px-4 py-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="p-2 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 shrink-0">
              <FileText className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold text-white truncate" title={document.name}>
                  {document.name}
                </h2>
                <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase shrink-0 ${
                  document.status === 'verified' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                  document.status === 'rejected' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' :
                  'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                }`}>
                  {document.status}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-mono truncate">
                {document.type} • {document.size} • Ingested: {document.uploadedAt}
              </p>
            </div>
          </div>

          {/* View Tab Switcher */}
          <div className="hidden md:flex items-center gap-1 bg-slate-800/80 p-1 rounded-xl border border-slate-700/50">
            <button
              onClick={() => setActiveViewTab('preview')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                activeViewTab === 'preview' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Eye className="w-3.5 h-3.5" /> Document Preview
            </button>
            <button
              onClick={() => setActiveViewTab('ocr_data')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                activeViewTab === 'ocr_data' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5" /> Extracted Attributes ({document.ocrData ? Object.keys(document.ocrData).length : 0})
            </button>
          </div>

          {/* Controls: Zoom, Rotate, Close */}
          <div className="flex items-center gap-1.5 shrink-0">
            <div className="flex items-center bg-slate-800 rounded-xl p-0.5 border border-slate-700">
              <button
                onClick={handleZoomOut}
                disabled={zoomLevel <= 60}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-700 rounded-lg transition cursor-pointer disabled:opacity-40"
                title="Zoom Out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="text-[10px] font-mono font-bold px-2 text-slate-300">{zoomLevel}%</span>
              <button
                onClick={handleZoomIn}
                disabled={zoomLevel >= 200}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-700 rounded-lg transition cursor-pointer disabled:opacity-40"
                title="Zoom In"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
            </div>

            <button
              onClick={handleRotate}
              className="p-2 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 transition cursor-pointer"
              title="Rotate 90°"
            >
              <RotateCw className="w-4 h-4" />
            </button>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 transition cursor-pointer ml-1"
              title="Close Viewer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Security & Access Banner (Notice: No Download Allowed) */}
        <div className="bg-slate-950 px-4 py-1.5 border-b border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
          <div className="flex items-center gap-2">
            <Lock className="w-3.5 h-3.5 text-amber-400" />
            <span>Bank-Grade Read-Only Vault • Digital Watermarked • Direct Downloads Disabled for Compliance</span>
          </div>
          <span className="font-mono text-[10px] text-slate-500">Viewer Session Active</span>
        </div>

        {/* Main Body Area */}
        <div className="flex-1 overflow-hidden flex flex-col md:flex-row">
          
          {/* Document Content Canvas */}
          <div className="flex-1 bg-slate-950 overflow-y-auto p-4 sm:p-8 flex justify-center items-start relative">
            {activeViewTab === 'preview' ? (
              renderDocumentContent()
            ) : (
              <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 text-left">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <Layers className="w-4 h-4 text-blue-400" /> Extracted Key-Value OCR Attributes
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">High-confidence field mapping from the institutional parser</p>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    99.4% AI Match
                  </span>
                </div>

                {document.ocrData && Object.keys(document.ocrData).length > 0 ? (
                  <div className="space-y-2.5">
                    {Object.entries(document.ocrData).map(([key, val]) => (
                      <div key={key} className="p-3 bg-slate-800/80 border border-slate-700/60 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <span className="text-xs font-bold text-slate-300 font-mono">{key}</span>
                        <span className="text-xs font-medium text-white bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-700/80 max-w-md text-left sm:text-right">
                          {val}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="py-12 text-center text-slate-400">
                    <Layers className="w-8 h-8 mx-auto mb-2 text-slate-600" />
                    <p className="text-xs">No key-value OCR attributes found for this document.</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Right-Hand Document Information & Actions Panel (For RM and Compliance Ops) */}
          <div className="w-full md:w-80 bg-slate-900 border-t md:border-t-0 md:border-l border-slate-800 p-4 space-y-4 text-left overflow-y-auto shrink-0 flex flex-col justify-between">
            <div className="space-y-4">
              <div>
                <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Document Overview
                </span>
                <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700 space-y-2 text-xs">
                  <div>
                    <span className="text-slate-400 text-[10px] block">Document Type</span>
                    <span className="font-bold text-white">{document.type}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] block">Uploaded Date</span>
                    <span className="font-mono text-slate-200">{document.uploadedAt}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] block">Source Ingestion</span>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className={`inline-block px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase ${
                        document.source === 'externally_sourced' 
                          ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' 
                          : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                      }`}>
                        {document.source === 'externally_sourced' ? '🌐 Externally Sourced' : '👤 Customer Provided'}
                      </span>
                    </div>
                    {document.sourceDetails && (
                      <span className="text-[10px] text-slate-400 font-mono block mt-1 leading-tight">
                        {document.sourceDetails}
                      </span>
                    )}
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] block">Status</span>
                    <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase mt-0.5 ${
                      document.status === 'verified' ? 'bg-emerald-500/20 text-emerald-300' :
                      document.status === 'rejected' ? 'bg-rose-500/20 text-rose-300' :
                      'bg-amber-500/20 text-amber-300'
                    }`}>
                      {document.status}
                    </span>
                  </div>
                </div>
              </div>

              {/* Compliance & Verification Badge */}
              <div className="p-3.5 bg-blue-950/40 border border-blue-500/30 rounded-xl space-y-1.5 text-xs text-blue-200">
                <div className="flex items-center gap-1.5 font-bold text-blue-300">
                  <ShieldCheck className="w-4 h-4 text-blue-400" />
                  <span>Institutional Compliance Vault</span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Document rendered securely in real-time. Direct downloads are disabled to enforce security policies.
                </p>
              </div>

              {/* Reject Reason Dialog for RM/Compliance */}
              {showRejectInput && (
                <div className="p-3 bg-rose-950/40 border border-rose-500/30 rounded-xl space-y-2 text-xs">
                  <span className="font-bold text-rose-300 block">Provide Rejection Reason:</span>
                  <textarea
                    rows={2}
                    value={rejectionReason}
                    onChange={(e) => setRejectionReason(e.target.value)}
                    placeholder="e.g., Unclear signature, expired date..."
                    className="w-full p-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs outline-none focus:ring-1 focus:ring-rose-500 resize-none"
                  />
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setShowRejectInput(false)}
                      className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => {
                        handleReject(rejectionReason);
                        setShowRejectInput(false);
                      }}
                      className="px-3 py-1 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded text-xs cursor-pointer"
                    >
                      Confirm Reject
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Action Buttons for RM / Compliance */}
            {!readOnly && (userRole === 'rm' || userRole === 'compliance') && (
              <div className="pt-3 border-t border-slate-800 space-y-2">
                <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block">
                  Staff Actions ({userRole.toUpperCase()})
                </span>
                <div className="flex flex-col gap-2">
                  <button
                    onClick={handleApprove}
                    className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow transition flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Approve Document
                  </button>

                  <button
                    onClick={() => setShowRejectInput(true)}
                    className="w-full py-2 bg-slate-800 hover:bg-rose-900/60 hover:text-rose-200 text-slate-300 font-bold text-xs rounded-xl border border-slate-700 transition flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <AlertTriangle className="w-4 h-4 text-rose-400" />
                    Reject / Request Re-upload
                  </button>
                </div>
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
}
