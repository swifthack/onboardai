import React from 'react';
import { LogOut } from 'lucide-react';
import { AppPersona } from '../../types';
import { PERSONA_TABS } from '../../constants/personaTabs';

interface SidebarProps {
  activePersona: AppPersona;
  currentPersonaInfo?: { name: string; role: string };
  activeTab: string;
  setActiveTab: (tabId: string) => void;
  onSwitchPersona: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activePersona,
  activeTab,
  setActiveTab,
  onSwitchPersona,
}) => {
  const activeTabsList = PERSONA_TABS[activePersona] || [];

  return (
    <aside className="w-full md:w-68 lg:w-72 bg-[#0B2545] text-[#00A3E0] flex flex-col shrink-0 border-b md:border-b-0 md:border-r border-[#00A3E0]/20 shadow-xl z-20">
      {/* Sidebar Brand Logo */}
      <div className="p-5 border-b border-[#00A3E0]/20 flex items-center gap-2.5 bg-[#002D62]">
        <div className="p-2 bg-[#008752] rounded-lg text-white flex items-center justify-center font-black shadow-sm tracking-tighter w-8 h-8">
          O
        </div>
        <div>
          <h2 className="font-bold text-sm tracking-tight text-white">Onboard.ai</h2>
          <span className="text-[9px] font-bold text-[#00A3E0] tracking-wider block uppercase font-mono">
            {activePersona === 'platform_admin' ? 'Admin Control Plane' : 
             activePersona === 'rm' ? 'RM Cockpit Node' :
             activePersona === 'compliance_officer' ? 'Compliance Gateway' :
             activePersona === 'operations_officer' ? 'Ops Review Hub' : 'System Node'}
          </span>
        </div>
      </div>

      {/* Dynamic Sidebar Navigation Links based on active persona */}
      <nav className="flex-1 p-4 space-y-1.5 bg-[#0B2545]">
        <span className="text-[9px] font-bold font-mono text-[#00A3E0]/80 uppercase tracking-widest block pl-2 mb-2">
          ORGANIZATION NODE
        </span>

        {activeTabsList.map(tab => {
          const IconComponent = tab.icon;
          const isSelected = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center justify-start text-left gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 cursor-pointer ${
                isSelected 
                  ? 'bg-[#008752] text-white shadow-md font-bold border border-[#008752]' 
                  : 'text-[#F4F6F8]/90 hover:text-white hover:bg-[#002D62]/60'
              }`}
            >
              <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-white bg-[#002D62] border border-[#00A3E0]/30 shadow-sm shrink-0 ${
                isSelected ? 'scale-105 bg-[#008752]' : 'opacity-80'
              }`}>
                <IconComponent className="w-3.5 h-3.5" />
              </div>
              <span className="text-left flex-1 leading-snug">{tab.label}</span>
            </button>
          );
        })}

        <div className="pt-6">
          <span className="text-[9px] font-bold font-mono text-[#00A3E0]/80 uppercase tracking-widest block pl-2 mb-2">
            SESSION CONTROL
          </span>
          <button
            type="button"
            onClick={onSwitchPersona}
            className="w-full flex items-center justify-start text-left gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-[#F4F6F8]/80 hover:text-rose-300 hover:bg-rose-900/30 transition cursor-pointer"
          >
            <div className="w-7 h-7 rounded-lg flex items-center justify-center bg-[#002D62] border border-[#00A3E0]/30 shadow-sm shrink-0">
              <LogOut className="w-3.5 h-3.5 text-[#00A3E0]" />
            </div>
            <span className="text-left flex-1">Logout</span>
          </button>
        </div>
      </nav>

      {/* Sidebar Footer */}
      <div className="p-4 border-t border-[#00A3E0]/20 text-[10px] font-mono text-[#00A3E0] bg-[#0B2545] hidden md:block">
        <p>COCKPIT PROTOCOL</p>
        <p className="text-white mt-0.5">VAULT LEV 4 • ACTIVE</p>
      </div>
    </aside>
  );
};

export default Sidebar;
