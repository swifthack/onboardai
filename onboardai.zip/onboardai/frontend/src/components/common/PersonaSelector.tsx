import React from 'react';
import { PERSONAS } from '../../mockData';
import { AppPersona } from '../../types';
import { getDeploymentMode, getVisiblePersonas } from '../../config/deploymentMode';
import {
  Settings,
  Briefcase,
  Shield,
  Bot,
  Fingerprint,
  ClipboardList
} from 'lucide-react';
import { motion } from 'motion/react';

interface PersonaSelectorProps {
  onSelect: (persona: AppPersona) => void;
  activePersona: AppPersona | null;
  onOpenAgentGenerator?: () => void;
}

const PERSONA_ICONS: Record<AppPersona, React.ReactNode> = {
  platform_admin: <Settings className="w-5 h-5" />,
  rm: <Briefcase className="w-5 h-5" />,
  compliance_officer: <Shield className="w-5 h-5" />,
  operations_officer: <ClipboardList className="w-5 h-5" />,
  customer: <Fingerprint className="w-5 h-5" />
};

export default function PersonaSelector({ onSelect, activePersona }: PersonaSelectorProps) {
  const deploymentMode = getDeploymentMode();
  const isDesign = deploymentMode === 'design';
  const visiblePersonas = getVisiblePersonas(PERSONAS);

  return (
    <div className="min-h-screen bg-[#262B40] text-white flex flex-col justify-between p-6 md:p-12 relative overflow-hidden font-sans">
      {/* Decorative dynamic ambient background shapes */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#06457F]/30 rounded-full blur-3xl animate-pulse pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#2C444C]/30 rounded-full blur-3xl animate-pulse delay-700 pointer-events-none" />

      {/* Top logo & branding */}
      <header className="z-10 flex items-center justify-between w-full max-w-6xl mx-auto border-b border-[#2C444C] pb-5">
        <div className="flex items-center gap-2.5">
          <div className="h-7 w-7 rounded bg-[#0474C4] flex items-center justify-center font-bold text-white text-base tracking-tighter shadow-sm">
            O
          </div>
          <span className="font-bold text-lg tracking-tight text-white">
            Onboard.ai
          </span>
        </div>
      </header>

      {/* Main content */}
      <main className="my-auto z-10 w-full max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center py-12">
        <div className="lg:col-span-5 space-y-6 text-left">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#06457F]/80 border border-[#5379AE]/40 text-xs font-mono text-[#A8C4EC]">
            <Bot className="w-3.5 h-3.5 text-[#0474C4]" />
            <span>{isDesign ? 'AgenticStudio · Design Console' : 'Banking Automation Core'}</span>
          </div>

          <h1 className="text-4xl md:text-5xl font-black tracking-tight text-white leading-tight">
            {isDesign ? (
              <>Design and govern the <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#A8C4EC] via-white to-[#0474C4]">agent mesh</span> that powers onboarding.</>
            ) : (
              <>Automating customer onboarding with <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#A8C4EC] via-white to-[#0474C4]">collaborative AI agents</span>.</>
            )}
          </h1>

          <p className="text-[#A8C4EC] text-sm md:text-base leading-relaxed font-medium">
            {isDesign
              ? 'Author agents, pipelines, guardrails, the API catalog, and MCP gateways here — the same configuration the execution environment runs against.'
              : 'Configure multi-agent decision systems, verify corporate registries, audit biometric and AML risks, and design policy journeys from a secure, single console.'}
          </p>
        </div>

        {/* Right card picker column (White Middle Panel) */}
        <div className="lg:col-span-7 bg-white text-[#262B40] border border-[#A8C4EC]/60 rounded-2xl p-6 md:p-8 space-y-6 shadow-2xl">
          <div className="text-left">
            <h2 className="text-xl font-bold text-[#262B40] tracking-tight">
              {isDesign ? 'Sign in to AgenticStudio' : 'Sign in to Onboard.ai'}
            </h2>
            <p className="text-[#5379AE] text-xs mt-1">
              {isDesign
                ? 'This design environment is for Platform Admin only — the other personas run in the execution environment.'
                : 'Select your designated organizational persona to launch your session.'}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {visiblePersonas.map((p, idx) => {
              const isSelected = activePersona === p.id;
              return (
                <motion.div
                  key={p.id}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  onClick={() => onSelect(p.id)}
                  className={`flex flex-col text-left border rounded-xl p-4.5 cursor-pointer transition-all duration-200 select-none group relative ${
                    isSelected 
                      ? 'border-[#0474C4] ring-2 ring-[#0474C4]/30 bg-[#F0F4FA] shadow-md' 
                      : 'border-[#A8C4EC]/60 bg-white hover:border-[#0474C4]/60 hover:bg-[#F0F4FA]/50 shadow-sm'
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className={`p-2 rounded-lg transition-all border ${
                      isSelected 
                        ? 'bg-[#0474C4] text-white border-[#0474C4]' 
                        : 'bg-[#F0F4FA] text-[#06457F] border-[#A8C4EC]/60 group-hover:text-white group-hover:bg-[#0474C4] group-hover:border-[#0474C4]'
                    }`}>
                      {PERSONA_ICONS[p.id]}
                    </div>
                    <span className="text-[10px] font-bold font-mono text-[#5379AE] tracking-wider group-hover:text-[#0474C4] transition-colors uppercase">
                      SELECT →
                    </span>
                  </div>

                  <h3 className="font-bold text-[#262B40] text-sm tracking-tight mb-1 group-hover:text-[#0474C4] transition-colors flex items-center gap-1.5">
                    {p.name}
                  </h3>
                  <p className="text-[11px] text-[#5379AE] leading-normal font-medium">
                    {p.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </main>
    </div>
  );
}
