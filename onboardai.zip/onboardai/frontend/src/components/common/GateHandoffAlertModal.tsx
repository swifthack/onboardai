import React from 'react';
import { ArrowRightCircle, X } from 'lucide-react';

interface GateHandoffAlertModalProps {
  alert: { clientName: string; nodeName: string; reviewerLabel: string } | null;
  onClose: () => void;
}

// Purely informational — the real gate is enforced elsewhere (NodeDetail's
// isApproveDisabled/canDirectNode). This just makes the review-gate handoff
// visible in a live demo: whenever the autonomous engine pauses a node for
// a different persona to sign off, this pops up to announce it.
export function GateHandoffAlertModal({ alert, onClose }: GateHandoffAlertModalProps) {
  if (!alert) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
      <div className="bg-white border border-slate-200 rounded-2xl shadow-2xl max-w-md w-full overflow-hidden">
        <div className="p-5 flex items-start gap-3 border-b border-slate-100">
          <div className="p-2 bg-blue-50 text-[#0474C4] rounded-xl shrink-0">
            <ArrowRightCircle className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <h3 className="text-sm font-extrabold text-[#262B40]">Handed Off for Review</h3>
            <p className="text-xs text-[#5379AE] mt-0.5">{alert.clientName}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-3">
          <p className="text-sm text-slate-700 leading-relaxed">
            <strong className="font-bold">{alert.nodeName}</strong> has completed automated processing and is now
            paused, waiting for review.
          </p>
          <div className="p-3 bg-blue-50/70 border border-blue-100 rounded-xl">
            <p className="text-xs text-blue-900 leading-relaxed">
              This step has been assigned to <strong className="font-bold">{alert.reviewerLabel}</strong> for review
              and approval. The workflow will resume automatically once they sign off.
            </p>
          </div>
        </div>

        <div className="p-4 bg-slate-50 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="w-full py-2.5 bg-[#0474C4] hover:bg-[#0463a8] text-white font-bold rounded-lg text-xs transition cursor-pointer"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
}
