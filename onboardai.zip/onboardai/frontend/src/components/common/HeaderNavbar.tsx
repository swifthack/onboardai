import React from 'react';
import { 
  Search, 
  Bell, 
  Mail, 
  X, 
  Lock, 
  LogOut, 
  ExternalLink, 
  User,
  LayoutDashboard,
  Compass,
  Activity,
  Users,
  Building2,
  ChevronDown
} from 'lucide-react';
import { AppPersona, ClientProfile, SystemNotification } from '../../types';
import { PERSONA_TABS } from '../../constants/personaTabs';

export interface SentEmailItem {
  id: string;
  clientName: string;
  email: string;
  subject: string;
  body: string;
  date: string;
  clientId: string;
  status: 'sent' | 'delivered' | 'opened' | 'clicked';
  sentAt?: string;
  deliveredAt?: string;
  openedAt?: string;
  clickedAt?: string;
}

interface HeaderNavbarProps {
  activeTabLabel: string;
  activeTab?: string;
  setActiveTab?: (tabId: string) => void;
  sentEmails: SentEmailItem[];
  showSimulatedMailbox: boolean;
  setShowSimulatedMailbox: (show: boolean) => void;
  setSentEmails: React.Dispatch<React.SetStateAction<SentEmailItem[]>>;
  activePersona: AppPersona;
  currentPersonaInfo: { name: string; role: string };
  showRmCopilot: boolean;
  setShowRmCopilot: (show: boolean) => void;
  onLogout: () => void;
  onSelectPersona?: (persona: AppPersona) => void;
  setSelectedClientId: (id: string) => void;
  systemNotifications?: SystemNotification[];
  activeClient?: ClientProfile;
  clients?: ClientProfile[];
  onSelectClient?: (clientId: string) => void;
}

export const HeaderNavbar: React.FC<HeaderNavbarProps> = ({
  activeTabLabel,
  activeTab,
  setActiveTab,
  sentEmails,
  showSimulatedMailbox,
  setShowSimulatedMailbox,
  setSentEmails,
  activePersona,
  currentPersonaInfo,
  showRmCopilot,
  setShowRmCopilot,
  onLogout,
  onSelectPersona,
  setSelectedClientId,
  systemNotifications = [],
  activeClient,
  clients = [],
  onSelectClient
}) => {
  const unreadNotifCount = systemNotifications.filter(n => !n.actioned).length;

  const journeyNavigationShortcuts = [
    { 
      id: activePersona === 'compliance_officer' ? 'review_queue' : activePersona === 'operations_officer' ? 'ops_queue' : 'my_pipeline', 
      label: 'My Pipeline', 
      icon: LayoutDashboard 
    },
    { 
      id: 'journey_workspace', 
      label: 'Journey Workspace', 
      icon: Compass 
    },
    { 
      id: 'digital_twin', 
      label: 'Digital Twin Explorer', 
      icon: Activity 
    },
    { 
      id: 'customer_360', 
      label: 'Customer 360', 
      icon: Users 
    }
  ];

  return (
    <header className="relative z-40 w-full bg-[#1a3070] border-b border-[#00A3E0]/30 shadow-md text-white px-4 md:px-6 py-2.5 transition-all duration-200">
      <div className="flex flex-col lg:flex-row items-center justify-between gap-3">
        {/* Left side: Brand Logo & Current View Title */}
        <div className="flex items-center gap-3 text-left self-start lg:self-center shrink-0">
          {activePersona !== 'platform_admin' && (
            <div className="flex items-center gap-2 pr-2 border-r border-[#00A3E0]/30">
              <div className="p-1.5 bg-[#008752] rounded-lg text-white flex items-center justify-center font-black shadow-sm tracking-tighter w-7 h-7 text-xs">
                O
              </div>
              <span className="font-bold text-sm text-white tracking-tight">
                Onboard.ai
              </span>
            </div>
          )}
          <div>
            <span className="text-[10px] font-mono tracking-wider text-[#00A3E0] uppercase font-bold">
              Pages / {activeTabLabel}
            </span>
            <h1 className="text-sm font-bold tracking-tight text-white mt-0.5">
              {activeTabLabel}
            </h1>
          </div>
        </div>

        {/* Center: Selected Journey & 5 Navigation Shortcuts */}
        {activeClient && activePersona !== 'platform_admin' && activePersona !== 'customer' && (
          <nav className="flex items-center gap-2 overflow-x-auto py-1 px-2.5 bg-[#0B2545]/90 border border-[#00A3E0]/40 rounded-2xl max-w-full scrollbar-none shadow-inner my-1 lg:my-0">
            {/* Active Selected Journey Selector */}
            <div className="flex items-center gap-1.5 pr-2.5 border-r border-[#00A3E0]/30 shrink-0">
              <div className="p-1 rounded-md bg-sky-500/20 text-sky-400">
                <Building2 className="w-3.5 h-3.5" />
              </div>
              <div className="flex flex-col text-left">
                <span className="text-[8px] font-mono text-[#00A3E0] font-bold uppercase tracking-wider leading-tight">
                  Active Journey
                </span>
                {clients && clients.length > 1 ? (
                  <select
                    value={activeClient.id}
                    onChange={(e) => {
                      if (onSelectClient) onSelectClient(e.target.value);
                      else if (setSelectedClientId) setSelectedClientId(e.target.value);
                    }}
                    className="bg-transparent text-white font-bold text-xs outline-none cursor-pointer pr-1 truncate max-w-[130px] sm:max-w-[160px]"
                    title="Switch Active Client Journey"
                  >
                    {clients.map((c) => (
                      <option key={c.id} value={c.id} className="bg-[#0B2545] text-white">
                        {c.companyName}
                      </option>
                    ))}
                  </select>
                ) : (
                  <span className="text-xs font-bold text-white truncate max-w-[140px]">
                    {activeClient.companyName}
                  </span>
                )}
              </div>
            </div>

            {/* 5 Requested Navigation Shortcuts */}
            <div className="flex items-center gap-1 shrink-0">
              {journeyNavigationShortcuts.map((shortcut) => {
                const IconComponent = shortcut.icon;
                const isSelected = activeTab === shortcut.id;
                return (
                  <button
                    key={shortcut.id}
                    onClick={() => setActiveTab && setActiveTab(shortcut.id)}
                    className={`px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer shrink-0 ${
                      isSelected
                        ? 'bg-[#008752] text-white shadow-md border border-[#008752] ring-1 ring-white/20'
                        : 'text-slate-200 hover:text-white hover:bg-[#002D62] border border-transparent hover:border-[#00A3E0]/30'
                    }`}
                    title={`Navigate to ${shortcut.label}`}
                  >
                    <IconComponent className={`w-3.5 h-3.5 ${isSelected ? 'text-white' : 'text-[#00A3E0]'}`} />
                    <span>{shortcut.label}</span>
                  </button>
                );
              })}
            </div>
          </nav>
        )}

        {/* Right side: controls, notifications, user info */}
        <div className="flex items-center gap-2.5 self-end lg:self-center shrink-0 flex-wrap">
          {/* Search input */}
          <div className="relative w-32 sm:w-40 md:w-48 hidden xl:block">
            <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-[#00A3E0]" />
            <input
              type="text"
              placeholder="Search..."
              className="w-full bg-[#0B2545]/60 border border-[#00A3E0]/40 rounded-xl pl-9 pr-4 py-1.5 text-xs outline-none text-white placeholder-[#F4F6F8]/70 focus:ring-1 focus:ring-[#00A3E0] transition-all duration-150"
              disabled
            />
          </div>

          <div className="h-4 w-px bg-[#00A3E0]/30 hidden sm:block" />

          {/* Notifications Bell Icon Button */}
          {activePersona !== 'admin' && activePersona !== 'platform_admin' && (
            <button
              id="btn-header-notifications"
              type="button"
              onClick={() => setActiveTab && setActiveTab('notifications')}
              className={`relative p-2 rounded-xl border transition cursor-pointer flex items-center justify-center shadow-sm ${
                activeTab === 'notifications'
                  ? 'bg-[#008752] text-white border-[#008752]'
                  : 'bg-[#0B2545] text-[#00A3E0] hover:text-white border-[#00A3E0]/40'
              }`}
              title={`Notifications (${unreadNotifCount} unread)`}
              aria-label="Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadNotifCount > 0 && (
                <span className="absolute -top-1 -right-1 px-1.5 py-0.2 bg-[#EB001B] text-[9px] font-black text-white rounded-full min-w-4 text-center">
                  {unreadNotifCount}
                </span>
              )}
            </button>
          )}

          <div className="h-4 w-px bg-[#00A3E0]/30" />

          {/* User Profile Icon */}
          <div
            className="p-2 rounded-xl bg-[#0B2545] text-[#00A3E0] hover:text-white border border-[#00A3E0]/40 flex items-center justify-center shadow-sm transition"
            title={`Profile: ${currentPersonaInfo.name} (${currentPersonaInfo.role})`}
            aria-label="User Profile"
          >
            <User className="w-4 h-4" />
          </div>

          {/* Logout Button */}
          <button
            type="button"
            onClick={onLogout}
            className="p-2 rounded-xl text-white bg-rose-600 hover:bg-rose-700 border border-rose-500/50 shadow-sm transition flex items-center justify-center cursor-pointer"
            title="Log out of current session"
            aria-label="Logout"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};

export default HeaderNavbar;
