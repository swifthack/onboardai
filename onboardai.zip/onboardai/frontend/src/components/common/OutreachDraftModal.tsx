import React, { useState, useEffect } from 'react';
import { Mail, Send, X, Sparkles, Shield } from 'lucide-react';
import { ClientProfile } from '../../types';

interface OutreachDraftModalProps {
  isOpen: boolean;
  client: ClientProfile | null;
  activePersona?: string;
  onClose: () => void;
  onSend: (emailData: {
    clientId: string;
    clientName: string;
    email: string;
    subject: string;
    body: string;
  }) => void;
}

export function OutreachDraftModal({ isOpen, client, activePersona, onClose, onSend }: OutreachDraftModalProps) {
  const isComplianceOfficer = activePersona === 'compliance_officer';

  const defaultRecipient = isComplianceOfficer
    ? 'relationship.manager@onboard.ai'
    : (client?.authorizedRepresentative?.email || 'representative@company.com');

  const defaultSubject = isComplianceOfficer
    ? `[Compliance Query] Onboarding Risk Review & Documentation Notice - ${client?.companyName || ''}`
    : `Action Required: Complete Secure Corporate Onboarding for ${client?.companyName || ''}`;

  const defaultBody = isComplianceOfficer
    ? `Hello Relationship Manager,\n\nI have completed the compliance & risk evaluation for "${client?.companyName || 'Corporate Client'}".\n\nPlease review the highlighted verification items, UBO register entries, and risk factors with the client before final signoff.\n\nBest regards,\nCompliance & Risk Officer\nOnboard.ai Risk & Compliance Division`
    : `Hello ${client?.authorizedRepresentative?.name || 'Representative'},\n\nOur Relationship Management team at Onboard.ai Bank has initiated your digital onboarding journey for "${client?.companyName || 'Corporate Client'}".\n\nTo securely complete the onboarding setup, please register/log in to our secure platform, verify your corporate identities using Singpass MyInfo or India Aadhaar/PAN Stack, and upload the required corporate files.\n\nBest regards,\nOnboard.ai Digital Onboarding Team`;

  const [recipient, setRecipient] = useState(defaultRecipient);
  const [subject, setSubject] = useState(defaultSubject);
  const [body, setBody] = useState(defaultBody);
  const [isSending, setIsSending] = useState(false);

  useEffect(() => {
    if (client) {
      setRecipient(isComplianceOfficer ? 'relationship.manager@onboard.ai' : (client.authorizedRepresentative?.email || 'representative@company.com'));
      setSubject(isComplianceOfficer ? `[Compliance Query] Onboarding Risk Review & Documentation Notice - ${client.companyName}` : `Action Required: Complete Secure Corporate Onboarding for ${client.companyName}`);
      setBody(isComplianceOfficer
        ? `Hello Relationship Manager,\n\nI have completed the compliance & risk evaluation for "${client.companyName}".\n\nPlease review the highlighted verification items, UBO register entries, and risk factors with the client before final signoff.\n\nBest regards,\nCompliance & Risk Officer\nOnboard.ai Risk & Compliance Division`
        : `Hello ${client.authorizedRepresentative?.name || 'Representative'},\n\nOur Relationship Management team at Onboard.ai Bank has initiated your digital onboarding journey for "${client.companyName}".\n\nTo securely complete the onboarding setup, please register/log in to our secure platform, verify your corporate identities using Singpass MyInfo or India Aadhaar/PAN Stack, and upload the required corporate files.\n\nBest regards,\nOnboard.ai Digital Onboarding Team`
      );
    }
  }, [client, isComplianceOfficer]);

  if (!isOpen || !client) return null;

  const handleApproveAndSend = () => {
    setIsSending(true);
    setTimeout(() => {
      onSend({
        clientId: client.id,
        clientName: client.companyName,
        email: recipient,
        subject: subject,
        body: body,
      });
      setIsSending(false);
      onClose();
    }, 300);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 animate-fadeIn">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl max-w-2xl w-full overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-indigo-900 to-slate-900 text-white flex items-center justify-between border-b border-indigo-800/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600/80 border border-indigo-400/30 flex items-center justify-center text-white shadow-inner">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white tracking-tight">
                  {isComplianceOfficer ? 'Draft Compliance Query to RM' : 'Draft Outreach Email'}
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-indigo-500/30 border border-indigo-400/40 text-indigo-200 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-amber-300" /> AI Draft
                </span>
              </div>
              <p className="text-xs text-indigo-200/80">
                {isComplianceOfficer 
                  ? 'Review and verify the compliance query / risk escalation notice to the Relationship Manager.'
                  : 'Review and verify the automated client onboarding outreach before sending.'}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs">
          <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/80 rounded-xl flex items-start gap-2.5 text-amber-900 dark:text-amber-300">
            <Shield className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-xs">Verification Required</p>
              <p className="text-[11px] opacity-90 mt-0.5">
                {isComplianceOfficer 
                  ? 'Please review the email content and recipient address before approving. Once sent, this inquiry will be logged and dispatched to the assigned RM inbox.'
                  : 'Please verify recipient details and subject line before approval. Once approved, the outreach package will be dispatched to the client inbox.'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-mono font-bold text-slate-600 dark:text-slate-400 uppercase mb-1">
                Target Company
              </label>
              <input
                type="text"
                disabled
                value={client.companyName}
                className="w-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 rounded-lg p-2.5 font-medium cursor-not-allowed"
              />
            </div>

            <div>
              <label className="block text-[11px] font-mono font-bold text-slate-600 dark:text-slate-400 uppercase mb-1">
                Recipient Email
              </label>
              <input
                type="email"
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-lg p-2.5 font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-mono font-bold text-slate-600 dark:text-slate-400 uppercase mb-1">
              Email Subject Line
            </label>
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-lg p-2.5 font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-mono font-bold text-slate-600 dark:text-slate-400 uppercase mb-1">
              Outreach Body Content
            </label>
            <textarea
              rows={7}
              value={body}
              onChange={(e) => setBody(e.target.value)}
              className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-lg p-3 font-mono text-xs leading-relaxed focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            />
          </div>
        </div>

        {/* Footer actions */}
        <div className="px-6 py-4 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <span className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
            Status: <strong className="text-amber-600 dark:text-amber-400">Awaiting Verification</strong>
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              disabled={isSending}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition cursor-pointer"
            >
              Cancel / Discard
            </button>
            <button
              onClick={handleApproveAndSend}
              disabled={isSending || !recipient || !subject}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold rounded-lg shadow-sm transition flex items-center gap-2 cursor-pointer"
            >
              <Send className="w-4 h-4" />
              {isSending ? 'Dispatching...' : 'Approve & Send Email'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
