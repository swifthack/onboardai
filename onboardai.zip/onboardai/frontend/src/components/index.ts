// Common components
export { default as PersonaSelector } from './common/PersonaSelector';
export { default as DemoScriptModal } from './common/DemoScriptModal';
export { default as CustomerLoginGate } from './common/CustomerLoginGate';
export { default as Sidebar } from './common/Sidebar';
export { default as HeaderNavbar } from './common/HeaderNavbar';
export * from './common/PersonaSubviews';

// Dashboard components
export { default as AdminDashboard } from './dashboard/AdminDashboard';
export { default as CustomerDashboard } from './dashboard/CustomerDashboard';
export { default as Customer360View } from './dashboard/Customer360View';

// Workflow components
export { default as WorkflowGraph } from './workflow/WorkflowGraph';
export { default as NodeDetail } from './workflow/NodeDetail';
export { default as AgentOrchestrator } from './workflow/AgentOrchestrator';
export { default as DigitalTwinExplorer } from './workflow/DigitalTwinExplorer';
export { default as JourneyInitiator } from './workflow/JourneyInitiator';
export { default as ClientCreator } from './workflow/ClientCreator';
export { default as JourneyWorkspace } from './workflow/JourneyWorkspace';
export { default as AgentGeneratorView } from './workflow/AgentGeneratorView';

// Copilot components
export { default as CopilotChatPanel } from './copilot/CopilotChatPanel';
export { default as CustomerCopilot } from './copilot/CustomerCopilot';

// Verification & Manager components
export { default as AgentManager } from './verification/AgentManager';

// Operations components
export { OperationsHub } from './operations/OperationsHub';

// Admin Architecture components
export { default as GuardrailsView } from './admin/GuardrailsView';
export { default as McpGatewayView } from './admin/McpGatewayView';
export { default as ApiCatalogView } from './admin/ApiCatalogView';

