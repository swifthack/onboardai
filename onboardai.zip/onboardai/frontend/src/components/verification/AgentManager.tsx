import React, { useState, useMemo } from 'react';
import { 
  Bot, 
  Plus, 
  Search, 
  Sparkles, 
  Cpu,
  Server,
  X,
  ShieldCheck,
  Zap,
  Power,
  Database,
  Link2,
  Sliders,
  TrendingUp,
  Clock,
  Coins,
  Activity,
  FileCode,
  ChevronRight,
  Edit2,
  Trash2,
  ToggleLeft,
  ToggleRight,
  Check,
  PlusCircle,
  HelpCircle,
  ArrowRight,
  Lock,
  Globe,
  FileText,
  Code,
  Network,
  ShoppingBag
} from 'lucide-react';
import { OrchestrationAgent } from '../../types';
import { motion, AnimatePresence } from 'motion/react';
import { McpServersView, MarketplaceView } from '../common/PersonaSubviews';
import { DeleteConfirmModal } from '../common/DeleteConfirmModal';

// Default Guardrails configuration presets
const DEFAULT_GUARDRAILS = {
  inputGuardrails: {
    piiMasking: true,
    profanityFilter: true,
    sqlInjectionPrevention: true,
    allowedLanguages: ['English', 'Spanish', 'Mandarin']
  },
  promptGuardrails: {
    jailbreakProtection: true,
    systemPromptEnforcement: true,
    maxPromptTokens: 4096
  },
  retrievalGuardrails: {
    minRelevanceScore: 0.75,
    maxRetrievalDocuments: 5,
    vectorSearchFilter: 'metadata.category == active'
  },
  toolGuardrails: {
    approvedToolsOnly: true,
    sandboxedExecution: true,
    requireApprovalForDestructive: true
  },
  outputGuardrails: {
    pciDssCompliance: true,
    hallucinationCheck: true,
    regexEnforcement: ''
  },
  runtimeGuardrails: {
    maxConcurrency: 10,
    fallbackAgentId: 'rm_copilot_agent',
    alertOnAnomaly: true
  },
  memoryGuardrails: {
    shortTermMemoryLimit: 20,
    vectorMemoryEnabled: true,
    dataRetentionDays: 30
  },
  tokenomicsTimeout: {
    maxTokensPerCall: 8192,
    dailySpendLimitUsd: 5.0,
    timeoutMs: 30000
  }
};

interface AgentManagerProps {
  agents: OrchestrationAgent[];
  setAgents: React.Dispatch<React.SetStateAction<OrchestrationAgent[]>>;
}

export default function AgentManager({ agents, setAgents }: AgentManagerProps) {
  // Registry view subtab (Directory, MCP Gateway, Agent Marketplace)
  const [registrySubTab, setRegistrySubTab] = useState<'directory' | 'mcp_servers' | 'marketplace'>('directory');

  // Filters & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [colFilters, setColFilters] = useState({
    name: '',
    version: 'all',
    owner: 'all',
    model: 'all',
    status: 'all',
    updated: ''
  });

  // Unique options for column-level filters
  const uniqueVersions = useMemo(() => {
    return Array.from(new Set(agents.map(a => a.version || 'v1.0.0'))).filter(Boolean).sort();
  }, [agents]);

  const uniqueOwners = useMemo(() => {
    return Array.from(new Set(agents.map(a => a.owner || 'Internal Ops'))).filter(Boolean).sort();
  }, [agents]);

  const uniqueModels = useMemo(() => {
    return Array.from(new Set(agents.map(a => a.model || 'Claude 3.5 Sonnet'))).filter(Boolean).sort();
  }, [agents]);

  const hasActiveFilters = useMemo(() => {
    return searchTerm !== '' || 
      colFilters.name !== '' || 
      colFilters.version !== 'all' || 
      colFilters.owner !== 'all' || 
      colFilters.model !== 'all' || 
      colFilters.status !== 'all' || 
      colFilters.updated !== '';
  }, [searchTerm, colFilters]);

  const handleResetFilters = () => {
    setSearchTerm('');
    setColFilters({
      name: '',
      version: 'all',
      owner: 'all',
      model: 'all',
      status: 'all',
      updated: ''
    });
  };

  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;
  const topFormRef = React.useRef<HTMLDivElement>(null);

  // Delete Confirmation Dialog State
  const [agentToDelete, setAgentToDelete] = useState<OrchestrationAgent | null>(null);

  // Selected agent for Drawer Details
  const [selectedAgent, setSelectedAgent] = useState<OrchestrationAgent | null>(null);
  const [drawerMode, setDrawerMode] = useState<'view' | 'edit' | 'create'>('view');

  React.useEffect(() => {
    if (selectedAgent || drawerMode === 'create') {
      setTimeout(() => {
        topFormRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
    }
  }, [selectedAgent, drawerMode]);
  const [activeTab, setActiveTab] = useState<'overview' | 'guardrails' | 'tools' | 'policies' | 'schema' | 'a2a' | 'metrics'>('overview');

  // Interactive inline tool state inside drawer
  const [isAttachingMcp, setIsAttachingMcp] = useState(false);
  const [newMcpUrl, setNewMcpUrl] = useState('');
  const [newMcpSource, setNewMcpSource] = useState('');

  // Drawer Form Data
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: 'Identity & Compliance',
    isEnabled: true,
    agentClass: 'normal' as 'super' | 'normal',
    usesGoogleProtocol: true,
    mcpServerUrl: '',
    mcpApisInput: '',
    mcpConnectedSourcesInput: '',
    subAgentsInput: '',
    version: 'v1.0.0',
    owner: 'Compliance Tech',
    model: 'Claude 3.5 Sonnet',
    riskLevel: 'Low' as 'Low' | 'Medium' | 'High',
    status: 'Active' as 'Active' | 'Deprecated' | 'Draft',
    inputSchema: '',
    outputSchema: '',
    canBeAskedByInput: '',
    canAskInput: '',
    permissions: [] as string[],
    policies: [] as string[],
    avgLatency: '250ms',
    successRate: '99.5%',
    avgCost: '$0.0015'
  });

  // Filter list with column-level filtering
  const filteredAgents = useMemo(() => {
    return agents.filter(agent => {
      // Column filters
      const matchesName = !colFilters.name || 
        agent.name.toLowerCase().includes(colFilters.name.toLowerCase()) ||
        agent.description.toLowerCase().includes(colFilters.name.toLowerCase()) ||
        agent.id.toLowerCase().includes(colFilters.name.toLowerCase());

      const matchesVersion = colFilters.version === 'all' || (agent.version || 'v1.0.0') === colFilters.version;
      const matchesOwner = colFilters.owner === 'all' || (agent.owner || 'Internal Ops') === colFilters.owner;
      const matchesModel = colFilters.model === 'all' || (agent.model || 'Claude 3.5 Sonnet') === colFilters.model;
      const matchesStatus = colFilters.status === 'all' || (agent.status || 'Active') === colFilters.status;
      const matchesUpdated = !colFilters.updated || (agent.lastUpdated || '').toLowerCase().includes(colFilters.updated.toLowerCase());

      // Global Search
      const matchesSearch = !searchTerm || 
        agent.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        agent.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (agent.model && agent.model.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (agent.owner && agent.owner.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (agent.version && agent.version.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (agent.status && agent.status.toLowerCase().includes(searchTerm.toLowerCase()));

      return matchesName && matchesVersion && matchesOwner && matchesModel && matchesStatus && matchesUpdated && matchesSearch;
    });
  }, [agents, searchTerm, colFilters]);

  // Reset pagination on filter or search change
  React.useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, colFilters]);

  // Listen for Copilot custom onboarding triggers
  React.useEffect(() => {
    const handleOpenForm = (e: any) => {
      handleStartCreate();
      if (e.detail && typeof e.detail === 'object') {
        setFormData(prev => ({ ...prev, ...e.detail }));
      }
    };
    const handleUpdateForm = (e: any) => {
      if (e.detail && typeof e.detail === 'object') {
        setFormData(prev => ({ ...prev, ...e.detail }));
      }
    };
    window.addEventListener('open_onboard_agent_form', handleOpenForm);
    window.addEventListener('update_onboard_agent_form', handleUpdateForm);
    return () => {
      window.removeEventListener('open_onboard_agent_form', handleOpenForm);
      window.removeEventListener('update_onboard_agent_form', handleUpdateForm);
    };
  }, []);

  const handleApplyPreset = (presetType: 'kyb' | 'sanctions' | 'ubo') => {
    if (presetType === 'kyb') {
      setFormData({
        name: 'Corporate Registry KYB Agent',
        description: 'Extracts ACRA/Companies House certificate of incorporation, corporate officers, and share capital distribution.',
        category: 'Identity & Compliance',
        isEnabled: true,
        agentClass: 'normal',
        usesGoogleProtocol: true,
        mcpServerUrl: 'mcp://localhost:3090/kyb-acra-mcp',
        mcpApisInput: 'fetchAcraFiling, extractShareholders, verifyRegistrationNumber',
        mcpConnectedSourcesInput: 'ACRA Registry, Companies House API',
        subAgentsInput: 'ubo_unwrapper_agent',
        version: 'v2.1.0',
        owner: 'Compliance Engineering',
        model: 'Claude 3.5 Sonnet',
        riskLevel: 'Low',
        status: 'Active',
        inputSchema: '{\n  "type": "object",\n  "properties": {\n    "uen": { "type": "string" },\n    "companyName": { "type": "string" }\n  },\n  "required": ["uen"]\n}',
        outputSchema: '{\n  "type": "object",\n  "properties": {\n    "shareholders": { "type": "array" },\n    "incorporationDate": { "type": "string" }\n  }\n}',
        canBeAskedByInput: 'onboarding_coordinator',
        canAskInput: 'ubo_unwrapper_agent, sanctions_screener',
        permissions: ['Read Customer', 'Read Documents'],
        policies: ['MAS Technology Risk', 'ACRA Data License'],
        avgLatency: '180ms',
        successRate: '99.8%',
        avgCost: '$0.0012'
      });
    } else if (presetType === 'sanctions') {
      setFormData({
        name: 'Global Sanctions & PEP Screener',
        description: 'Screens ultimate beneficial owners and key executive names against OFAC, UN, EU, and MAS consolidated sanctions registers.',
        category: 'Intelligence',
        isEnabled: true,
        agentClass: 'super',
        usesGoogleProtocol: true,
        mcpServerUrl: 'mcp://localhost:3095/sanctions-mcp',
        mcpApisInput: 'screenName, checkPEPStatus, verifyAdverseMedia',
        mcpConnectedSourcesInput: 'World-Check, OFAC Watchlist, MAS Register',
        subAgentsInput: 'adverse_news_agent',
        version: 'v1.8.4',
        owner: 'Financial Crime Unit',
        model: 'GPT-4o',
        riskLevel: 'High',
        status: 'Active',
        inputSchema: '{\n  "type": "object",\n  "properties": {\n    "entityName": { "type": "string" },\n    "country": { "type": "string" }\n  },\n  "required": ["entityName"]\n}',
        outputSchema: '{\n  "type": "object",\n  "properties": {\n    "matchFound": { "type": "boolean" },\n    "riskScore": { "type": "number" }\n  }\n}',
        canBeAskedByInput: 'kyb_agent, ubo_unwrapper_agent',
        canAskInput: 'compliance_escalation_bot',
        permissions: ['Read Customer', 'Screen Sanctions'],
        policies: ['MAS AML/CFT Notice 626', 'EU Sanctions Regulation'],
        avgLatency: '110ms',
        successRate: '99.9%',
        avgCost: '$0.0008'
      });
    } else if (presetType === 'ubo') {
      setFormData({
        name: 'Multi-Tier UBO Graph Analyzer',
        description: 'Recursively unpacks complex holding company structures across offshore jurisdictions to identify 25%+ Ultimate Beneficial Owners.',
        category: 'Operations',
        isEnabled: true,
        agentClass: 'super',
        usesGoogleProtocol: true,
        mcpServerUrl: 'mcp://localhost:3100/ubo-graph-mcp',
        mcpApisInput: 'buildOwnershipGraph, calculateEquityStake, flagShellCompanies',
        mcpConnectedSourcesInput: 'BVI Registry, Cayman CIMA, Singapore ACRA',
        subAgentsInput: 'kyb_agent, sanctions_screener',
        version: 'v3.0.1',
        owner: 'KYC Operations',
        model: 'Claude 3.5 Sonnet',
        riskLevel: 'Medium',
        status: 'Active',
        inputSchema: '{\n  "type": "object",\n  "properties": {\n    "parentEntity": { "type": "string" }\n  }\n}',
        outputSchema: '{\n  "type": "object",\n  "properties": {\n    "ultimateOwners": { "type": "array" }\n  }\n}',
        canBeAskedByInput: 'onboarding_coordinator',
        canAskInput: 'sanctions_screener',
        permissions: ['Read Customer', 'Graph Operations'],
        policies: ['FATF Guidance on Beneficial Ownership'],
        avgLatency: '320ms',
        successRate: '99.4%',
        avgCost: '$0.0025'
      });
    }
  };

  const paginatedAgents = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredAgents.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredAgents, currentPage, itemsPerPage]);

  const totalPages = Math.ceil(filteredAgents.length / itemsPerPage);

  // Open Drawer in View Mode
  const handleOpenView = (agent: OrchestrationAgent) => {
    setSelectedAgent(agent);
    setDrawerMode('view');
    setActiveTab('overview');
    setIsAttachingMcp(false);
  };

  // Toggle active/inactive
  const handleToggleEnable = (agentId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setAgents(prev => prev.map(a => {
      if (a.id === agentId) {
        const nextEnabled = !a.isEnabled;
        const nextStatus = nextEnabled ? 'Active' : 'Deprecated';
        return { ...a, isEnabled: nextEnabled, status: nextStatus };
      }
      return a;
    }));
    // If the currently viewed agent is toggled, update local state
    if (selectedAgent && selectedAgent.id === agentId) {
      setSelectedAgent(prev => prev ? { ...prev, isEnabled: !prev.isEnabled, status: !prev.isEnabled ? 'Active' : 'Deprecated' } : null);
    }
  };

  // Delete Agent
  const handleDeleteAgent = (agentId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const target = agents.find(a => a.id === agentId);
    if (target) {
      setAgentToDelete(target);
    }
  };

  const handleConfirmDeleteAgent = () => {
    if (!agentToDelete) return;
    setAgents(prev => prev.filter(a => a.id !== agentToDelete.id));
    if (selectedAgent && selectedAgent.id === agentToDelete.id) {
      setSelectedAgent(null);
    }
    setAgentToDelete(null);
  };

  // Populate form for Edit Mode
  const handleStartEdit = (agent: OrchestrationAgent) => {
    setFormData({
      name: agent.name,
      description: agent.description,
      category: agent.category,
      isEnabled: agent.isEnabled,
      agentClass: agent.agentClass,
      usesGoogleProtocol: agent.usesGoogleProtocol,
      mcpServerUrl: agent.mcpServerUrl || '',
      mcpApisInput: agent.mcpApis ? agent.mcpApis.join(', ') : '',
      mcpConnectedSourcesInput: agent.mcpConnectedSources ? agent.mcpConnectedSources.join(', ') : '',
      subAgentsInput: agent.subAgents ? agent.subAgents.join(', ') : '',
      version: agent.version || 'v1.0.0',
      owner: agent.owner || 'Compliance Tech',
      model: agent.model || 'Claude 3.5 Sonnet',
      riskLevel: agent.riskLevel || 'Low',
      status: agent.status || 'Active',
      inputSchema: agent.inputSchema || '{\n  "type": "object",\n  "properties": {}\n}',
      outputSchema: agent.outputSchema || '{\n  "type": "object",\n  "properties": {}\n}',
      canBeAskedByInput: agent.canBeAskedBy ? agent.canBeAskedBy.join(', ') : '',
      canAskInput: agent.canAsk ? agent.canAsk.join(', ') : '',
      permissions: agent.subAgents || [], // use subAgents mapping as permissions placeholder
      policies: ['MAS Technology Risk', 'EU GDPR Compliance'], // mock default policies
      avgLatency: agent.metrics?.avgLatency || '240ms',
      successRate: agent.metrics?.successRate || '99.5%',
      avgCost: agent.metrics?.avgCost || '$0.0015'
    });
    setDrawerMode('edit');
  };

  // Start Create Mode
  const handleStartCreate = () => {
    setFormData({
      name: '',
      description: '',
      category: 'Identity & Compliance',
      isEnabled: true,
      agentClass: 'normal',
      usesGoogleProtocol: true,
      mcpServerUrl: 'mcp://localhost:3090/new-agent-mcp',
      mcpApisInput: 'queryData, validateDetails',
      mcpConnectedSourcesInput: 'Internal Database, Salesforce API',
      subAgentsInput: '',
      version: 'v1.0.0',
      owner: 'Operations Systems',
      model: 'Claude 3.5 Sonnet',
      riskLevel: 'Low',
      status: 'Active',
      inputSchema: '{\n  "type": "object",\n  "properties": {\n    "clientId": { "type": "string" }\n  },\n  "required": ["clientId"]\n}',
      outputSchema: '{\n  "type": "object",\n  "properties": {\n    "status": { "type": "string" }\n  }\n}',
      canBeAskedByInput: 'onboarding_coordinator',
      canAskInput: '',
      permissions: ['Read Customer', 'Read Documents'],
      policies: ['MAS Technology Risk'],
      avgLatency: '150ms',
      successRate: '99.9%',
      avgCost: '$0.0005'
    });
    setSelectedAgent(null);
    setDrawerMode('create');
    setActiveTab('overview');
  };

  // Save changes from Edit/Create
  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    const parsedMcpApis = formData.mcpApisInput
      ? formData.mcpApisInput.split(',').map(s => s.trim()).filter(Boolean)
      : undefined;

    const parsedMcpConnectedSources = formData.mcpConnectedSourcesInput
      ? formData.mcpConnectedSourcesInput.split(',').map(s => s.trim()).filter(Boolean)
      : undefined;

    const parsedSubAgents = formData.subAgentsInput
      ? formData.subAgentsInput.split(',').map(s => s.trim()).filter(Boolean)
      : undefined;

    const parsedCanBeAskedBy = formData.canBeAskedByInput
      ? formData.canBeAskedByInput.split(',').map(s => s.trim()).filter(Boolean)
      : undefined;

    const parsedCanAsk = formData.canAskInput
      ? formData.canAskInput.split(',').map(s => s.trim()).filter(Boolean)
      : undefined;

    if (drawerMode === 'edit' && selectedAgent) {
      // Update Agent
      const updatedAgent: OrchestrationAgent = {
        ...selectedAgent,
        name: formData.name,
        description: formData.description,
        category: formData.category,
        isEnabled: formData.isEnabled,
        agentClass: formData.agentClass,
        usesGoogleProtocol: formData.usesGoogleProtocol,
        mcpServerUrl: formData.mcpServerUrl.trim() || undefined,
        mcpApis: parsedMcpApis,
        mcpConnectedSources: parsedMcpConnectedSources,
        subAgents: parsedSubAgents,
        version: formData.version,
        owner: formData.owner,
        model: formData.model,
        riskLevel: formData.riskLevel,
        status: formData.status,
        inputSchema: formData.inputSchema,
        outputSchema: formData.outputSchema,
        canBeAskedBy: parsedCanBeAskedBy,
        canAsk: parsedCanAsk,
        metrics: {
          avgLatency: formData.avgLatency,
          successRate: formData.successRate,
          avgCost: formData.avgCost,
          sparklineData: selectedAgent.metrics?.sparklineData || [98, 99, 99, 99.5, 99.4, 99.5, 99.5]
        }
      };

      setAgents(prev => prev.map(a => a.id === selectedAgent.id ? updatedAgent : a));
      setSelectedAgent(updatedAgent);
      setDrawerMode('view');
    } else if (drawerMode === 'create') {
      // Create Agent
      const newAgent: OrchestrationAgent = {
        id: `agent_${Date.now()}`,
        name: formData.name,
        description: formData.description,
        category: formData.category,
        isEnabled: formData.isEnabled,
        agentClass: formData.agentClass,
        usesGoogleProtocol: formData.usesGoogleProtocol,
        mcpServerUrl: formData.mcpServerUrl.trim() || undefined,
        mcpApis: parsedMcpApis,
        mcpConnectedSources: parsedMcpConnectedSources,
        subAgents: parsedSubAgents,
        version: formData.version,
        owner: formData.owner,
        model: formData.model,
        riskLevel: formData.riskLevel,
        status: formData.status,
        inputSchema: formData.inputSchema,
        outputSchema: formData.outputSchema,
        canBeAskedBy: parsedCanBeAskedBy,
        canAsk: parsedCanAsk,
        metrics: {
          avgLatency: formData.avgLatency,
          successRate: formData.successRate,
          avgCost: formData.avgCost,
          sparklineData: [99.0, 99.2, 99.5, 99.6, 99.8, 99.9, 99.9]
        },
        position: {
          x: 100 + Math.random() * 400,
          y: 100 + Math.random() * 200
        }
      };

      setAgents(prev => [...prev, newAgent]);
      setSelectedAgent(newAgent);
      setDrawerMode('view');
    }
  };

  // Add a quick tool attachment inside View Mode
  const handleAttachMcpSource = () => {
    if (!selectedAgent || !newMcpUrl.trim()) return;
    
    const updatedSources = selectedAgent.mcpConnectedSources 
      ? [...selectedAgent.mcpConnectedSources, newMcpSource.trim() || 'Custom MCP Source']
      : [newMcpSource.trim() || 'Custom MCP Source'];

    const updatedAgent: OrchestrationAgent = {
      ...selectedAgent,
      mcpServerUrl: newMcpUrl.trim(),
      mcpConnectedSources: updatedSources
    };

    setAgents(prev => prev.map(a => a.id === selectedAgent.id ? updatedAgent : a));
    setSelectedAgent(updatedAgent);
    setIsAttachingMcp(false);
    setNewMcpUrl('');
    setNewMcpSource('');
  };

  // Live guardrails update hander
  const handleUpdateGuardrails = (category: string, field: string, value: any) => {
    if (!selectedAgent) return;
    const currentGuardrails = selectedAgent.guardrails || DEFAULT_GUARDRAILS;
    const updatedGuardrails = {
      ...currentGuardrails,
      [category]: {
        ...(currentGuardrails[category as keyof typeof DEFAULT_GUARDRAILS] || DEFAULT_GUARDRAILS[category as keyof typeof DEFAULT_GUARDRAILS]),
        [field]: value
      }
    };
    const updatedAgent: OrchestrationAgent = {
      ...selectedAgent,
      guardrails: updatedGuardrails
    };
    setSelectedAgent(updatedAgent);
    setAgents(prev => prev.map(a => a.id === selectedAgent.id ? updatedAgent : a));
  };

  // Reset guardrails to robust safety defaults
  const handleResetGuardrails = () => {
    if (!selectedAgent) return;
    const updatedAgent: OrchestrationAgent = {
      ...selectedAgent,
      guardrails: JSON.parse(JSON.stringify(DEFAULT_GUARDRAILS))
    };
    setSelectedAgent(updatedAgent);
    setAgents(prev => prev.map(a => a.id === selectedAgent.id ? updatedAgent : a));
  };

  // UI styling helpers
  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Identity & Compliance':
        return 'bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-100 dark:border-blue-500/20';
      case 'Intelligence':
        return 'bg-purple-50 dark:bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-100 dark:border-purple-500/20';
      case 'Operations':
        return 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-100 dark:border-emerald-500/20';
      case 'Support':
        return 'bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-100 dark:border-amber-500/20';
      default:
        return 'bg-slate-50 dark:bg-slate-500/10 text-slate-600 dark:text-slate-400 border-slate-100 dark:border-slate-500/20';
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'High':
        return 'bg-rose-50 dark:bg-rose-500/15 text-rose-700 dark:text-rose-400 border-rose-100 dark:border-rose-500/30';
      case 'Medium':
        return 'bg-amber-50 dark:bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-100 dark:border-amber-500/30';
      case 'Low':
        return 'bg-emerald-50 dark:bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-100 dark:border-emerald-500/30';
      default:
        return 'bg-slate-50 dark:bg-slate-500/15 text-slate-600 dark:text-slate-400 border-slate-100 dark:border-slate-500/30';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active':
        return 'bg-emerald-50 dark:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border-emerald-150 dark:border-emerald-500/30';
      case 'Deprecated':
        return 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700';
      case 'Draft':
        return 'bg-blue-50 dark:bg-blue-500/20 text-blue-700 dark:text-blue-300 border-blue-150 dark:border-blue-500/30';
      default:
        return 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700';
    }
  };

  return (
    <div className="space-y-6 text-slate-800 dark:text-slate-100">
      {/* Upper Registry Controller Banner */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 bg-white dark:bg-[#1d1d1d] border border-slate-100 dark:border-slate-800/80 rounded-2xl p-6 shadow-[0_20px_27px_rgba(0,0,0,0.04)]">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-blue-50 dark:bg-blue-600/10 border border-blue-100 dark:border-blue-500/20 rounded-xl text-blue-500 shrink-0">
            <Bot className="w-6 h-6 animate-pulse" />
          </div>
          <div className="text-left">
            <h2 className="font-bold text-base flex flex-wrap items-center gap-2 text-slate-800 dark:text-white">
              Agent Registry & Governance
              <span className="text-[10px] font-mono font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 px-2 py-0.5 border border-emerald-500/20 rounded-full uppercase">A2A Peer Protocol Active</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-2xl leading-relaxed">
              Configure, audit, and trace super-agents and normal operational tools. Real-time classification, schema inspection, and Model Context Protocol (MCP) data mappings.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap self-start md:self-center">
          <button
            onClick={handleStartCreate}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-lg shadow-sm transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-4 h-4" /> Onboard New Agent
          </button>
        </div>
      </div>

      {/* Inline Workspace: Onboard Agent Form or Agent Details (Inline on main screen canvas TOP) */}
      <AnimatePresence mode="wait">
        {(selectedAgent || drawerMode === 'create') && (
          <motion.div
            ref={topFormRef}
            key="inline-agent-container"
            initial={{ opacity: 0, y: -15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.2 }}
            className="w-full bg-white dark:bg-[#1d1d1d] border-2 border-blue-500/30 dark:border-blue-500/40 rounded-2xl shadow-lg overflow-hidden flex flex-col text-slate-800 dark:text-slate-100 mb-6"
          >
            {/* Inline Panel Header */}
            <div className="bg-slate-50/80 dark:bg-slate-900/60 px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-3">
                <div className={`p-2.5 rounded-xl border ${
                  drawerMode === 'create' || (selectedAgent && selectedAgent.agentClass === 'super')
                    ? 'bg-amber-50 border-amber-200 text-amber-600 dark:bg-amber-500/10 dark:border-amber-500/30 dark:text-amber-400'
                    : 'bg-blue-50 border-blue-200 text-blue-600 dark:bg-blue-500/10 dark:border-blue-500/30 dark:text-blue-400'
                }`}>
                  {drawerMode === 'create' ? <Plus className="w-5 h-5 animate-pulse" /> : <Bot className="w-5 h-5" />}
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-extrabold text-sm text-slate-900 dark:text-white uppercase tracking-tight">
                      {drawerMode === 'create' ? 'Onboard Custom Agent' : (drawerMode === 'edit' ? `Configure: ${selectedAgent?.name}` : selectedAgent?.name)}
                    </h3>
                    {selectedAgent && (
                      <span className="text-[10px] font-mono text-slate-500">
                        {selectedAgent.version}
                      </span>
                    )}
                    <span className="text-[10px] font-mono font-bold bg-blue-500/10 text-blue-600 dark:text-blue-400 px-2.5 py-0.5 border border-blue-500/20 rounded-full flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-amber-500 animate-spin" /> Autonomous Agent Config Active
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    {drawerMode === 'create' 
                      ? 'Key in attributes below or select an AI agent preset below' 
                      : `Autonomous Agent ID: ${selectedAgent?.id}`}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {drawerMode === 'view' && selectedAgent && (
                  <button
                    onClick={() => handleStartEdit(selectedAgent)}
                    className="px-3 py-1.5 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg transition text-xs font-bold flex items-center gap-1.5 cursor-pointer border border-slate-200 dark:border-slate-700 shadow-xs"
                  >
                    <Edit2 className="w-3.5 h-3.5" /> Edit Config
                  </button>
                )}
                <button
                  onClick={() => {
                    setSelectedAgent(null);
                    setDrawerMode('view');
                  }}
                  className="px-3 py-1.5 bg-slate-200/60 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 border border-slate-300 dark:border-slate-700"
                >
                  <X className="w-4 h-4" /> Close & Return to Agents
                </button>
              </div>
            </div>

            {/* AI Presets Quick Fill Bar when Creating */}
            {drawerMode === 'create' && (
              <div className="bg-gradient-to-r from-blue-50/70 via-indigo-50/40 to-slate-50 dark:from-blue-950/20 dark:to-slate-900/40 p-4 border-b border-slate-200 dark:border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-500 shrink-0 animate-pulse" />
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    Auto-Fill via AI Presets:
                  </span>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 hidden lg:inline">
                    (Clicking populates form fields on screen in real-time)
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleApplyPreset('kyb')}
                    className="px-3 py-1 bg-white dark:bg-slate-800 hover:bg-blue-50 dark:hover:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-xs font-bold rounded-lg border border-blue-200 dark:border-blue-800 transition cursor-pointer flex items-center gap-1 shadow-xs"
                  >
                    + KYB Registry Agent
                  </button>
                  <button
                    type="button"
                    onClick={() => handleApplyPreset('sanctions')}
                    className="px-3 py-1 bg-white dark:bg-slate-800 hover:bg-emerald-50 dark:hover:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 text-xs font-bold rounded-lg border border-emerald-200 dark:border-emerald-800 transition cursor-pointer flex items-center gap-1 shadow-xs"
                  >
                    + Sanctions & PEP Screener
                  </button>
                  <button
                    type="button"
                    onClick={() => handleApplyPreset('ubo')}
                    className="px-3 py-1 bg-white dark:bg-slate-800 hover:bg-purple-50 dark:hover:bg-purple-900/30 text-purple-600 dark:text-purple-400 text-xs font-bold rounded-lg border border-purple-200 dark:border-purple-800 transition cursor-pointer flex items-center gap-1 shadow-xs"
                  >
                    + UBO Graph Analyzer
                  </button>
                </div>
              </div>
            )}

            {/* Drawer Mode: VIEW - Tab-based Details */}
            {drawerMode === 'view' && selectedAgent && (
              <div className="flex flex-col flex-1 min-h-0">
                {/* Tab Navigation inside panel */}
                <div className="bg-slate-50 dark:bg-slate-900/40 px-6 border-b border-slate-200 dark:border-slate-800 flex items-center gap-1 overflow-x-auto">
                  {[
                    { id: 'overview', label: 'Overview & Metadata', icon: Bot },
                    { id: 'guardrails', label: 'Guardrails & Safety', icon: ShieldCheck },
                    { id: 'tools', label: 'Tools & MCP', icon: Server },
                    { id: 'policies', label: 'Governance & Compliance', icon: Lock },
                    { id: 'schema', label: 'Input / Output Schemas', icon: Code },
                    { id: 'a2a', label: 'A2A Topology', icon: Network },
                    { id: 'metrics', label: 'Telemetry & Cost', icon: Activity }
                  ].map(tab => {
                    const Icon = tab.icon;
                    const isActive = activeTab === tab.id;
                    return (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id as any)}
                        className={`px-3.5 py-3 text-xs font-semibold flex items-center gap-2 border-b-2 transition whitespace-nowrap cursor-pointer ${
                          isActive
                            ? 'border-blue-600 text-blue-600 dark:text-blue-400 font-bold bg-white dark:bg-slate-800/60'
                            : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
                        }`}
                      >
                        <Icon className="w-3.5 h-3.5" />
                        {tab.label}
                      </button>
                    );
                  })}
                </div>

                {/* Tab Content Area */}
                <div className="p-6 space-y-6 max-h-[600px] overflow-y-auto">
                  {activeTab === 'overview' && (
                    <div className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        <div className="p-4 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-slate-200/80 dark:border-slate-800">
                          <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block mb-1">Agent Classification</span>
                          <span className="text-xs font-bold text-slate-800 dark:text-slate-200 capitalize flex items-center gap-1.5">
                            {selectedAgent.agentClass === 'super' ? (
                              <span className="text-amber-500 flex items-center gap-1 font-extrabold"><Sparkles className="w-3.5 h-3.5" /> Super Agent</span>
                            ) : (
                              <span>Standard Operational Agent</span>
                            )}
                          </span>
                        </div>

                        <div className="p-4 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-slate-200/80 dark:border-slate-800">
                          <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block mb-1">Risk Rating</span>
                          <span className={`text-xs font-bold px-2 py-0.5 rounded border inline-block ${getRiskColor(selectedAgent.riskLevel || 'Low')}`}>
                            {selectedAgent.riskLevel || 'Low Risk'}
                          </span>
                        </div>

                        <div className="p-4 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-slate-200/80 dark:border-slate-800">
                          <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block mb-1">LLM Engine</span>
                          <span className="text-xs font-bold text-slate-800 dark:text-slate-200 font-mono">
                            {selectedAgent.model || 'Claude 3.5 Sonnet'}
                          </span>
                        </div>

                        <div className="p-4 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-slate-200/80 dark:border-slate-800">
                          <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block mb-1">Owner Team</span>
                          <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                            {selectedAgent.owner || 'Compliance Tech'}
                          </span>
                        </div>
                      </div>

                      <div className="p-4 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-slate-200/80 dark:border-slate-800">
                        <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block mb-1">System Description & Objectives</span>
                        <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                          {selectedAgent.description}
                        </p>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="p-4 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-slate-200/80 dark:border-slate-800">
                          <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block mb-1">Avg Execution Latency</span>
                          <span className="text-sm font-extrabold text-slate-800 dark:text-slate-100 font-mono">
                            {selectedAgent.avgLatency || '240ms'}
                          </span>
                        </div>

                        <div className="p-4 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-slate-200/80 dark:border-slate-800">
                          <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block mb-1">SLA Accuracy Rate</span>
                          <span className="text-sm font-extrabold text-emerald-600 dark:text-emerald-400 font-mono">
                            {selectedAgent.successRate || '99.8%'}
                          </span>
                        </div>

                        <div className="p-4 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-slate-200/80 dark:border-slate-800">
                          <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block mb-1">Cost per 1k Invocations</span>
                          <span className="text-sm font-extrabold text-slate-800 dark:text-slate-100 font-mono">
                            {selectedAgent.avgCost || '$0.0012'}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}

                  {activeTab === 'guardrails' && (
                    <div className="space-y-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300 font-mono">
                            Safety Guardrails & Policy Filters
                          </h4>
                          <p className="text-[11px] text-slate-500">
                            Configure boundary filters, token output limits, and regulatory constraints.
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={handleResetGuardrails}
                          className="px-2.5 py-1 text-[10px] font-mono font-bold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded transition cursor-pointer"
                        >
                          Reset to Safety Defaults
                        </button>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {Object.entries((selectedAgent.guardrails || DEFAULT_GUARDRAILS) as Record<string, Record<string, any>>).map(([category, fields]) => (
                          <div 
                            key={category}
                            className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 space-y-3"
                          >
                            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-2">
                              <span className="font-bold text-xs uppercase tracking-wider text-slate-800 dark:text-slate-200 font-mono">
                                {category.replace(/([A-Z])/g, ' $1').trim()}
                              </span>
                              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-500/10 text-blue-600 dark:text-blue-400 font-semibold">
                                Active Policy
                              </span>
                            </div>
                            <div className="space-y-2">
                              {Object.entries(fields || {}).map(([field, val]) => (
                                <div key={field} className="flex items-center justify-between text-xs">
                                  <span className="text-slate-600 dark:text-slate-400 capitalize">
                                    {field.replace(/([A-Z])/g, ' $1').trim()}
                                  </span>
                                  {typeof val === 'boolean' ? (
                                    <button
                                      type="button"
                                      onClick={() => handleUpdateGuardrails(category, field, !val)}
                                      className="cursor-pointer"
                                    >
                                      {val ? (
                                        <ToggleRight className="w-5 h-5 text-emerald-500" />
                                      ) : (
                                        <ToggleLeft className="w-5 h-5 text-slate-400" />
                                      )}
                                    </button>
                                  ) : (
                                    <span className="font-mono text-[11px] bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded text-slate-700 dark:text-slate-300">
                                      {Array.isArray(val) ? val.join(', ') : String(val)}
                                    </span>
                                  )}
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {activeTab === 'tools' && (
                    <div className="space-y-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300 font-mono">
                            Model Context Protocol (MCP) & Connected APIs
                          </h4>
                          <p className="text-[11px] text-slate-500">
                            Inspect active Model Context Protocol (MCP) server endpoints, exposed tools, and connected data sources.
                          </p>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div className="p-4 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-slate-200/80 dark:border-slate-800">
                          <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block mb-1">MCP Server Endpoint</span>
                          <code className="text-xs font-mono font-bold text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-900/30 px-2.5 py-1 rounded border border-blue-200/50 dark:border-blue-800/50 inline-block">
                            {selectedAgent.mcpServerUrl || 'mcp://localhost:3090/default-agent-mcp'}
                          </code>
                        </div>

                        <div className="p-4 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-slate-200/80 dark:border-slate-800 space-y-2">
                          <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block">Exposed MCP Tool Actions</span>
                          <div className="flex flex-wrap gap-2">
                            {(selectedAgent.mcpApis && selectedAgent.mcpApis.length > 0 
                              ? selectedAgent.mcpApis 
                              : ['fetchEntityDetails', 'validateJurisdiction', 'verifyTaxId']
                            ).map((action, idx) => (
                              <span key={idx} className="px-2.5 py-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-xs font-mono font-bold text-slate-700 dark:text-slate-300">
                                {action}
                              </span>
                            ))}
                          </div>
                        </div>

                        <div className="p-4 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-slate-200/80 dark:border-slate-800 space-y-2">
                          <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block">Connected Enterprise Data Sources</span>
                          <div className="flex flex-wrap gap-2">
                            {(selectedAgent.mcpConnectedSources && selectedAgent.mcpConnectedSources.length > 0 
                              ? selectedAgent.mcpConnectedSources 
                              : ['ACRA Corporate Registry', 'World-Check Sanctions List', 'Internal Risk DB']
                            ).map((source, idx) => (
                              <span key={idx} className="px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 rounded text-xs font-semibold text-emerald-700 dark:text-emerald-400 flex items-center gap-1.5">
                                <Check className="w-3 h-3 text-emerald-500" /> {source}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {activeTab === 'policies' && (
                    <div className="space-y-4">
                      <h4 className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300 font-mono">
                        Governance Policies & Regulatory Mandates
                      </h4>
                      <div className="space-y-2">
                        {(selectedAgent.policies && selectedAgent.policies.length > 0 
                          ? selectedAgent.policies 
                          : ['MAS Technology Risk Management Guidelines', 'FATF Recommendation 10 (CDD)', 'EU AI Act High-Risk System Mandates']
                        ).map((policy, idx) => (
                          <div key={idx} className="p-3 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 rounded-xl flex items-center justify-between text-xs font-medium text-slate-700 dark:text-slate-300">
                            <span className="flex items-center gap-2">
                              <Lock className="w-3.5 h-3.5 text-blue-500" /> {policy}
                            </span>
                            <span className="text-[10px] font-mono bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 px-2 py-0.5 rounded font-bold border border-emerald-500/20">
                              Enforced
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {activeTab === 'schema' && (
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300 font-mono mb-2">
                          Input Schema (JSON Schema)
                        </h4>
                        <pre className="p-4 bg-slate-900 text-slate-200 rounded-xl font-mono text-xs overflow-x-auto border border-slate-800">
                          {selectedAgent.inputSchema || '{\n  "type": "object",\n  "properties": {\n    "entityUen": { "type": "string" }\n  }\n}'}
                        </pre>
                      </div>

                      <div>
                        <h4 className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300 font-mono mb-2">
                          Output Schema (JSON Schema)
                        </h4>
                        <pre className="p-4 bg-slate-900 text-slate-200 rounded-xl font-mono text-xs overflow-x-auto border border-slate-800">
                          {selectedAgent.outputSchema || '{\n  "type": "object",\n  "properties": {\n    "verificationResult": { "type": "string" }\n  }\n}'}
                        </pre>
                      </div>
                    </div>
                  )}

                  {activeTab === 'a2a' && (
                    <div className="space-y-4">
                      <h4 className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300 font-mono">
                        Agent-to-Agent (A2A) Peer Topologies
                      </h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="p-4 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-slate-200 dark:border-slate-800">
                          <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block mb-2">Can Be Invoked By</span>
                          <div className="flex flex-wrap gap-1.5">
                            {(selectedAgent.canBeAskedByInput 
                              ? selectedAgent.canBeAskedByInput.split(',').map(s => s.trim()) 
                              : ['onboarding_coordinator', 'compliance_gatekeeper']
                            ).map((item, idx) => (
                              <span key={idx} className="px-2 py-1 bg-blue-50 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 text-xs font-mono rounded">
                                {item}
                              </span>
                            ))}
                          </div>
                        </div>

                        <div className="p-4 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-slate-200 dark:border-slate-800">
                          <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block mb-2">Can Delegate To</span>
                          <div className="flex flex-wrap gap-1.5">
                            {(selectedAgent.canAskInput 
                              ? selectedAgent.canAskInput.split(',').map(s => s.trim()) 
                              : ['ubo_unwrapper_agent', 'sanctions_screener']
                            ).map((item, idx) => (
                              <span key={idx} className="px-2 py-1 bg-purple-50 dark:bg-purple-900/30 border border-purple-200 dark:border-purple-800 text-purple-700 dark:text-purple-300 text-xs font-mono rounded">
                                {item}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {activeTab === 'metrics' && (
                    <div className="space-y-4">
                      <h4 className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300 font-mono">
                        Production Telemetry & Audit Logs
                      </h4>
                      <div className="p-4 bg-slate-900 rounded-xl font-mono text-xs text-slate-300 space-y-1">
                        <p className="text-emerald-400">[2026-08-03T16:10:02Z] INFO: Agent {selectedAgent.id} executed successfully. Latency 182ms.</p>
                        <p className="text-slate-400">[2026-08-03T16:08:14Z] DEBUG: A2A handshaking with ubo_unwrapper completed. Token usage: 412 in / 120 out.</p>
                        <p className="text-emerald-400">[2026-08-03T16:05:30Z] INFO: MCP Tool fetchAcraFiling invoked via mcp://localhost:3090.</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Drawer Mode: EDIT or CREATE - Interactive Form */}
            {(drawerMode === 'create' || drawerMode === 'edit') && (
              <form onSubmit={handleSaveForm} className="p-6 space-y-6 max-h-[650px] overflow-y-auto">
                {/* Section 1: Core Identity */}
                <div className="space-y-4">
                  <h4 className="text-xs font-bold font-mono text-slate-700 dark:text-slate-300 uppercase tracking-wider border-b border-slate-200 dark:border-slate-800 pb-2">
                    1. Core Identity & Classification
                  </h4>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold font-mono text-slate-500 uppercase tracking-wider mb-1">Agent Name *</label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                        className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-xs font-medium text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500"
                        placeholder="e.g. Corporate KYB Extractor"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold font-mono text-slate-500 uppercase tracking-wider mb-1">Domain Category</label>
                      <select
                        value={formData.category}
                        onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
                        className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-xs font-medium text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500"
                      >
                        <option value="Identity & Compliance">Identity & Compliance</option>
                        <option value="Intelligence">Intelligence</option>
                        <option value="Operations">Operations</option>
                        <option value="Support">Support</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold font-mono text-slate-500 uppercase tracking-wider mb-1">System Description & Purpose</label>
                    <textarea
                      rows={3}
                      value={formData.description}
                      onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                      className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-xs font-medium text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500"
                      placeholder="Describe what this autonomous agent verifies or extracts..."
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold font-mono text-slate-500 uppercase tracking-wider mb-1">LLM Model Core</label>
                      <select
                        value={formData.model}
                        onChange={(e) => setFormData(prev => ({ ...prev, model: e.target.value }))}
                        className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-xs font-medium text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500"
                      >
                        <option value="Claude 3.5 Sonnet">Claude 3.5 Sonnet</option>
                        <option value="GPT-4o">GPT-4o</option>
                        <option value="Claude 3.5 Haiku">Claude 3.5 Haiku</option>
                        <option value="GPT-4o-mini">GPT-4o-mini</option>
                        <option value="o3-mini">o3-mini</option>
                        <option value="o1">o1</option>
                        <option value="Claude 3 Opus">Claude 3 Opus</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold font-mono text-slate-500 uppercase tracking-wider mb-1">Risk Rating</label>
                      <select
                        value={formData.riskLevel}
                        onChange={(e) => setFormData(prev => ({ ...prev, riskLevel: e.target.value as any }))}
                        className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-xs font-medium text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500"
                      >
                        <option value="Low">Low Risk</option>
                        <option value="Medium">Medium Risk</option>
                        <option value="High">High Risk</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold font-mono text-slate-500 uppercase tracking-wider mb-1">Owner Team</label>
                      <input
                        type="text"
                        value={formData.owner}
                        onChange={(e) => setFormData(prev => ({ ...prev, owner: e.target.value }))}
                        className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-xs font-medium text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500"
                        placeholder="e.g. Risk Engineering"
                      />
                    </div>
                  </div>
                </div>

                {/* Section 2: MCP & Tool Connections */}
                <div className="space-y-4">
                  <h4 className="text-xs font-bold font-mono text-slate-700 dark:text-slate-300 uppercase tracking-wider border-b border-slate-200 dark:border-slate-800 pb-2">
                    2. Model Context Protocol (MCP) Bindings
                  </h4>

                  <div className="space-y-3">
                    <div>
                      <label className="block text-[10px] font-bold font-mono text-slate-500 uppercase tracking-wider mb-1">MCP Server Endpoint URL</label>
                      <input
                        type="text"
                        value={formData.mcpServerUrl}
                        onChange={(e) => setFormData(prev => ({ ...prev, mcpServerUrl: e.target.value }))}
                        className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500"
                        placeholder="mcp://localhost:3090/kyb-acra-mcp"
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] font-bold font-mono text-slate-500 uppercase tracking-wider mb-1">Exposed MCP Tool Actions (Comma Separated)</label>
                        <input
                          type="text"
                          value={formData.mcpApisInput}
                          onChange={(e) => setFormData(prev => ({ ...prev, mcpApisInput: e.target.value }))}
                          className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500"
                          placeholder="fetchAcraFiling, extractShareholders"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold font-mono text-slate-500 uppercase tracking-wider mb-1">Connected Sources (Comma Separated)</label>
                        <input
                          type="text"
                          value={formData.mcpConnectedSourcesInput}
                          onChange={(e) => setFormData(prev => ({ ...prev, mcpConnectedSourcesInput: e.target.value }))}
                          className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500"
                          placeholder="ACRA Registry, Companies House API"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Section 3: A2A Peer Network & Schemas */}
                <div className="space-y-4">
                  <h4 className="text-xs font-bold font-mono text-slate-700 dark:text-slate-300 uppercase tracking-wider border-b border-slate-200 dark:border-slate-800 pb-2">
                    3. A2A Topology & Schemas
                  </h4>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold font-mono text-slate-500 uppercase tracking-wider mb-1">Can Be Asked By (Incoming)</label>
                      <input
                        type="text"
                        value={formData.canBeAskedByInput}
                        onChange={(e) => setFormData(prev => ({ ...prev, canBeAskedByInput: e.target.value }))}
                        className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500"
                        placeholder="onboarding_coordinator"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold font-mono text-slate-500 uppercase tracking-wider mb-1">Can Delegate To (Outgoing)</label>
                      <input
                        type="text"
                        value={formData.canAskInput}
                        onChange={(e) => setFormData(prev => ({ ...prev, canAskInput: e.target.value }))}
                        className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500"
                        placeholder="ubo_unwrapper_agent"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold font-mono text-slate-500 uppercase tracking-wider mb-1">Input JSON Schema</label>
                      <textarea
                        rows={3}
                        value={formData.inputSchema}
                        onChange={(e) => setFormData(prev => ({ ...prev, inputSchema: e.target.value }))}
                        className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500"
                        placeholder='{\n  "type": "object"\n}'
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold font-mono text-slate-500 uppercase tracking-wider mb-1">Output JSON Schema</label>
                      <textarea
                        rows={3}
                        value={formData.outputSchema}
                        onChange={(e) => setFormData(prev => ({ ...prev, outputSchema: e.target.value }))}
                        className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500"
                        placeholder='{\n  "type": "object"\n}'
                      />
                    </div>
                  </div>
                </div>

                {/* Form Footer Buttons */}
                <div className="bg-slate-50 dark:bg-slate-900/80 px-6 py-4 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-3 sticky bottom-0 rounded-b-xl">
                  <button
                    type="button"
                    onClick={() => {
                      if (drawerMode === 'create') {
                        setDrawerMode('view');
                        setSelectedAgent(null);
                      } else {
                        setDrawerMode('view');
                      }
                    }}
                    className="px-4 py-2 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold text-xs rounded-lg transition cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-lg shadow-md transition cursor-pointer flex items-center gap-1.5"
                  >
                    <Check className="w-4 h-4" /> 
                    {drawerMode === 'create' ? 'Onboard Agent' : 'Save Config'}
                  </button>
                </div>
              </form>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Search and Filter Bar */}
      <div className="bg-white dark:bg-[#1d1d1d] border border-slate-100 dark:border-slate-800/80 rounded-2xl p-4 shadow-[0_20px_27px_rgba(0,0,0,0.04)] flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        {/* Global Search */}
        <div className="relative w-full lg:w-96">
          <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-slate-400 dark:text-slate-500">
            <Search className="w-4 h-4" />
          </span>
          <input
            type="text"
            placeholder="Quick search all columns (name, ID, owner, model, version)..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 border border-slate-200 dark:border-slate-800 rounded-lg text-xs font-medium text-slate-800 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-blue-500 bg-slate-50 dark:bg-slate-950"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute inset-y-0 right-0 flex items-center pr-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Filter Badges and Reset Controls */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">
            Showing <span className="font-bold text-slate-800 dark:text-white">{filteredAgents.length}</span> of <span className="font-bold text-slate-800 dark:text-white">{agents.length}</span> agents
          </div>

          {hasActiveFilters && (
            <button
              onClick={handleResetFilters}
              className="px-3 py-1.5 bg-rose-50 dark:bg-rose-500/10 hover:bg-rose-100 dark:hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <X className="w-3.5 h-3.5" /> Clear All Table Filters
            </button>
          )}
        </div>
      </div>

      {/* Main Registry Display Area */}
      <div className="bg-white dark:bg-[#1d1d1d] border border-slate-150 dark:border-slate-800 rounded-2xl overflow-hidden shadow-[0_20px_27px_rgba(0,0,0,0.04)]">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              {/* Column Header Titles */}
              <tr className="border-b border-slate-100 dark:border-slate-800 text-[10px] font-bold font-mono text-slate-400 dark:text-slate-500 uppercase tracking-wider bg-slate-50/50 dark:bg-slate-950/50">
                <th className="px-6 py-3.5">Agent Name & Description</th>
                <th className="px-4 py-3.5">Version</th>
                <th className="px-4 py-3.5">Owner Team</th>
                <th className="px-4 py-3.5">LLM Core</th>
                <th className="px-4 py-3.5 text-center">Status</th>
                <th className="px-4 py-3.5">Last Updated</th>
                <th className="px-6 py-3.5 text-right">Actions</th>
              </tr>

              {/* Table-Level Column Filter Row */}
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/60 text-xs">
                {/* Agent Name Filter */}
                <th className="px-6 py-2">
                  <div className="relative">
                    <Search className="w-3 h-3 absolute left-2.5 top-2.5 text-slate-400 pointer-events-none" />
                    <input
                      type="text"
                      placeholder="Filter name, ID..."
                      value={colFilters.name}
                      onChange={(e) => setColFilters(prev => ({ ...prev, name: e.target.value }))}
                      className="w-full pl-7 pr-6 py-1 text-[11px] bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-md text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 font-normal shadow-xs"
                    />
                    {colFilters.name && (
                      <button
                        onClick={() => setColFilters(prev => ({ ...prev, name: '' }))}
                        className="absolute right-2 top-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </th>

                {/* Version Filter */}
                <th className="px-4 py-2">
                  <select
                    value={colFilters.version}
                    onChange={(e) => setColFilters(prev => ({ ...prev, version: e.target.value }))}
                    className="w-full py-1 px-2 text-[11px] bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-md text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500 font-normal shadow-xs"
                  >
                    <option value="all">All Versions</option>
                    {uniqueVersions.map(v => (
                      <option key={v} value={v}>{v}</option>
                    ))}
                  </select>
                </th>

                {/* Owner Team Filter */}
                <th className="px-4 py-2">
                  <select
                    value={colFilters.owner}
                    onChange={(e) => setColFilters(prev => ({ ...prev, owner: e.target.value }))}
                    className="w-full py-1 px-2 text-[11px] bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-md text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500 font-normal shadow-xs"
                  >
                    <option value="all">All Owners</option>
                    {uniqueOwners.map(o => (
                      <option key={o} value={o}>{o}</option>
                    ))}
                  </select>
                </th>

                {/* LLM Core Filter */}
                <th className="px-4 py-2">
                  <select
                    value={colFilters.model}
                    onChange={(e) => setColFilters(prev => ({ ...prev, model: e.target.value }))}
                    className="w-full py-1 px-2 text-[11px] bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-md text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500 font-normal shadow-xs"
                  >
                    <option value="all">All Models</option>
                    {uniqueModels.map(m => (
                      <option key={m} value={m}>{m}</option>
                    ))}
                  </select>
                </th>

                {/* Status Filter */}
                <th className="px-4 py-2 text-center">
                  <select
                    value={colFilters.status}
                    onChange={(e) => setColFilters(prev => ({ ...prev, status: e.target.value }))}
                    className="w-full py-1 px-2 text-[11px] bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-md text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500 font-normal shadow-xs text-center"
                  >
                    <option value="all">All Statuses</option>
                    <option value="Active">Active</option>
                    <option value="Draft">Draft</option>
                    <option value="Deprecated">Deprecated</option>
                  </select>
                </th>

                {/* Last Updated Filter */}
                <th className="px-4 py-2">
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="Filter date..."
                      value={colFilters.updated}
                      onChange={(e) => setColFilters(prev => ({ ...prev, updated: e.target.value }))}
                      className="w-full px-2 py-1 text-[11px] bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-md text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 font-normal shadow-xs"
                    />
                    {colFilters.updated && (
                      <button
                        onClick={() => setColFilters(prev => ({ ...prev, updated: '' }))}
                        className="absolute right-2 top-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </th>

                {/* Reset / Actions */}
                <th className="px-6 py-2 text-right">
                  {hasActiveFilters ? (
                    <button
                      type="button"
                      onClick={handleResetFilters}
                      className="px-2.5 py-1 text-[10px] font-bold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-md border border-rose-200 dark:border-rose-800 transition cursor-pointer inline-flex items-center gap-1 shadow-xs"
                      title="Reset all column filters"
                    >
                      <X className="w-3 h-3" /> Reset
                    </button>
                  ) : (
                    <span className="text-[10px] font-mono text-slate-400">Filters</span>
                  )}
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs text-slate-700 dark:text-slate-300">
              {paginatedAgents.map(agent => {
                const isSuper = agent.agentClass === 'super';
                return (
                  <tr 
                    key={agent.id}
                    onClick={() => handleOpenView(agent)}
                    className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition duration-150 cursor-pointer group"
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className={`p-1.5 rounded-lg shrink-0 border ${
                          isSuper 
                            ? 'bg-amber-500/10 border-amber-500/20 text-amber-400' 
                            : 'bg-slate-800 border-slate-700 text-slate-300'
                        }`}>
                          {isSuper ? <Sparkles className="w-3.5 h-3.5 animate-spin" /> : <Cpu className="w-3.5 h-3.5" />}
                        </div>
                        <div>
                          <div className="font-bold text-slate-800 dark:text-slate-100 group-hover:text-indigo-600 dark:group-hover:text-blue-400 transition flex items-center gap-1.5">
                            {agent.name}
                            {isSuper && <span className="text-[8px] uppercase px-1.5 py-0.2 font-mono bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded">Super</span>}
                          </div>
                          <p className="text-[10px] text-slate-500 truncate max-w-[280px] mt-0.5">{agent.description}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap font-mono text-[11px] text-slate-600 dark:text-slate-400">
                      {agent.version || 'v1.0.0'}
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap text-slate-700 dark:text-slate-300 font-medium">
                      {agent.owner || 'Internal Ops'}
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap text-slate-600 dark:text-slate-400 font-mono text-[11px]">
                      {agent.model || 'Claude 3.5 Sonnet'}
                    </td>
                    <td className="px-4 py-4 text-center whitespace-nowrap">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${getStatusColor(agent.status || 'Active')}`}>
                        {agent.status || 'Active'}
                      </span>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap text-slate-500 font-mono text-[11px]">
                      {agent.lastUpdated || '2026-07-18'}
                    </td>
                    <td className="px-6 py-4 text-right" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-end gap-2 opacity-60 group-hover:opacity-100 transition">
                        <button
                          onClick={() => handleOpenView(agent)}
                          className="p-1 hover:bg-slate-700 rounded text-slate-400 hover:text-white transition cursor-pointer"
                          title="View Details"
                        >
                          <ChevronRight className="w-4 h-4" />
                        </button>
                        <button
                          onClick={(e) => { handleToggleEnable(agent.id, e); }}
                          className="p-1 hover:bg-slate-700 rounded text-slate-400 hover:text-white transition cursor-pointer"
                          title={agent.isEnabled ? "Disable Agent" : "Enable Agent"}
                        >
                          {agent.isEnabled ? <ToggleRight className="w-4 h-4 text-emerald-500" /> : <ToggleLeft className="w-4 h-4 text-slate-500" />}
                        </button>
                        <button
                          onClick={(e) => handleDeleteAgent(agent.id, e)}
                          className="p-1 hover:bg-slate-700 rounded text-slate-400 hover:text-rose-400 transition cursor-pointer"
                          title="Delete Agent"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}

              {filteredAgents.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-slate-500">
                    <Bot className="w-12 h-12 text-slate-700 mx-auto mb-3" />
                    <h3 className="font-bold text-slate-400">No agents found</h3>
                    <p className="text-[11px] text-slate-500 mt-1 max-w-sm mx-auto">
                      No registered agents match the selected column filters or query parameters.
                    </p>
                    {hasActiveFilters && (
                      <button
                        onClick={handleResetFilters}
                        className="mt-3 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition cursor-pointer"
                      >
                        Reset All Filters
                      </button>
                    )}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Dynamic Pagination Footer */}
        {totalPages > 1 && (
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 px-6 py-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/30">
            <div className="text-[11px] text-slate-500 font-medium">
              Showing <span className="font-bold text-slate-700 dark:text-slate-300">{Math.min((currentPage - 1) * itemsPerPage + 1, filteredAgents.length)}</span> to <span className="font-bold text-slate-700 dark:text-slate-300">{Math.min(currentPage * itemsPerPage, filteredAgents.length)}</span> of <span className="font-bold text-slate-700 dark:text-slate-300">{filteredAgents.length}</span> agents
            </div>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                className="px-2.5 py-1 text-[11px] font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-40 disabled:hover:bg-white dark:disabled:hover:bg-slate-900 transition cursor-pointer"
              >
                &larr; Previous
              </button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(pageNum => (
                <button
                  key={pageNum}
                  type="button"
                  onClick={() => setCurrentPage(pageNum)}
                  className={`px-2.5 py-1 text-[11px] font-bold rounded border cursor-pointer transition ${
                    currentPage === pageNum
                      ? 'bg-blue-600 border-blue-500 text-white shadow-sm font-extrabold'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                  }`}
                >
                  {pageNum}
                </button>
              ))}
              <button
                type="button"
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                className="px-2.5 py-1 text-[11px] font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-40 disabled:hover:bg-white dark:disabled:hover:bg-slate-900 transition cursor-pointer"
              >
                Next &rarr;
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Delete Agent Confirmation Dialog */}
      <DeleteConfirmModal
        isOpen={!!agentToDelete}
        onClose={() => setAgentToDelete(null)}
        onConfirm={handleConfirmDeleteAgent}
        title="Retire AI Agent"
        description={`Are you sure you want to retire "${agentToDelete?.name}" (${agentToDelete?.id})? This will remove the agent from all active orchestrations and registry pipelines.`}
        confirmLabel="Retire Agent"
      />
    </div>
  );
}
