import React, { useState, useEffect, useMemo } from 'react';
import {
  Server,
  Plus,
  Search,
  Trash2,
  Bot,
  Wrench,
  Check,
  Loader2,
  AlertTriangle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { OrchestrationAgent } from '../../types';
import { DeleteConfirmModal } from '../common/DeleteConfirmModal';
import { mcpGatewaysApi, apiCatalogApi, BackendMcpGateway, BackendApiCatalogEntry } from '../../services/agenticStudioApi';

export interface McpGatewayConfig {
  id: string;
  name: string;
  url: string;
  protocol: 'mcp-sse' | 'mcp-stdio' | 'mcp-websocket' | 'mcp-http';
  status: 'ONLINE' | 'DEGRADED' | 'OFFLINE';
  description: string;
  associatedAgentIds: string[];
  associatedApiIds: string[];
  latencyMs: number;
  uptime: string;
  toolsCount: number;
  environment: 'PRODUCTION' | 'STAGING' | 'SANDBOX';
  authType: 'BEARER_TOKEN' | 'MTLS' | 'API_KEY' | 'NONE';
  lastHeartbeat: string;
}

export interface CatalogApi {
  id: string;
  name: string;
  domain: string;
  process: string;
  endpoint: string;
  method: string;
  description: string;
}

const slugify = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');

// The backend's mcp_gateways table owns name/description/status natively;
// transport fields (url, protocol, authType, environment) and the agent
// association list live in its opaque `config` bag — see schema.sql.
function toGatewayConfig(row: BackendMcpGateway): McpGatewayConfig {
  const cfg = row.config || {};
  const bindings = row.bindings || [];
  return {
    id: row.id,
    name: row.name,
    url: cfg.url || '',
    protocol: cfg.protocol || 'mcp-sse',
    status: row.status === 'active' ? 'ONLINE' : 'OFFLINE',
    description: row.description,
    associatedAgentIds: cfg.associatedAgentIds || [],
    associatedApiIds: bindings.filter((b) => b.api_id).map((b) => b.api_id as string),
    latencyMs: cfg.latencyMs ?? 60,
    uptime: cfg.uptime || '99.9%',
    toolsCount: bindings.length,
    environment: cfg.environment || 'PRODUCTION',
    authType: cfg.authType || 'NONE',
    lastHeartbeat: row.status === 'active' ? 'Just now' : 'Unreachable',
  };
}

function toCatalogApi(row: BackendApiCatalogEntry): CatalogApi {
  return {
    id: row.id,
    name: row.name,
    domain: row.domain,
    process: row.process_label || row.pipeline_id || '',
    endpoint: row.path,
    method: row.method,
    description: row.description,
  };
}

interface McpGatewayViewProps {
  agents?: OrchestrationAgent[];
}

export default function McpGatewayView({ agents = [] }: McpGatewayViewProps) {
  const [rawGateways, setRawGateways] = useState<BackendMcpGateway[]>([]);
  const [rawApis, setRawApis] = useState<BackendApiCatalogEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGatewayId, setSelectedGatewayId] = useState<string | null>(null);
  const [isRegistering, setIsRegistering] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [gatewayToDelete, setGatewayToDelete] = useState<McpGatewayConfig | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    url: '',
    protocol: 'mcp-sse' as 'mcp-sse' | 'mcp-http' | 'mcp-websocket',
    description: '',
    environment: 'PRODUCTION' as 'PRODUCTION' | 'STAGING' | 'SANDBOX',
    authType: 'MTLS' as 'BEARER_TOKEN' | 'MTLS' | 'API_KEY' | 'NONE',
    selectedApis: [] as string[],
    selectedAgents: [] as string[]
  });

  const loadAll = () => {
    setIsLoading(true);
    mcpGatewaysApi.list()
      .then(async (gateways) => {
        const detailed = await Promise.all(gateways.map((g) => mcpGatewaysApi.get(g.id)));
        setRawGateways(detailed);
        const apis = await apiCatalogApi.list();
        setRawApis(apis);
        setLoadError(null);
      })
      .catch((e) => setLoadError(e.message || 'Failed to load MCP gateways from AgenticStudio backend'))
      .finally(() => setIsLoading(false));
  };

  useEffect(() => { loadAll(); }, []);

  const gateways: McpGatewayConfig[] = useMemo(() => rawGateways.map(toGatewayConfig), [rawGateways]);
  const availableApis: CatalogApi[] = useMemo(() => rawApis.map(toCatalogApi), [rawApis]);

  useEffect(() => {
    if (!selectedGatewayId && gateways.length > 0) setSelectedGatewayId(gateways[0].id);
  }, [gateways, selectedGatewayId]);

  const selectedGateway = gateways.find((g) => g.id === selectedGatewayId) || null;

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  const refreshGateway = async (id: string) => {
    const detail = await mcpGatewaysApi.get(id);
    setRawGateways((prev) => prev.map((g) => (g.id === id ? detail : g)));
  };

  const handleSaveGateway = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.url) return;

    setIsSaving(true);
    try {
      const created = await mcpGatewaysApi.create({
        name: formData.name,
        description: formData.description || 'Enterprise MCP Gateway bridge',
        status: 'active',
        config: {
          url: formData.url,
          protocol: formData.protocol,
          authType: formData.authType,
          environment: formData.environment,
          latencyMs: Math.floor(Math.random() * 80) + 40,
          uptime: '100.00%',
          associatedAgentIds: formData.selectedAgents,
        },
      });

      for (const apiId of formData.selectedApis) {
        const api = rawApis.find((a) => a.id === apiId);
        if (!api) continue;
        await mcpGatewaysApi.addBinding(created.id, { apiId, exposedName: slugify(api.path) || slugify(api.name) });
      }

      await refreshGateway(created.id);
      setRawGateways((prev) => (prev.some((g) => g.id === created.id) ? prev : [created, ...prev]));
      setSelectedGatewayId(created.id);
      setIsRegistering(false);
      showToast(`MCP Gateway "${created.name}" registered successfully!`);
      setFormData({
        name: '', url: '', protocol: 'mcp-sse', description: '', environment: 'PRODUCTION',
        authType: 'MTLS', selectedApis: [], selectedAgents: [],
      });
    } catch (err: any) {
      showToast(`Failed to register gateway: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteGateway = (gwId: string) => {
    const target = gateways.find(g => g.id === gwId);
    if (target) setGatewayToDelete(target);
  };

  const handleConfirmDeleteGateway = async () => {
    if (!gatewayToDelete) return;
    try {
      await mcpGatewaysApi.remove(gatewayToDelete.id);
      setRawGateways((prev) => prev.filter((g) => g.id !== gatewayToDelete.id));
      if (selectedGatewayId === gatewayToDelete.id) setSelectedGatewayId(null);
      showToast('MCP Gateway deleted');
    } catch (err: any) {
      showToast(`Failed to delete gateway: ${err.message}`);
    } finally {
      setGatewayToDelete(null);
    }
  };

  const handleToggleApiAssociation = async (gwId: string, apiId: string) => {
    const gwRow = rawGateways.find((g) => g.id === gwId);
    const api = rawApis.find((a) => a.id === apiId);
    if (!gwRow || !api) return;

    const existingBinding = (gwRow.bindings || []).find((b) => b.api_id === apiId);
    try {
      if (existingBinding) {
        await mcpGatewaysApi.removeBinding(gwId, existingBinding.id);
      } else {
        await mcpGatewaysApi.addBinding(gwId, { apiId, exposedName: slugify(api.path) || slugify(api.name) });
      }
      await refreshGateway(gwId);
      showToast('API association updated');
    } catch (err: any) {
      showToast(`Failed to update API association: ${err.message}`);
    }
  };

  const handleToggleAgentAssociation = async (gwId: string, agentId: string) => {
    const gwRow = rawGateways.find((g) => g.id === gwId);
    if (!gwRow) return;

    const current: string[] = gwRow.config?.associatedAgentIds || [];
    const next = current.includes(agentId) ? current.filter((id) => id !== agentId) : [...current, agentId];

    try {
      const updated = await mcpGatewaysApi.update(gwId, { config: { ...gwRow.config, associatedAgentIds: next } });
      setRawGateways((prev) => prev.map((g) => (g.id === gwId ? { ...updated, bindings: g.bindings } : g)));
      showToast('Agent binding updated');
    } catch (err: any) {
      showToast(`Failed to update agent binding: ${err.message}`);
    }
  };

  const filteredGateways = gateways.filter(gw => {
    return gw.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      gw.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      gw.url.toLowerCase().includes(searchTerm.toLowerCase());
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-24 text-slate-400">
        <Loader2 className="w-6 h-6 animate-spin mr-2" /> Loading MCP gateways from AgenticStudio backend…
      </div>
    );
  }

  if (loadError) {
    return (
      <div className="bg-rose-50 border border-rose-200 rounded-2xl p-8 text-center text-rose-700 space-y-2">
        <AlertTriangle className="w-8 h-8 mx-auto" />
        <p className="text-sm font-bold">Could not reach the AgenticStudio backend</p>
        <p className="text-xs">{loadError}</p>
        <p className="text-[11px] text-rose-500">Is it running at the URL in VITE_AGENTICSTUDIO_URL (default http://localhost:4001)?</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 text-slate-800">
      {/* Toast Alert */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-5 right-5 z-50 bg-[#008752] text-white px-4 py-2.5 rounded-xl shadow-xl font-bold text-xs flex items-center gap-2"
          >
            <Check className="w-4 h-4" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header Banner */}
      <div className="bg-white border border-[#A8C4EC]/60 rounded-2xl p-6 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[#00A3E0] text-white rounded-xl shadow-sm">
            <Server className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-[#0B2545] tracking-tight">MCP Gateway Manager</h1>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-100 text-cyan-800 font-bold border border-cyan-300">
                Model Context Protocol v2024-11
              </span>
            </div>
            <p className="text-xs text-slate-600 mt-0.5">
              Provision Model Context Protocol bridges, bind enterprise API catalog endpoints, and assign tools to onboarding agents.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsRegistering(true)}
            className="px-3.5 py-2 bg-[#0474C4] hover:bg-[#008752] text-white font-bold text-xs rounded-xl shadow-sm transition flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Register MCP Bridge</span>
          </button>
        </div>
      </div>

      {/* Register New Modal / Drawer */}
      <AnimatePresence>
        {isRegistering && (
          <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto space-y-4 text-left"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <Server className="w-5 h-5 text-[#0474C4]" />
                  <h3 className="text-base font-bold text-[#0B2545]">Register New MCP Gateway Bridge</h3>
                </div>
                <button
                  onClick={() => setIsRegistering(false)}
                  className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleSaveGateway} className="space-y-4 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Bridge Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. MAS Regulatory Reporting MCP Bridge"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-[#F4F6F8] border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:ring-1 focus:ring-[#0474C4]"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">MCP Endpoint URL</label>
                    <input
                      type="text"
                      required
                      placeholder="mcp://gateway.internal.bank.corp:8080/mcp/v1/..."
                      value={formData.url}
                      onChange={(e) => setFormData({ ...formData, url: e.target.value })}
                      className="w-full font-mono bg-[#F4F6F8] border border-slate-200 rounded-xl px-3 py-2 text-slate-800 text-[11px] focus:outline-none focus:ring-1 focus:ring-[#0474C4]"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Protocol Type</label>
                    <select
                      value={formData.protocol}
                      onChange={(e) => setFormData({ ...formData, protocol: e.target.value as any })}
                      className="w-full bg-[#F4F6F8] border border-slate-200 rounded-xl px-3 py-2 text-slate-700 focus:outline-none"
                    >
                      <option value="mcp-sse">MCP Server-Sent Events (SSE)</option>
                      <option value="mcp-http">MCP HTTP Post Gateway</option>
                      <option value="mcp-websocket">MCP Full-Duplex WebSocket</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Description & Purpose</label>
                  <textarea
                    rows={2}
                    placeholder="Describe which enterprise data sources this MCP gateway exposes as tools..."
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="w-full bg-[#F4F6F8] border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Auth Strategy</label>
                    <select
                      value={formData.authType}
                      onChange={(e) => setFormData({ ...formData, authType: e.target.value as any })}
                      className="w-full bg-[#F4F6F8] border border-slate-200 rounded-xl px-3 py-2 text-slate-700 focus:outline-none"
                    >
                      <option value="MTLS">Mutual TLS (mTLS X.509)</option>
                      <option value="BEARER_TOKEN">OAuth2 / Bearer JWT</option>
                      <option value="API_KEY">Enterprise API Key</option>
                      <option value="NONE">None (Internal VPC)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Target Environment</label>
                    <select
                      value={formData.environment}
                      onChange={(e) => setFormData({ ...formData, environment: e.target.value as any })}
                      className="w-full bg-[#F4F6F8] border border-slate-200 rounded-xl px-3 py-2 text-slate-700 focus:outline-none"
                    >
                      <option value="PRODUCTION">Production</option>
                      <option value="STAGING">Staging</option>
                      <option value="SANDBOX">Sandbox</option>
                    </select>
                  </div>
                </div>

                {/* Associate APIs from Catalog */}
                <div className="space-y-1.5 pt-2">
                  <label className="block font-bold text-[#0B2545] text-xs">
                    Associate APIs from Catalog ({formData.selectedApis.length} selected)
                  </label>
                  <div className="max-h-36 overflow-y-auto border border-slate-200 rounded-xl p-2 bg-[#F4F6F8] space-y-1">
                    {availableApis.map(api => {
                      const isSelected = formData.selectedApis.includes(api.id);
                      return (
                        <div
                          key={api.id}
                          onClick={() => {
                            const newSelection = isSelected
                              ? formData.selectedApis.filter(id => id !== api.id)
                              : [...formData.selectedApis, api.id];
                            setFormData({ ...formData, selectedApis: newSelection });
                          }}
                          className={`p-2 rounded-lg cursor-pointer flex items-center justify-between transition text-xs ${
                            isSelected ? 'bg-cyan-100 text-cyan-900 font-bold border border-cyan-300' : 'bg-white text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          <div>
                            <span className="font-semibold">{api.name}</span>
                            <span className="text-[10px] font-mono text-slate-500 block">{api.domain} • {api.endpoint}</span>
                          </div>
                          {isSelected && <Check className="w-3.5 h-3.5 text-cyan-700" />}
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setIsRegistering(false)}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="px-5 py-2 bg-[#0474C4] hover:bg-[#008752] text-white rounded-xl font-bold transition cursor-pointer shadow-sm disabled:opacity-60"
                  >
                    {isSaving ? 'Deploying…' : 'Save & Deploy Bridge'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Main Two-Column View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

        {/* Left Column: Registered MCP Gateways List */}
        <div className="lg:col-span-5 bg-white border border-[#A8C4EC]/60 rounded-2xl p-4 shadow-sm space-y-3">

          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <span className="text-xs font-bold text-[#0B2545] uppercase font-mono">
              Active MCP Bridges ({gateways.length})
            </span>
            <div className="relative w-40">
              <Search className="w-3 h-3 absolute left-2.5 top-2 text-slate-400" />
              <input
                type="text"
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-7 pr-2 py-1 bg-[#F4F6F8] border border-slate-200 rounded-lg text-xs focus:outline-none"
              />
            </div>
          </div>

          <div className="space-y-2 max-h-[700px] overflow-y-auto pr-1">
            {filteredGateways.map((gw) => {
              const isSelected = selectedGatewayId === gw.id;
              return (
                <div
                  key={gw.id}
                  onClick={() => setSelectedGatewayId(gw.id)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer text-left space-y-2 ${
                    isSelected
                      ? 'bg-[#0B2545] text-white border-[#0B2545] shadow-md'
                      : 'bg-[#F4F6F8] hover:bg-slate-100 text-slate-800 border-slate-200/80'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className={`p-1.5 rounded-lg ${isSelected ? 'bg-cyan-500/20 text-cyan-300' : 'bg-cyan-100 text-[#0474C4]'}`}>
                        <Server className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="text-xs font-bold leading-tight">{gw.name}</h4>
                        <span className={`text-[10px] font-mono block ${isSelected ? 'text-slate-300' : 'text-slate-500'}`}>
                          {gw.protocol.toUpperCase()} • {gw.authType}
                        </span>
                      </div>
                    </div>

                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shrink-0">
                      {gw.status}
                    </span>
                  </div>

                  <p className={`text-[11px] line-clamp-2 ${isSelected ? 'text-slate-300' : 'text-slate-600'}`}>
                    {gw.description}
                  </p>

                  <div className={`pt-2 border-t flex items-center justify-between text-[10px] font-mono ${
                    isSelected ? 'border-white/10 text-slate-300' : 'border-slate-200 text-slate-500'
                  }`}>
                    <span>⚡ {gw.latencyMs}ms avg</span>
                    <span>🛠️ {gw.toolsCount} Tools Attached</span>
                    <span>🤖 {gw.associatedAgentIds.length} Agents</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Selected MCP Bridge Inspector & API/Agent Binding Matrix */}
        <div className="lg:col-span-7 space-y-4">
          {selectedGateway ? (
            <div className="space-y-4">

              {/* Detail Banner */}
              <div className="bg-white border border-[#A8C4EC]/60 rounded-2xl p-5 shadow-sm space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 className="text-base font-bold text-[#0B2545]">{selectedGateway.name}</h2>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold">
                        {selectedGateway.status}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 mt-1 font-mono">{selectedGateway.url}</p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleDeleteGateway(selectedGateway.id)}
                      className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                      title="Delete Gateway"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Gateway Specs */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
                  <div className="p-2.5 bg-[#F4F6F8] rounded-xl border border-slate-200 text-center">
                    <span className="text-[10px] text-slate-500 block">Protocol</span>
                    <span className="font-bold text-[#0B2545]">{selectedGateway.protocol}</span>
                  </div>
                  <div className="p-2.5 bg-[#F4F6F8] rounded-xl border border-slate-200 text-center">
                    <span className="text-[10px] text-slate-500 block">Auth Security</span>
                    <span className="font-bold text-[#0474C4]">{selectedGateway.authType}</span>
                  </div>
                  <div className="p-2.5 bg-[#F4F6F8] rounded-xl border border-slate-200 text-center">
                    <span className="text-[10px] text-slate-500 block">Latency</span>
                    <span className="font-bold text-emerald-700">{selectedGateway.latencyMs}ms</span>
                  </div>
                  <div className="p-2.5 bg-[#F4F6F8] rounded-xl border border-slate-200 text-center">
                    <span className="text-[10px] text-slate-500 block">Uptime</span>
                    <span className="font-bold text-emerald-700">{selectedGateway.uptime}</span>
                  </div>
                </div>
              </div>

              {/* 1. API Catalog Binding Section (Tools Accessible via this MCP Gateway) */}
              <div className="bg-white border border-[#A8C4EC]/60 rounded-2xl p-5 shadow-sm space-y-3">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <div className="flex items-center gap-2">
                    <Wrench className="w-4 h-4 text-[#0474C4]" />
                    <h3 className="text-xs font-bold uppercase font-mono text-[#0B2545]">
                      Bound API Catalog Tools ({selectedGateway.associatedApiIds.length} of {availableApis.length} Active)
                    </h3>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">Click to toggle tool access</span>
                </div>

                <div className="grid grid-cols-1 gap-2 max-h-56 overflow-y-auto pr-1">
                  {availableApis.map(api => {
                    const isBound = selectedGateway.associatedApiIds.includes(api.id);
                    return (
                      <div
                        key={api.id}
                        onClick={() => handleToggleApiAssociation(selectedGateway.id, api.id)}
                        className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                          isBound
                            ? 'bg-blue-50 border-blue-300 text-blue-950 shadow-xs'
                            : 'bg-[#F4F6F8] border-slate-200 text-slate-600 opacity-60 hover:opacity-100'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-extrabold ${
                            api.method === 'GET' ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'
                          }`}>
                            {api.method}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="text-xs font-bold">{api.name}</h4>
                              <span className="text-[10px] font-mono text-slate-500 bg-white px-1.5 py-0.2 rounded border border-slate-200">
                                {api.domain}
                              </span>
                            </div>
                            <span className="text-[10px] font-mono text-slate-500">{api.endpoint}</span>
                          </div>
                        </div>

                        <div className="shrink-0 flex items-center gap-2">
                          <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                            isBound ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-600'
                          }`}>
                            {isBound ? 'BOUND' : 'UNBOUND'}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* 2. Agent Association Section (MCP Gateways may or may not be associated with agents) */}
              <div className="bg-white border border-[#A8C4EC]/60 rounded-2xl p-5 shadow-sm space-y-3">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <div className="flex items-center gap-2">
                    <Bot className="w-4 h-4 text-[#008752]" />
                    <h3 className="text-xs font-bold uppercase font-mono text-[#0B2545]">
                      Associated Onboarding Agents ({selectedGateway.associatedAgentIds.length} Attached)
                    </h3>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">Gateways may operate standalone or agent-wired</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
                  {(agents.length > 0 ? agents : []).map((agent) => {
                    const isAttached = selectedGateway.associatedAgentIds.includes(agent.id);
                    return (
                      <div
                        key={agent.id}
                        onClick={() => handleToggleAgentAssociation(selectedGateway.id, agent.id)}
                        className={`p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between text-xs ${
                          isAttached
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-950 font-semibold shadow-xs'
                            : 'bg-[#F4F6F8] border-slate-200 text-slate-600 opacity-60 hover:opacity-100'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          <Bot className={`w-3.5 h-3.5 ${isAttached ? 'text-emerald-700' : 'text-slate-400'}`} />
                          <span className="truncate">{agent.name}</span>
                        </div>
                        {isAttached ? (
                          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-600 text-white font-bold shrink-0">
                            WIRED
                          </span>
                        ) : (
                          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-200 text-slate-600 font-bold shrink-0">
                            OFF
                          </span>
                        )}
                      </div>
                    );
                  })}
                  {agents.length === 0 && (
                    <p className="text-[11px] text-slate-400 col-span-2 py-4 text-center">
                      No agents loaded yet from the Agent Registry.
                    </p>
                  )}
                </div>
              </div>

            </div>
          ) : (
            <div className="bg-white rounded-2xl p-12 border border-slate-200 text-center text-slate-400">
              <Server className="w-10 h-10 mx-auto mb-2 opacity-40" />
              <p className="text-sm font-bold text-slate-600">Select or register an MCP Gateway</p>
            </div>
          )}
        </div>

      </div>

      {/* Delete MCP Gateway Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={!!gatewayToDelete}
        onClose={() => setGatewayToDelete(null)}
        onConfirm={handleConfirmDeleteGateway}
        title="Delete MCP Gateway"
        description={`Are you sure you want to delete MCP Gateway "${gatewayToDelete?.name}" (${gatewayToDelete?.url})? This will detach its tools and routing bridge.`}
        confirmLabel="Delete Gateway"
      />
    </div>
  );
}
