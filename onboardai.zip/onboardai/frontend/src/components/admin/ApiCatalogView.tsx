import React, { useState, useMemo, useEffect } from 'react';
import {
  Database,
  Plus,
  Search,
  Server,
  CheckCircle2,
  Code,
  Trash2,
  Loader2,
  AlertTriangle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { DeleteConfirmModal } from '../common/DeleteConfirmModal';
import { apiCatalogApi, mcpGatewaysApi, BackendApiCatalogEntry, BackendMcpGateway } from '../../services/agenticStudioApi';

export interface CatalogApiRecord {
  id: string;
  name: string;
  domain: string; // e.g. Corporate Registry, Sanctions & Watchlist, Digital Identity, Tax Compliance
  process: string; // display label, includes the pipeline id (P-XX) when linked
  endpoint: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  version: string;
  description: string;
  category: 'REGISTRY' | 'AML_COMPLIANCE' | 'BANKING_CORE' | 'DOCUMENT_AI' | 'CREDIT_RISK' | 'FRAUD_INTEL';
  rateLimit: string;
  sampleRequest: string;
  sampleResponse: string;
  associatedGatewayNames: string[];
}

// Presentation-only bucket for the method badge/category chip — the
// backend's `domain` is free text, this is just a coarse coloring heuristic.
function deriveCategory(domain: string): CatalogApiRecord['category'] {
  const d = domain.toLowerCase();
  if (d.includes('registry')) return 'REGISTRY';
  if (d.includes('sanction') || d.includes('aml') || d.includes('adverse') || d.includes('watchlist')) return 'AML_COMPLIANCE';
  if (d.includes('document')) return 'DOCUMENT_AI';
  if (d.includes('bank')) return 'BANKING_CORE';
  return 'CREDIT_RISK';
}

function toCatalogRecord(row: BackendApiCatalogEntry, gateways: BackendMcpGateway[]): CatalogApiRecord {
  const process = row.pipeline_id
    ? `${row.process_label || row.pipeline_id} (${row.pipeline_id})`
    : (row.process_label || '—');

  const associatedGatewayNames = gateways
    .filter((gw) => (gw.bindings || []).some((b) => b.api_id === row.id))
    .map((gw) => gw.name);

  let sampleResponse = '';
  try {
    sampleResponse = JSON.stringify(row.sample_response ?? {}, null, 2);
  } catch {
    sampleResponse = String(row.sample_response ?? '');
  }

  return {
    id: row.id,
    name: row.name,
    domain: row.domain,
    process,
    endpoint: row.path,
    method: row.method,
    version: row.version,
    description: row.description,
    category: deriveCategory(row.domain),
    rateLimit: row.rate_limit || '—',
    sampleRequest: row.sample_request || `${row.method} ${row.path}`,
    sampleResponse,
    associatedGatewayNames,
  };
}

// Splits "KYB Entity Verification (P-03)" into { label: 'KYB Entity Verification', pipelineId: 'P-03' }
function parseProcessInput(process: string): { processLabel: string | null; pipelineId: string | null } {
  const match = process.match(/^(.*?)\s*\((P-\d+)\)\s*$/i);
  if (match) return { processLabel: match[1].trim() || null, pipelineId: match[2].toUpperCase() };
  return { processLabel: process.trim() || null, pipelineId: null };
}

export default function ApiCatalogView() {
  const [rawApis, setRawApis] = useState<BackendApiCatalogEntry[]>([]);
  const [rawGateways, setRawGateways] = useState<BackendMcpGateway[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [selectedApiId, setSelectedApiId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [domainFilter, setDomainFilter] = useState<string>('ALL');
  const [isRegistering, setIsRegistering] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [apiToDelete, setApiToDelete] = useState<CatalogApiRecord | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    domain: 'Corporate Registry',
    process: '',
    endpoint: '',
    method: 'GET' as 'GET' | 'POST' | 'PUT' | 'DELETE',
    version: 'v1.0',
    description: '',
    rateLimit: '120 req/min',
    sampleRequest: '',
    sampleResponse: '',
  });

  const loadAll = () => {
    setIsLoading(true);
    Promise.all([apiCatalogApi.list(), mcpGatewaysApi.list()])
      .then(async ([apis, gateways]) => {
        // The list endpoints don't include bindings; fetch each gateway's
        // detail once so "associated gateways" can be derived accurately.
        const detailed = await Promise.all(gateways.map((g) => mcpGatewaysApi.get(g.id)));
        setRawApis(apis);
        setRawGateways(detailed);
        setLoadError(null);
      })
      .catch((e) => setLoadError(e.message || 'Failed to load API catalog from AgenticStudio backend'))
      .finally(() => setIsLoading(false));
  };

  useEffect(() => { loadAll(); }, []);

  const apis: CatalogApiRecord[] = useMemo(
    () => rawApis.map((row) => toCatalogRecord(row, rawGateways)),
    [rawApis, rawGateways],
  );

  useEffect(() => {
    if (!selectedApiId && apis.length > 0) setSelectedApiId(apis[0].id);
  }, [apis, selectedApiId]);

  // The list endpoint omits sample_request/sample_response/openapi_spec to
  // stay lightweight — fetch the full row once an entry is selected so the
  // detail panel has real payloads instead of the list's placeholder shape.
  useEffect(() => {
    if (!selectedApiId) return;
    const current = rawApis.find((a) => a.id === selectedApiId);
    if (current?.sample_response !== undefined && current?.sample_request !== undefined) return;
    let cancelled = false;
    apiCatalogApi.get(selectedApiId)
      .then((full) => {
        if (cancelled) return;
        setRawApis((prev) => prev.map((a) => (a.id === full.id ? full : a)));
      })
      .catch((e) => showToast(`Failed to load API detail: ${e.message}`));
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedApiId]);

  const selectedApi = apis.find((a) => a.id === selectedApiId) || null;

  const domainsList = useMemo(() => {
    const set = new Set<string>();
    apis.forEach(a => set.add(a.domain));
    return Array.from(set);
  }, [apis]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  const handleSaveApi = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.endpoint) return;

    const { processLabel, pipelineId } = parseProcessInput(formData.process);
    let sampleResponseParsed: any = { status: 'success' };
    if (formData.sampleResponse.trim()) {
      try {
        sampleResponseParsed = JSON.parse(formData.sampleResponse);
      } catch {
        sampleResponseParsed = { note: formData.sampleResponse };
      }
    }

    setIsSaving(true);
    try {
      const created = await apiCatalogApi.create({
        name: formData.name,
        method: formData.method,
        path: formData.endpoint,
        description: formData.description || `${formData.method} ${formData.endpoint}`,
        domain: formData.domain,
        pipelineId: pipelineId || undefined,
        processLabel: processLabel || undefined,
        rateLimit: formData.rateLimit,
        version: formData.version,
        sampleRequest: formData.sampleRequest || `${formData.method} ${formData.endpoint}`,
        sampleResponse: sampleResponseParsed,
      });
      setRawApis((prev) => [created, ...prev]);
      setSelectedApiId(created.id);
      setIsRegistering(false);
      showToast(`API "${created.name}" registered in Enterprise Catalog!`);
    } catch (err: any) {
      showToast(`Failed to register API: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteApi = (apiId: string) => {
    const target = apis.find(a => a.id === apiId);
    if (target) setApiToDelete(target);
  };

  const handleConfirmDeleteApi = async () => {
    if (!apiToDelete) return;
    try {
      await apiCatalogApi.remove(apiToDelete.id);
      setRawApis((prev) => prev.filter((a) => a.id !== apiToDelete.id));
      if (selectedApiId === apiToDelete.id) setSelectedApiId(null);
      showToast('API removed from catalog');
    } catch (err: any) {
      showToast(`Failed to delete API: ${err.message}`);
    } finally {
      setApiToDelete(null);
    }
  };

  const filteredApis = apis.filter(api => {
    const matchesSearch = searchTerm === '' ||
      api.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      api.endpoint.toLowerCase().includes(searchTerm.toLowerCase()) ||
      api.process.toLowerCase().includes(searchTerm.toLowerCase()) ||
      api.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDomain = domainFilter === 'ALL' || api.domain === domainFilter;
    return matchesSearch && matchesDomain;
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-24 text-slate-400">
        <Loader2 className="w-6 h-6 animate-spin mr-2" /> Loading API catalog from AgenticStudio backend…
      </div>
    );
  }

  if (loadError) {
    return (
      <div className="bg-rose-50 border border-rose-200 rounded-2xl p-8 text-center text-rose-700 space-y-2">
        <AlertTriangle className="w-8 h-8 mx-auto" />
        <p className="text-sm font-bold">Could not reach the AgenticStudio backend</p>
        <p className="text-xs">{loadError}</p>
        <p className="text-[11px] text-rose-500">Is it running at the URL in VITE_AGENTICSTUDIO_URL (default http://localhost:4001)?</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 text-slate-800">
      {/* Toast Alert */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-5 right-5 z-50 bg-[#008752] text-white px-4 py-2.5 rounded-xl shadow-xl font-bold text-xs flex items-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header Banner */}
      <div className="bg-white border border-[#A8C4EC]/60 rounded-2xl p-6 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[#0474C4] text-white rounded-xl shadow-sm">
            <Database className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-[#0B2545] tracking-tight">Enterprise API Catalog</h1>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-blue-100 text-[#0474C4] font-bold border border-blue-300">
                {apis.length} REGISTERED ENDPOINTS
              </span>
            </div>
            <p className="text-xs text-slate-600 mt-0.5">
              Register domain & process APIs that are exposed as tools and bound to MCP Gateways for autonomous agent execution.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsRegistering(true)}
            className="px-3.5 py-2 bg-[#008752] hover:bg-[#006e42] text-white font-bold text-xs rounded-xl shadow-sm transition flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Register New API</span>
          </button>
        </div>
      </div>

      {/* Register New API Modal */}
      <AnimatePresence>
        {isRegistering && (
          <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto space-y-4 text-left"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <Database className="w-5 h-5 text-[#0474C4]" />
                  <h3 className="text-base font-bold text-[#0B2545]">Register API into Enterprise Catalog</h3>
                </div>
                <button
                  onClick={() => setIsRegistering(false)}
                  className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleSaveApi} className="space-y-3.5 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">API Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Hong Kong ICR Registry Direct Search"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-[#F4F6F8] border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Domain</label>
                    <select
                      value={formData.domain}
                      onChange={(e) => setFormData({ ...formData, domain: e.target.value })}
                      className="w-full bg-[#F4F6F8] border border-slate-200 rounded-xl px-3 py-2 text-slate-700 focus:outline-none"
                    >
                      <option value="Corporate Registry">Corporate Registry</option>
                      <option value="Sanctions & Watchlist">Sanctions & Watchlist</option>
                      <option value="Adverse Media">Adverse Media</option>
                      <option value="Digital Identity">Digital Identity</option>
                      <option value="Tax Compliance">Tax Compliance</option>
                      <option value="Document Intelligence">Document Intelligence</option>
                      <option value="Core Banking">Core Banking</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Target Process Flow</label>
                    <input
                      type="text"
                      placeholder="e.g. KYB Entity Verification (P-03)"
                      value={formData.process}
                      onChange={(e) => setFormData({ ...formData, process: e.target.value })}
                      className="w-full bg-[#F4F6F8] border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="md:col-span-1">
                    <label className="block font-semibold text-slate-700 mb-1">HTTP Method</label>
                    <select
                      value={formData.method}
                      onChange={(e) => setFormData({ ...formData, method: e.target.value as any })}
                      className="w-full bg-[#F4F6F8] border border-slate-200 rounded-xl px-3 py-2 text-slate-700 focus:outline-none"
                    >
                      <option value="GET">GET</option>
                      <option value="POST">POST</option>
                      <option value="PUT">PUT</option>
                      <option value="DELETE">DELETE</option>
                    </select>
                  </div>

                  <div className="md:col-span-2">
                    <label className="block font-semibold text-slate-700 mb-1">Endpoint Path</label>
                    <input
                      type="text"
                      required
                      placeholder="/api/v1/hk/icr/company"
                      value={formData.endpoint}
                      onChange={(e) => setFormData({ ...formData, endpoint: e.target.value })}
                      className="w-full font-mono bg-[#F4F6F8] border border-slate-200 rounded-xl px-3 py-2 text-slate-800 text-[11px] focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Description</label>
                  <textarea
                    rows={2}
                    placeholder="Describe what data or transaction this API executes..."
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="w-full bg-[#F4F6F8] border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Sample Response (JSON)</label>
                  <textarea
                    rows={3}
                    placeholder='{"status": "SUCCESS", "records": []}'
                    value={formData.sampleResponse}
                    onChange={(e) => setFormData({ ...formData, sampleResponse: e.target.value })}
                    className="w-full font-mono bg-[#F4F6F8] border border-slate-200 rounded-xl px-3 py-2 text-slate-800 text-[11px] focus:outline-none"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setIsRegistering(false)}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="px-5 py-2 bg-[#008752] hover:bg-[#006e42] text-white rounded-xl font-bold transition cursor-pointer shadow-sm disabled:opacity-60"
                  >
                    {isSaving ? 'Registering…' : 'Register API'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Main Two-Column View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

        {/* Left Column: API Catalog List with Filters */}
        <div className="lg:col-span-5 bg-white border border-[#A8C4EC]/60 rounded-2xl p-4 shadow-sm space-y-3">

          <div className="flex flex-col gap-2 pb-2 border-b border-slate-100">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#0B2545] uppercase font-mono">
                API Catalog ({filteredApis.length})
              </span>
              <select
                value={domainFilter}
                onChange={(e) => setDomainFilter(e.target.value)}
                className="bg-[#F4F6F8] border border-slate-200 text-[11px] rounded-lg px-2 py-1 text-slate-700 focus:outline-none"
              >
                <option value="ALL">All Domains</option>
                {domainsList.map(d => (
                  <option key={d} value={d}>{d}</option>
                ))}
              </select>
            </div>

            <div className="relative w-full">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search endpoints, processes, domains..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 bg-[#F4F6F8] border border-slate-200 rounded-xl text-xs focus:outline-none"
              />
            </div>
          </div>

          <div className="space-y-2 max-h-[700px] overflow-y-auto pr-1">
            {filteredApis.map((api) => {
              const isSelected = selectedApiId === api.id;
              return (
                <div
                  key={api.id}
                  onClick={() => setSelectedApiId(api.id)}
                  className={`p-3 rounded-xl border transition-all cursor-pointer text-left space-y-1.5 ${
                    isSelected
                      ? 'bg-[#0B2545] text-white border-[#0B2545] shadow-md'
                      : 'bg-[#F4F6F8] hover:bg-slate-100 text-slate-800 border-slate-200/80'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-extrabold ${
                        api.method === 'GET'
                          ? 'bg-emerald-100 text-emerald-800'
                          : api.method === 'POST'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-amber-100 text-amber-800'
                      }`}>
                        {api.method}
                      </span>
                      <h4 className="text-xs font-bold leading-tight truncate max-w-[200px]">{api.name}</h4>
                    </div>

                    <span className={`text-[9px] font-mono px-1.5 py-0.2 rounded shrink-0 ${
                      isSelected ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-700'
                    }`}>
                      {api.domain}
                    </span>
                  </div>

                  <div className={`font-mono text-[10px] truncate ${isSelected ? 'text-cyan-300' : 'text-blue-700'}`}>
                    {api.endpoint}
                  </div>

                  <div className={`flex items-center justify-between text-[10px] font-mono pt-1 ${
                    isSelected ? 'text-slate-300' : 'text-slate-500'
                  }`}>
                    <span className="truncate max-w-[180px]">⚙️ {api.process}</span>
                    <span>{api.rateLimit}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: API Catalog Inspector, Schema & Bridge Binding */}
        <div className="lg:col-span-7 space-y-4">
          {selectedApi ? (
            <div className="space-y-4">

              {/* Detail Header Banner */}
              <div className="bg-white border border-[#A8C4EC]/60 rounded-2xl p-5 shadow-sm space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-xs font-mono font-extrabold ${
                        selectedApi.method === 'GET' ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'
                      }`}>
                        {selectedApi.method}
                      </span>
                      <h2 className="text-base font-bold text-[#0B2545]">{selectedApi.name}</h2>
                    </div>
                    <p className="text-xs font-mono text-[#0474C4] mt-1 font-semibold">{selectedApi.endpoint}</p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleDeleteApi(selectedApi.id)}
                      className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                      title="Delete API"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">{selectedApi.description}</p>

                {/* Meta Attributes */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono pt-1">
                  <div className="p-2 bg-[#F4F6F8] rounded-xl border border-slate-200">
                    <span className="text-[10px] text-slate-500 block">Domain</span>
                    <span className="font-bold text-[#0B2545]">{selectedApi.domain}</span>
                  </div>
                  <div className="p-2 bg-[#F4F6F8] rounded-xl border border-slate-200">
                    <span className="text-[10px] text-slate-500 block">Process</span>
                    <span className="font-bold text-[#0474C4] truncate block">{selectedApi.process}</span>
                  </div>
                  <div className="p-2 bg-[#F4F6F8] rounded-xl border border-slate-200">
                    <span className="text-[10px] text-slate-500 block">Rate Limit</span>
                    <span className="font-bold text-emerald-700">{selectedApi.rateLimit}</span>
                  </div>
                  <div className="p-2 bg-[#F4F6F8] rounded-xl border border-slate-200">
                    <span className="text-[10px] text-slate-500 block">Version</span>
                    <span className="font-bold text-slate-700">{selectedApi.version}</span>
                  </div>
                </div>
              </div>

              {/* Sample Request & Response */}
              <div className="bg-white border border-[#A8C4EC]/60 rounded-2xl p-5 shadow-sm space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-bold font-mono text-[#0B2545] uppercase flex items-center gap-1.5">
                      <Code className="w-3.5 h-3.5 text-[#0474C4]" /> Sample Request Payload
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">OpenAPI Spec v3</span>
                  </div>
                  <pre className="p-3 bg-[#0B2545] text-cyan-200 rounded-xl font-mono text-[11px] overflow-x-auto leading-relaxed border border-[#00A3E0]/20">
                    {selectedApi.sampleRequest}
                  </pre>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-bold font-mono text-[#0B2545] uppercase flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Expected Response Schema
                    </span>
                    <span className="text-[10px] font-mono text-emerald-600 font-bold">200 OK</span>
                  </div>
                  <pre className="p-3 bg-[#0B2545] text-emerald-200 rounded-xl font-mono text-[11px] overflow-x-auto leading-relaxed border border-[#00A3E0]/20">
                    {selectedApi.sampleResponse}
                  </pre>
                </div>
              </div>

              {/* Associated MCP Gateways */}
              <div className="bg-white border border-[#A8C4EC]/60 rounded-2xl p-4 shadow-sm flex items-center justify-between gap-3">
                <div className="flex items-center gap-2 min-w-0">
                  <Server className="w-4 h-4 text-[#008752] shrink-0" />
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-[#0B2545]">Exposed via MCP Gateway</h4>
                    <p className="text-[11px] text-slate-500 truncate">
                      {selectedApi.associatedGatewayNames.length > 0
                        ? selectedApi.associatedGatewayNames.join(', ')
                        : 'Not yet bound to any gateway — bind it from the MCP Gateway Manager.'}
                    </p>
                  </div>
                </div>
                {selectedApi.associatedGatewayNames.length > 0 ? (
                  <span className="text-xs font-mono font-bold px-3 py-1 bg-emerald-100 text-emerald-800 rounded-lg border border-emerald-300 shrink-0">
                    AVAILABLE AS TOOL
                  </span>
                ) : (
                  <span className="text-xs font-mono font-bold px-3 py-1 bg-slate-100 text-slate-500 rounded-lg border border-slate-300 shrink-0">
                    UNBOUND
                  </span>
                )}
              </div>

            </div>
          ) : (
            <div className="bg-white rounded-2xl p-12 border border-slate-200 text-center text-slate-400">
              <Database className="w-10 h-10 mx-auto mb-2 opacity-40" />
              <p className="text-sm font-bold text-slate-600">Select an API from the catalog to view details</p>
            </div>
          )}
        </div>

      </div>

      {/* Delete API Confirmation Dialog */}
      <DeleteConfirmModal
        isOpen={!!apiToDelete}
        onClose={() => setApiToDelete(null)}
        onConfirm={handleConfirmDeleteApi}
        title="Delete API from Catalog"
        description={`Are you sure you want to delete API "${apiToDelete?.name}" (${apiToDelete?.endpoint}) from the institutional catalog?`}
        confirmLabel="Delete API"
      />
    </div>
  );
}
