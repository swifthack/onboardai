import React, { useState, useMemo, useEffect } from 'react';
import {
  ShieldCheck,
  Search,
  CheckCircle2,
  XCircle,
  Sliders,
  Lock,
  FileText,
  Cpu,
  Database,
  Wrench,
  Sparkles,
  Coins,
  Scale,
  Bot,
  Activity,
  TrendingDown,
  Layers,
  Loader2,
  AlertTriangle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { guardrailDomainsApi, guardrailsApi, BackendGuardrail, BackendGuardrailDomain } from '../../services/agenticStudioApi';

// ── Backend <-> UI shape bridging ───────────────────────────────────────
// AgenticStudio's `guardrails` table owns domain_id/name/description/
// severity/enforcement/enabled natively, plus an opaque `config` JSONB bag.
// This view's richer display fields (a short `code`, the 5-way
// actionOnBreach, a simulated latency figure, and parameter chips) live
// inside that bag — `code`/`actionOnBreach`/`latencyImpactMs` are reserved
// config keys the UI knows about; every other config key is shown as a
// generic parameter chip, so the real seeded config (max_chars,
// score_threshold, etc.) displays automatically with no extra mapping.

export interface GuardrailRule {
  id: string;
  name: string;
  code: string;
  description: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  enabled: boolean;
  actionOnBreach: 'BLOCK' | 'REDACT' | 'FLAG_AUDIT' | 'ROUTE_HUMAN' | 'THROTTLE';
  latencyImpactMs: number;
  parameters: { key: string; value: string; label: string }[];
}

export interface GuardrailDomain {
  id: string;
  name: string;
  icon: React.ComponentType<any>;
  color: string;
  description: string;
  category: 'Safety & Security' | 'Operations & Cost' | 'Compliance & Intelligence';
  rules: GuardrailRule[];
}

export const DOMAIN_ICON_MAP: Record<string, React.ComponentType<any>> = {
  input: ShieldCheck,
  prompt: Sparkles,
  retrieval: Database,
  tools: Wrench,
  output: FileText,
  runtime: Cpu,
  memory: Layers,
  tokenomics: Coins,
  security: Lock,
  regulatory: Scale,
  agentic_ai: Bot,
  observability: Activity,
  cost_optimization: TrendingDown,
};

const DOMAIN_COLOR_MAP: Record<string, string> = {
  input: '#0474C4',
  prompt: '#00A3E0',
  retrieval: '#5379AE',
  tools: '#008752',
  output: '#06457F',
  runtime: '#262B40',
  memory: '#3E4766',
  tokenomics: '#E06A3B',
  security: '#EB001B',
  regulatory: '#06457F',
  agentic_ai: '#00A3E0',
  observability: '#008752',
  cost_optimization: '#0474C4',
};

const DOMAIN_CATEGORY_MAP: Record<string, GuardrailDomain['category']> = {
  input: 'Safety & Security',
  prompt: 'Safety & Security',
  retrieval: 'Compliance & Intelligence',
  tools: 'Safety & Security',
  output: 'Safety & Security',
  runtime: 'Operations & Cost',
  memory: 'Safety & Security',
  tokenomics: 'Operations & Cost',
  security: 'Safety & Security',
  regulatory: 'Compliance & Intelligence',
  agentic_ai: 'Compliance & Intelligence',
  observability: 'Operations & Cost',
  cost_optimization: 'Operations & Cost',
};

export const getDomainIcon = (domainId: string): React.ComponentType<any> => {
  return DOMAIN_ICON_MAP[domainId] || ShieldCheck;
};

const RESERVED_CONFIG_KEYS = new Set(['code', 'actionOnBreach', 'latencyImpactMs']);

const humanizeKey = (key: string) =>
  key.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());

const enforcementToAction = (enforcement: BackendGuardrail['enforcement']): GuardrailRule['actionOnBreach'] => {
  if (enforcement === 'block') return 'BLOCK';
  if (enforcement === 'warn') return 'FLAG_AUDIT';
  return 'FLAG_AUDIT'; // 'log'
};

function toGuardrailRule(row: BackendGuardrail): GuardrailRule {
  const cfg = row.config || {};
  const parameters = Object.entries(cfg)
    .filter(([k, v]) => !RESERVED_CONFIG_KEYS.has(k) && v !== null && v !== undefined && !(Array.isArray(v) && v.length === 0))
    .map(([k, v]) => ({ key: k, label: humanizeKey(k), value: Array.isArray(v) ? v.join(', ') : String(v) }));

  return {
    id: row.id,
    name: row.name,
    code: cfg.code || row.name.toUpperCase().replace(/[^A-Z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 40),
    description: row.description,
    severity: row.severity.toUpperCase() as GuardrailRule['severity'],
    enabled: row.enabled,
    actionOnBreach: cfg.actionOnBreach || enforcementToAction(row.enforcement),
    latencyImpactMs: cfg.latencyImpactMs ?? 5,
    parameters,
  };
}

export default function GuardrailsView() {
  const [rawDomains, setRawDomains] = useState<BackendGuardrailDomain[]>([]);
  const [rawGuardrails, setRawGuardrails] = useState<BackendGuardrail[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [selectedDomainId, setSelectedDomainId] = useState<string>('input');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSeverity, setSelectedSeverity] = useState<string>('ALL');
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setSuccessToast(msg);
    setTimeout(() => setSuccessToast(null), 2500);
  };

  useEffect(() => {
    let cancelled = false;
    Promise.all([guardrailDomainsApi.list(), guardrailsApi.list()])
      .then(([domains, guardrails]) => {
        if (cancelled) return;
        setRawDomains(domains);
        setRawGuardrails(guardrails);
        if (domains.length > 0) setSelectedDomainId((prev) => domains.some((d) => d.id === prev) ? prev : domains[0].id);
      })
      .catch((e) => { if (!cancelled) setLoadError(e.message || 'Failed to load guardrails from AgenticStudio backend'); })
      .finally(() => { if (!cancelled) setIsLoading(false); });
    return () => { cancelled = true; };
  }, []);

  const domains: GuardrailDomain[] = useMemo(() => {
    return rawDomains.map((d) => ({
      id: d.id,
      name: d.name.endsWith('Guardrails') ? d.name : `${d.name} Guardrails`,
      icon: getDomainIcon(d.id),
      color: DOMAIN_COLOR_MAP[d.id] || '#0474C4',
      description: d.description,
      category: DOMAIN_CATEGORY_MAP[d.id] || 'Safety & Security',
      rules: rawGuardrails.filter((g) => g.domain_id === d.id).map(toGuardrailRule),
    }));
  }, [rawDomains, rawGuardrails]);

  const activeDomain = useMemo(() => {
    return domains.find(d => d.id === selectedDomainId) || domains[0];
  }, [domains, selectedDomainId]);

  // Counts & Stats
  const stats = useMemo(() => {
    let totalRules = 0;
    let enabledRules = 0;
    let criticalRules = 0;
    domains.forEach(d => {
      d.rules.forEach(r => {
        totalRules++;
        if (r.enabled) enabledRules++;
        if (r.severity === 'CRITICAL') criticalRules++;
      });
    });
    return {
      totalDomains: domains.length,
      totalRules,
      enabledRules,
      criticalRules,
      complianceScore: totalRules > 0 ? Math.round((enabledRules / totalRules) * 100) : 0
    };
  }, [domains]);

  const toggleRule = (domainId: string, ruleId: string) => {
    const current = rawGuardrails.find(g => g.id === ruleId);
    if (!current) return;
    const nextEnabled = !current.enabled;

    setRawGuardrails(prev => prev.map(g => g.id === ruleId ? { ...g, enabled: nextEnabled } : g));
    showToast('Rule updated successfully');

    guardrailsApi.update(ruleId, { enabled: nextEnabled }).catch((e) => {
      setRawGuardrails(prev => prev.map(g => g.id === ruleId ? { ...g, enabled: current.enabled } : g));
      showToast(`Failed to update rule: ${e.message}`);
    });
  };

  const updateRuleAction = (domainId: string, ruleId: string, action: GuardrailRule['actionOnBreach']) => {
    const current = rawGuardrails.find(g => g.id === ruleId);
    if (!current) return;
    const nextConfig = { ...current.config, actionOnBreach: action };

    setRawGuardrails(prev => prev.map(g => g.id === ruleId ? { ...g, config: nextConfig } : g));
    showToast(`Enforcement action changed to ${action}`);

    guardrailsApi.update(ruleId, { config: nextConfig }).catch((e) => {
      setRawGuardrails(prev => prev.map(g => g.id === ruleId ? { ...g, config: current.config } : g));
      showToast(`Failed to update action: ${e.message}`);
    });
  };

  const handleToggleAllInDomain = (domainId: string, enable: boolean) => {
    const targets = rawGuardrails.filter(g => g.domain_id === domainId);
    setRawGuardrails(prev => prev.map(g => g.domain_id === domainId ? { ...g, enabled: enable } : g));
    showToast(`All rules in ${activeDomain.name} ${enable ? 'enabled' : 'disabled'}`);

    Promise.all(targets.map(g => guardrailsApi.update(g.id, { enabled: enable })))
      .catch((e) => showToast(`Some updates failed to save: ${e.message}`));
  };

  const filteredRules = useMemo(() => {
    if (!activeDomain) return [];
    return activeDomain.rules.filter(r => {
      const matchesSearch = searchTerm === '' ||
        r.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesSeverity = selectedSeverity === 'ALL' || r.severity === selectedSeverity;
      return matchesSearch && matchesSeverity;
    });
  }, [activeDomain, searchTerm, selectedSeverity]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-24 text-slate-400">
        <Loader2 className="w-6 h-6 animate-spin mr-2" /> Loading guardrails from AgenticStudio backend…
      </div>
    );
  }

  if (loadError || !activeDomain) {
    return (
      <div className="bg-rose-50 border border-rose-200 rounded-2xl p-8 text-center text-rose-700 space-y-2">
        <AlertTriangle className="w-8 h-8 mx-auto" />
        <p className="text-sm font-bold">Could not reach the AgenticStudio backend</p>
        <p className="text-xs">{loadError || 'No guardrail domains were returned.'}</p>
        <p className="text-[11px] text-rose-500">Is it running at the URL in VITE_AGENTICSTUDIO_URL (default http://localhost:4001)?</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 text-slate-800">
      {/* Toast */}
      <AnimatePresence>
        {successToast && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-5 right-5 z-50 bg-[#008752] text-white px-4 py-2.5 rounded-xl shadow-xl font-bold text-xs flex items-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{successToast}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header Banner */}
      <div className="bg-white border border-[#A8C4EC]/60 rounded-2xl p-6 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2.5 bg-[#0474C4] text-white rounded-xl shadow-sm">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-[#0B2545] tracking-tight">Enterprise Agent Guardrails Framework</h1>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold border border-emerald-300">
                  {stats.totalDomains} DOMAINS ACTIVE
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-0.5">
                Comprehensive security, deterministic compliance, safety, tokenomics, and agentic autonomy boundaries.
              </p>
            </div>
          </div>
        </div>

        {/* Global Summary Metric Cards */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="bg-[#F4F6F8] px-3.5 py-2 rounded-xl border border-slate-200 text-center">
            <span className="text-[10px] uppercase font-mono text-slate-500 block font-bold">Total Domains</span>
            <span className="text-base font-extrabold text-[#0B2545]">{stats.totalDomains}</span>
          </div>
          <div className="bg-[#F4F6F8] px-3.5 py-2 rounded-xl border border-slate-200 text-center">
            <span className="text-[10px] uppercase font-mono text-slate-500 block font-bold">Active Rules</span>
            <span className="text-base font-extrabold text-[#008752]">{stats.enabledRules} / {stats.totalRules}</span>
          </div>
          <div className="bg-[#F4F6F8] px-3.5 py-2 rounded-xl border border-slate-200 text-center">
            <span className="text-[10px] uppercase font-mono text-slate-500 block font-bold">Critical Gates</span>
            <span className="text-base font-extrabold text-[#EB001B]">{stats.criticalRules}</span>
          </div>
          <div className="bg-emerald-50 px-3.5 py-2 rounded-xl border border-emerald-200 text-center">
            <span className="text-[10px] uppercase font-mono text-emerald-700 block font-bold">Posture Score</span>
            <span className="text-base font-extrabold text-[#008752]">{stats.complianceScore}%</span>
          </div>
        </div>
      </div>

      {/* Main Two-Column Guardrails Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

        {/* Left Column: Guardrail Domains Navigation List */}
        <div className="lg:col-span-4 bg-white border border-[#A8C4EC]/60 rounded-2xl p-4 shadow-sm space-y-3">
          <div className="px-2 pb-2 border-b border-slate-100 flex items-center justify-between">
            <span className="text-xs font-bold text-[#0B2545] uppercase tracking-wider font-mono">
              {stats.totalDomains} Policy Domains
            </span>
            <span className="text-[10px] font-mono text-slate-500">
              Select to inspect
            </span>
          </div>

          <div className="space-y-1.5 max-h-[720px] overflow-y-auto pr-1">
            {domains.map((domain, index) => {
              const Icon = getDomainIcon(domain.id);
              const isSelected = domain.id === selectedDomainId;
              const activeCount = domain.rules.filter(r => r.enabled).length;
              const totalCount = domain.rules.length;

              return (
                <button
                  key={domain.id}
                  onClick={() => setSelectedDomainId(domain.id)}
                  className={`w-full text-left p-3 rounded-xl transition-all flex items-center justify-between cursor-pointer border ${
                    isSelected
                      ? 'bg-[#0B2545] text-white border-[#0B2545] shadow-md'
                      : 'bg-[#F4F6F8] hover:bg-slate-100 text-slate-700 border-slate-200/80'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                        isSelected ? 'bg-white/20 text-white' : 'bg-white text-[#0474C4] border border-slate-200 shadow-xs'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="truncate">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-mono font-bold opacity-70">#{index + 1}</span>
                        <h4 className="text-xs font-bold truncate">{domain.name}</h4>
                      </div>
                      <p className={`text-[10px] truncate ${isSelected ? 'text-slate-300' : 'text-slate-500'}`}>
                        {domain.category}
                      </p>
                    </div>
                  </div>

                  <div className="text-right shrink-0 pl-2">
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold ${
                        isSelected
                          ? 'bg-emerald-500/30 text-emerald-300 border border-emerald-400/40'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {activeCount}/{totalCount}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: Selected Domain Detail & Interactive Rule Configuration */}
        <div className="lg:col-span-8 space-y-4">

          {/* Domain Banner Card */}
          <div className="bg-white border border-[#A8C4EC]/60 rounded-2xl p-5 shadow-sm space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-[#0474C4] text-white shadow-sm">
                  {React.createElement(getDomainIcon(activeDomain.id), { className: 'w-5 h-5' })}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base font-bold text-[#0B2545]">{activeDomain.name}</h2>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-100 text-[#0474C4] font-bold">
                      {activeDomain.category}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                    {activeDomain.description}
                  </p>
                </div>
              </div>

              {/* Quick Batch Actions */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => handleToggleAllInDomain(activeDomain.id, true)}
                  className="px-2.5 py-1.5 bg-[#008752] hover:bg-[#006e42] text-white rounded-lg text-xs font-bold transition cursor-pointer shadow-xs"
                >
                  Enable All
                </button>
                <button
                  onClick={() => handleToggleAllInDomain(activeDomain.id, false)}
                  className="px-2.5 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-xs font-bold transition cursor-pointer"
                >
                  Disable All
                </button>
              </div>
            </div>

            {/* Filter and Search within Domain */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-1">
              <div className="relative w-full sm:w-64">
                <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search rules in this domain..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 bg-[#F4F6F8] border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-[#0474C4]"
                />
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <span className="text-[11px] font-semibold text-slate-500">Severity:</span>
                <select
                  value={selectedSeverity}
                  onChange={(e) => setSelectedSeverity(e.target.value)}
                  className="bg-[#F4F6F8] border border-slate-200 text-xs rounded-xl px-2.5 py-1.5 text-slate-700 focus:outline-none"
                >
                  <option value="ALL">All Severities</option>
                  <option value="CRITICAL">Critical</option>
                  <option value="HIGH">High</option>
                  <option value="MEDIUM">Medium</option>
                  <option value="LOW">Low</option>
                </select>
              </div>
            </div>
          </div>

          {/* Rules List for Selected Domain */}
          <div className="space-y-3.5">
            {filteredRules.length === 0 ? (
              <div className="bg-white rounded-2xl p-8 border border-slate-200 text-center text-slate-400">
                <ShieldCheck className="w-8 h-8 mx-auto mb-2 opacity-40 text-slate-500" />
                <p className="text-xs font-bold text-slate-600">No matching guardrail rules found</p>
                <p className="text-[11px] mt-1 text-slate-400">Try adjusting your search query or severity filter.</p>
              </div>
            ) : (
              filteredRules.map((rule) => {
                const isCritical = rule.severity === 'CRITICAL';
                const isHigh = rule.severity === 'HIGH';

                return (
                  <div
                    key={rule.id}
                    className={`bg-white rounded-2xl border p-5 transition-all shadow-sm ${
                      rule.enabled
                        ? 'border-slate-200 hover:border-[#0474C4]'
                        : 'border-slate-200/60 opacity-60 bg-slate-50'
                    }`}
                  >
                    <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">

                      {/* Left info */}
                      <div className="space-y-2 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-bold border border-slate-200">
                            {rule.code}
                          </span>

                          <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-extrabold ${
                            isCritical
                              ? 'bg-rose-100 text-rose-800 border border-rose-300'
                              : isHigh
                                ? 'bg-amber-100 text-amber-800 border border-amber-300'
                                : 'bg-blue-100 text-blue-800 border border-blue-300'
                          }`}>
                            {rule.severity}
                          </span>

                          <span className="text-[10px] font-mono text-slate-400 flex items-center gap-1">
                            <Activity className="w-3 h-3 text-cyan-600" /> +{rule.latencyImpactMs}ms latency
                          </span>
                        </div>

                        <h3 className="text-sm font-bold text-[#0B2545]">{rule.name}</h3>
                        <p className="text-xs text-slate-600 leading-relaxed">{rule.description}</p>

                        {/* Parameter Chips */}
                        {rule.parameters && rule.parameters.length > 0 && (
                          <div className="pt-2 flex items-center gap-2 flex-wrap">
                            <span className="text-[10px] font-mono text-slate-400 uppercase font-semibold">Config:</span>
                            {rule.parameters.map((param, pIdx) => (
                              <div key={pIdx} className="text-[10px] font-mono bg-[#F4F6F8] border border-slate-200 px-2 py-1 rounded-lg text-slate-700 flex items-center gap-1">
                                <span className="text-slate-500">{param.label}:</span>
                                <span className="font-bold text-[#0474C4]">{param.value}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Right controls */}
                      <div className="flex flex-col sm:flex-row md:flex-col items-end gap-3 shrink-0 pt-1 md:pt-0 border-t md:border-t-0 border-slate-100">
                        {/* Toggle Button */}
                        <button
                          onClick={() => toggleRule(activeDomain.id, rule.id)}
                          className={`w-full sm:w-auto px-3.5 py-1.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer ${
                            rule.enabled
                              ? 'bg-[#008752] text-white hover:bg-[#006e42] shadow-sm'
                              : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                          }`}
                        >
                          {rule.enabled ? (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>Enforced</span>
                            </>
                          ) : (
                            <>
                              <XCircle className="w-3.5 h-3.5" />
                              <span>Disabled</span>
                            </>
                          )}
                        </button>

                        {/* Action on Breach Dropdown */}
                        <div className="w-full sm:w-auto text-right">
                          <label className="block text-[10px] font-mono text-slate-400 mb-1">Action on Breach:</label>
                          <select
                            value={rule.actionOnBreach}
                            disabled={!rule.enabled}
                            onChange={(e) => updateRuleAction(activeDomain.id, rule.id, e.target.value as GuardrailRule['actionOnBreach'])}
                            className="bg-[#F4F6F8] border border-slate-200 text-xs font-semibold rounded-lg px-2.5 py-1 text-slate-700 focus:outline-none cursor-pointer disabled:opacity-50"
                          >
                            <option value="BLOCK">🛑 Block Request</option>
                            <option value="REDACT">✂️ Redact & Tokenize</option>
                            <option value="ROUTE_HUMAN">👤 Route to Human (RM)</option>
                            <option value="FLAG_AUDIT">⚠️ Flag & Write Audit</option>
                            <option value="THROTTLE">⏳ Throttle Rate</option>
                          </select>
                        </div>

                      </div>

                    </div>
                  </div>
                );
              })
            )}
          </div>

        </div>

      </div>

    </div>
  );
}
