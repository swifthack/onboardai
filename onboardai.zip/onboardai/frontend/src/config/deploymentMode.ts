import { AppPersona } from '../types';

// Which deployment this running container is — set at container runtime via
// the DEPLOYMENT_MODE env var (see server.ts's /runtime-config.js), not
// baked in at build time, so the same built image serves both. Plain local
// dev (`npm run dev` with no env var set) resolves to null, which keeps the
// original "show everything" behavior.
export type DeploymentMode = 'design' | 'execution' | null;

export function getDeploymentMode(): DeploymentMode {
  const raw =
    typeof window !== 'undefined' ? (window as any).__DEPLOYMENT_MODE__ : '';
  return raw === 'design' || raw === 'execution' ? raw : null;
}

// design = AgenticStudio, the configuration console — only the persona that
// builds/governs agents, pipelines, guardrails, etc. belongs there.
// execution = the running onboarding platform — every other, non-admin
// persona operates there instead. Local dev (mode === null) shows all of
// them, unchanged from before this split existed.
export function getVisiblePersonas<T extends { id: AppPersona }>(personas: T[]): T[] {
  const mode = getDeploymentMode();
  if (mode === 'design') return personas.filter((p) => p.id === 'platform_admin');
  if (mode === 'execution') return personas.filter((p) => p.id !== 'platform_admin');
  return personas;
}
