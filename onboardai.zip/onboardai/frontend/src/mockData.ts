import { ClientProfile, WorkflowNode, UploadedDocument, OrchestrationAgent, AgentOrchestration } from './types';

export const PERSONAS = [
  {
    id: 'platform_admin' as const,
    name: 'Platform Admin',
    role: 'Platform Administrator',
    badgeColor: 'bg-blue-100 text-blue-800 border-blue-200',
    description: 'Build, govern, operate agents, and compose onboarding journeys'
  },
  {
    id: 'rm' as const,
    name: 'Relationship Manager',
    role: 'Relationship Manager',
    badgeColor: 'bg-indigo-100 text-indigo-800 border-indigo-200',
    description: 'Manage customer onboarding journeys'
  },
  {
    id: 'compliance_officer' as const,
    name: 'Compliance & Risk Officer',
    role: 'Compliance & Risk Officer',
    badgeColor: 'bg-rose-100 text-rose-800 border-rose-200',
    description: 'Review escalations and screening results'
  },
  {
    id: 'operations_officer' as const,
    name: 'Operations Officer',
    role: 'Operations & Review Officer',
    badgeColor: 'bg-amber-100 text-amber-800 border-amber-200',
    description: 'Review document verification, task exceptions, registry extraction validations, and operational sign-offs'
  },
  {
    id: 'customer' as const,
    name: 'Customer Self Service',
    role: 'Customer / Self-Service User',
    badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    description: 'Self-service portal to view, verify, upload documents, and link identity providers'
  }
];

export const createInitialWorkflowNodes = (): WorkflowNode[] => [
  {
    id: 'stage_1',
    name: 'STAGE 1: PROSPECT QUALIFICATION',
    agentType: 'data_aggregator',
    team: 'Registry & Lead Intelligence Engine',
    description: 'RM creates new lead. Lead intelligence and entity resolution pipelines enrich entity profile and prepare briefing.',
    status: 'pending',
    dependsOn: [],
    logs: ['[Journey Orchestrator] Prospect qualification and lead intelligence initiated.'],
    assignedAgentId: 'lead_intelligence_agent',
    attachedAgentIds: ['lead_intelligence_agent', 'entity_resolution_agent'],
    pipelines: ['P-01 (Lead Intelligence)', 'P-02 (Entity Resolution)'],
    executionMode: 'sequential'
  },
  {
    id: 'stage_2',
    name: 'STAGE 2: ENTITY RESEARCH',
    agentType: 'data_aggregator',
    team: 'Autonomous Research Engine',
    description: 'Autonomous research queries corporate registries and regulatory databases to map ownership chain and identify directors.',
    status: 'pending',
    dependsOn: ['stage_1'],
    logs: ['[Journey Orchestrator] Awaiting registry aggregation...'],
    assignedAgentId: 'research_agent',
    attachedAgentIds: ['research_agent', 'registry_connector_agent', 'regulatory_database_agent', 'ownership_agent', 'ubo_agent'],
    pipelines: ['P-03 (Autonomous Research)', 'P-04 (Ownership Mapping)'],
    executionMode: 'parallel'
  },
  {
    id: 'stage_3',
    name: 'STAGE 3: INDIVIDUAL VERIFICATION',
    agentType: 'data_aggregator',
    team: 'Director & Identity Registry Engine',
    description: 'Verifies individual directors and UBOs via official government identity registries and cryptographically validates vLEI credentials.',
    status: 'pending',
    dependsOn: ['stage_1'],
    logs: ['[Journey Orchestrator] Awaiting individual registry verification...'],
    assignedAgentId: 'director_verification_agent',
    attachedAgentIds: ['director_verification_agent', 'identity_verification_agent', 'vlei_agent'],
    pipelines: ['P-05 (Director Verification)', 'P-06 (vLEI Verification)'],
    executionMode: 'parallel'
  },
  {
    id: 'stage_4',
    name: 'STAGE 4: DYNAMIC KYC',
    agentType: 'legal_compliance',
    team: 'Dynamic KYC Engine',
    description: 'Dynamic KYC engine computes minimum-necessary question set based on entity type and jurisdiction.',
    status: 'pending',
    dependsOn: ['stage_2', 'stage_3'],
    logs: ['[Journey Orchestrator] Awaiting entity research and individual verification completion...'],
    assignedAgentId: 'kyc_engine_agent',
    attachedAgentIds: ['kyc_engine_agent', 'regulatory_rules_agent'],
    pipelines: ['P-08 (Dynamic KYC Engine)'],
    executionMode: 'sequential'
  },
  {
    id: 'stage_5',
    name: 'STAGE 5: COMPLIANCE DATA COLLECTION',
    agentType: 'legal_compliance',
    team: 'Client Outreach & Compliance Engine',
    description: 'Client outreach dispatched via digital portal. Compiles and validates corporate profile and registry information.',
    status: 'pending',
    dependsOn: ['stage_4'],
    logs: ['[Journey Orchestrator] Awaiting client data collection...'],
    assignedAgentId: 'client_outreach_agent',
    attachedAgentIds: ['client_outreach_agent', 'document_intelligence_agent'],
    pipelines: ['P-09 (Client Outreach)', 'P-07 (Compliance Data Synthesis)'],
    executionMode: 'sequential'
  },
  {
    id: 'stage_6',
    name: 'STAGE 6: SCREENING',
    agentType: 'name_screening',
    team: 'Global Sanctions & PEP Screening',
    description: 'Real-time global sanctions, PEP lists, and adverse media screening.',
    status: 'pending',
    dependsOn: ['stage_4'],
    logs: ['[Journey Orchestrator] Awaiting sanctions and PEP screening...'],
    assignedAgentId: 'sanctions_screening_agent',
    attachedAgentIds: ['sanctions_screening_agent', 'pep_screening_agent', 'adverse_media_agent'],
    pipelines: ['P-10 (Sanctions and PEP)', 'P-11 (Adverse Media)'],
    executionMode: 'parallel'
  },
  {
    id: 'stage_7',
    name: 'STAGE 7: RISK ASSESSMENT',
    agentType: 'client_risk',
    team: 'Multi-Factor Risk Engine',
    description: 'Multi-factor risk matrix calculates overall risk score and assigns risk band.',
    status: 'pending',
    dependsOn: ['stage_5', 'stage_6'],
    logs: ['[Journey Orchestrator] Awaiting document verification and screening completion...'],
    assignedAgentId: 'risk_assessment_agent',
    attachedAgentIds: ['risk_assessment_agent', 'edd_trigger_agent'],
    pipelines: ['P-12 (Risk Assessment)'],
    executionMode: 'sequential'
  },
  {
    id: 'stage_8',
    name: 'STAGE 8: APPROVAL',
    agentType: 'legal_compliance',
    team: 'Approval Gateway',
    description: 'Approval Gateway routes onboarding decision to auto-approval or compliance review.',
    status: 'pending',
    dependsOn: ['stage_7'],
    logs: ['[Journey Orchestrator] Awaiting risk assessment clearance...'],
    assignedAgentId: 'approval_gateway_agent',
    attachedAgentIds: ['approval_gateway_agent'],
    pipelines: ['P-20 (Approval Gateway)'],
    executionMode: 'sequential'
  },
  {
    id: 'stage_9',
    name: 'STAGE 9: PRODUCT PROVISIONING',
    agentType: 'credit_risk',
    team: 'Product Provisioning Engine',
    description: 'Parallel product account setup (CASA, FX/MM, Derivatives, Trade Finance) adhering to dependency order.',
    status: 'pending',
    dependsOn: ['stage_8'],
    logs: ['[Journey Orchestrator] Awaiting approval sign-off...'],
    assignedAgentId: 'casa_provisioning_agent',
    attachedAgentIds: ['signatory_intelligence_agent', 'casa_provisioning_agent', 'fx_mm_provisioning_agent'],
    pipelines: ['P-21 (CASA)', 'P-22 (FX/MM)'],
    executionMode: 'parallel'
  },
  {
    id: 'stage_10',
    name: 'STAGE 10: READY TO TRADE',
    agentType: 'legal_compliance',
    team: 'Ready-to-Trade Validation',
    description: 'Ready-to-Trade validation verifies all product accounts are operational and unlocks client trading.',
    status: 'pending',
    dependsOn: ['stage_9'],
    logs: ['[Journey Orchestrator] Awaiting product provisioning completion...'],
    assignedAgentId: 'rtt_validation_agent',
    attachedAgentIds: ['rtt_validation_agent'],
    pipelines: ['P-26 (RTT Validation)'],
    executionMode: 'sequential'
  },
  {
    id: 'stage_11',
    name: 'ONGOING: PERPETUAL KYC',
    agentType: 'aml',
    team: 'Perpetual KYC Monitor',
    description: 'Continuous post-onboarding monitoring for corporate registry changes and sanctions updates.',
    status: 'pending',
    dependsOn: ['stage_10'],
    logs: ['[Journey Orchestrator] Continuous perpetual KYC monitoring active.'],
    assignedAgentId: 'perpetual_kyc_agent',
    attachedAgentIds: ['perpetual_kyc_agent'],
    pipelines: ['P-27 (Perpetual KYC)'],
    executionMode: 'sequential'
  }
];

export const MOCK_CLIENTS: ClientProfile[] = [
  {
    id: 'client_1',
    companyName: 'Aether Aero-Tech Pte Ltd',
    registrationNumber: '202419822K',
    jurisdiction: 'Singapore',
    industry: 'High-Tech Aerospace Engineering',
    authorizedRepresentative: {
      name: 'Dr. Evelyn Chen',
      role: 'Chief Executive Officer',
      email: 'evelyn.chen@aether-aero.com',
      biometricVerified: true,
      biometricMatchScore: 98.6,
      biometricSelfieUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80'
    },
    shareholders: [
      { name: 'Dr. Evelyn Chen', equity: 45.0, pepStatus: false },
      { name: 'Temasek Holdings (Pvt)', equity: 35.0, pepStatus: false },
      { name: 'AeroVentures Capital Ltd', equity: 20.0, pepStatus: false }
    ],
    financials: {
      revenue: '$14.2M SGD',
      assets: '$8.5M SGD',
      debtRatio: '0.18',
      rating: 'AA-'
    },
    documents: [
      {
        id: 'doc_1',
        name: 'ACRA_BizProfile_Aether.pdf',
        type: 'Business Profile Registry Extract',
        size: '1.2 MB',
        uploadedAt: '2026-07-16 14:22',
        status: 'verified',
        source: 'externally_sourced',
        sourceDetails: 'Singapore ACRA Registry Connector (API Sync)',
        ocrData: {
          'Company Name': 'Aether Aero-Tech Pte Ltd',
          'Registration No': '202419822K',
          'Incorporation Date': '12 Oct 2024',
          'Registered Office': '79 Ayer Rajah Crescent, Singapore 139955',
          'Status': 'Live & Active'
        }
      },
      {
        id: 'doc_2',
        name: 'Certificate_of_Incorporation.pdf',
        type: 'Certificate of Incorporation',
        size: '850 KB',
        uploadedAt: '2026-07-16 14:23',
        status: 'verified',
        source: 'customer_provided',
        sourceDetails: 'Uploaded by Dr. Evelyn Chen via Portal',
        ocrData: {
          'Incorporator': 'Registrar of Companies Singapore',
          'Company Name': 'Aether Aero-Tech Pte Ltd',
          'Registered No': '202419822K'
        }
      },
      {
        id: 'doc_3',
        name: 'Board_Resolution_Representative.pdf',
        type: 'Board Resolution for Account Opening',
        size: '1.5 MB',
        uploadedAt: '2026-07-16 14:25',
        status: 'verified',
        source: 'customer_provided',
        sourceDetails: 'Uploaded by Dr. Evelyn Chen via Portal',
        ocrData: {
          'Appointed Representative': 'Dr. Evelyn Chen',
          'Authorized Action': 'Open Corporate Bank Account & Execute Loans',
          'Board Quorum': 'Met - 3 Directors Signed'
        }
      }
    ],
    journeyId: 'corporate_onboarding_journey',
    journeyName: '🏢 Corporate Entity Onboarding Journey',
    overallStatus: 'approved',
    workflowNodes: createInitialWorkflowNodes().map(node => {
      // Set to fully completed with mock logs/metrics
      let results: any = { summary: '', metrics: {}, findings: [] };
      if (node.id === 'stage_1' || node.agentType === 'data_aggregator') {
        results = {
          summary: 'Successfully aggregated Singapore ACRA business registry data.',
          metrics: { 'Registry Status': 'Live & Active', 'Tax Standing': 'Good', 'Filing Recency': '100% Up to Date' },
          findings: ['Validated Singapore Registration No: 202419822K', 'Active Business License confirmed']
        };
      } else if (node.id === 'stage_5') {
        results = {
          summary: 'Statutory profile and compliance attributes compiled successfully.',
          metrics: { 'Registry Records': 'Complete', 'Digital Attestation': 'Authentic', 'Signatory Authority': 'Confirmed' },
          findings: ['Data matched 100% with registered ACRA company record', 'Signing authority confirmed']
        };
      } else if (node.id === 'stage_3') {
        results = {
          summary: 'Dr. Evelyn Chen identity verified via official government registry lookup.',
          metrics: { 'Identity Match': '100%', 'Registry Validation': 'Passed', 'vLEI Status': 'Verified' },
          findings: ['Representative identity credentials verified', 'Directorship matches official government registry record']
        };
      } else if (node.id === 'stage_6' || node.agentType === 'name_screening') {
        results = {
          summary: 'Global screening completed for company, executive, and venture capital partners.',
          metrics: { 'Sanction Hits': 0, 'PEP Hits': 0, 'Adverse Media Hits': 0 },
          findings: ['Dr. Evelyn Chen screened on PEP databases: Clear', 'No match found on OFAC or EU lists']
        };
      } else if (node.id === 'stage_2' || node.agentType === 'aml') {
        results = {
          summary: 'Ultimate Beneficial Owner chain resolved and vetted successfully.',
          metrics: { 'UBO Count': 2, 'Venture Shell Layers': 1, 'Source of Wealth': 'Vetted Venture Equity' },
          findings: ['Dr. Evelyn Chen identified as 45% owner', 'Venture Capital and Government Backed entities cleared']
        };
      } else if (node.id === 'stage_7' || node.agentType === 'client_risk') {
        results = {
          summary: 'Composite compliance risk calculated as Low.',
          metrics: { 'Risk Classification': 'LOW', 'Geographic Score': '95/100 (Safe)', 'Industry Score': '90/100' },
          findings: ['Zero adverse findings', 'Highly stable Singapore tech jurisdiction']
        };
      } else if (node.id === 'stage_9' || node.agentType === 'credit_risk') {
        results = {
          summary: 'Excellent financial position. Recommended Credit Limit: $1.5M SGD.',
          metrics: { 'Credit Score': 'AA-', 'Debt-to-Equity Ratio': '0.18', 'Current Ratio': '2.4x' },
          findings: ['Audited Singapore statements confirm strong liquid cash assets of $4.2M SGD', 'Very low debt leverage']
        };
      } else if (node.id === 'stage_4' || node.id === 'stage_8' || node.id === 'stage_10' || node.agentType === 'legal_compliance') {
        results = {
          summary: 'All legal and compliance requirements met. Master Account SLA ready.',
          metrics: { 'SLA Drafting': 'Completed', 'Board Resolution Check': 'Valid', 'Legal Sign-off': 'Passed' },
          findings: ['Authorized signing authority confirmed for Evelyn Chen', 'Master account opening contract executed']
        };
      }

      return {
        ...node,
        status: 'completed' as const,
        lastUpdated: '2026-07-16 15:45',
        logs: [
          'Initial check started.',
          'Database query returned success.',
          'Vetted matching items.',
          `Completed execution by designated AI module/agent team.`
        ],
        results
      };
    }),
    directors: [
      { name: 'Dr. Evelyn Chen', role: 'Managing Director & CEO', appointmentDate: '2024-10-12', nationality: 'Singapore' },
      { name: 'Marcus Sterling Vance', role: 'Non-Executive Director (AeroVentures)', appointmentDate: '2024-11-01', nationality: 'United States' },
      { name: 'Lau Jun Jie', role: 'Independent Director (ACRA Legal Rep)', appointmentDate: '2025-01-15', nationality: 'Singapore' }
    ],
    relatedParties: [
      { name: 'AeroVentures Capital Ltd', relationType: 'Parent Entity (Investment)', status: 'Active', riskLevel: 'Low' },
      { name: 'Aether Aero-Tech UK Ltd', relationType: 'Subsidiary (100% Owned)', status: 'Active', riskLevel: 'Low' },
      { name: 'Temasek Holdings (Pvt)', relationType: 'Anchor Sovereign Investor', status: 'Active', riskLevel: 'Low' }
    ]
  },
  {
    id: 'client_2',
    companyName: 'Vortex Global Trade Ltd',
    registrationNumber: 'KY-982414',
    jurisdiction: 'Cayman Islands',
    industry: 'Commodities Trading & Logistics',
    authorizedRepresentative: {
      name: 'Maximilian Sterling',
      role: 'Managing Director',
      email: 'm.sterling@vortex-global.com',
      biometricVerified: false,
      biometricMatchScore: 0,
      biometricSelfieUrl: ''
    },
    shareholders: [
      { name: 'Maximilian Sterling', equity: 40.0, pepStatus: true }, // PEP ALERT!
      { name: 'Horizon Trust LLC (Nevada)', equity: 35.0, pepStatus: false },
      { name: 'Equator Marine Assets (Seychelles)', equity: 25.0, pepStatus: false } // Offshore jurisdiction alert!
    ],
    financials: {
      revenue: '$28.4M USD',
      assets: '$11.2M USD',
      debtRatio: '0.62',
      rating: 'BB'
    },
    documents: [
      {
        id: 'doc_4',
        name: 'Cayman_Certificate_Of_Good_Standing.pdf',
        type: 'Certificate of Incorporation',
        size: '1.4 MB',
        uploadedAt: '2026-07-16 14:31',
        status: 'verified',
        source: 'externally_sourced',
        sourceDetails: 'Cayman Islands CIMA / Registry Gateway',
        ocrData: {
          'Company Name': 'Vortex Global Trade Ltd',
          'Registered No': 'KY-982414',
          'Jurisdiction': 'Cayman Islands',
          'Status': 'Active'
        }
      },
      {
        id: 'doc_5',
        name: 'Shareholder_Register_Vortex.pdf',
        type: 'Shareholder Register & Allocation',
        size: '1.1 MB',
        uploadedAt: '2026-07-16 14:32',
        status: 'verified',
        source: 'customer_provided',
        sourceDetails: 'Uploaded by Maximilian Sterling via Portal',
        ocrData: {
          'Major Shareholder 1': 'Maximilian Sterling - 40%',
          'Major Shareholder 2': 'Horizon Trust LLC - 35%',
          'Major Shareholder 3': 'Equator Marine Assets - 25%'
        }
      }
    ],
    journeyId: 'corporate_onboarding_journey',
    journeyName: '🏢 Corporate Entity Onboarding Journey',
    overallStatus: 'in_progress',
    workflowNodes: createInitialWorkflowNodes().map(node => {
      // Partially complete / flagged workflowNodes
      if (['stage_1', 'stage_2', 'stage_3', 'stage_4', 'stage_5'].includes(node.id) || node.agentType === 'data_aggregator') {
        return {
          ...node,
          status: 'completed',
          lastUpdated: '2026-07-16 15:10',
          logs: [
            `Triggering stage processing for ${node.name}...`,
            'Successfully completed automated checks.'
          ],
          results: {
            summary: `${node.name} completed successfully.`,
            metrics: { 'Status': 'Verified' },
            findings: ['Check passed against official sources']
          }
        };
      }

      if (node.id === 'stage_6' || node.agentType === 'name_screening') {
        return {
          ...node,
          status: 'flagged',
          lastUpdated: '2026-07-17 10:18',
          logs: [
            'Executing screening against global database...',
            'CRITICAL MATCH: Shareholder Maximilian Sterling identified as a Politically Exposed Person (PEP).',
            'Reason: Relatives of former high-ranking diplomat in Western Europe.',
            'CRITICAL MATCH: Seychelle shareholder entity flagged as high AML risk tax haven.'
          ],
          results: {
            summary: 'PEP Match and Jurisdiction Alerts detected.',
            metrics: { 'PEP Matches': '1 (Maximilian Sterling)', 'Sanctions Match': 0, 'Adverse Media': 'Moderate (Related to offshore entity audit)' },
            findings: [
              'Maximilian Sterling is a PEP (Secondary degree connection). Enhanced Due Diligence (EDD) REQUIRED.',
              'Equator Marine Assets Ltd is incorporated in Seychelles (FATF Gray Listed jurisdiction).'
            ]
          }
        };
      }

      return node;
    }),
    directors: [
      { name: 'Maximilian Sterling', role: 'Managing Director & CEO', appointmentDate: '2021-04-10', nationality: 'United Kingdom' },
      { name: 'Sir Charles Sinclair', role: 'Chairman & Director', appointmentDate: '2021-04-10', nationality: 'United Kingdom' },
      { name: 'Alistair Thorne', role: 'Resident Cayman Director', appointmentDate: '2023-09-18', nationality: 'Cayman Islands' }
    ],
    relatedParties: [
      { name: 'Horizon Trust LLC (Nevada)', relationType: 'Parent Holding Company', status: 'Active', riskLevel: 'Medium' },
      { name: 'Equator Marine Assets (Seychelles)', relationType: 'Vested Shareholder Subsidiary', status: 'Active', riskLevel: 'High' },
      { name: 'Vortex Commodities Asia Pte Ltd', relationType: 'Regional Branch (Singapore)', status: 'Active', riskLevel: 'Low' }
    ]
  }
];

export { INITIAL_AGENTS, INITIAL_ORCHESTRATIONS } from './agents';

