import { useEffect, useRef, useCallback } from 'react';

/**
 * Generic debounced reconciler that keeps a live in-memory array (e.g.
 * App.tsx's `agents`/`orchestrations` state) synced to a backend resource,
 * without requiring every mutation call site (AgentManager.tsx,
 * AgentOrchestrator.tsx — dozens of fine-grained inline field editors) to
 * know about the network at all. Those components just keep calling
 * setAgents/setOrchestrations exactly as before; this hook watches the
 * resulting array and pushes create/update/delete calls to the backend
 * after `delayMs` of no further local changes.
 *
 * Call `markSynced` once per item right after an initial fetch-and-merge
 * so the first sync tick doesn't try to re-create things that already
 * exist on the backend unchanged.
 */
export interface BackendSyncAdapter<T> {
  getId: (item: T) => string;
  /** Stable string representing this item's backend-relevant fields —
   * used only to detect "did this change", never sent as-is. */
  snapshot: (item: T) => string;
  create: (item: T) => Promise<unknown>;
  update: (id: string, item: T) => Promise<unknown>;
  remove: (id: string) => Promise<unknown>;
}

export function useBackendSync<T>(
  items: T[],
  ready: boolean,
  adapter: BackendSyncAdapter<T>,
  delayMs = 1000,
) {
  const syncedRef = useRef<Map<string, string>>(new Map());
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const adapterRef = useRef(adapter);
  adapterRef.current = adapter;

  const markSynced = useCallback((item: T) => {
    syncedRef.current.set(adapterRef.current.getId(item), adapterRef.current.snapshot(item));
  }, []);

  useEffect(() => {
    if (!ready) return undefined;
    if (timerRef.current) clearTimeout(timerRef.current);

    timerRef.current = setTimeout(async () => {
      const a = adapterRef.current;
      const currentIds = new Set(items.map(a.getId));

      for (const id of Array.from(syncedRef.current.keys())) {
        if (currentIds.has(id)) continue;
        try {
          await a.remove(id);
        } catch (e) {
          console.warn('[useBackendSync] delete failed', id, e);
        }
        syncedRef.current.delete(id);
      }

      for (const item of items) {
        const id = a.getId(item);
        const snap = a.snapshot(item);
        if (syncedRef.current.get(id) === snap) continue;

        try {
          if (syncedRef.current.has(id)) {
            await a.update(id, item);
          } else {
            await a.create(item);
          }
          syncedRef.current.set(id, snap);
        } catch (e) {
          console.warn('[useBackendSync] upsert failed', id, e);
        }
      }
      // eslint-disable-next-line @typescript-eslint/no-unused-expressions
    }, delayMs);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [items, ready, delayMs]);

  return { markSynced };
}
